from __future__ import annotations

from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any, Final, Literal

from exmekh_lib.capabilities.tools.call_sub_agent.sub_agent_tool import SubAgentTool
from exmekh_lib.capabilities.tools.read_tool_output.summary import SummaryMode
from exmekh_lib.config.runtime import RUNTIME
from exmekh_lib.config.runtime_text import RUNTIME_TEXT
from exmekh_lib.core.agents.capabilities.capabilities import Capabilities
from exmekh_lib.core.agents.capabilities.data import CapabilitiesData
from exmekh_lib.core.agents.capabilities.defaults import DefaultCapabilities
from exmekh_lib.core.agents.capabilities.tool_composer import _DefaultToolComposer
from exmekh_lib.core.agents.deep_agent.agent_response import AgentResponse
from exmekh_lib.core.agents.hds.hds import HDS
from exmekh_lib.core.cache.node_cache import NodeCache
from exmekh_lib.core.models.tool import PreformattedToolResult, Tool
from exmekh_lib.core.tool_calls.execution_history import ExecutionHistory
from exmekh_lib.interfaces.event_handler import DeepAgentEventHandler
from exmekh_lib.interfaces.message import Message
from exmekh_lib.interfaces.provider import Provider

from .node_runtime import NodeRuntime, NodeRuntimeConfig
from .types import NodeUserMessage


class Node:
    """Configure one node in a deep-agent hierarchy."""

    REQUIRED_TOOL_CHOICE: Final[str] = NodeRuntime.REQUIRED_TOOL_CHOICE
    EMPTY_RESPONSE_MESSAGE: Final[str] = NodeRuntime.EMPTY_RESPONSE_MESSAGE

    def __init__(
        self,
        capabilities_paths: Sequence[Path] | None = None,
        name_hds: str = "",
        children: Sequence[Node] = (),
        persistent_history: bool = True,
        depth: int = 0,
        agent_context_id: str | None = None,
        *,
        default_capabilities: DefaultCapabilities | None = None,
    ) -> None:
        if capabilities_paths is None or (
            isinstance(capabilities_paths, Sequence)
            and not isinstance(capabilities_paths, (str, bytes))
            and not capabilities_paths
        ):
            capabilities_paths = None
        self._capability_loader = Capabilities(
            capabilities_paths, default_capabilities=default_capabilities
        )
        self._default_capabilities = default_capabilities
        self._resolved_default_capabilities = default_capabilities
        self._name_hds = self._validate_hds_name(name_hds)
        self._children = self._validate_children(children)
        self._persistent_history = self._validate_persistent_history(persistent_history)
        self._initial_depth = self._validate_depth(depth)
        self._agent_context_id = self._validate_agent_context_id(agent_context_id)
        self._runtime: NodeRuntime | None = None
        self._hds: HDS | None = None
        self._sub_agent_tool: SubAgentTool | None = None

    @property
    def name_hds(self) -> str:
        return self._name_hds

    @property
    def children(self) -> tuple[Node, ...]:
        return self._children

    @property
    def persistent_history(self) -> bool:
        return self._persistent_history

    @property
    def depth(self) -> int:
        if self._runtime is None:
            return self._initial_depth
        return self._runtime.depth

    @property
    def agent_context_id(self) -> str | None:
        if self._agent_context_id is not None:
            return self._agent_context_id
        if self._runtime is not None:
            return self._runtime.agent_context_id
        return None

    def initialize(
        self,
        provider: Provider,
        *,
        work_root: Path,
        on_stream: DeepAgentEventHandler | None = None,
    ) -> CapabilitiesData:
        if not isinstance(provider, Provider):
            raise TypeError(RUNTIME_TEXT.provider_must_be_a_provider)
        if on_stream is not None:
            DeepAgentEventHandler.validate_instance(on_stream)

        self._resolved_default_capabilities = self._default_capabilities
        capabilities = self.load_capabilities(work_root=work_root)
        defaults = self._resolved_default_capabilities
        hds = capabilities.get_hds(self._name_hds)
        exit_tool_name = hds.get_exit_tool_name()
        exit_tool = capabilities.get_exit_tool(exit_tool_name)
        runtime_tools = self._build_runtime_tools(defaults, work_root)
        context_id = self._agent_context_id or hds.get_agent_context_id()
        self._runtime = NodeRuntime(
            NodeRuntimeConfig(
                provider=provider,
                capabilities=capabilities,
                hds=hds,
                exit_tool=exit_tool,
                persistent_history=self._persistent_history,
                initial_depth=self._initial_depth,
                work_root=work_root,
                agent_context_id=context_id,
                runtime_tools=runtime_tools,
                default_capabilities=defaults,
                on_stream=on_stream,
            )
        )
        self._hds = hds
        return capabilities

    def _build_runtime_tools(
        self, defaults: DefaultCapabilities | None, work_root: Path
    ) -> tuple[Tool, ...]:
        self._sub_agent_tool = None
        if not self._children:
            if defaults is not None and defaults.customizes_tool(
                RUNTIME.sub_agent_tool_name
            ):
                raise ValueError(
                    RUNTIME_TEXT.call_sub_agent_requires_at_least_one_child_node
                )
            return ()
        if defaults is not None and not defaults.includes(RUNTIME.sub_agent_tool_name):
            return ()
        tool = _DefaultToolComposer(defaults).compose_runtime_tool(
            SubAgentTool(self._children, work_root)
        )
        if isinstance(tool, SubAgentTool):
            self._sub_agent_tool = tool
        return (tool,) if tool is not None else ()

    def get_hds(self) -> HDS:
        if self._hds is None:
            raise RuntimeError(
                RUNTIME_TEXT.node_must_be_initialized_before_accessing_its_hds
            )
        return self._hds

    def update_sub_agent_tool_description(self) -> None:
        if self._runtime is None:
            raise RuntimeError(
                RUNTIME_TEXT.node_must_be_initialized_before_updating_sub_agents
            )
        if self._sub_agent_tool is not None:
            child_hds = (child.get_hds() for child in self._children)
            self._sub_agent_tool.set_child_descriptions(
                {hds.get_name(): hds.get_description() for hds in child_hds}
            )

    def load_capabilities(self, *, work_root: Path) -> CapabilitiesData:
        capabilities, defaults = self._capability_loader.load_with_defaults(
            work_root=work_root
        )
        capabilities.get_hds(self._name_hds)
        self._resolved_default_capabilities = defaults
        return capabilities

    def run(self, user_message: NodeUserMessage) -> AgentResponse:
        if self._runtime is None:
            raise RuntimeError(RUNTIME_TEXT.node_must_be_initialized_before_run)
        return self._runtime.run(user_message)

    def get_tools_text(self) -> str:
        """Return this node's serialized tools request field without inference."""
        if self._runtime is None:
            raise RuntimeError(
                RUNTIME_TEXT.node_must_be_initialized_before_accessing_tools
            )
        return self._runtime.get_tools_text()

    def steer(self, user_message: NodeUserMessage) -> None:
        """Queue guidance and release managed tool waits in this node's active run."""
        if self._runtime is None:
            raise RuntimeError(RUNTIME.inactive_steering_message)
        self._runtime.steer(user_message)

    def control_tool_execution(
        self,
        tool_call_id: str,
        action: Literal["wait", "cancel"] = "wait",
        wait_seconds: float = RUNTIME.default_tool_wait_seconds,
    ) -> dict[str, Any]:
        """Control node-local work without changing the conversation history."""
        if self._runtime is None:
            raise RuntimeError(
                RUNTIME_TEXT.node_must_be_initialized_before_controlling_tool_work
            )
        return self._runtime.control_tool_execution(tool_call_id, action, wait_seconds)

    def read_tool_output(
        self,
        output_id: str,
        cursor: int | None = None,
        summary_mode: SummaryMode = "none",
    ) -> PreformattedToolResult:
        """Read node-local output; a final read acknowledges automatic delivery."""
        if self._runtime is None:
            raise RuntimeError(
                RUNTIME_TEXT.node_must_be_initialized_before_reading_tool_output
            )
        return self._runtime.read_tool_output(output_id, cursor, summary_mode)

    def restore_history(
        self,
        messages: Sequence[Message[Any]],
        restore_execution_state: Callable[[ExecutionHistory, NodeCache], None]
        | None = None,
    ) -> None:
        """Restore a saved conversation before the next run."""
        if self._runtime is None:
            raise RuntimeError(
                RUNTIME_TEXT.node_must_be_initialized_before_restoring_history
            )
        self._runtime.restore_history(messages, restore_execution_state)

    @staticmethod
    def _validate_hds_name(name_hds: str) -> str:
        if not isinstance(name_hds, str):
            raise TypeError(RUNTIME_TEXT.name_hds_must_be_a_string)
        if not name_hds.strip():
            raise ValueError(RUNTIME_TEXT.name_hds_cannot_be_empty)
        return name_hds

    @staticmethod
    def _validate_children(children: Sequence[Node]) -> tuple[Node, ...]:
        if isinstance(children, (str, bytes)) or not isinstance(children, Sequence):
            raise TypeError(RUNTIME_TEXT.children_must_be_a_sequence_of_node)
        nodes = tuple(children)
        if not all(isinstance(child, Node) for child in nodes):
            raise TypeError(RUNTIME_TEXT.children_must_contain_only_node_instances)
        return nodes

    @staticmethod
    def _validate_persistent_history(persistent_history: bool) -> bool:
        if not isinstance(persistent_history, bool):
            raise TypeError(RUNTIME_TEXT.persistent_history_must_be_a_bool)
        return persistent_history

    @staticmethod
    def _validate_depth(depth: int) -> int:
        if not isinstance(depth, int) or isinstance(depth, bool):
            raise TypeError(RUNTIME_TEXT.depth_must_be_an_integer)
        if depth < 0:
            raise ValueError(RUNTIME_TEXT.depth_cannot_be_negative)
        return depth

    @staticmethod
    def _validate_agent_context_id(agent_context_id: str | None) -> str | None:
        if agent_context_id is None:
            return None
        if not isinstance(agent_context_id, str):
            raise TypeError(RUNTIME_TEXT.agent_context_id_must_be_a_string)
        if not agent_context_id.strip():
            raise ValueError(RUNTIME_TEXT.agent_context_id_cannot_be_empty)
        return agent_context_id
