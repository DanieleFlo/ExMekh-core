from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace
from uuid import uuid4

from exmekh_lib.config.runtime import RUNTIME
from exmekh_lib.config.runtime_text import RUNTIME_TEXT
from exmekh_lib.core.cache.node_cache import NodeCache
from exmekh_lib.core.cache.tool_call_record import CalledToolMetadata, ToolCallRecord
from exmekh_lib.core.cache.user_message_codec import serialize_user_message
from exmekh_lib.core.models.user_message import UserMessage
from exmekh_lib.core.tool_calls.execution_history import ExecutionHistory
from exmekh_lib.core.tool_calls.execution_manager import ToolExecutionManager
from exmekh_lib.core.tool_calls.output_preparer import ToolOutputPreparer
from exmekh_lib.core.tool_calls.output_runtime import ToolOutputRuntime
from exmekh_lib.utils.json import to_json_value

from .types import CacheIdentity, ToolExecutionResult


class ToolResultRecorder:
    """Keep invocation history and cached outputs synchronized with tool work."""

    def __init__(
        self,
        history: ExecutionHistory,
        cache_provider: Callable[[], NodeCache],
        execution_manager: ToolExecutionManager,
        output_preparer: ToolOutputPreparer | None = None,
    ) -> None:
        self._history = history
        self._cache_provider = cache_provider
        self._execution_manager = execution_manager
        self._output_runtime = ToolOutputRuntime(execution_manager, output_preparer)

    def record_call(
        self, call: CalledToolMetadata, thinking: str | None
    ) -> CacheIdentity:
        entry = self._history.record(call.name, call.call_id)
        return CacheIdentity(
            name=call.name,
            source="Tool",
            tool_call_id=call.call_id,
            args=to_json_value(call.arguments),
            history_position=entry.position,
            thinking=thinking,
        )

    def persist_result(
        self,
        result: ToolExecutionResult,
        identity: CacheIdentity,
        skill_path: str,
    ) -> None:
        if result.execution is not None and result.output_id is None:
            raise RuntimeError(
                RUNTIME_TEXT.managed_tool_execution_is_missing_its_output_id
            )
        record = None
        if result.save_result:
            identity = result.cache_identity or identity
            if result.executed_arguments is not None:
                identity = replace(identity, args=result.executed_arguments)
            attachments = result.response.get_attachments()
            record = ToolCallRecord(
                name=identity.name,
                id=result.output_id or uuid4().hex,
                tool_call_id=identity.tool_call_id,
                args=identity.args,
                result=result.raw_result,
                skill_path=skill_path,
                thinking=identity.thinking,
                source=identity.source,
                used_tools=result.used_tools,
                user_message=(
                    serialize_user_message(attachments)
                    if attachments is not None
                    else None
                ),
                execution=result.execution_metadata(),
                external_output=result.external_output,
            )
            cache = self._cache_provider()
            cache.store(record)
            self._history.attach_output_at_position(
                identity.history_position, record.id, cache.session_dir
            )
        if result.execution is not None:
            assert result.output_id is not None
            self._execution_manager.attach_output(
                result.execution.call_id, result.output_id, record
            )

    def persist_steering(
        self,
        message: UserMessage,
        output_id: str,
        skill_path: str,
        *,
        name: str = RUNTIME.steering_output_name,
    ) -> None:
        record = ToolCallRecord(
            name=name,
            id=output_id,
            args={},
            result=message.message_dump()["content"],
            skill_path=skill_path,
            source="UserMessage",
            user_message=serialize_user_message(message),
        )
        cache = self._cache_provider()
        cache.store(record)
        entry = self._history.record(record.name, output_id)
        entry.attach_output(record.id, cache.session_dir)

    def sync_completed(self) -> None:
        for snapshot, record in self._execution_manager.completed_to_persist():
            published = self._output_runtime.publish_final(snapshot)
            assert published.execution is not None
            snapshot = published.execution
            attachments = published.result.attachments
            updated = replace(
                record,
                args=snapshot.output_arguments(),
                result=snapshot.record_result(),
                external_output=snapshot.external_output,
                execution={
                    **snapshot.status_info(),
                    "response_type": snapshot.response_type,
                },
                user_message=(
                    serialize_user_message(attachments)
                    if attachments is not None
                    else None
                ),
            )
            if published.failure is not None:
                updated = updated.with_delivery_failure(published.failure)
            self._cache_provider().store(updated)
            self._execution_manager.mark_persisted_output(snapshot)
