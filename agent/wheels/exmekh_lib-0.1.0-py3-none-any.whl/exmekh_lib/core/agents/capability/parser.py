from __future__ import annotations

import re
from typing import Any, Final, Protocol

import yaml

from exmekh_lib.config.agent_text import AGENT_TEXT
from exmekh_lib.config.validation import VALIDATION_PATTERNS
from exmekh_lib.core.agents.capability.conditions import has_conditions
from exmekh_lib.core.agents.capability.markdown import CapabilityMarkdown
from exmekh_lib.core.agents.capability.metadata import (
    CapabilityMetadata,
)
from exmekh_lib.core.agents.capability.references import parse_references


class MetadataParser[MetadataType: CapabilityMetadata](Protocol):
    def parse(self, data: dict[str, Any]) -> MetadataType: ...


class CapabilityMarkdownParser[
    MetadataType: CapabilityMetadata,
    MarkdownType: CapabilityMarkdown[Any],
]:
    FRONT_MATTER_PATTERN: Final[re.Pattern[str]] = re.compile(
        VALIDATION_PATTERNS.capability_front_matter, re.DOTALL
    )

    def __init__(
        self,
        metadata_parser: MetadataParser[MetadataType],
        markdown_type: type[MarkdownType],
    ) -> None:
        self._metadata_parser = metadata_parser
        self._markdown_type = markdown_type

    def parse(self, markdown: str) -> MarkdownType:
        if not isinstance(markdown, str):
            raise TypeError(AGENT_TEXT.markdown_must_be_a_string)

        head, body = self._split_markdown(markdown)
        metadata = self._parse_metadata(head)
        parsed_body, references = self._parse_body(body)

        return self._markdown_type(
            metadata=metadata,
            body=parsed_body,
            references=references,
        )

    def _split_markdown(self, markdown: str) -> tuple[str, str]:
        match = self.FRONT_MATTER_PATTERN.match(markdown)

        if match is None:
            raise ValueError(
                AGENT_TEXT.markdown_must_contain_a_valid_yaml_front_matter_section
            )

        return match.group("head"), match.group("body")

    def _parse_metadata(self, head: str) -> MetadataType:
        return self._metadata_parser.parse(self._load_yaml(head))

    @staticmethod
    def _load_yaml(head: str) -> dict[str, Any]:
        try:
            data = yaml.safe_load(head)
        except yaml.YAMLError as error:
            raise ValueError(
                AGENT_TEXT.invalid_yaml_metadata.format(error=error)
            ) from error

        if data is None:
            raise ValueError(AGENT_TEXT.metadata_section_cannot_be_empty)

        if not isinstance(data, dict):
            raise TypeError(AGENT_TEXT.metadata_section_must_be_a_yaml_mapping)

        return data

    def _parse_body(self, body: str) -> tuple[str, tuple[str, ...]]:
        if has_conditions(body):
            return body, ()
        return parse_references(body)
