"""Expose output reads to the model."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from exmekh_lib.capabilities.tools.read_tool_output.summary import SummaryMode
from exmekh_lib.config.runtime import RUNTIME
from exmekh_lib.core.agents.tools.decorator import deep_tool
from exmekh_lib.core.models.tool import PreformattedToolResult


@deep_tool(
    name=RUNTIME.read_tool_name,
    description=(
        "Read the current status and available output of a tool by "
        "output ID. Use an optional cursor to read only new output; "
        "omit it to read the complete output. Includes the final "
        "result when available. Also reads saved user steering and restores its attachments. "
        "summary_mode defaults to 'none'; 'brief' gives 3 to 5 bullet points, "
        f"'detailed' preserves essential details. Outputs below {RUNTIME.tool_output_summary_min_tokens} tokens stay complete."
    ),
    background_enabled=False,
)
def run(
    work_root: Path,
    read_output: Callable[[str, int | None, SummaryMode], PreformattedToolResult],
    output_id: str,
    cursor: int | None = None,
    summary_mode: SummaryMode = "none",
) -> PreformattedToolResult:
    del work_root
    return read_output(output_id, cursor, summary_mode)
