"""Read one public page with browser rendering and structured extraction."""

from pathlib import Path
from typing import Literal

from exmekh_lib.config.web import WEB_NAVIGATION
from exmekh_lib.core.agents.tools.decorator import deep_tool
from exmekh_lib.core.web_navigation.errors import WebNavigationError
from exmekh_lib.core.web_navigation.tool_output import navigation_error
from exmekh_lib.utils.tool_errors import missing_dependency


@deep_tool(
    name="read-web-page",
    description=(WEB_NAVIGATION.read_web_page_description),
)
def run(
    work_root: Path,
    url: str,
    output_mode: Literal["markdown", "ast", "hybrid"] = "markdown",
    timeout_seconds: int = WEB_NAVIGATION.default_timeout_seconds,
) -> dict[str, object]:
    try:
        from exmekh_lib.core.web_navigation.crawler import crawl_page

        return crawl_page(
            url=url,
            output_mode=output_mode,
            timeout_seconds=timeout_seconds,
            workroot=work_root,
        )
    except ModuleNotFoundError as error:
        return missing_dependency(error)
    except WebNavigationError as error:
        return navigation_error(error)
