from __future__ import annotations

import inspect
import json
from typing import Any

from qs.core.models.tool import Tool
from qs.core.models.tools import Tools
from qs.core.providers.openai_chat_completion_value_coercer import (
    OpenAIChatCompletionValueCoercer,
)
from qs.core.providers.openai_function_tool_call import OpenAIFunctionToolCall


class OpenAIFunctionToolCallResolver:
    def __init__(self, coercer: OpenAIChatCompletionValueCoercer) -> None:
        self._coercer = coercer

    def find_tool(self, call: OpenAIFunctionToolCall, tools: Tools) -> Tool:
        return self._registered_tool(call.get_name(), tools)

    def resolve(
        self,
        call: OpenAIFunctionToolCall,
        tools: Tools,
    ) -> tuple[Tool, dict[str, Any]]:
        tool = self._registered_tool(call.get_name(), tools)
        arguments = tool.normalize_call_arguments(self._parse_arguments(call))
        bound_arguments = self._bind_arguments(tool, arguments)
        return tool, self._coerce_arguments(tool, bound_arguments)

    @staticmethod
    def _registered_tool(name: str, tools: Tools) -> Tool:
        tool = tools.get_tool(name)
        if tool is None:
            raise LookupError(f"Tool '{name}' is not registered")
        return tool

    @staticmethod
    def _parse_arguments(call: OpenAIFunctionToolCall) -> dict[str, Any]:
        try:
            arguments = json.loads(call.get_arguments())
        except json.JSONDecodeError as error:
            raise ValueError(
                f"Tool '{call.get_name()}' arguments are not valid JSON"
            ) from error

        if not isinstance(arguments, dict):
            raise TypeError(f"Tool '{call.get_name()}' arguments must be a JSON object")
        return arguments

    @staticmethod
    def _bind_arguments(
        tool: Tool,
        arguments: dict[str, Any],
    ) -> inspect.BoundArguments:
        signature = tool.get_signature()
        try:
            return signature.bind(**arguments)
        except TypeError as error:
            raise ValueError(
                f"Invalid arguments for tool '{tool.get_name()}': {error}"
            ) from error

    def _coerce_arguments(
        self,
        tool: Tool,
        bound: inspect.BoundArguments,
    ) -> dict[str, Any]:
        signature = tool.get_signature()
        hints = tool.get_type_hints()

        return {
            name: self._coercer.coerce(
                value,
                hints.get(name, signature.parameters[name].annotation),
                path=name,
            )
            for name, value in bound.arguments.items()
        }
