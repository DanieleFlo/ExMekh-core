from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field, fields, replace
from importlib.resources import files
from pathlib import Path
from typing import Any, Mapping, Sequence


class _Unset:
    """Represent an inherited configuration value in override dataclasses."""

    def __repr__(self) -> str:
        """Return a readable sentinel representation."""
        return "UNSET"


UNSET = _Unset()


@dataclass(frozen=True, slots=True)
class ModelRequestConfig:
    """Configure provider-agnostic model request parameters."""

    temperature: float = 0.0
    top_p: float | None = None
    max_output_tokens: int | None = None
    stop: str | list[str] | tuple[str, ...] | None = None
    seed: int | None = None
    user: str | None = None
    thinking: bool = True


@dataclass(frozen=True, slots=True)
class RetryRecoveryToolConfig:
    """Configure the no-argument tool used to recover retryable model failures."""

    tool_name: str


@dataclass(frozen=True, slots=True)
class RetryConfig:
    """Configure retry behavior around transient model request failures."""

    max_retries: int = 3
    multiplier: float = 1.0
    min_seconds: float = 1.0
    max_seconds: float = 4.0
    recovery_tool: RetryRecoveryToolConfig | None = None


@dataclass(frozen=True, slots=True)
class LoopConfig:
    """Configure the deep agent model loop."""

    max_steps: int = 10000


@dataclass(frozen=True, slots=True)
class CheckpointConfig:
    """Configure automatic checkpoint persistence."""

    directory: Path | str = ".agent-wiki/checkpoint"
    enabled: bool = True
    message_threshold: int | None = None
    on_tool_or_skill_before_execution: bool = True
    on_skill_close: bool = True


@dataclass(frozen=True, slots=True)
class ToolOutputConfig:
    """Configure reusable tool-output memory and model awareness."""

    memory_dir: Path | str = ".agent-wiki/tmp/tool-output-memory"
    description_token_limit: int = 10
    content_token_limit: int = 20
    metadata_preview_char_limit: int = 20
    reference_similarity_mode: str = "characters"
    awareness_default_page_size: int = 20
    awareness_max_page_size: int = 20

    def __post_init__(self) -> None:
        """Validate reusable-output matching configuration."""
        if self.reference_similarity_mode not in {"characters", "tokens"}:
            raise ValueError(
                "Tool-output reference similarity mode must be 'characters' or 'tokens'."
            )


@dataclass(frozen=True, slots=True)
class DiagnosticLogConfig:
    """Configure optional runtime diagnostic log persistence."""

    enabled: bool = False
    directory: Path | str = ".agent-wiki/diagnostic-logs"
    level: str = "DEBUG"
    file_name: str = "runtime.log"


@dataclass(frozen=True, slots=True)
class FileInspectionConfig:
    """Configure bounded workspace-file inspection and its persistent cache."""

    cache_directory: Path | str = ".agent-wiki/tmp/file-inspection-cache"
    model_cache_directory: Path | str = ".agent-wiki/tmp/model-cache"
    preanalysis_max_bytes: int = 10 * 1024 * 1024
    expanded_max_bytes: int = 50 * 1024 * 1024
    pdf_max_pages: int = 3
    pdf_native_text_min_chars: int = 32
    image_max_frames: int = 3
    ocr_language: str = "eng"
    ocr_model: str = "ibm-granite/granite-docling-258M"
    ocr_max_new_tokens: int = 4096
    ocr_device: str = "auto"
    cache_max_bytes: int = 128 * 1024 * 1024
    cache_entry_max_bytes: int = 16 * 1024 * 1024
    max_symbols: int = 2000
    max_columns: int = 512
    max_sheets: int = 256
    max_archive_entry_names: int = 500
    max_list_items: int = 50

    def __post_init__(self) -> None:
        """Reject non-positive inspection and cache limits."""
        for item in fields(self):
            if item.name in {
                "cache_directory",
                "model_cache_directory",
                "ocr_language",
                "ocr_model",
                "ocr_device",
            }:
                continue
            value = getattr(self, item.name)
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                raise ValueError(f"File inspection setting '{item.name}' must be positive.")
        for name in ("ocr_language", "ocr_model", "ocr_device"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(
                    f"File inspection setting '{name}' must contain text."
                )


@dataclass(frozen=True, slots=True)
class AgentRuntimeConfig:
    """Group all runtime settings inherited by HDS nodes."""

    model: ModelRequestConfig = field(default_factory=ModelRequestConfig)
    retry: RetryConfig = field(default_factory=RetryConfig)
    loop: LoopConfig = field(default_factory=LoopConfig)
    checkpoint: CheckpointConfig = field(default_factory=CheckpointConfig)
    tool_output: ToolOutputConfig = field(default_factory=ToolOutputConfig)
    diagnostic_logs: DiagnosticLogConfig = field(default_factory=DiagnosticLogConfig)
    file_inspection: FileInspectionConfig = field(default_factory=FileInspectionConfig)

    @property
    def temperature(self) -> float:
        """Return the legacy flat model temperature value."""
        return self.model.temperature

    @property
    def top_p(self) -> float | None:
        """Return the legacy flat top-p value."""
        return self.model.top_p

    @property
    def max_output_tokens(self) -> int | None:
        """Return the legacy flat output-token cap value."""
        return self.model.max_output_tokens

    @property
    def stop(self) -> str | list[str] | tuple[str, ...] | None:
        """Return the legacy flat stop sequence value."""
        return self.model.stop

    @property
    def seed(self) -> int | None:
        """Return the legacy flat seed value."""
        return self.model.seed

    @property
    def user(self) -> str | None:
        """Return the legacy flat provider user value."""
        return self.model.user

    @property
    def thinking(self) -> bool:
        """Return the legacy flat thinking request flag."""
        return self.model.thinking

    @property
    def max_retries(self) -> int:
        """Return the legacy flat maximum retry count."""
        return self.retry.max_retries

    @property
    def retry_multiplier(self) -> float:
        """Return the legacy flat retry multiplier."""
        return self.retry.multiplier

    @property
    def retry_min_seconds(self) -> float:
        """Return the legacy flat retry minimum delay."""
        return self.retry.min_seconds

    @property
    def retry_max_seconds(self) -> float:
        """Return the legacy flat retry maximum delay."""
        return self.retry.max_seconds

    @property
    def retry_recovery_tool(self) -> RetryRecoveryToolConfig | None:
        """Return the legacy flat retry recovery tool configuration."""
        return self.retry.recovery_tool

    @property
    def max_steps(self) -> int:
        """Return the legacy flat maximum loop step count."""
        return self.loop.max_steps

    @property
    def checkpoint_dir(self) -> Path | str:
        """Return the legacy flat checkpoint directory."""
        return self.checkpoint.directory

    @property
    def checkpoint_enabled(self) -> bool:
        """Return the legacy flat checkpoint enabled flag."""
        return self.checkpoint.enabled

    @property
    def checkpoint_message_threshold(self) -> int | None:
        """Return the legacy flat checkpoint message threshold."""
        return self.checkpoint.message_threshold

    @property
    def checkpoint_on_tool_or_skill_before_execution(self) -> bool:
        """Return the legacy flat before-execution checkpoint flag."""
        return self.checkpoint.on_tool_or_skill_before_execution

    @property
    def checkpoint_on_skill_close(self) -> bool:
        """Return the legacy flat after-skill-close checkpoint flag."""
        return self.checkpoint.on_skill_close

    @property
    def tool_output_memory_dir(self) -> Path | str:
        """Return the legacy flat reusable-output memory directory."""
        return self.tool_output.memory_dir

    @property
    def tool_output_description_token_limit(self) -> int:
        """Return the legacy flat output-description token limit."""
        return self.tool_output.description_token_limit

    @property
    def tool_output_content_token_limit(self) -> int:
        """Return the legacy flat output-content token limit."""
        return self.tool_output.content_token_limit

    @property
    def tool_output_metadata_preview_char_limit(self) -> int:
        """Return the legacy flat metadata preview character limit."""
        return self.tool_output.metadata_preview_char_limit

    @property
    def tool_output_awareness_default_page_size(self) -> int:
        """Return the legacy flat awareness default page size."""
        return self.tool_output.awareness_default_page_size

    @property
    def tool_output_awareness_max_page_size(self) -> int:
        """Return the legacy flat awareness maximum page size."""
        return self.tool_output.awareness_max_page_size

    @property
    def diagnostic_logs_enabled(self) -> bool:
        """Return the legacy flat diagnostic-log enabled flag."""
        return self.diagnostic_logs.enabled

    @property
    def diagnostic_logs_dir(self) -> Path | str:
        """Return the legacy flat diagnostic-log directory."""
        return self.diagnostic_logs.directory

    @property
    def diagnostic_logs_level(self) -> str:
        """Return the legacy flat diagnostic-log level."""
        return self.diagnostic_logs.level

    @property
    def diagnostic_logs_file_name(self) -> str:
        """Return the legacy flat diagnostic-log file name."""
        return self.diagnostic_logs.file_name


@dataclass(frozen=True, slots=True)
class ModelRequestConfigOverride:
    """Override model request settings while preserving inherited values."""

    temperature: float | _Unset = UNSET
    top_p: float | None | _Unset = UNSET
    max_output_tokens: int | None | _Unset = UNSET
    stop: str | list[str] | tuple[str, ...] | None | _Unset = UNSET
    seed: int | None | _Unset = UNSET
    user: str | None | _Unset = UNSET
    thinking: bool | _Unset = UNSET


@dataclass(frozen=True, slots=True)
class RetryConfigOverride:
    """Override retry settings while preserving inherited values."""

    max_retries: int | _Unset = UNSET
    multiplier: float | _Unset = UNSET
    min_seconds: float | _Unset = UNSET
    max_seconds: float | _Unset = UNSET
    recovery_tool: RetryRecoveryToolConfig | None | _Unset = UNSET


@dataclass(frozen=True, slots=True)
class LoopConfigOverride:
    """Override loop settings while preserving inherited values."""

    max_steps: int | _Unset = UNSET


@dataclass(frozen=True, slots=True)
class CheckpointConfigOverride:
    """Override checkpoint settings while preserving inherited values."""

    directory: Path | str | None | _Unset = UNSET
    enabled: bool | _Unset = UNSET
    message_threshold: int | None | _Unset = UNSET
    on_tool_or_skill_before_execution: bool | _Unset = UNSET
    on_skill_close: bool | _Unset = UNSET


@dataclass(frozen=True, slots=True)
class ToolOutputConfigOverride:
    """Override reusable-output settings while preserving inherited values."""

    memory_dir: Path | str | None | _Unset = UNSET
    description_token_limit: int | _Unset = UNSET
    content_token_limit: int | _Unset = UNSET
    metadata_preview_char_limit: int | _Unset = UNSET
    reference_similarity_mode: str | _Unset = UNSET
    awareness_default_page_size: int | _Unset = UNSET
    awareness_max_page_size: int | _Unset = UNSET


@dataclass(frozen=True, slots=True)
class DiagnosticLogConfigOverride:
    """Override diagnostic log settings while preserving inherited values."""

    enabled: bool | _Unset = UNSET
    directory: Path | str | None | _Unset = UNSET
    level: str | _Unset = UNSET
    file_name: str | _Unset = UNSET


@dataclass(frozen=True, slots=True)
class FileInspectionConfigOverride:
    """Override inherited workspace-file inspection settings."""

    cache_directory: Path | str | _Unset = UNSET
    model_cache_directory: Path | str | _Unset = UNSET
    preanalysis_max_bytes: int | _Unset = UNSET
    expanded_max_bytes: int | _Unset = UNSET
    pdf_max_pages: int | _Unset = UNSET
    pdf_native_text_min_chars: int | _Unset = UNSET
    image_max_frames: int | _Unset = UNSET
    ocr_language: str | _Unset = UNSET
    ocr_model: str | _Unset = UNSET
    ocr_max_new_tokens: int | _Unset = UNSET
    ocr_device: str | _Unset = UNSET
    cache_max_bytes: int | _Unset = UNSET
    cache_entry_max_bytes: int | _Unset = UNSET
    max_symbols: int | _Unset = UNSET
    max_columns: int | _Unset = UNSET
    max_sheets: int | _Unset = UNSET
    max_archive_entry_names: int | _Unset = UNSET
    max_list_items: int | _Unset = UNSET


@dataclass(frozen=True, slots=True)
class RuntimeConfigOverrides:
    """Collect node-local runtime overrides using UNSET for inheritance."""

    model: ModelRequestConfigOverride | None = None
    retry: RetryConfigOverride | None = None
    loop: LoopConfigOverride | None = None
    checkpoint: CheckpointConfigOverride | None = None
    tool_output: ToolOutputConfigOverride | None = None
    diagnostic_logs: DiagnosticLogConfigOverride | None = None
    file_inspection: FileInspectionConfigOverride | None = None

    def apply(self, runtime: AgentRuntimeConfig) -> AgentRuntimeConfig:
        """Return a runtime config with all explicit overrides applied."""
        return AgentRuntimeConfig(
            model=_apply_override(runtime.model, self.model),
            retry=_apply_override(runtime.retry, self.retry),
            loop=_apply_override(runtime.loop, self.loop),
            checkpoint=_apply_override(runtime.checkpoint, self.checkpoint),
            tool_output=_apply_override(runtime.tool_output, self.tool_output),
            diagnostic_logs=_apply_override(
                runtime.diagnostic_logs,
                self.diagnostic_logs,
            ),
            file_inspection=_apply_override(
                runtime.file_inspection,
                self.file_inspection,
            ),
        )


@dataclass(frozen=True, slots=True)
class DeepSkillLayoutConfig:
    """Configure deep-skill source locations and instruction filenames."""

    deep_skills_path: Path
    prompt_file: str = "deep-skill.md"


@dataclass(frozen=True, slots=True)
class ToolLayoutConfig:
    """Configure regular tool source locations."""

    tools_path: Path


@dataclass(frozen=True, slots=True)
class ExitSkillLayoutConfig:
    """Configure exit-skill source locations."""

    exit_skills_path: Path


@dataclass(frozen=True, slots=True)
class HDSLayoutConfig:
    """Configure hierarchical deep-skill source locations."""

    hds_path: Path


@dataclass(frozen=True, slots=True)
class CapabilityLayoutConfig:
    """Configure capability filesystem roots and standard subdirectories."""

    capabilities_path: Path
    builtin_roots: tuple[Path, ...]
    deep_skill: DeepSkillLayoutConfig
    tools: ToolLayoutConfig
    exit_skills: ExitSkillLayoutConfig
    hds: HDSLayoutConfig
    extra_roots: tuple[Path, ...] = ()
    workroot_bridge_dir: str | None = "capabilities"

    @classmethod
    def from_package_root(cls, package_root: Path) -> "CapabilityLayoutConfig":
        """Build the default capability layout for the installed package."""
        capabilities_path = package_root / "backend" / "capabilities"
        return cls(
            capabilities_path=capabilities_path,
            builtin_roots=(capabilities_path,),
            deep_skill=DeepSkillLayoutConfig(
                deep_skills_path=capabilities_path / "skills"
            ),
            tools=ToolLayoutConfig(tools_path=capabilities_path / "tools"),
            exit_skills=ExitSkillLayoutConfig(
                exit_skills_path=capabilities_path / "exit-skills"
            ),
            hds=HDSLayoutConfig(hds_path=capabilities_path / "hierarchical-skills"),
        )

    def with_builtin_root(self, root: Path | str) -> "CapabilityLayoutConfig":
        """Return a copy with one builtin root appended if it is not present."""
        resolved = Path(root).resolve()
        roots = tuple(Path(item).resolve() for item in self.builtin_roots)
        if resolved in roots:
            return replace(self, builtin_roots=roots)
        return replace(self, builtin_roots=(*roots, resolved))

    def with_overrides(
        self,
        *,
        builtin_roots: Sequence[Path | str] | None = None,
        extra_roots: Sequence[Path | str] | None = None,
        workroot_bridge_dir: str | None | _Unset = UNSET,
    ) -> "CapabilityLayoutConfig":
        """Return a copy with node-local capability overrides applied."""
        updates: dict[str, object] = {}
        if builtin_roots is not None:
            updates["builtin_roots"] = tuple(
                Path(path).resolve() for path in builtin_roots
            )
        if extra_roots is not None:
            updates["extra_roots"] = tuple(Path(path).resolve() for path in extra_roots)
        if workroot_bridge_dir is not UNSET:
            updates["workroot_bridge_dir"] = workroot_bridge_dir
        return replace(self, **updates)


@dataclass(frozen=True, slots=True)
class FeatureConfigSet:
    """Store feature-owned runtime configuration sections."""

    wiki: Any | None = None

    def with_wiki(self, wiki: Any) -> "FeatureConfigSet":
        """Return a copy with AgentWiki feature configuration attached."""
        return replace(self, wiki=wiki)


@dataclass(frozen=True, slots=True)
class RuntimePackageConfig:
    """Resolved typed configuration consumed by runtime components."""

    package_path: Path
    runtime: AgentRuntimeConfig = field(default_factory=AgentRuntimeConfig)
    capabilities: CapabilityLayoutConfig | None = None
    features: FeatureConfigSet = field(default_factory=FeatureConfigSet)
    inject_capability_summaries: bool = True

    def __post_init__(self) -> None:
        """Populate capability defaults when omitted."""
        if not isinstance(self.inject_capability_summaries, bool):
            raise TypeError("inject_capability_summaries must be a boolean.")
        if self.capabilities is None:
            object.__setattr__(
                self,
                "capabilities",
                CapabilityLayoutConfig.from_package_root(self.package_path),
            )

    @property
    def agent(self) -> AgentRuntimeConfig:
        """Return runtime settings through the legacy `config.agent` path."""
        return self.runtime

    @property
    def wiki(self) -> Any | None:
        """Return AgentWiki feature settings through the legacy `config.wiki` path."""
        return self.features.wiki

    def with_runtime(self, runtime: AgentRuntimeConfig) -> "RuntimePackageConfig":
        """Return a copy with new runtime settings."""
        return replace(self, runtime=runtime)

    def with_capabilities(
        self, capabilities: CapabilityLayoutConfig
    ) -> "RuntimePackageConfig":
        """Return a copy with new capability layout settings."""
        return replace(self, capabilities=capabilities)

    def with_features(self, features: FeatureConfigSet) -> "RuntimePackageConfig":
        """Return a copy with new feature settings."""
        return replace(self, features=features)


@dataclass(frozen=True, slots=True)
class PackageDefaults:
    """Expose dataclass-only package defaults for Agent Wiki runtime."""

    config: RuntimePackageConfig = field(
        default_factory=lambda: _default_package_config()
    )

    def __post_init__(self) -> None:
        """Validate package defaults immediately after construction."""
        self.validate()

    @classmethod
    def load_default(cls) -> "PackageDefaults":
        """Return the installed package defaults."""
        return cls()

    def resolve_package_path(self, path: Path | str) -> Path:
        """Resolve one path relative to the installed package root."""
        candidate = Path(path).expanduser()
        if candidate.is_absolute():
            return candidate.resolve()
        return (self.config.package_path / candidate).resolve()

    def runtime_defaults(self) -> Mapping[str, object]:
        """Return legacy flat runtime defaults for compatibility callers."""
        return legacy_runtime_mapping(self.config.runtime)

    def capability_defaults(self) -> Mapping[str, object]:
        """Return basic capability defaults for compatibility callers."""
        capabilities = self.config.capabilities
        if capabilities is None:
            return {}
        return {
            "capabilities_path": capabilities.capabilities_path,
            "builtin_roots": capabilities.builtin_roots,
            "deep_skill": capabilities.deep_skill,
            "tools": capabilities.tools,
            "exit_skills": capabilities.exit_skills,
            "hds": capabilities.hds,
            "extra_roots": capabilities.extra_roots,
            "workroot_bridge_dir": capabilities.workroot_bridge_dir,
        }

    def validate(self) -> None:
        """Validate the dataclass package defaults."""
        capabilities = self.config.capabilities
        if capabilities is None:
            raise ValueError("Package defaults require capability layout settings.")
        if not capabilities.deep_skill.prompt_file.strip():
            raise ValueError("Capability layout requires a deep-skill prompt file.")


def legacy_runtime_mapping(runtime: AgentRuntimeConfig) -> dict[str, object]:
    """Return a flat mapping matching the legacy AgentConfig field names."""
    return {
        "max_steps": runtime.max_steps,
        "max_retries": runtime.max_retries,
        "retry_multiplier": runtime.retry_multiplier,
        "retry_min_seconds": runtime.retry_min_seconds,
        "retry_max_seconds": runtime.retry_max_seconds,
        "retry_recovery_tool": runtime.retry.recovery_tool,
        "temperature": runtime.temperature,
        "top_p": runtime.top_p,
        "max_output_tokens": runtime.max_output_tokens,
        "stop": runtime.stop,
        "seed": runtime.seed,
        "user": runtime.user,
        "thinking": runtime.thinking,
        "tool_output_memory_dir": runtime.tool_output_memory_dir,
        "tool_output_description_token_limit": runtime.tool_output_description_token_limit,
        "tool_output_content_token_limit": runtime.tool_output_content_token_limit,
        "tool_output_metadata_preview_char_limit": (
            runtime.tool_output_metadata_preview_char_limit
        ),
        "tool_output_reference_similarity_mode": (
            runtime.tool_output.reference_similarity_mode
        ),
        "tool_output_awareness_default_page_size": (
            runtime.tool_output_awareness_default_page_size
        ),
        "tool_output_awareness_max_page_size": (
            runtime.tool_output_awareness_max_page_size
        ),
        "checkpoint_dir": runtime.checkpoint_dir,
        "checkpoint_enabled": runtime.checkpoint_enabled,
        "checkpoint_message_threshold": runtime.checkpoint_message_threshold,
        "checkpoint_on_tool_or_skill_before_execution": (
            runtime.checkpoint_on_tool_or_skill_before_execution
        ),
        "checkpoint_on_skill_close": runtime.checkpoint_on_skill_close,
        "diagnostic_logs_enabled": runtime.diagnostic_logs_enabled,
        "diagnostic_logs_dir": runtime.diagnostic_logs_dir,
        "diagnostic_logs_level": runtime.diagnostic_logs_level,
        "diagnostic_logs_file_name": runtime.diagnostic_logs_file_name,
    }


def runtime_overrides_from_legacy(
    values: Mapping[str, object],
) -> RuntimeConfigOverrides:
    """Build structured runtime overrides from legacy flat field names."""
    return RuntimeConfigOverrides(
        model=ModelRequestConfigOverride(
            temperature=values.get("temperature", UNSET),
            top_p=values.get("top_p", UNSET),
            max_output_tokens=values.get("max_output_tokens", UNSET),
            stop=values.get("stop", UNSET),
            seed=values.get("seed", UNSET),
            user=values.get("user", UNSET),
            thinking=values.get("thinking", UNSET),
        ),
        retry=RetryConfigOverride(
            max_retries=values.get("max_retries", UNSET),
            multiplier=values.get("retry_multiplier", UNSET),
            min_seconds=values.get("retry_min_seconds", UNSET),
            max_seconds=values.get("retry_max_seconds", UNSET),
            recovery_tool=_coerce_retry_recovery_tool(
                values.get("retry_recovery_tool", UNSET)
            ),
        ),
        loop=LoopConfigOverride(max_steps=values.get("max_steps", UNSET)),
        checkpoint=CheckpointConfigOverride(
            directory=values.get("checkpoint_dir", UNSET),
            enabled=values.get("checkpoint_enabled", UNSET),
            message_threshold=values.get("checkpoint_message_threshold", UNSET),
            on_tool_or_skill_before_execution=values.get(
                "checkpoint_on_tool_or_skill_before_execution",
                UNSET,
            ),
            on_skill_close=values.get("checkpoint_on_skill_close", UNSET),
        ),
        tool_output=ToolOutputConfigOverride(
            memory_dir=values.get("tool_output_memory_dir", UNSET),
            description_token_limit=values.get(
                "tool_output_description_token_limit",
                UNSET,
            ),
            content_token_limit=values.get("tool_output_content_token_limit", UNSET),
            metadata_preview_char_limit=values.get(
                "tool_output_metadata_preview_char_limit",
                UNSET,
            ),
            reference_similarity_mode=values.get(
                "tool_output_reference_similarity_mode",
                UNSET,
            ),
            awareness_default_page_size=values.get(
                "tool_output_awareness_default_page_size",
                UNSET,
            ),
            awareness_max_page_size=values.get(
                "tool_output_awareness_max_page_size",
                UNSET,
            ),
        ),
        diagnostic_logs=DiagnosticLogConfigOverride(
            enabled=values.get("diagnostic_logs_enabled", UNSET),
            directory=values.get("diagnostic_logs_dir", UNSET),
            level=values.get("diagnostic_logs_level", UNSET),
            file_name=values.get("diagnostic_logs_file_name", UNSET),
        ),
    )


def clone_runtime_config(config: RuntimePackageConfig) -> RuntimePackageConfig:
    """Return a detached copy of a runtime package configuration."""
    return deepcopy(config)


def _coerce_retry_recovery_tool(
    value: object,
) -> RetryRecoveryToolConfig | None | _Unset:
    """Normalize legacy retry recovery tool values into the typed config."""
    if value is UNSET:
        return UNSET
    if value is None or isinstance(value, RetryRecoveryToolConfig):
        return value
    if isinstance(value, Mapping):
        tool_name = value.get("tool_name")
        if isinstance(tool_name, str):
            return RetryRecoveryToolConfig(tool_name=tool_name)
    raise TypeError("retry_recovery_tool must be RetryRecoveryToolConfig or None.")


def _apply_override(base: Any, override: Any | None) -> Any:
    """Apply explicit fields from one override dataclass to a frozen dataclass."""
    if override is None:
        return base
    updates = {
        item.name: value
        for item in fields(override)
        if (value := getattr(override, item.name)) is not UNSET
    }
    return replace(base, **updates)


def _default_package_config() -> RuntimePackageConfig:
    """Build package defaults from the installed package location."""
    package_path = Path(files("agent_wiki")).resolve()
    return RuntimePackageConfig(package_path=package_path)
