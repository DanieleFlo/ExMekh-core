from __future__ import annotations

from pathlib import Path

from agent_wiki.configs.runtime import PackageDefaults, RuntimePackageConfig


class SystemConfig(PackageDefaults):
    """Compatibility wrapper for dataclass-only package defaults."""


def resolve_package_path(path: Path | str) -> Path:
    """Resolve one path relative to the installed package root."""
    return SystemConfig().resolve_package_path(path)


SystemConfigInterface = PackageDefaults

__all__ = [
    "PackageDefaults",
    "RuntimePackageConfig",
    "SystemConfig",
    "SystemConfigInterface",
    "resolve_package_path",
]
