from __future__ import annotations

from functools import lru_cache
from importlib.resources import files
from pathlib import Path
from string import Template

from omegaconf import DictConfig, OmegaConf


_PACKAGE_ROOT = Path(str(files("agent_wiki")))
_TEXT_CONFIG_ROOT = _PACKAGE_ROOT / "configs" / "text"


@lru_cache(maxsize=None)
def _load_catalog(file_name: str) -> DictConfig:
    """Load and cache one YAML text catalog from the package resources."""
    loaded = OmegaConf.load(_TEXT_CONFIG_ROOT / file_name)
    if not isinstance(loaded, DictConfig):
        raise TypeError(f"Text catalog '{file_name}' must load as a DictConfig.")
    return loaded


def runtime_texts() -> DictConfig:
    """Return the runtime-oriented text catalog."""
    return _load_catalog("runtime.yaml")


def capability_texts() -> DictConfig:
    """Return the capability-oriented text catalog."""
    return _load_catalog("capabilities.yaml")


def get_runtime_text(key: str, **values: object) -> str:
    """Resolve and interpolate one string from the runtime text catalog."""
    return _get_text(runtime_texts(), key, **values)


def get_capability_text(key: str, **values: object) -> str:
    """Resolve and interpolate one string from the capability text catalog."""
    return _get_text(capability_texts(), key, **values)


def _get_text(catalog: DictConfig, key: str, **values: object) -> str:
    """Traverse a dotted key path and substitute template placeholders."""
    node: object = catalog
    for part in key.split("."):
        if not isinstance(node, DictConfig) or part not in node:
            raise KeyError(f"Unknown text catalog key: {key}")
        node = node[part]

    if not isinstance(node, str):
        raise TypeError(f"Text catalog key '{key}' must resolve to a string.")

    substitutions = {name: str(value) for name, value in values.items()}
    return Template(node).safe_substitute(substitutions)
