from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path

from agent_wiki.configs.runtime import (
    RetryRecoveryToolConfig,
    RuntimeConfigOverrides,
    runtime_overrides_from_legacy,
)


@dataclass
class AgentConfig:
    """Deprecated flat runtime config wrapper for one HDS node."""

    max_steps: int = 10000
    max_retries: int = 5
    retry_multiplier: float = 1.0
    retry_min_seconds: float = 1.0
    retry_max_seconds: float = 4.0
    retry_recovery_tool: RetryRecoveryToolConfig | None = None
    temperature: float = 0.0
    top_p: float | None = None
    max_output_tokens: int | None = None
    stop: str | list[str] | tuple[str, ...] | None = None
    seed: int | None = None
    user: str | None = None
    tool_output_memory_dir: Path | str = ".agent-wiki/tmp/tool-output-memory"
    tool_output_description_token_limit: int = 10
    tool_output_content_token_limit: int = 20
    tool_output_metadata_preview_char_limit: int = 20
    tool_output_reference_similarity_mode: str = "characters"
    tool_output_awareness_default_page_size: int = 20
    tool_output_awareness_max_page_size: int = 20
    checkpoint_dir: Path | str = ".agent-wiki/checkpoint"
    checkpoint_enabled: bool = True
    checkpoint_message_threshold: int | None = None
    checkpoint_on_tool_or_skill_before_execution: bool = True
    checkpoint_on_skill_close: bool = True
    diagnostic_logs_enabled: bool = False
    diagnostic_logs_dir: Path | str = ".agent-wiki/diagnostic-logs"
    diagnostic_logs_level: str = "DEBUG"
    diagnostic_logs_file_name: str = "runtime.log"

    def to_runtime_overrides(self) -> RuntimeConfigOverrides:
        """Convert this flat compatibility config into structured overrides."""
        return runtime_overrides_from_legacy(asdict(self))
