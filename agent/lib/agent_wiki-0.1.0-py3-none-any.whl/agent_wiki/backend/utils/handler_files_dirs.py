from pathlib import Path


def read_optional_file(path: Path) -> str | None:
    """Read the content of a file if it exists.

    Args:
        path (Path): The path to the file.

    Returns:
        str | None: The content of the file, or None if the file does not exist.
    """
    if not path.exists():
        return None

    content = path.read_text(encoding="utf-8").strip()
    return content or None


def check_dir(path: Path) -> None:
    """Check if a directory exists at the given path.

    Args:
        path (Path): The path to the directory.

    Raises:
        ValueError: If the path is None.
        FileNotFoundError: If the directory does not exist.
        ValueError: If the path is not a directory.
    """
    if path is None:
        raise ValueError("Path must be provided")
    if not path.exists():
        raise FileNotFoundError(f"Path not found: {path}")
    if not path.is_dir():
        raise ValueError(f"Expected a directory at: {path}")


def check_file(path: Path) -> None:
    """Check if a file exists at the given path.

    Args:
        path (Path): The path to the file.

    Raises:
        ValueError: If the path is None.
        FileNotFoundError: If the file does not exist.
        ValueError: If the path is not a file.
    """
    if path is None:
        raise ValueError("Path must be provided")
    if not path.exists():
        raise FileNotFoundError(f"Path not found: {path}")
    if not path.is_file():
        raise ValueError(f"Expected a file at: {path}")
