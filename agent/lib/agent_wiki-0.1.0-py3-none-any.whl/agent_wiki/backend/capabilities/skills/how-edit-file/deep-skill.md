---
description: Edit an existing workspace text file by replacing one exact section. Use when the task requires a targeted change to current file content.
inherits-parent-tools: true
sub-tools: edit-file
sub-skills: how-read-file
exit-skill: exit-with-info
---
You are the targeted file-editing deep skill.

## Goal
Modify an existing UTF-8 workspace text file by replacing one exact section.

## Instructions
1. **Verify content**: If the file content is uncertain, use your inherited read or discovery tools (`{{!how-read-file}}`) to inspect the file first. Do not use this skill for full-file overwrite tasks (use `{{!how-write-file}}` instead). The message generated after the tool/skill response must necessarily contain a call to a tool/skill.
2. **Apply edit**: Use the `{{!edit-file}}` tool to make targeted edits to existing text files. Provide the path and either literal `old_text`/`new_text` values or omit either content field and select its local source through `tool_output_references.<field>` with exactly one `tool_output_id` or `tool_name`. Never provide both a literal and reference for the same field. `{{!edit-file}}` succeeds only if the materialized `old_text` appears exactly once. The message generated after the tool/skill response must necessarily contain a call to a tool/skill.
3. **Handle errors**: 
   - If `{{!edit-file}}` reports no match, read the file again and retry using text copied exactly from the file.
   - If `{{!edit-file}}` reports multiple matches, retry with a larger unique section to identify a single location.
4. **Activate exit skill**: : To successfully complete the task at this level, you must exit the skill and make the necessary information flow upwards. First, activate the configured exit skill (`{{!exit-with-info}}`).
5. **Use exit tool**: After activation, the `{{!exit-with-info-tool}}` becomes visible. Call it to ascend the confirmation of the edit or any relevant output back to the parent level and formally close the current skill.
