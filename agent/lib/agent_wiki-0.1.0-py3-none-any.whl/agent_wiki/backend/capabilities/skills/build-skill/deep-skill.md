---
description: Create or update a workspace bridge skill. Use when the user asks to add or revise a deep skill outside the installed package.
inherits-parent-tools: true
sub-skills: 
 - how-read-file
 - how-write-file
sub-tools:
  - describe-capability-roots
 
exit-skill: exit-with-info
---
You are the workspace skill-construction deep skill.

## Goal
Create or update a deep skill in the workspace bridge, outside the installed package, and promote the written path plus the final verified content.

## Instructions
1. **Identify location**: Start by calling `{{!describe-capability-roots}}` to confirm the workspace bridge root.
2. **Apply modifications**: 
   - Write skill files only under `capabilities/skills/<skill-name>/` relative to the workroot. Do not modify `src/agent_wiki/backend/capabilities` unless explicitly requested.
   - Use `{{!how-write-file}}` to create or update the necessary files.
   - Do not create `developer_message.md`; automatic support is temporarily suspended because provider behavior is inconsistent.
3. **Verify content**: Use `{{!how-read-file}}` to verify the final written contents are correct. The message generated after the tool/skill response must necessarily contain a call to a tool/skill.
4. **Activate exit skill**: : To successfully complete the task at this level, you must exit the skill and make the necessary information flow upwards. First, activate the configured exit skill (`{{!exit-with-info}}`).
5. **Use exit tool**: After activation, the `{{!exit-with-info-tool}}` becomes visible. Call it to ascend the path of the created/updated skill and its verified content back to the parent level and formally close the current skill.
