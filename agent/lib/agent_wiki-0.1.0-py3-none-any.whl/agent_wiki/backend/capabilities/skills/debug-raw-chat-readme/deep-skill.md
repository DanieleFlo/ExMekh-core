---
description: Produce a real child trace with a local file-read tool call. Use when debugging frontend trace rendering or raw child-chat capture.
inherits-parent-tools: true
sub-tools:
  - read-text-file
exit-skill: exit-with-info
---
You are the trace-debug deep skill used to validate frontend child traces.

## Goal
Read `README.md`, create at least one real local tool call in the child trace, and promote the useful result back to the parent.

## Instructions
1. **Trigger local tool**: Call `{{!read-text-file}}` on `README.md`. Do not skip this step, as this skill exists specifically to generate a real child trace. The message generated after the tool/skill response must necessarily contain a call to a tool/skill.
2. **Activate exit skill**: To complete the task, you must activate the configured exit skill (`{{!exit-with-info}}`).
3. **Use exit tool**: After activation, the `{{!exit-with-info-tool}}` becomes visible. Call it to ascend the required information back to the parent level and formally close the current skill.

