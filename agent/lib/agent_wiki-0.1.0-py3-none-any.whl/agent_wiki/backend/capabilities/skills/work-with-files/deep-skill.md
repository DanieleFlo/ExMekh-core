---
description: Inspect workspace files before reading when their format and size and structure are not already known.
inherits-parent-tools: true
sub-tools:
  - inspect-file
exit-skill: exit-with-info
---
# Workspace File Operations

## Goal
Inspect a requested workspace file before choosing a reading strategy, while keeping every filesystem operation inside the injected workroot.

## Instructions
1. **Inspect first when needed**: Call `{{!inspect-file}}` with `detailed=false` before reading when the file type, size, structure, or safe processing strategy is not already established. This compact mode is equally accurate and returns the information most likely to guide an agent, including `total_lines` for decoded text and bounded `start_line`/`end_line` navigation regions where the format supports them. Treat those coordinates as 1-based and inclusive. Analysis lists return at most 50 items by default. Lower `max_items` when less context is sufficient, or add a non-empty `query` to rank each list recursively by the complete text of its items. Check `list_selection.semantic_ranking_applied` and `semantic_fallback_applied` before describing how results were ranked. Repeat with `detailed=true` only when timestamps, permissions, filesystem details, configured limits, cache state, or full format-specific statistics are needed. The message generated after the tool response must necessarily contain a call to another tool or skill.
2. **Interpret the status exactly**: Distinguish `complete`, `skipped_limit`, `not_implemented`, `unsupported`, and `failed`. Never claim that content or format-specific structure was extracted when the status says otherwise. The message generated after any supporting tool response must necessarily contain a call to another tool or skill.
3. **Respect bounded processing**: When preanalysis was skipped, preserve the reported generic metadata and tell the parent that a future read must use a bounded, format-appropriate strategy. Do not invent a line count when `total_lines` is absent. Do not bypass the workroot or size limits with shell commands.
4. **Verify the evidence**: Check the returned path, detected family and format, analysis status, and warnings before reporting completion. When detailed mode was requested, also verify its limits and cache status.
5. **Activate the exit skill**: Activate the configured exit skill (`{{!exit-with-info}}`). The message generated after the skill response must necessarily contain a call to another tool or skill.
6. **Use the exit tool**: After activation, call `{{!exit-with-info-tool}}`. Promote the exact inspection output by its visible output id when the parent needs the structured report; otherwise promote only a concise status with `{{null}}` and `[null]`.
