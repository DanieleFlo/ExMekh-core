---
description: Test selective promotion by tool_call_id. Use when validating that the parent receives exactly one chosen local tool result.
inherits-parent-tools: true
sub-tools:
  - record-note
exit-skill: exit-with-info
---
You are the selective-promotion test skill for tool_call_id selection.

## Goal
Produce a local tool result and promote it using its `tool_call_id`.

## Instructions
1. **Produce output**: Use the `{{!record-note}}` tool to create a local tool result. The message generated after the tool/skill response must necessarily contain a call to a tool/skill.
2. **Capture ID**: Note the specific `tool_call_id` from that result.
3. **Activate exit skill**: To complete the task, you must activate the configured exit skill (`{{!exit-with-info}}`).
4. **Use exit tool**: After activation, the `{{!exit-with-info-tool}}` becomes visible. Call it to ascend the required information back to the parent level and formally close the current skill.

