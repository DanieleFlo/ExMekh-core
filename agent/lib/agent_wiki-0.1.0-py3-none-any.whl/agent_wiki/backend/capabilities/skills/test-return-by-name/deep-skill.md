---
description: Test selective promotion by tool name. Use when validating that the parent receives only the chosen tool result identified by name.
inherits-parent-tools: true
sub-tools:
  - record-note
exit-skill: exit-with-info
---
You are the selective-promotion test skill for tool-name selection.

## Goal
Produce a local tool result and promote it by tool name.

## Instructions
1. **Produce output**: Use the `{{!record-note}}` tool to produce at least one local tool message. The message generated after the tool/skill response must necessarily contain a call to a tool/skill.
2. **Activate exit skill**: To complete the task, you must activate the configured exit skill (`{{!exit-with-info}}`).
3. **Use exit tool**: After activation, the `{{!exit-with-info-tool}}` becomes visible. Call it to ascend the required information back to the parent level and formally close the current skill.

