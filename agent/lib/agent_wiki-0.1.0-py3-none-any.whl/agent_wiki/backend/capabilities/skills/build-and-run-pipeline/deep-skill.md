---
description: Build and run temporary text-to-text pipelines from visible deep skills and child HDS nodes.
inherits-parent-tools: true
sub-tools:
  - create-pipeline
  - run-pipeline
sub-skills:
  - how-read-file
  - how-write-file
  - how-edit-file
exit-skill: exit-with-info
---
# Dynamic Pipeline Builder

## Goal
Create and execute an invocation-local sequential or for-pipeline using only the regular deep skills and direct child HDS nodes visible in this level.

## Instructions
1. **Inspect available capabilities**: Use the inherited awareness tools, especially `{{!model-awareness}}`, to inspect the skills, tools, and direct child HDS nodes visible in this level before designing the pipeline. Use `{{!list-tool-outputs}}` when existing local outputs may help prepare pipeline input. For `{{!run-pipeline}}`, omit literal `message` or `static_text` and set the corresponding `tool_output_references` entry to exactly one visible `tool_output_id` or exact `tool_name`; never provide both forms for one field. The message following an awareness-tool response must necessarily contain another tool or skill call.
2. **Design the pipeline**: Select an ordered sequence of visible regular deep-skill or direct child-HDS names. The runtime infers each node type from its unique name. Immediate tools cannot be pipeline steps. The message following any tool or skill response must necessarily contain another tool or skill call.
3. **Create the pipeline**: Call `{{!create-pipeline}}` once with a unique name, a `sequential` or `for` kind, and the ordered steps. Do not request runtime, provider, or workspace overrides. The message following the tool response must necessarily contain another tool or skill call.
4. **Run the pipeline**: Call `{{!run-pipeline}}` with `message` for a sequential pipeline, or with a non-empty `messages` list and optional `static_text` for a for-pipeline. The message following the tool response must necessarily contain another tool or skill call.
5. **Handle results**: Reuse a pipeline when useful while this skill remains open. Report validation or execution failures without inventing a result.
6. **Activate exit skill**: Activate the configured `{{!exit-with-info}}` skill after the requested pipeline work is complete. The message following the skill response must necessarily contain another tool or skill call.
7. **Use exit tool**: Call the exposed `{{!exit-with-info-tool}}` to promote the final pipeline result and close this level.

## Pipeline specification

Every step requires only its capability name:

```json
{"name": "how-write-file"}
```

The runtime infers whether the name identifies a regular deep skill or a direct child HDS. Skill and HDS names must therefore be unambiguous. Immediate tools are not supported as steps, and `kind` or `type` is not needed inside a step.

## Parameter reference and purpose

### `{{!create-pipeline}}`

- `name` (required string): Identifies the pipeline inside this skill invocation. It exists so `{{!run-pipeline}}` can select one previously validated definition and so multiple temporary pipelines can coexist without ambiguity. Choose a short unique name; duplicate names are rejected.
- `kind` (required string): Selects the execution strategy. Use `sequential` to run the step list once for one text input, or `for` to run the complete step list once for every item in a text list. It exists because the runtime must validate the correct input shape and checkpoint state before execution begins.
- `steps` (required non-empty list): Defines the exact ordered capability names that form one pipeline pass. It exists to make execution deterministic: the runtime follows this order instead of asking a model to choose the next node at each boundary. The runtime infers whether each unique name is a skill or child HDS.
- `carry_outputs` (optional boolean, default `false`): Applies to `for` pipelines. When enabled, every completed iteration's promoted text is appended to the input of later iterations. It exists for cumulative workflows where later work genuinely needs earlier textual results. It does not append files or recover content that a skill did not promote.
- `success_message` (optional non-empty string): Applies to a `for` pipeline when `carry_outputs` is disabled. It is returned after every iteration succeeds. It exists to provide one stable completion result when individual iteration outputs are intentionally independent.
- `output_prefix` (optional non-empty string, default `<output>`): Wraps the beginning of each carried output. It exists to separate prior results from the current item and reduce ambiguity for the receiving skill.
- `output_suffix` (optional non-empty string, default `</output>`): Wraps the end of each carried output. It exists together with `output_prefix` to mark an exact boundary around every prior result.

### Each item in `steps`

- `name` (required non-empty string): Names the visible regular deep skill or direct child HDS to execute. It exists to bind the declarative step to one capability already authorized in the current level. The runtime derives the node type from this name. Filesystem-only names, immediate tools, hidden capabilities, and names shared by a skill and child HDS are rejected.

### `{{!run-pipeline}}`

- `name` (required string): Selects the pipeline definition created earlier in the same skill invocation. It exists because creation and execution are separate operations and a definition may be reused.
- `message` (required only for `sequential`): Supplies the single text payload for the first step. It exists for one-pass workflows. Do not combine it with `messages` or `static_text`.
- `messages` (required only for `for`): Supplies a non-empty list of non-empty text items. Each item starts exactly one complete pipeline iteration, in list order. It exists to define the collection being processed and to make the number and order of repetitions explicit. Each item should contain only the independently actionable assignment for that iteration, not work already completed for other items.
- `static_text` (optional string for `for`): Adds the same supporting text after the current list item in every iteration. It exists for concise shared constraints such as a target path, format, audience, or style. Do not place precomputed chapter contents or the completed result in it, because doing so bypasses the iterative work the pipeline is meant to perform.

Create a sequential pipeline with a scalar input:

```json
{
  "name": "read-then-edit",
  "kind": "sequential",
  "steps": [
    {"name": "how-read-file"},
    {"name": "how-edit-file"}
  ]
}
```

Run it with:

```json
{"name": "read-then-edit", "message": "Read and update the requested file."}
```

Create a for-pipeline when the same complete step sequence must run once for each input text:

```json
{
  "name": "write-sections",
  "kind": "for",
  "steps": [{"name": "how-write-file"}],
  "carry_outputs": true,
  "output_prefix": "<output>",
  "output_suffix": "</output>"
}
```

Run it with one independently actionable assignment per list item:

```json
{
  "name": "write-sections",
  "messages": [
    "Write the first requested section.",
    "Write the second requested section while preserving prior content."
  ],
  "static_text": "Use simple language."
}
```

`carry_outputs` supplies prior promoted text to later iterations; it does not automatically append files. Select skills whose text output and filesystem behavior can actually preserve earlier work. If the visible skills cannot satisfy that requirement, report the limitation instead of claiming success.
