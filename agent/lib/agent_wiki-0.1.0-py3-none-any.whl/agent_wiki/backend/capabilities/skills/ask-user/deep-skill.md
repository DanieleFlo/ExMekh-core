---
description: Ask the user one blocking structured question when their input is required to continue safely.
inherits-parent-tools: true
sub-tools:
  - ask-user-text
  - ask-user-choice
  - ask-user-choice-or-text
exit-skill: exit-with-info
---
# Ask User

## Goal
Ask the user exactly one question, wait for a validated answer, and promote that answer unchanged to the parent level.

## Instructions
1. **Choose the question type**: Use `{{!ask-user-text}}` for unconstrained text, `{{!ask-user-choice}}` when every valid answer is known, or `{{!ask-user-choice-or-text}}` when useful predefined answers exist but the user may need a custom response.
2. **Ask one question**: Call exactly one question tool with a stable question id, a concise title and question, and the required strict configuration. Option ids must be unique. Do not answer on the user's behalf. The message following the tool response must necessarily contain another tool or skill call.
3. **Preserve the answer**: Treat the tool's JSON result as authoritative. Do not alter the selected id or free text. The response is a tool result and is not inserted as a direct user message in model history.
4. **Activate exit skill**: Activate the configured `{{!exit-with-info}}` skill immediately after receiving the answer. The message following the skill response must necessarily contain another tool or skill call.
5. **Use exit tool**: Call `{{!exit-with-info-tool}}` and promote the complete answer JSON to the parent level. Do not finish this regular deep-skill level with plain assistant text.

Each invocation asks one question only. If the parent needs another decision, it must open this skill again after receiving the first answer.

## Tool examples

Use only the tool that matches the decision.

### Free text

`{{!ask-user-text}}`:

```json
{"question":{"question_id":"project-name","title":"Project name","question":"What name should be used?","text":{"label":"Project name","required":true,"min_length":2,"max_length":512}}}
```

### Fixed choice

`{{!ask-user-choice}}`:

```json
{"question":{"question_id":"environment","title":"Environment","question":"Where should the application be deployed?","options":[{"id":"staging","title":"Staging"},{"id":"production","title":"Production"}]}}
```

### Choice or custom text

`{{!ask-user-choice-or-text}}`:

```json
{"question":{"question_id":"format","title":"Output format","question":"Which format should be used?","options":[{"id":"markdown","title":"Markdown"},{"id":"json","title":"JSON"}],"text":{"label":"Other format","required":true,"min_length":2,"max_length":512}}}
```

## Arguments

All tools receive one `question` object:

- `question_id`: stable non-blank id returned with the answer.
- `title`: short heading shown to the user.
- `question`: one focused question.
- `comment`: optional supporting context.

Choice tools also require `options`, with at least two entries:

- `id`: unique machine-facing value returned as `option_id`.
- `title`: user-facing label.
- `comment`: optional explanation.

Text tools also require `text`:

- `label`: text-area label.
- `placeholder`: optional example.
- `required`: whether text is mandatory; defaults to `true`.
- `min_length` and `max_length`: accepted character limits; `max_length` defaults to and cannot exceed `512`.

Unknown fields, blank required values, duplicate option ids, and invalid limits are rejected.
Every textual field and free-text answer is limited to 512 characters.

## Which tool to use

- Use `{{!ask-user-text}}` when the answer is open, such as a name or explanation.
- Use `{{!ask-user-choice}}` when all valid answers are known, such as staging versus production.
- Use `{{!ask-user-choice-or-text}}` when common choices help but another valid answer may exist, such as Markdown, JSON, or a custom format.
