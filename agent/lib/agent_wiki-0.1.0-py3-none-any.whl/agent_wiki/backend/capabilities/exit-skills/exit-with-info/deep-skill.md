---
description: Closes the current level with a message that can reuse local outputs.
---
# Exit with Info

Close the current level by promoting only what its parent needs next. A regular
deep-skill level must close through this exit tool; an HDS may instead respond
normally when it does not need controlled output reuse.

## Instructions

1. Decide which handoff the parent needs: **defer**, **reference**, or **write**.
   In `message`, briefly state why that handoff is sufficient, then apply it.
   Give useful orientation in a few words, not hidden reasoning or a recap of
   local work.
2. **Defer** when successful work or an artifact does not need to be reproduced
   now. State what is ready, then use `{{null}}` and
   `selected_tool_outputs: [null]`. Outputs remain discoverable through
   `metadata.used_capabilities` and by later regular skills in this HDS node.
   Do not defer content needed across an HDS-node boundary.
3. **Reference** when the parent needs existing content. Never rewrite or
   summarize it. Prefer one visible id for one exact result. Put each reference
   in `message` as `{{id}}` and list the same id in `selected_tool_outputs`.
   Reuse an unambiguous visible id; call `list-tool-outputs` when it is unknown
   or ambiguous. Use an exact tool name only when every matching result is
   intended. Call `read-tool-output` only to inspect full content.
4. **Write** only for a new conclusion, failure, remaining work, or small fact
   that no reusable output represents efficiently. Use the null form without
   references, or cite matching references without `null`.
5. References are local to the current HDS node; never invent one or use a
   provider-internal call id. Call `exit-with-info-tool`. At depth greater than
   one, every assistant message after a tool or skill response must contain
   another tool or skill call.

Keep local chat history, hidden reasoning, redundant summaries, envelopes, and
unrelated outputs out of `message`. Do not mix `null` with real selections. The
runtime rejects missing, unknown, or unmatched references and supplies corrective
examples when possible.

## Decision Guide

| Situation | Best exit |
|---|---|
| A file was written, an action completed, or an artifact verified | Brief confirmation plus `{{null}}` |
| An output may be useful later in this HDS node or another regular skill in it | Brief confirmation plus `{{null}}`; the output remains inventoried |
| The receiver needs exact or substantial content now | One visible output id |
| The receiver needs several exact outputs | One visible id per output |
| Every local output from one tool is needed | The exact tool name |
| A new conclusion combines several outputs | Brief literal conclusion; references only if the complete sources must also ascend |
| Only a tiny fact from a large output is needed, such as a path | Write the fact; do not expand the whole output |
| Work failed or remains incomplete | State the useful cause and next step; error outputs are not reusable |
| The handoff crosses to a different parent or child HDS | Promote required content now; do not rely on the local inventory |
| A root HDS can answer finally without output reuse | Respond normally without the exit flow |

## Effective Examples

Completed work whose content can remain local:

```json
{"message":"The file was written and verified; its content can be retrieved later in this HDS node. {{null}}","selected_tool_outputs":[null]}
```

Exact content needed by the parent:

```json
{"message":"The parent needs the exact source content, so the reusable result is promoted unchanged:\n{{blue_river_note}}","selected_tool_outputs":["blue_river_note"]}
```

New conclusion not represented by one reusable output:

```json
{"message":"No reusable output contains the combined conclusion: the configuration is valid but requires a restart. {{null}}","selected_tool_outputs":[null]}
```

Content crossing an HDS-node boundary:

```json
{"message":"This result crosses an HDS-node boundary and cannot be retrieved later, so it is promoted now:\n{{blue_river_note}}","selected_tool_outputs":["blue_river_note"]}
```
