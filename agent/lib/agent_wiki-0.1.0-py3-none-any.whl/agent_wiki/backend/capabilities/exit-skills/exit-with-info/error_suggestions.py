from __future__ import annotations

from collections.abc import Mapping, Sequence
import re
from typing import Any

from agent_wiki.backend.core.capabilities.tool import get_local_tool_error_text
from agent_wiki.backend.core.outputs.exit_validation import (
    ExitErrorSuggestion,
    ExitValidationError,
)

_PLACEHOLDER_PATTERN = re.compile(r"\{\{\s*([A-Za-z0-9_-]+)\s*\}\}")
_NULL_MARKER_PATTERN = re.compile(
    r"\{\{\s*null\s*\}\}|\{\{\s*\}\}|\[\[null\]\]|\[null\]"
)


def generate_error_suggestions(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Build corrective payloads for the exit-with-info contract."""
    handlers = {
        "selected_outputs_required": _suggest_selecting_placeholders,
        "missing_tokens": _suggest_missing_tokens,
        "extra_tokens": _suggest_extra_tokens,
        "null_only_item": _suggest_null_mix,
        "selected_outputs_array": _suggest_reconstructed_selection,
        "selected_item_type": _suggest_reconstructed_selection,
        "non_empty_message": _suggest_without_outputs,
        "null_marker_required": _suggest_without_outputs,
        "multiple_null_markers": _suggest_single_null_marker,
        "unknown_local_reference": _suggest_unknown_reference,
    }
    handler = handlers.get(error.code)
    if handler is None:
        return []
    return handler(error, payload, local_references)


def _suggest_selecting_placeholders(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Suggest selecting every placeholder already present in the message."""
    del local_references
    placeholders = _detail_strings(error, "placeholder_tokens")
    return _one(
        "select_placeholders",
        _payload(payload, selected_tool_outputs=placeholders),
    )


def _suggest_missing_tokens(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Suggest adding missing selections or removing their placeholders."""
    del local_references
    missing = _detail_strings(error, "missing_tokens")
    selected = _real_selections(payload.get("selected_tool_outputs"))
    add_payload = _payload(
        payload,
        selected_tool_outputs=_unique([*selected, *missing]),
    )
    remove_payload = _payload(
        payload,
        message=_remove_placeholders(str(payload.get("message", "")), missing),
        selected_tool_outputs=selected,
    )
    return [
        _suggestion("add_missing_selections", add_payload),
        _suggestion("remove_missing_placeholders", remove_payload),
    ]


def _suggest_extra_tokens(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Suggest citing every selected output while preserving the selection."""
    del local_references
    extra = _detail_strings(error, "extra_tokens")
    message = str(payload.get("message", ""))
    cited_message = _append_placeholders(message, extra)
    selected = _real_selections(payload.get("selected_tool_outputs"))
    return _one(
        "cite_extra_selections",
        _payload(payload, message=cited_message, selected_tool_outputs=selected),
    )


def _suggest_null_mix(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Suggest either real output promotion or a null-only exit."""
    del error, local_references
    selected = _real_selections(payload.get("selected_tool_outputs"))
    message = _remove_null_markers(str(payload.get("message", "")))
    with_outputs = _payload(
        payload,
        message=_append_placeholders(message, selected),
        selected_tool_outputs=selected,
    )
    return [
        _suggestion("keep_real_outputs", with_outputs),
        _suggestion("use_no_outputs", _without_outputs_payload(payload)),
    ]


def _suggest_reconstructed_selection(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Reconstruct selections from recognizable message placeholders."""
    del local_references
    placeholders = _detail_strings(error, "placeholder_tokens")
    if placeholders:
        return _one(
            "rebuild_selection",
            _payload(payload, selected_tool_outputs=placeholders),
        )
    return _suggest_without_outputs(error, payload, ())


def _suggest_without_outputs(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Suggest a descriptive payload that promotes no local output."""
    del error, local_references
    return _one("use_no_outputs", _without_outputs_payload(payload))


def _suggest_single_null_marker(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Suggest retaining one canonical null marker."""
    del error, local_references
    return _one("keep_one_null_marker", _without_outputs_payload(payload))


def _suggest_unknown_reference(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Suggest replacing an unknown token with each local output candidate."""
    token = str(error.details.get("token", ""))
    replacements = _detail_strings(error, "replacement_tokens")
    available = ", ".join(local_references) or "none"
    suggestions = [
        ExitErrorSuggestion(
            description=_text(
                "replace_unknown_reference",
                token=token,
                replacement=replacement,
                available_references=available,
            ),
            payload=_replace_unknown_reference_payload(
                payload=payload,
                token=token,
                replacement=replacement,
            ),
        )
        for replacement in replacements
    ]
    return suggestions or _one("use_no_outputs", _without_outputs_payload(payload))


def _replace_unknown_reference_payload(
    *, payload: Mapping[str, Any], token: str, replacement: str
) -> dict[str, Any]:
    """Replace one unknown selection and cite its local replacement in the message."""
    selected = [
        replacement if item == token else item
        for item in _real_selections(payload.get("selected_tool_outputs"))
    ]
    message = _remove_placeholders(str(payload.get("message", "")), [token])
    return _payload(
        payload,
        message=_append_placeholders(message, [replacement]),
        selected_tool_outputs=_unique(selected),
    )


def _payload(
    payload: Mapping[str, Any],
    *,
    message: str | None = None,
    selected_tool_outputs: Sequence[str | None] | None = None,
) -> dict[str, Any]:
    """Copy a payload while replacing its message-selection contract fields."""
    updated = dict(payload)
    if message is not None:
        updated["message"] = message
    if selected_tool_outputs is not None:
        updated["selected_tool_outputs"] = list(selected_tool_outputs)
    return updated


def _without_outputs_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Build a canonical payload that intentionally promotes no tool output."""
    message = _remove_null_markers(str(payload.get("message", ""))).strip()
    message = _PLACEHOLDER_PATTERN.sub("", message).strip()
    if not message:
        message = _text("no_output_message")
    return _payload(
        payload,
        message=f"{message} {{{{null}}}}",
        selected_tool_outputs=[None],
    )


def _append_placeholders(message: str, tokens: Sequence[str]) -> str:
    """Append any missing placeholders to a message."""
    existing = set(_PLACEHOLDER_PATTERN.findall(message))
    additions = [f"{{{{{token}}}}}" for token in tokens if token not in existing]
    return " ".join(part for part in [message.strip(), *additions] if part)


def _remove_placeholders(message: str, tokens: Sequence[str]) -> str:
    """Remove selected shorthand placeholders from a message."""
    token_set = set(tokens)
    return _PLACEHOLDER_PATTERN.sub(
        lambda match: "" if match.group(1) in token_set else match.group(0),
        message,
    ).strip()


def _remove_null_markers(message: str) -> str:
    """Remove every supported null marker from a message."""
    return _NULL_MARKER_PATTERN.sub("", message).strip()


def _real_selections(value: Any) -> list[str]:
    """Return normalized real string selections from an arbitrary value."""
    if not isinstance(value, list):
        return []
    selections: list[str] = []
    for item in value:
        if not isinstance(item, str):
            continue
        token = item.strip()
        if token.startswith("{{") and token.endswith("}}"):
            token = token[2:-2].strip()
        if token and token not in {"null"}:
            selections.append(token)
    return _unique(selections)


def _detail_strings(error: ExitValidationError, key: str) -> list[str]:
    """Read one ordered string sequence from validation details."""
    value = error.details.get(key, ())
    if not isinstance(value, Sequence) or isinstance(value, str):
        return []
    return _unique([item for item in value if isinstance(item, str) and item])


def _unique(values: Sequence[str]) -> list[str]:
    """Return values in first-seen order without duplicates."""
    return list(dict.fromkeys(values))


def _one(key: str, payload: Mapping[str, Any]) -> Sequence[ExitErrorSuggestion]:
    """Build a one-item suggestion sequence."""
    return [_suggestion(key, payload)]


def _suggestion(key: str, payload: Mapping[str, Any]) -> ExitErrorSuggestion:
    """Build one suggestion using the exit-local text catalog."""
    return ExitErrorSuggestion(description=_text(key), payload=payload)


def _text(key: str, **values: object) -> str:
    """Resolve one exit-local suggestion string."""
    return get_local_tool_error_text(
        __file__,
        f"suggestions.{key}",
        **values,
    )
