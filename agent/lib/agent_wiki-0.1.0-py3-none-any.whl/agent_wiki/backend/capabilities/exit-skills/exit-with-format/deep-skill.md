---
description: Closes the current level with a formatted message that can reuse local outputs.
---
# Exit with Format

Close the current level by promoting only what its parent needs next. A regular
deep-skill level must close through this exit tool; an HDS may instead respond
normally when it does not need controlled output reuse.

## Instructions

1. Decide whether the parent needs output content or only a concise result.
2. If content is unnecessary, use a short, non-empty completion message with
   `{{null}}` and `selected_tool_outputs: [null]`. Do not copy or summarize an
   output merely to prove the work happened: the promoted envelope can already
   expose successful local activity in `metadata.used_capabilities`.
3. If content must ascend, call `list-tool-outputs` first. Use one visible output
   id for one exact result; use an exact tool name only to include every matching
   result visible in this HDS node. The node root and all regular deep skills in
   the same node share these outputs before and after ascent. Call
   `read-tool-output` only when you must inspect full content.
4. Put each selected reference in `message` as `{{reference}}` and list the same
   bare string in `selected_tool_outputs`. References are local to the current
   HDS node; never invent one or use a provider-internal call id.
5. Set `output_format` to `"json"` only when the final rendered message is JSON;
   the runtime then parses and wraps it as a JSON code block. Other values leave
   the rendered text unchanged.
6. Call `exit-with-format-tool`. At depth greater than one, every assistant
   message after a tool or skill response must contain another tool or skill call.

Keep local chat history, hidden reasoning, redundant summaries, envelopes, and
unrelated outputs out of `message`. Do not mix `null` with real selections. The
runtime rejects missing, unknown, or unmatched references and supplies corrective
examples when possible.

## Examples

Plain completion without copied output:

```json
{"message":"The requested artifact was created and verified. {{null}}","selected_tool_outputs":[null]}
```

JSON built from one exact output:

```json
{"message":"{\"result\":{{blue_json_data}}}","selected_tool_outputs":["blue_json_data"],"output_format":"json"}
```
