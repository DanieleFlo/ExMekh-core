from __future__ import annotations

from agent_wiki.backend.core.capabilities.tool import sign_tool


@sign_tool(
    short_description=(
        "Closes the current level with a formatted message template that can inline local tool outputs."
    )
)
def main(
    message: str | None = None,
    selected_tool_outputs: list[str | None] | None = None,
    output_format: str = "text",
) -> dict[str, object]:
    """Return the selected exit payload for runtime validation and rendering."""
    return {
        "message": message or "",
        "selected_tool_outputs": selected_tool_outputs or [],
        "output_format": output_format,
    }
