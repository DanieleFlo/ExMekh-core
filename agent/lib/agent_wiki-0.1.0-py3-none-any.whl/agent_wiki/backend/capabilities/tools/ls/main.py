from __future__ import annotations

from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _workspace_root(*, workroot: Path | None) -> Path:
    """Return the workspace root used by the tool."""
    return workroot if workroot is not None else Path.cwd()


def _resolve_path(path: str, *, workroot: Path | None) -> Path:
    """Resolve a path and ensure it stays inside the workspace root."""
    workspace_root = _workspace_root(workroot=workroot).resolve()
    candidate = Path(path)
    target = candidate if candidate.is_absolute() else workspace_root / candidate
    resolved_target = target.resolve()
    resolved_target.relative_to(workspace_root)
    return resolved_target


def _format_entry(path: Path) -> str:
    """Render one directory entry using an `ls`-style suffix for directories."""
    return f"{path.name}/" if path.is_dir() else path.name


@sign_tool(
    short_description="List files and directories like ls, anchored at the workroot."
)
def main(
    path: str = ".", show_hidden: bool = False, workroot: Path | None = None
) -> str | ToolOutput:
    """List directory contents relative to the injected workspace root."""
    try:
        target = _resolve_path(path, workroot=workroot)
    except Exception as error:
        return _error("resolve_path", error=error)

    if not target.exists():
        return _error("path_not_found", path=target)

    if target.is_file():
        return ToolOutput(
            result=_format_entry(target),
            metadata=format_tool_metadata(
                {"path": target, "kind": "file", "entries": 1}
            ),
        )

    try:
        children = sorted(target.iterdir(), key=lambda item: item.name.lower())
    except OSError as error:
        return _error("list_failed", path=target, error=error)

    entries = [
        _format_entry(child)
        for child in children
        if show_hidden or not child.name.startswith(".")
    ]
    return ToolOutput(
        result="\n".join(entries),
        metadata=format_tool_metadata(
            {"path": target, "kind": "directory", "entries": len(entries)}
        ),
    )
