"""Ask the user for a free-text response."""

from __future__ import annotations

from pydantic import ValidationError

from agent_wiki.backend.core.capabilities.tool import ToolOutput, sign_tool
from agent_wiki.backend.interface.user_question import (
    TextQuestion,
    UserQuestionRuntimeInterface,
)
from agent_wiki.configs.text_catalog import get_capability_text


@sign_tool(short_description=get_capability_text("descriptions.ask_user_text"))
def main(
    question: TextQuestion,
    user_question_runtime: UserQuestionRuntimeInterface | None = None,
) -> str | ToolOutput:
    """Suspend the active level and return one validated free-text answer as JSON."""
    if user_question_runtime is None:
        return ToolOutput(
            result=get_capability_text("user_questions.errors.runtime_unavailable"),
            error_kind="tool_execution",
        )
    try:
        request = TextQuestion.model_validate(question)
        answer = user_question_runtime.ask_text(request)
    except (ValidationError, ValueError) as error:
        return ToolOutput(
            result=get_capability_text(
                "user_questions.errors.invalid_request", error=error
            ),
            error_kind="invalid_tool_call",
        )
    return answer.model_dump_json()
