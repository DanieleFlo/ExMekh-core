from __future__ import annotations

from typing import Any

from agent_wiki.backend.core.capabilities.tool import sign_tool


@sign_tool(
    short_description="Records a note and exposes the local skill context for debugging.",
    reusable_input_fields=("note",),
)
def main(
    note: str,
    current_skill: str | None = None,
    chat_history: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return {
        "note": note,
        "current_skill": current_skill,
        "chat_history_length": len(chat_history or []),
    }
