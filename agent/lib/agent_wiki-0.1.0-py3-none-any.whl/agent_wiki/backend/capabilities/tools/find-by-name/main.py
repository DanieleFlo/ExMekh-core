from __future__ import annotations

import logging
import os
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)


logger = logging.getLogger(__name__)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _workspace_root(*, workroot: Path | None) -> Path:
    """Return the workspace root used to anchor the search."""
    return workroot if workroot is not None else Path.cwd()


def _tokenize_keywords(keywords: str) -> list[str]:
    """Split a keyword string into non-empty lowercase search tokens."""
    return [token for token in keywords.lower().split() if token]


def _is_hidden(path: Path, *, root: Path) -> bool:
    """Return whether a path is hidden relative to the workspace root."""
    try:
        if path.name.startswith("."):
            return True
        relative_parts = path.relative_to(root).parts[:-1]
    except ValueError:
        return True
    return any(part.startswith(".") for part in relative_parts)


def _format_match(path: Path, *, root: Path) -> str:
    """Render a match as a workspace-relative path."""
    relative = path.relative_to(root).as_posix()
    return f"{relative}/" if path.is_dir() else relative


@sign_tool(
    short_description="Search files and directories by name keywords, recursively from the workroot."
)
def main(
    keywords: str,
    show_hidden: bool = False,
    limit: int = 200,
    workroot: Path | None = None,
) -> str | ToolOutput:
    """Search recursively for filesystem entries whose names contain all keywords."""
    tokens = _tokenize_keywords(keywords)
    if not tokens:
        return _error("empty_keywords")

    try:
        root = _workspace_root(workroot=workroot).resolve()
    except Exception as exc:
        logger.exception("Failed to resolve find-by-name workroot")
        return _error("search_failed", error=exc)

    if not root.exists():
        return _error("root_not_found", root=root)
    if not root.is_dir():
        return _error("root_not_directory", root=root)

    max_results = max(1, limit)
    matches: list[str] = []
    skipped_count = 0

    def on_walk_error(error: OSError) -> None:
        """Record an inaccessible branch without stopping the whole search."""
        nonlocal skipped_count
        skipped_count += 1
        logger.warning("Skipping path during find-by-name search: %s", error)

    try:
        walker = os.walk(root, onerror=on_walk_error)
        for current_root, dir_names, file_names in walker:
            current_path = Path(current_root)
            candidate_names = sorted(
                [*dir_names, *file_names],
                key=lambda item: (current_path / item).as_posix().lower(),
            )

            for candidate_name_raw in candidate_names:
                candidate = current_path / candidate_name_raw
                try:
                    if not show_hidden and _is_hidden(candidate, root=root):
                        continue

                    candidate_name = candidate.name.lower()
                    if not all(token in candidate_name for token in tokens):
                        continue

                    matches.append(_format_match(candidate, root=root))
                except (OSError, RuntimeError, ValueError) as exc:
                    skipped_count += 1
                    logger.warning(
                        "Skipping candidate during find-by-name search: %s", exc
                    )
                    continue

                if len(matches) >= max_results:
                    break

            if len(matches) >= max_results:
                break
    except Exception as exc:
        logger.exception("find-by-name search failed unexpectedly")
        if matches:
            skipped_count += 1
        else:
            return _error("search_failed", error=exc)

    if not matches:
        if skipped_count:
            return _error("no_matches_with_skips", skipped_count=skipped_count)
        return _error("no_matches")

    rendered = "\n".join(matches)
    if skipped_count:
        rendered = (
            rendered + "\n" + _error("partial_results", skipped_count=skipped_count)
        )
    return ToolOutput(
        result=rendered,
        metadata=format_tool_metadata(
            {
                "path": root,
                "matches": len(matches),
                "skipped": skipped_count,
                "truncated": len(matches) >= max_results,
            }
        ),
    )
