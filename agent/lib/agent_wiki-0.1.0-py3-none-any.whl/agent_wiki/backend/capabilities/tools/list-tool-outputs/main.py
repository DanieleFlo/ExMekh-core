from __future__ import annotations

from typing import Any, Mapping, Optional
from dataclasses import dataclass
from math import ceil
import yaml

from agent_wiki.backend.core.outputs.tool_output_memory import (
    StoredToolOutput,
    _preview_content,
)
from agent_wiki.backend.core.outputs.tool_output_records import (
    collect_tool_output_records,
    current_level_tool_output_records,
)
from agent_wiki.backend.core.capabilities.tool import sign_tool
from agent_wiki.configs.text_catalog import get_capability_text, get_runtime_text


@dataclass(slots=True)
class ToolOutputFilters:
    """Encapsulates filter conditions for tool outputs."""

    tool_name: Optional[str] = None
    content: Optional[str] = None
    description: Optional[str] = None

    def apply(self, records: list[StoredToolOutput]) -> list[StoredToolOutput]:
        """Apply case-insensitive substring filters with AND semantics."""
        normalized_tool = self._normalize_filter_value(self.tool_name)
        normalized_content = self._normalize_filter_value(self.content)
        normalized_description = self._normalize_filter_value(self.description)

        filtered_records: list[StoredToolOutput] = []
        for record in records:
            if (
                normalized_tool
                and normalized_tool not in (record.tool_name or "").lower()
            ):
                continue
            if normalized_content and normalized_content not in record.content.lower():
                continue
            if (
                normalized_description
                and normalized_description not in record.short_description.lower()
            ):
                continue
            filtered_records.append(record)
        return filtered_records

    @staticmethod
    def _normalize_filter_value(value: Optional[str]) -> str:
        """Normalize an optional filter value for case-insensitive matching."""
        if not isinstance(value, str):
            return ""
        return value.strip().lower()


@dataclass(slots=True)
class PaginationContext:
    """Encapsulates pagination configuration and logic."""

    page: int = 1
    page_size: Optional[int] = None
    default_page_size: int = 10
    max_page_size: int = 100

    def get_slice_indices(self, total_items: int) -> tuple[int, int, int, int]:
        """
        Calculate pagination indices.
        Returns: (start_index, end_index, current_page, total_pages)
        """
        effective_max_page_size = max(1, self.max_page_size)
        requested_page_size = (
            self.page_size
            if isinstance(self.page_size, int)
            else self.default_page_size
        )
        effective_page_size = max(1, min(requested_page_size, effective_max_page_size))

        total_pages = ceil(total_items / effective_page_size) if total_items else 0
        requested_page = max(1, self.page)
        current_page = min(requested_page, total_pages) if total_pages else 1

        start_index = (current_page - 1) * effective_page_size
        end_index = start_index + effective_page_size

        return start_index, end_index, current_page, total_pages


def _format_record_yaml(
    record: StoredToolOutput, description_limit: int, content_limit: int
) -> str:
    """Render one stored output as a YAML block."""
    record_dict = {
        "tool_call_id": record.visible_tool_call_id,
        "tool_name": record.tool_name or "",
        "description": _preview_content(
            record.short_description, token_limit=description_limit
        ),
        "content": _preview_content(record.content, token_limit=content_limit)
        or get_runtime_text("model_awareness.empty_preview"),
    }
    return yaml.safe_dump(
        record_dict, sort_keys=False, default_flow_style=False
    ).strip()


def _format_awareness_yaml(
    *,
    records: list[StoredToolOutput],
    page: int,
    total_items: int,
    total_pages: int,
    filters: ToolOutputFilters,
    description_token_limit: int,
    content_token_limit: int,
) -> str:
    """Render awareness records as YAML."""
    summary = {
        "page": page,
        "total_pages": total_pages,
        "total_items": total_items,
        "filters": {
            "tool_name": filters.tool_name or "",
            "content": filters.content or "",
            "description": filters.description or "",
        },
    }
    sections = [
        yaml.safe_dump(summary, sort_keys=False, default_flow_style=False).strip()
    ]
    if not records:
        return "\n".join(sections)
    for record in records:
        sections.append("---")
        sections.append(
            _format_record_yaml(record, description_token_limit, content_token_limit)
        )
    return "\n".join(sections)


def _format_record_entry(record: StoredToolOutput) -> str:
    """Render one normalized record into the compact awareness string format."""
    return get_runtime_text(
        "model_awareness.entry_format",
        tool_call_id=record.visible_tool_call_id,
        short_description=record.short_description,
        preview=record.preview or get_runtime_text("model_awareness.empty_preview"),
    )


def _format_current_level_tool_output_entries(
    *,
    chat_history: list[dict[str, Any]] | None,
    description_token_limit: int,
) -> list[str]:
    """Render fallback outputs found directly in the current level chat history."""
    return [
        _format_record_entry(record)
        for record in current_level_tool_output_records(
            chat_history=chat_history,
            description_token_limit=description_token_limit,
            ignored_tools=None,
        )
    ]


def build_tool_output_awareness_result(
    *,
    chat_history: list[dict[str, Any]] | None,
    tool_output_awareness: Mapping[str, Any] | None,
    description_token_limit: int,
    content_token_limit: int,
    filters: ToolOutputFilters | None = None,
    pagination: PaginationContext | None = None,
    ignored_tools: list[str] | None = None,
) -> str:
    """Build the filtered and paginated YAML payload for callable outputs."""
    records = collect_tool_output_records(
        chat_history=chat_history,
        tool_output_awareness=tool_output_awareness,
        description_token_limit=description_token_limit,
        ignored_tools=ignored_tools,
    )

    active_filters = filters or ToolOutputFilters()
    filtered_records = active_filters.apply(records=records)

    active_pagination = pagination or PaginationContext()
    total_items = len(filtered_records)
    start_index, end_index, current_page, total_pages = (
        active_pagination.get_slice_indices(total_items)
    )
    current_records = filtered_records[start_index:end_index]

    return _format_awareness_yaml(
        records=current_records,
        page=current_page,
        total_items=total_items,
        total_pages=total_pages,
        filters=active_filters,
        description_token_limit=description_token_limit,
        content_token_limit=content_token_limit,
    )


@sign_tool(short_description=get_capability_text("descriptions.list_tool_outputs"))
def main(
    tool_name_filter: str | None = None,
    content_filter: str | None = None,
    description_filter: str | None = None,
    page: int = 1,
    page_size: int | None = None,
    chat_history: list[dict[str, Any]] | None = None,
    tool_output_awareness: dict[str, Any] | None = None,
    tool_output_awareness_default_page_size: int | None = None,
    tool_output_awareness_max_page_size: int | None = None,
    tool_output_description_token_limit: int | None = None,
    tool_output_content_token_limit: int | None = None,
    tool_output_ignored_tools: list[str] | None = None,
) -> str:
    """Report callable outputs as Markdown with optional filters and pagination."""
    filters = ToolOutputFilters(
        tool_name=tool_name_filter,
        content=content_filter,
        description=description_filter,
    )

    pagination = PaginationContext(
        page=page,
        page_size=page_size,
        default_page_size=(
            tool_output_awareness_default_page_size
            if isinstance(tool_output_awareness_default_page_size, int)
            else 20
        ),
        max_page_size=(
            tool_output_awareness_max_page_size
            if isinstance(tool_output_awareness_max_page_size, int)
            else 20
        ),
    )

    return build_tool_output_awareness_result(
        chat_history=chat_history,
        tool_output_awareness=tool_output_awareness,
        description_token_limit=(
            tool_output_description_token_limit
            if isinstance(tool_output_description_token_limit, int)
            else 10
        ),
        content_token_limit=(
            tool_output_content_token_limit
            if isinstance(tool_output_content_token_limit, int)
            else 20
        ),
        filters=filters,
        pagination=pagination,
        ignored_tools=tool_output_ignored_tools,
    )
