"""Search for public URLs or read one public page through Crawl4AI."""

from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.capabilities.utils.web_navigation import (
    WebNavigationError,
    crawl_page,
    search_web,
)
from agent_wiki.backend.capabilities.utils.web_navigation.image_discovery import (
    load_local_query_image,
)
from agent_wiki.backend.capabilities.utils.web_navigation.search import (
    search_web_multimodal,
)
from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(
    short_description=(
        "Search the public web for candidate URLs or read one known public page. "
        "Use query when no URL is known, optionally with image_path for visual "
        "reranking, and url for Markdown or AST extraction; "
        "search snippets are discovery hints only and every cited page must be read."
    )
)
def main(
    url: str | None = None,
    query: str | None = None,
    output_mode: str = "markdown",
    timeout_seconds: int = 30,
    max_results: int = 5,
    image_path: str | None = None,
    workroot: Path | None = None,
) -> ToolOutput:
    """Search for candidate URLs or read one page with LLM-free extraction."""
    try:
        if bool(url and str(url).strip()) == bool(query and str(query).strip()):
            raise WebNavigationError(
                "Provide exactly one of url or query.", kind="invalid_arguments"
            )
        if image_path is not None and query is None:
            raise WebNavigationError(
                "image_path can only be used together with query.",
                kind="invalid_arguments",
            )
        if query is not None:
            if image_path is None:
                payload = search_web(
                    query=query,
                    max_results=max_results,
                    timeout_seconds=timeout_seconds,
                )
            else:
                local_image = load_local_query_image(
                    image_path=image_path, workroot=workroot
                )
                payload = search_web_multimodal(
                    query=query,
                    local_image=local_image,
                    max_results=max_results,
                    timeout_seconds=timeout_seconds,
                )
            return ToolOutput(
                result=json.dumps(payload, ensure_ascii=False),
                metadata=format_tool_metadata(
                    {
                        "operation": "search",
                        "query": payload["query"],
                        "result_count": payload["result_count"],
                        "visual_ranking_applied": payload.get(
                            "visual_ranking_applied"
                        ),
                        "visual_images_used": payload.get("visual_images_used"),
                        "untrusted_content": True,
                    }
                ),
            )
        payload = crawl_page(
            url=str(url),
            output_mode=output_mode,
            timeout_seconds=timeout_seconds,
            workroot=workroot,
        )
    except WebNavigationError as error:
        return ToolOutput(
            result=_error("navigation_failed", kind=error.kind, error=error),
            error_kind="invalid_tool_call" if error.kind.startswith("invalid_") else "tool_execution",
        )
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "url": payload["final_url"],
                "output_mode": payload["output_mode"],
                "status_code": payload["status_code"],
                "retrieved_at": payload.get("retrieved_at"),
                "content_scope": payload.get("content_scope"),
                "untrusted_content": True,
            }
        ),
    )
