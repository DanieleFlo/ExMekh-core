from __future__ import annotations

from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.text_catalog import get_capability_text


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _resolve_path(path: str, *, workroot: Path | None) -> Path:
    """Resolve relative paths from the injected workroot when available."""
    candidate = Path(path)
    if candidate.is_absolute():
        return candidate
    base_path = workroot if workroot is not None else Path.cwd()
    return base_path / candidate


@sign_tool(
    short_description=get_capability_text("descriptions.write_text_file"),
    reusable_input_fields=("content",),
)
def main(
    path: str,
    content: str,
    workroot: Path | None = None,
) -> str | ToolOutput:
    """Write direct or runtime-materialized UTF-8 content to a workspace file."""

    try:
        target = _resolve_path(path, workroot=workroot)
    except Exception as error:
        return _error("resolve_path", path=path, error=error)

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    except OSError as error:
        return _error("write_failed", path=target, error=error)

    return ToolOutput(
        result=get_capability_text(
            "write_text_file.success.wrote_file",
            length=len(content),
            target=target,
        ),
        metadata=format_tool_metadata(
            {
                "path": target,
                "bytes": len(content.encode("utf-8")),
                "characters": len(content),
                "source": "content",
            }
        ),
    )
