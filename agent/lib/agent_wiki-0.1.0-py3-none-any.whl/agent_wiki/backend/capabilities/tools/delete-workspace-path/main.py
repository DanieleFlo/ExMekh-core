from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any, Mapping

from agent_wiki.backend.core.capabilities.capability_middleware import (
    CapabilityMiddlewareAbort,
)
from agent_wiki.backend.core.capabilities.tool import (
    Tool,
    ToolBeforeResult,
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
    with_middleware,
)
from agent_wiki.configs.text_catalog import get_capability_text


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _workspace_root(*, workroot: Path | None) -> Path:
    """Return the workspace root used by the tool."""
    return workroot if workroot is not None else Path.cwd()


def _resolve_path(path: str, *, workroot: Path | None) -> tuple[Path, Path]:
    """Resolve a path and ensure it stays inside the workspace root."""
    workspace_root = _workspace_root(workroot=workroot).resolve()
    candidate = Path(path)
    target = candidate if candidate.is_absolute() else workspace_root / candidate
    resolved_target = target.resolve()
    resolved_target.relative_to(workspace_root)
    return workspace_root, resolved_target


def _check_delete_permissions(target: Path) -> str | None:
    """Return an error message when the current process cannot delete the target."""
    parent = target.parent
    if not os.access(parent, os.W_OK | os.X_OK):
        return _error("missing_parent_permission", path=parent)

    if target.is_dir():
        for current_root, dir_names, file_names in os.walk(target):
            current_path = Path(current_root)
            if not os.access(current_path, os.W_OK | os.X_OK):
                return _error("missing_directory_permission", path=current_path)

            for dir_name in dir_names:
                directory = current_path / dir_name
                if not os.access(directory, os.W_OK | os.X_OK):
                    return _error("missing_directory_permission", path=directory)

            for file_name in file_names:
                file_path = current_path / file_name
                if not os.access(file_path.parent, os.W_OK | os.X_OK):
                    return _error(
                        "missing_file_parent_permission", path=file_path.parent
                    )
        return None

    if not os.access(target.parent, os.W_OK | os.X_OK):
        return _error("missing_file_parent_permission", path=target.parent)

    return None


def _confirm_delete_workspace_path(*, path: str, recursive: bool) -> bool:
    """Print the mock confirmation prompt and return the current yes response."""
    print(
        get_capability_text(
            "delete_workspace_path.confirmation.prompt",
            path=path,
            recursive=recursive,
        )
    )
    return True


def _confirm_before_delete(
    *,
    tool: Tool,
    arguments: dict[str, Any],
    injected_arguments: Mapping[str, Any],
) -> ToolBeforeResult:
    """Confirm delete-workspace-path calls before the handler runs."""
    confirmed = _confirm_delete_workspace_path(
        path=str(arguments.get("path", "")),
        recursive=bool(arguments.get("recursive", True)),
    )
    if confirmed:
        return ToolBeforeResult(arguments=dict(arguments))

    raise CapabilityMiddlewareAbort(
        _error(
            "confirmation_cancelled",
            path=arguments.get("path", ""),
        )
    )


@sign_tool(
    short_description="Delete a file or directory from the workroot after a permission preflight check."
)
@with_middleware(before=_confirm_before_delete)
def main(
    path: str, recursive: bool = True, workroot: Path | None = None
) -> str | ToolOutput:
    """Delete one filesystem path anchored at the injected workspace root."""
    try:
        workspace_root, target = _resolve_path(path, workroot=workroot)
    except Exception:
        attempted = Path(path)
        attempted_path = (
            attempted
            if attempted.is_absolute()
            else _workspace_root(workroot=workroot) / attempted
        )
        return _error("path_outside_workroot", path=attempted_path.resolve())

    if target == workspace_root:
        return _error("refuse_workroot", path=workspace_root)

    if not target.exists():
        return _error("path_not_found", path=target)

    permission_error = _check_delete_permissions(target)
    if permission_error is not None:
        return permission_error

    if target.is_dir():
        if any(target.iterdir()) and not recursive:
            return _error("directory_not_empty", path=target)
        if recursive:
            shutil.rmtree(target)
        else:
            target.rmdir()
        return ToolOutput(
            result=f"Deleted directory: {target}",
            metadata=format_tool_metadata(
                {"path": target, "deleted": True, "kind": "directory"}
            ),
        )

    target.unlink()
    return ToolOutput(
        result=f"Deleted file: {target}",
        metadata=format_tool_metadata(
            {"path": target, "deleted": True, "kind": "file"}
        ),
    )
