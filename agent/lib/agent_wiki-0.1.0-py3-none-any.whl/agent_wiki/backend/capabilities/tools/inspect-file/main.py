"""Thin tool entrypoint for bounded workspace file inspection."""

from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.capabilities.utils.file_inspection import (
    FileInspectionError,
    FileInspectionSelectionError,
    FileInspectionService,
    validate_list_selection,
)
from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import PackageDefaults, RuntimePackageConfig


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(
    short_description=(
        "Inspect one regular workspace file before reading it. Returns portable "
        "metadata, total physical lines for decoded text, and bounded navigation "
        "regions with inclusive line ranges without returning the file's full "
        "content. Every analysis list is limited by max_items (default 50); add "
        "query to rank complete list items by lexical and semantic similarity. "
        "Set detailed=true for technical metadata, applied limits, and cache status."
    )
)
def main(
    path: str,
    detailed: bool = False,
    max_items: int = 50,
    query: str | None = None,
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> ToolOutput:
    """Inspect one file and project bounded, optionally ranked analysis lists."""
    workspace_root = workroot if workroot is not None else Path.cwd()
    resolved_config = config or PackageDefaults.load_default().config
    try:
        validate_list_selection(
            max_items=max_items,
            max_list_items=resolved_config.runtime.file_inspection.max_list_items,
            query=query,
        )
        service = FileInspectionService(
            workroot=workspace_root,
            config=resolved_config.runtime.file_inspection,
        )
        report = service.inspect(path)
        projection_arguments = {
            "max_items": max_items,
            "max_list_items": resolved_config.runtime.file_inspection.max_list_items,
            "query": query,
            "cache_directory": service.model_cache_directory(),
        }
        payload = (
            report.to_dict(**projection_arguments)
            if detailed
            else report.to_compact_dict(**projection_arguments)
        )
    except FileInspectionSelectionError as error:
        return ToolOutput(
            result=_error(error.catalog_key, **error.values),
            error_kind="invalid_tool_call",
        )
    except FileInspectionError as error:
        return ToolOutput(
            result=_error("inspection_rejected", error=error),
            error_kind="invalid_tool_call",
        )
    except Exception as error:
        return ToolOutput(
            result=_error("inspection_failed", error=error),
            error_kind="tool_execution",
        )
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
    )
