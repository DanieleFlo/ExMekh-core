"""Perform one bounded sequence of browser actions through Crawl4AI."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agent_wiki.backend.capabilities.utils.web_navigation import (
    WebNavigationError,
    crawl_page,
    validate_actions,
)
from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(
    short_description=(
        "Execute a non-empty sequence of 1-10 typed actions on one known public page "
        "and return its observed final state within five same-origin navigation hops. "
        "Use only after reading an AST when the request requires interaction; never "
        "use it for search or call it without actions."
    )
)
def main(
    url: str,
    actions: list[dict[str, Any]],
    output_mode: str = "ast",
    timeout_seconds: int = 30,
    workroot: Path | None = None,
) -> ToolOutput:
    """Execute one stateless atomic interaction sequence and report its final state."""
    try:
        normalized_actions = validate_actions(actions)
        payload = crawl_page(
            url=url,
            actions=normalized_actions,
            output_mode=output_mode,
            timeout_seconds=timeout_seconds,
            workroot=workroot,
        )
    except WebNavigationError as error:
        return ToolOutput(
            result=_error("navigation_failed", kind=error.kind, error=error),
            error_kind="invalid_tool_call" if error.kind.startswith("invalid_") else "tool_execution",
        )
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "url": payload["final_url"],
                "actions": len(normalized_actions),
                "actions_completed": payload["actions_completed"],
                "output_mode": payload["output_mode"],
                "retrieved_at": payload.get("retrieved_at"),
                "content_scope": payload.get("content_scope"),
                "untrusted_content": True,
            }
        ),
    )
