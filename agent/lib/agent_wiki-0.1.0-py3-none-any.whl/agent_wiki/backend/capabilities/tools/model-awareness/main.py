from __future__ import annotations

from typing import Any

from agent_wiki.backend.core.capabilities.tool import sign_tool
from agent_wiki.configs.text_catalog import get_capability_text


@sign_tool(short_description=get_capability_text("descriptions.model_awareness"))
def main(
    model_name: str | None = None,
    current_skill: str | None = None,
    current_hds: str | None = None,
    parent_hds: str | None = None,
    child_hds_nodes: list[str] | None = None,
    hds_node_path: list[str] | None = None,
    available_tools: list[str] | None = None,
    chat_history: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Report the current runtime and HDS structure scope."""
    return {
        "model_name": model_name,
        "current_skill": current_skill,
        "current_hds": current_hds,
        "parent_hds": parent_hds,
        "child_hds_nodes": child_hds_nodes or [],
        "hds_node_path": hds_node_path or [],
        "available_tools": available_tools or [],
        "chat_history_length": len(chat_history or []),
    }
