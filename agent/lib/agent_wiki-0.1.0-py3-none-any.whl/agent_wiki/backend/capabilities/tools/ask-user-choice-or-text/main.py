"""Ask the user for one option or a free-text alternative."""

from __future__ import annotations

from pydantic import ValidationError

from agent_wiki.backend.core.capabilities.tool import ToolOutput, sign_tool
from agent_wiki.backend.interface.user_question import (
    ChoiceOrTextQuestion,
    UserQuestionRuntimeInterface,
)
from agent_wiki.configs.text_catalog import get_capability_text


@sign_tool(
    short_description=get_capability_text("descriptions.ask_user_choice_or_text")
)
def main(
    question: ChoiceOrTextQuestion,
    user_question_runtime: UserQuestionRuntimeInterface | None = None,
) -> str | ToolOutput:
    """Suspend the active level and return one exclusive choice-or-text answer."""
    if user_question_runtime is None:
        return ToolOutput(
            result=get_capability_text("user_questions.errors.runtime_unavailable"),
            error_kind="tool_execution",
        )
    try:
        request = ChoiceOrTextQuestion.model_validate(question)
        answer = user_question_runtime.ask_choice_or_text(request)
    except (ValidationError, ValueError) as error:
        return ToolOutput(
            result=get_capability_text(
                "user_questions.errors.invalid_request", error=error
            ),
            error_kind="invalid_tool_call",
        )
    return answer.model_dump_json(exclude_none=True)
