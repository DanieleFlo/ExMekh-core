from __future__ import annotations

import subprocess
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    StandardToolHITLResolver,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_hitl,
    sign_tool,
)
from agent_wiki.configs.text_catalog import get_capability_text


OUTPUT_LIMIT = 12000


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _workspace_root(*, workroot: Path | None) -> Path:
    """Return the workspace root used as the shell working directory."""
    return workroot if workroot is not None else Path.cwd()


def _clip_output(value: str) -> str:
    """Limit command output so tool results remain compact enough for the model."""
    if not value:
        return get_capability_text("run_bash_command.output.empty")
    if len(value) <= OUTPUT_LIMIT:
        return value.rstrip()
    clipped_length = len(value) - OUTPUT_LIMIT
    return (
        value[:OUTPUT_LIMIT].rstrip()
        + "\n"
        + get_capability_text(
            "run_bash_command.output.truncated",
            clipped_length=clipped_length,
        )
    )


def _render_result(
    *,
    cwd: Path,
    exit_code: int,
    stdout: str,
    stderr: str,
) -> str:
    """Render one completed shell command result for the model."""
    return get_capability_text(
        "run_bash_command.output.result",
        cwd=cwd,
        exit_code=exit_code,
        stdout=_clip_output(stdout),
        stderr=_clip_output(stderr),
    )


@sign_tool(short_description=get_capability_text("descriptions.run_bash_command"))
@sign_hitl(
    resolver=StandardToolHITLResolver(),
    denial_message=get_capability_text("run_bash_command.hitl.denial"),
    allow_argument_modification=True,
    allow_denial_override=True,
    title=get_capability_text("run_bash_command.hitl.title"),
)
def main(
    command: str, timeout_seconds: int = 30, workroot: Path | None = None
) -> str | ToolOutput:
    """Run one bash command from the injected workspace root."""
    if not command.strip():
        return _error("empty_command")
    if timeout_seconds <= 0:
        return _error("invalid_timeout", timeout_seconds=timeout_seconds)

    cwd = _workspace_root(workroot=workroot).resolve()
    try:
        completed = subprocess.run(
            command,
            shell=True,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as error:
        return ToolOutput(
            result=_error(
                "timeout",
                timeout_seconds=timeout_seconds,
                stdout=_clip_output(_normalize_timeout_output(error.stdout)),
                stderr=_clip_output(_normalize_timeout_output(error.stderr)),
            ),
            metadata=format_tool_metadata(
                {"cwd": cwd, "timeout": True, "timeout_seconds": timeout_seconds}
            ),
        )
    except OSError as error:
        return _error("execution_failed", error=error)

    return ToolOutput(
        result=_render_result(
            cwd=cwd,
            exit_code=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        ),
        metadata=format_tool_metadata(
            {
                "cwd": cwd,
                "exit_code": completed.returncode,
                "timeout": False,
            }
        ),
    )


def _normalize_timeout_output(value: str | bytes | None) -> str:
    """Normalize partial timeout output captured by subprocess."""
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode(encoding="utf-8", errors="replace")
    return value
