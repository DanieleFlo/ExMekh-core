"""Create an invocation-local dynamic text pipeline."""

from __future__ import annotations

from agent_wiki.backend.core.capabilities.tool import sign_tool
from agent_wiki.backend.interface.dynamic_pipeline import (
    DynamicPipelineRuntimeInterface,
)
from agent_wiki.configs.text_catalog import get_capability_text


@sign_tool(short_description=get_capability_text("descriptions.create_pipeline"))
def main(
    name: str,
    kind: str,
    steps: list[dict[str, str]],
    carry_outputs: bool = False,
    success_message: str = "Loop executed successfully.",
    output_prefix: str = "<output>",
    output_suffix: str = "</output>",
    dynamic_pipeline_runtime: DynamicPipelineRuntimeInterface | None = None,
) -> str:
    """Validate and register one temporary text-to-text pipeline."""
    if dynamic_pipeline_runtime is None:
        return "Error: dynamic pipeline runtime is not available."
    try:
        return dynamic_pipeline_runtime.create_pipeline(
            name=name,
            kind=kind,
            steps=steps,
            carry_outputs=carry_outputs,
            success_message=success_message,
            output_prefix=output_prefix,
            output_suffix=output_suffix,
        )
    except (TypeError, ValueError) as error:
        return f"Error: {error}"
