from __future__ import annotations

from pathlib import Path

from agent_wiki.backend.core.capabilities.capability_roots import (
    build_workroot_capabilities_root,
)
from agent_wiki.backend.core.capabilities.tool import sign_tool
from agent_wiki.configs.settings import SystemConfig


def _workspace_root(*, workroot: Path | None) -> Path:
    return workroot if workroot is not None else Path(__file__).resolve().parents[7]


@sign_tool(
    short_description="Returns the workspace and capability roots together with the currently visible capabilities."
)
def main(
    current_skill: str | None = None,
    available_tools: list[str] | None = None,
    workroot: Path | None = None,
) -> dict[str, object]:
    workspace_root = _workspace_root(workroot=workroot)
    capabilities_root = (
        workspace_root / "src" / "agent_wiki" / "backend" / "capabilities"
    )
    bridge_root = build_workroot_capabilities_root(
        config=SystemConfig().config,
        workroot=workspace_root,
    )
    return {
        "workspace_root": str(workspace_root),
        "capabilities_root": str(capabilities_root),
        "workroot_capabilities_root": str(bridge_root)
        if bridge_root is not None
        else None,
        "skills_path": str(capabilities_root / "skills"),
        "tools_path": str(capabilities_root / "tools"),
        "exit_skills_path": str(capabilities_root / "exit-skills"),
        "wiki_root": str(workspace_root / "wiki"),
        "current_skill": current_skill,
        "visible_capabilities": available_tools or [],
    }
