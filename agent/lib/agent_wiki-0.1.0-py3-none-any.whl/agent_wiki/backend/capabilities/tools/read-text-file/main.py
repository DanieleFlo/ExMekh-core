from __future__ import annotations
from pathlib import Path
from .script.utils import _resolve_path
from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(
    short_description="Read a UTF-8 text file relative to the injected workspace root."
)
def main(path: str, workroot: Path | None = None) -> str:
    """Read one text file from the workspace using the injected workroot."""
    try:
        target = _resolve_path(path, workroot=workroot)
        content = target.read_text(encoding="utf-8")
        return ToolOutput(
            result=content,
            metadata=format_tool_metadata(
                {
                    "path": target,
                    "bytes": len(content.encode("utf-8")),
                    "lines": len(content.splitlines()),
                    "source_kind": "text_file",
                }
            ),
        )
    except Exception as error:
        return _error("read_failed", error=error)
