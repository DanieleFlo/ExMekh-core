from pathlib import Path


def _resolve_path(path: str, workroot: Path | None = None) -> Path:
    workspace_root = workroot if workroot is not None else Path().cwd()
    candidate = Path(path)
    if candidate.is_absolute():
        return candidate

    direct = workspace_root / candidate
    if direct.exists() or direct.suffix:
        return direct

    parts = candidate.parts
    if parts and parts[0] == "agent_wiki":
        stripped = Path(*parts[1:])
        if stripped.parts:
            return workspace_root / stripped

    return direct
