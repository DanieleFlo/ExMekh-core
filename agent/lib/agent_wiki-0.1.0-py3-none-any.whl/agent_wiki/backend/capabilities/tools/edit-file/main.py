from __future__ import annotations

from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.text_catalog import get_capability_text


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _workspace_root(*, workroot: Path | None) -> Path:
    """Return the workspace root used by the tool."""
    return workroot if workroot is not None else Path.cwd()


def _resolve_path(path: str, *, workroot: Path | None) -> Path:
    """Resolve a path and ensure it stays inside the workspace root."""
    workspace_root = _workspace_root(workroot=workroot).resolve()
    candidate = Path(path)
    target = candidate if candidate.is_absolute() else workspace_root / candidate
    resolved_target = target.resolve()
    resolved_target.relative_to(workspace_root)
    return resolved_target


def _count_matches(content: str, old_text: str) -> int:
    """Return the number of non-overlapping exact text matches."""
    return content.count(old_text)


@sign_tool(
    short_description=(
        "Edit a UTF-8 workspace text file by replacing one exact text section."
    ),
    reusable_input_fields=("old_text", "new_text"),
)
def main(
    path: str,
    old_text: str,
    new_text: str,
    workroot: Path | None = None,
) -> str | ToolOutput:
    """Replace one exact text section in an existing workspace file."""
    if not old_text:
        return _error("empty_old_text")

    try:
        target = _resolve_path(path, workroot=workroot)
    except Exception as error:
        return _error("resolve_path", path=path, error=error)

    if not target.exists():
        return _error("path_not_found", path=target)

    if target.is_dir():
        return _error("path_is_directory", path=target)

    try:
        content = target.read_text(encoding="utf-8")
    except UnicodeDecodeError as error:
        return _error("decode_failed", path=target, error=error)
    except OSError as error:
        return _error("read_failed", path=target, error=error)

    match_count = _count_matches(content, old_text)
    if match_count == 0:
        return _error("no_match", path=target)
    if match_count > 1:
        return _error("multiple_matches", path=target, count=match_count)

    edited_content = content.replace(old_text, new_text, 1)

    try:
        target.write_text(edited_content, encoding="utf-8")
    except OSError as error:
        return _error("write_failed", path=target, error=error)

    return ToolOutput(
        result=get_capability_text(
            "edit_file.success.replaced_text",
            target=target,
            old_length=len(old_text),
            new_length=len(new_text),
        ),
        metadata=format_tool_metadata(
            {
                "path": target,
                "old_characters": len(old_text),
                "new_characters": len(new_text),
                "replacements": 1,
            }
        ),
    )
