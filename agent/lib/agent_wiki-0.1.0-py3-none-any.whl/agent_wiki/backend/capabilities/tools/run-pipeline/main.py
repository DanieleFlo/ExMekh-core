"""Run an invocation-local dynamic text pipeline."""

from __future__ import annotations

from agent_wiki.backend.core.capabilities.tool import sign_tool
from agent_wiki.backend.interface.dynamic_pipeline import (
    DynamicPipelineRuntimeInterface,
)
from agent_wiki.configs.text_catalog import get_capability_text


@sign_tool(
    short_description=get_capability_text("descriptions.run_pipeline"),
    reusable_input_fields=("message", "static_text"),
)
def main(
    name: str,
    message: str | None = None,
    messages: list[str] | None = None,
    static_text: str | None = None,
    dynamic_pipeline_runtime: DynamicPipelineRuntimeInterface | None = None,
) -> str:
    """Execute or resume one registered dynamic pipeline."""
    if dynamic_pipeline_runtime is None:
        return "Error: dynamic pipeline runtime is not available."
    try:
        return dynamic_pipeline_runtime.run_pipeline(
            name=name,
            message=message,
            messages=messages,
            static_text=static_text,
        )
    except (RuntimeError, TypeError, ValueError) as error:
        return f"Error: {error}"
