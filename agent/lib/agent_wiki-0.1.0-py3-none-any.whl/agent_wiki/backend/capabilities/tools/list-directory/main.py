from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _workspace_root(*, workroot: Path | None) -> Path:
    """Return the workspace root used by the tool."""
    return workroot if workroot is not None else Path.cwd()


def _resolve_path(path: str, *, workroot: Path | None) -> Path:
    """Resolve a path and ensure it stays inside the workspace root."""
    workspace_root = _workspace_root(workroot=workroot).resolve()
    candidate = Path(path)
    target = candidate if candidate.is_absolute() else workspace_root / candidate
    resolved_target = target.resolve()
    resolved_target.relative_to(workspace_root)
    return resolved_target


@sign_tool(
    short_description="Lists only files and directories directly under a path (no recursion)."
)
def main(
    path: str = ".", workroot: Path | None = None
) -> dict[str, object] | ToolOutput:
    """List direct filesystem entries under a workspace-relative path."""
    try:
        target = _resolve_path(path, workroot=workroot)
    except Exception as error:
        return {
            "path": path,
            "exists": False,
            "entries": [],
            "error": _error("resolve_path", path=path, error=error),
        }

    if not target.exists():
        return {
            "path": str(target),
            "exists": False,
            "entries": [],
            "error": _error("path_not_found", path=target),
        }

    if target.is_file():
        payload = {
            "path": str(target),
            "exists": True,
            "kind": "file",
            "entries": [
                {
                    "name": target.name,
                    "path": str(target),
                    "kind": "file",
                }
            ],
        }
        return ToolOutput(
            result=json.dumps(payload, ensure_ascii=False),
            metadata=format_tool_metadata(
                {"path": target, "kind": "file", "entries": 1}
            ),
        )

    try:
        children = sorted(target.iterdir())
    except OSError as error:
        return {
            "path": str(target),
            "exists": True,
            "kind": "directory",
            "entries": [],
            "error": _error("list_failed", path=target, error=error),
        }

    entries = [
        {
            "name": child.name,
            "path": str(child),
            "kind": "directory" if child.is_dir() else "file",
        }
        for child in children
    ]

    payload = {
        "path": str(target),
        "exists": True,
        "kind": "directory",
        "entries": entries,
    }
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {"path": target, "kind": "directory", "entries": len(entries)}
        ),
    )
