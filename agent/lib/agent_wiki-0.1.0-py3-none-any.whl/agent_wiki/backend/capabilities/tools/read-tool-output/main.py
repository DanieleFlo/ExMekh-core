from __future__ import annotations

from typing import Any, Mapping

import yaml

from agent_wiki.backend.core.capabilities.tool import (
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.backend.core.outputs.tool_output_memory import StoredToolOutput
from agent_wiki.backend.core.outputs.tool_output_records import collect_tool_output_records
from agent_wiki.configs.text_catalog import get_capability_text


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _normalize_id_list(
    *, tool_output_id: str | None, tool_output_ids: list[str] | None
) -> tuple[list[str] | None, str | None]:
    """Normalize single-id and multi-id lookup arguments."""
    if tool_output_id is not None:
        if not isinstance(tool_output_id, str) or not tool_output_id.strip():
            return None, _error("empty_tool_output_id")
        return [tool_output_id.strip()], None

    if tool_output_ids is None:
        return None, None
    if not isinstance(tool_output_ids, list) or not tool_output_ids:
        return None, _error("empty_tool_output_ids")
    normalized_ids: list[str] = []
    for item in tool_output_ids:
        if not isinstance(item, str) or not item.strip():
            return None, _error("invalid_tool_output_ids")
        normalized_ids.append(item.strip())
    return normalized_ids, None


def _select_by_ids(
    *, records: list[StoredToolOutput], requested_ids: list[str]
) -> tuple[list[StoredToolOutput], list[str]]:
    """Select records by visible ids while preserving the requested id order."""
    records_by_id = {record.visible_tool_call_id: record for record in records}
    selected: list[StoredToolOutput] = []
    missing_ids: list[str] = []
    for requested_id in requested_ids:
        record = records_by_id.get(requested_id)
        if record is None:
            missing_ids.append(requested_id)
            continue
        selected.append(record)
    return selected, missing_ids


def _format_result(records: list[StoredToolOutput]) -> str:
    """Render selected output records as model-facing YAML."""
    payload = {
        "matches": len(records),
        "outputs": [
            {
                "tool_call_id": record.visible_tool_call_id,
                "tool_name": record.tool_name or "",
                "content": record.content,
            }
            for record in records
        ],
    }
    return yaml.safe_dump(payload, sort_keys=False, default_flow_style=False).strip()


@sign_tool(short_description=get_capability_text("descriptions.read_tool_output"))
def main(
    tool_output_id: str | None = None,
    tool_output_ids: list[str] | None = None,
    tool_name: str | None = None,
    chat_history: list[dict[str, Any]] | None = None,
    tool_output_awareness: Mapping[str, Any] | None = None,
    tool_output_description_token_limit: int | None = None,
    tool_output_ignored_tools: list[str] | None = None,
) -> str:
    """Return full reusable tool-output content by visible id, ids, or tool name."""
    requested_ids, id_error = _normalize_id_list(
        tool_output_id=tool_output_id,
        tool_output_ids=tool_output_ids,
    )
    if id_error is not None:
        return id_error

    normalized_tool_name = tool_name.strip() if isinstance(tool_name, str) else None
    if tool_name is not None and not normalized_tool_name:
        return _error("empty_tool_name")

    active_modes = sum(
        [
            tool_output_id is not None,
            tool_output_ids is not None,
            normalized_tool_name is not None,
        ]
    )
    if active_modes != 1:
        return _error("exclusive_lookup")

    records = collect_tool_output_records(
        chat_history=chat_history,
        tool_output_awareness=tool_output_awareness,
        description_token_limit=(
            tool_output_description_token_limit
            if isinstance(tool_output_description_token_limit, int)
            else 10
        ),
        ignored_tools=tool_output_ignored_tools,
    )

    if requested_ids is not None:
        selected, missing_ids = _select_by_ids(
            records=records, requested_ids=requested_ids
        )
        if missing_ids:
            return _error("unknown_tool_output_ids", joined_ids=", ".join(missing_ids))
        return _format_result(selected)

    selected_by_name = [
        record for record in records if record.tool_name == normalized_tool_name
    ]
    if not selected_by_name:
        return _error("unknown_tool_name", tool_name=normalized_tool_name)
    return _format_result(selected_by_name)
