"""Private helpers shared by builtin capability implementations."""
