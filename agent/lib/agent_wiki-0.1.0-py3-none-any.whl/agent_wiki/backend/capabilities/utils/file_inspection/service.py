"""Secure orchestration service for workspace-relative file inspection."""

from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import stat
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from agent_wiki.configs.runtime import FileInspectionConfig

from .analyzers import AnalyzerRegistry, DeferredFileAnalyzer, UnsupportedAnalyzer
from .cache import FilesystemFilePreprocessingCache
from .interfaces import FilePreprocessingCacheInterface, ImageToTextInterface
from .models import (
    AnalyzerResult,
    CacheLookup,
    FileFingerprint,
    FileInspectionContext,
    FileInspectionReport,
)
from .ocr import GraniteDoclingImageToText


class FileInspectionError(RuntimeError):
    """Represent a safe model-facing file inspection failure."""


class FileInspectionService:
    """Resolve, classify, inspect, cache, and report one workspace file."""

    def __init__(
        self,
        *,
        workroot: Path,
        config: FileInspectionConfig,
        registry: AnalyzerRegistry | None = None,
        image_to_text: ImageToTextInterface | None = None,
        cache: FilePreprocessingCacheInterface | None = None,
    ) -> None:
        """Initialize the service with one immutable workspace boundary."""
        self.workroot = workroot.resolve()
        self.config = config
        resolved_image_to_text = image_to_text
        if registry is None and resolved_image_to_text is None:
            resolved_image_to_text = GraniteDoclingImageToText(
                model_name=config.ocr_model,
                device=config.ocr_device,
                cache_directory=self._resolve_cache_directory(
                    config.model_cache_directory
                ),
                max_new_tokens=config.ocr_max_new_tokens,
            )
        self.registry = registry or AnalyzerRegistry.build_default(
            image_to_text=resolved_image_to_text
        )
        cache_directory = self._resolve_cache_directory(config.cache_directory)
        self.cache = cache or FilesystemFilePreprocessingCache(
            directory=cache_directory,
            max_bytes=config.cache_max_bytes,
            entry_max_bytes=config.cache_entry_max_bytes,
        )

    def inspect(self, path: str) -> FileInspectionReport:
        """Return generic metadata and bounded type-specific analysis."""
        target, relative_path, is_symlink = self._resolve_file(path)
        file_stat = target.stat()
        extension = _normalized_extension(target)
        mime_type = mimetypes.guess_type(target.name, strict=False)[0]
        context = FileInspectionContext(
            path=target,
            relative_path=relative_path,
            extension=extension,
            mime_type=mime_type,
            size_bytes=file_stat.st_size,
            config=self.config,
        )
        analyzer = self.registry.select(context)
        fingerprint = self._fingerprint(
            context=context,
            analyzer_id=analyzer.descriptor.analyzer_id,
            analyzer_version=analyzer.descriptor.version,
            processor_identity=str(
                getattr(analyzer, "processor_identity", "")
            ),
            file_stat=file_stat,
        )
        warnings: list[str] = []
        cache_status = "not_applicable"
        cached_preprocessing = None
        result: AnalyzerResult

        should_preanalyze = (
            context.size_bytes <= self.config.preanalysis_max_bytes
            or isinstance(analyzer, (DeferredFileAnalyzer, UnsupportedAnalyzer))
        )
        if not should_preanalyze:
            result = AnalyzerResult(
                status="skipped_limit",
                format_name=_fallback_format(extension),
                warnings=("File size exceeds the configured preanalysis limit.",),
            )
        elif isinstance(analyzer, (DeferredFileAnalyzer, UnsupportedAnalyzer)):
            result = analyzer.analyze(context)
        else:
            try:
                lookup = self.cache.get(fingerprint)
            except Exception:
                lookup = CacheLookup(status="unavailable")
                warnings.append(
                    "The inspection cache is unavailable; analysis continued."
                )
            cache_status = lookup.status
            if lookup.analysis is not None:
                cached_preprocessing = lookup.preprocessing
                result = AnalyzerResult(
                    status="complete",
                    analysis=lookup.analysis,
                    format_name=lookup.format_name,
                    warnings=lookup.warnings,
                )
            else:
                try:
                    result = analyzer.analyze(context)
                except Exception as error:
                    result = AnalyzerResult(
                        status="failed",
                        format_name=_fallback_format(extension),
                        warnings=(
                            "Format-specific analysis failed: "
                            f"{type(error).__name__}: "
                            f"{_safe_error_text(error, target=target, relative_path=relative_path)}",
                        ),
                    )
                if result.status == "complete":
                    try:
                        stored = self.cache.put(fingerprint, result)
                        cache_status = f"{cache_status}_{stored}"
                    except Exception:
                        cache_status = f"{cache_status}_not_stored_unavailable"
                        warnings.append(
                            "The inspection cache could not store this completed analysis."
                        )

        warnings.extend(result.warnings)
        analysis = dict(result.analysis)
        if (
            result.status == "complete"
            and analyzer.descriptor.analyzer_id in {"pdf", "image"}
        ):
            preprocessing = cached_preprocessing or result.preprocessing
            stored = cache_status == "hit" or cache_status.endswith("_stored")
            analysis["artifacts_available"] = stored
            analysis["preprocessing_cached"] = stored
            analysis["cached_artifacts"] = (
                len(preprocessing.artifacts) if stored and preprocessing else 0
            )
        total_lines = analysis.get("total_lines")
        if result.status == "complete" and not isinstance(total_lines, int):
            warnings.append(
                "Physical line count is unavailable for this non-textual format."
            )
        payload = {
            "path": relative_path,
            "name": target.name,
            "extension": extension or None,
            "extensions": [suffix.casefold() for suffix in target.suffixes],
            "mime_type": mime_type,
            "family": analyzer.descriptor.family,
            "format": result.format_name or _fallback_format(extension),
            "analyzer": analyzer.descriptor.analyzer_id,
            "size": {
                "bytes": file_stat.st_size,
                "human": _human_size(file_stat.st_size),
            },
            "timestamps": _timestamps(file_stat),
            "permissions": {
                "mode": stat.filemode(file_stat.st_mode),
                "octal": format(stat.S_IMODE(file_stat.st_mode), "04o"),
                "readable": os.access(target, os.R_OK),
                "writable": os.access(target, os.W_OK),
                "executable": os.access(target, os.X_OK),
            },
            "filesystem": {
                "is_symlink": is_symlink,
                "link_count": file_stat.st_nlink,
                "owner_uid": getattr(file_stat, "st_uid", None),
                "owner_gid": getattr(file_stat, "st_gid", None),
            },
            "analysis_status": result.status,
            "analysis": analysis,
            "warnings": warnings,
            "limits": {
                "preanalysis_max_bytes": self.config.preanalysis_max_bytes,
                "expanded_max_bytes": self.config.expanded_max_bytes,
                "pdf_max_pages": self.config.pdf_max_pages,
                "pdf_native_text_min_chars": self.config.pdf_native_text_min_chars,
                "image_max_frames": self.config.image_max_frames,
                "ocr_language": self.config.ocr_language,
                "ocr_model": self.config.ocr_model,
                "ocr_max_new_tokens": self.config.ocr_max_new_tokens,
                "ocr_device": self.config.ocr_device,
                "max_symbols": self.config.max_symbols,
                "max_columns": self.config.max_columns,
                "max_sheets": self.config.max_sheets,
                "max_archive_entry_names": self.config.max_archive_entry_names,
                "max_list_items": self.config.max_list_items,
            },
            "cache": {"status": cache_status},
        }
        if isinstance(total_lines, int):
            payload["total_lines"] = total_lines
        return FileInspectionReport(
            payload=payload,
            model_cache_directory=self.model_cache_directory(),
        )

    def get_cached_preprocessing(self, path: str) -> CacheLookup:
        """Return reusable preprocessing without running the analyzer on a miss."""
        target, relative_path, _ = self._resolve_file(path)
        file_stat = target.stat()
        context = FileInspectionContext(
            path=target,
            relative_path=relative_path,
            extension=_normalized_extension(target),
            mime_type=mimetypes.guess_type(target.name, strict=False)[0],
            size_bytes=file_stat.st_size,
            config=self.config,
        )
        analyzer = self.registry.select(context)
        fingerprint = self._fingerprint(
            context=context,
            analyzer_id=analyzer.descriptor.analyzer_id,
            analyzer_version=analyzer.descriptor.version,
            processor_identity=str(
                getattr(analyzer, "processor_identity", "")
            ),
            file_stat=file_stat,
        )
        try:
            return self.cache.get(fingerprint)
        except Exception:
            return CacheLookup(status="unavailable")

    def model_cache_directory(self) -> Path:
        """Return the workroot-confined cache used by lazy inspection models."""
        return self._resolve_cache_directory(self.config.model_cache_directory)

    def _resolve_file(self, path: str) -> tuple[Path, str, bool]:
        """Resolve one path and reject escapes, directories, and special files."""
        if not isinstance(path, str) or not path.strip():
            raise FileInspectionError("Path must contain non-space text.")
        candidate = Path(path.strip())
        unresolved = candidate if candidate.is_absolute() else self.workroot / candidate
        is_symlink = unresolved.is_symlink()
        try:
            target = unresolved.resolve(strict=True)
            target.relative_to(self.workroot)
        except FileNotFoundError as error:
            raise FileInspectionError("The requested path does not exist.") from error
        except ValueError as error:
            raise FileInspectionError(
                "Path must remain inside the injected workroot."
            ) from error
        target_stat = target.stat()
        if not stat.S_ISREG(target_stat.st_mode):
            if target.is_dir():
                raise FileInspectionError(
                    "The requested path is a directory, not a file."
                )
            raise FileInspectionError("The requested path is not a regular file.")
        return target, target.relative_to(self.workroot).as_posix(), is_symlink

    def _resolve_cache_directory(self, value: Path | str) -> Path:
        """Resolve cache storage and keep it inside the active workroot."""
        candidate = Path(value)
        unresolved = candidate if candidate.is_absolute() else self.workroot / candidate
        resolved = unresolved.resolve()
        try:
            resolved.relative_to(self.workroot)
        except ValueError as error:
            raise FileInspectionError(
                "File inspection cache directory must remain inside the workroot."
            ) from error
        return resolved

    def _fingerprint(
        self,
        *,
        context: FileInspectionContext,
        analyzer_id: str,
        analyzer_version: int,
        processor_identity: str,
        file_stat: os.stat_result,
    ) -> FileFingerprint:
        """Build a cache fingerprint from file state and analysis settings."""
        signature_values = asdict(self.config)
        for name in (
            "cache_directory",
            "model_cache_directory",
            "cache_max_bytes",
            "cache_entry_max_bytes",
            "max_list_items",
        ):
            signature_values.pop(name, None)
        signature_values["processor_identity"] = processor_identity
        config_signature = hashlib.sha256(
            json.dumps(
                signature_values,
                sort_keys=True,
                default=str,
                separators=(",", ":"),
            ).encode("utf-8")
        ).hexdigest()
        return FileFingerprint(
            relative_path=context.relative_path,
            size_bytes=context.size_bytes,
            modified_ns=file_stat.st_mtime_ns,
            changed_ns=file_stat.st_ctime_ns,
            analyzer_id=analyzer_id,
            analyzer_version=analyzer_version,
            config_signature=config_signature,
        )


def _normalized_extension(path: Path) -> str:
    """Return a lower-case extension, preserving compound TAR suffixes."""
    lowered = path.name.casefold()
    if lowered.endswith(".tar.gz"):
        return ".tar.gz"
    if not path.suffix and lowered.startswith("."):
        return lowered
    return path.suffix.casefold()


def _fallback_format(extension: str) -> str:
    """Return an extension-derived format name for generic statuses."""
    return extension.lstrip(".").replace(".", "_") or "unknown"


def _human_size(size_bytes: int) -> str:
    """Render bytes with decimal SI units as requested by the public schema."""
    value = float(size_bytes)
    for unit in ("B", "kB", "MB", "GB"):
        if value < 1000 or unit == "GB":
            return f"{int(value)} {unit}" if unit == "B" else f"{value:.2f} {unit}"
        value /= 1000
    return f"{value:.2f} GB"


def _timestamps(file_stat: os.stat_result) -> dict[str, str | None]:
    """Return portable UTC timestamps without mislabeling POSIX ctime."""
    birth_time = getattr(file_stat, "st_birthtime", None)
    return {
        "created_at": _iso_timestamp(birth_time) if birth_time is not None else None,
        "modified_at": _iso_timestamp(file_stat.st_mtime),
        "accessed_at": _iso_timestamp(file_stat.st_atime),
        "metadata_changed_at": _iso_timestamp(file_stat.st_ctime),
    }


def _iso_timestamp(value: float) -> str:
    """Render one filesystem timestamp as an ISO-8601 UTC value."""
    return datetime.fromtimestamp(value, timezone.utc).isoformat()


def _safe_error_text(
    error: Exception,
    *,
    target: Path,
    relative_path: str,
) -> str:
    """Remove the absolute workspace path from an analyzer error message."""
    return str(error).replace(str(target), relative_path)
