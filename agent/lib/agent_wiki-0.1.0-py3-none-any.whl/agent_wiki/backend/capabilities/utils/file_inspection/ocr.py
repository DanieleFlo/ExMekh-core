"""Replaceable image-to-text backends for file preprocessing."""

from __future__ import annotations

import importlib
import io
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Any

from PIL import Image

from .interfaces import ImageToTextInterface


class ImageToTextError(RuntimeError):
    """Represent an observable image-to-text backend failure."""


class GraniteDoclingImageToText(ImageToTextInterface):
    """Extract structured document text with IBM Granite-Docling-258M."""

    def __init__(
        self,
        *,
        model_name: str = "ibm-granite/granite-docling-258M",
        device: str = "auto",
        cache_directory: Path | None = None,
        max_new_tokens: int = 4096,
    ) -> None:
        """Configure lazy supported Transformers inference and model caching."""
        if max_new_tokens < 1:
            raise ValueError("OCR generation token limit must be positive.")
        self.model_name = model_name
        self.requested_device = device.casefold()
        self.cache_directory = cache_directory
        self.max_new_tokens = max_new_tokens
        self._runtime: tuple[Any, Any, Any, str, Any] | None = None
        self._load_lock = threading.Lock()
        self._inference_lock = threading.Lock()

    @property
    def identity(self) -> str:
        """Return the model and inference settings used by fingerprints."""
        return (
            f"granite-docling-v1:{self.model_name}:"
            f"{self.requested_device}:{self.max_new_tokens}"
        )

    def extract_text(self, image_png: bytes, *, language: str) -> str:
        """Convert one page image to ordered Markdown-compatible text."""
        del language
        try:
            with Image.open(io.BytesIO(image_png)) as source:
                image = source.convert("RGB")
        except Exception as error:
            raise ImageToTextError(
                f"Granite Docling received an invalid PNG: {type(error).__name__}."
            ) from error
        processor, model, torch, device, dtype = self._get_runtime()
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image"},
                    {"type": "text", "text": "Convert this page to docling."},
                ],
            }
        ]
        try:
            prompt = processor.apply_chat_template(
                messages,
                add_generation_prompt=True,
            )
            inputs = processor(
                text=prompt,
                images=[image],
                return_tensors="pt",
            )
            prepared = {
                name: value.to(device=device, dtype=dtype)
                if value.is_floating_point()
                else value.to(device)
                for name, value in inputs.items()
            }
            with self._inference_lock, torch.inference_mode():
                output_ids = model.generate(
                    **prepared,
                    max_new_tokens=self.max_new_tokens,
                )
            prompt_length = int(prepared["input_ids"].shape[1])
            generated_ids = output_ids[:, prompt_length:]
            doctags = processor.batch_decode(
                generated_ids,
                skip_special_tokens=False,
            )[0].lstrip()
            text = self._doctags_to_markdown(
                doctags=doctags,
                image=image,
                processor=processor,
                generated_ids=generated_ids,
            )
        except Exception as error:
            raise ImageToTextError(
                "Granite Docling inference failed: "
                f"{type(error).__name__}: {_bounded_error_detail(error)}."
            ) from error
        if not text:
            raise ImageToTextError("Granite Docling returned no extracted text.")
        return text

    def _get_runtime(self) -> tuple[Any, Any, Any, str, Any]:
        """Load the processor and model exactly once on first OCR use."""
        if self._runtime is None:
            with self._load_lock:
                if self._runtime is None:
                    self._runtime = self._load_runtime()
        return self._runtime

    def _load_runtime(self) -> tuple[Any, Any, Any, str, Any]:
        """Load the official Transformers model on the configured local device."""
        try:
            import torch
            from transformers import AutoModelForMultimodalLM, AutoProcessor

            cache_path = self.cache_directory
            if cache_path is not None:
                cache_path.mkdir(parents=True, exist_ok=True)
            device = self._resolve_device(torch)
            dtype = torch.bfloat16 if device == "cuda" else torch.float32
            processor = AutoProcessor.from_pretrained(
                self.model_name,
                cache_dir=cache_path,
                backend="pil",
            )
            model = AutoModelForMultimodalLM.from_pretrained(
                self.model_name,
                dtype=dtype,
                cache_dir=cache_path,
                attn_implementation="sdpa",
            ).to(device)
            model.eval()
        except Exception as error:
            raise ImageToTextError(
                f"Granite Docling model '{self.model_name}' could not be loaded: "
                f"{type(error).__name__}: {_bounded_error_detail(error)}."
            ) from error
        return processor, model, torch, device, dtype

    def _resolve_device(self, torch: Any) -> str:
        """Resolve auto device selection without requiring an accelerator."""
        if self.requested_device != "auto":
            return self.requested_device
        if torch.cuda.is_available():
            return "cuda"
        if torch.backends.mps.is_available():
            return "mps"
        return "cpu"

    @staticmethod
    def _doctags_to_markdown(
        *,
        doctags: str,
        image: Image.Image,
        processor: Any,
        generated_ids: Any,
    ) -> str:
        """Convert DocTags to Markdown, with a plain decoded-text fallback."""
        try:
            from docling_core.types.doc import DoclingDocument
            from docling_core.types.doc.document import DocTagsDocument

            doctags_document = DocTagsDocument.from_doctags_and_image_pairs(
                [doctags],
                [image],
            )
            document = DoclingDocument.load_from_doctags(
                doctags_document,
                document_name="Document",
            )
            return document.export_to_markdown().strip()
        except Exception:
            return processor.batch_decode(
                generated_ids,
                skip_special_tokens=True,
            )[0].strip()


class OpenVINOImageToText(ImageToTextInterface):
    """Extract document text with a lazy OpenVINO-compiled LightOnOCR model."""

    def __init__(
        self,
        *,
        model_name: str = "lightonai/LightOnOCR-2-1B",
        device: str = "CPU",
        cache_directory: Path | None = None,
        max_new_tokens: int = 4096,
    ) -> None:
        """Configure lazy local inference and workroot-confined model caches."""
        if max_new_tokens < 1:
            raise ValueError("OCR generation token limit must be positive.")
        self.model_name = model_name
        self.device = device.upper()
        self.cache_directory = cache_directory
        self.max_new_tokens = max_new_tokens
        self._runtime: tuple[Any, Any, Any, Any] | None = None
        self._openvino_enabled = True
        self._load_lock = threading.Lock()
        self._inference_lock = threading.Lock()

    @property
    def identity(self) -> str:
        """Return the model and runtime settings used by cache fingerprints."""
        return (
            f"openvino-lightonocr-v2:{self.model_name}:"
            f"{self.device}:{self.max_new_tokens}"
        )

    def extract_text(self, image_png: bytes, *, language: str) -> str:
        """Decode one PNG and return naturally ordered model-generated text."""
        del language
        try:
            with Image.open(io.BytesIO(image_png)) as source:
                image = source.convert("RGB")
        except Exception as error:
            raise ImageToTextError(
                f"OpenVINO OCR received an invalid PNG: {type(error).__name__}."
            ) from error
        processor, model, torch, eager_forward = self._get_runtime()
        conversation = [
            {"role": "user", "content": [{"type": "image", "image": image}]}
        ]
        try:
            inputs = processor.apply_chat_template(
                conversation,
                add_generation_prompt=True,
                tokenize=True,
                return_dict=True,
                return_tensors="pt",
            )
            prepared = {
                name: value.to(dtype=torch.float32)
                if value.is_floating_point()
                else value
                for name, value in inputs.items()
            }
            with self._inference_lock:
                output_ids = self._generate(
                    model=model,
                    torch=torch,
                    prepared=prepared,
                    eager_forward=eager_forward,
                )
            prompt_length = int(prepared["input_ids"].shape[1])
            generated_ids = output_ids[0, prompt_length:]
            text = processor.decode(
                generated_ids,
                skip_special_tokens=True,
            ).strip()
        except Exception as error:
            raise ImageToTextError(
                "OpenVINO OCR inference failed: "
                f"{type(error).__name__}: {_bounded_error_detail(error)}."
            ) from error
        if not text:
            raise ImageToTextError("OpenVINO OCR returned no extracted text.")
        return text

    def _generate(
        self,
        *,
        model: Any,
        torch: Any,
        prepared: dict[str, Any],
        eager_forward: Any,
    ) -> Any:
        """Generate with OpenVINO first and retry once through eager PyTorch."""
        try:
            with torch.inference_mode():
                return model.generate(
                    **prepared,
                    max_new_tokens=self.max_new_tokens,
                )
        except Exception as openvino_error:
            if not self._openvino_enabled:
                raise
            model.forward = eager_forward
            self._openvino_enabled = False
            try:
                with torch.inference_mode():
                    return model.generate(
                        **prepared,
                        max_new_tokens=self.max_new_tokens,
                    )
            except Exception as eager_error:
                openvino_detail = _bounded_error_detail(openvino_error)
                eager_detail = _bounded_error_detail(eager_error)
                raise RuntimeError(
                    "OpenVINO and eager OCR inference both failed; "
                    f"OpenVINO: {openvino_detail}; eager: {eager_detail}"
                ) from eager_error

    def _get_runtime(self) -> tuple[Any, Any, Any, Any]:
        """Load and compile the model once on first OCR use."""
        if self._runtime is None:
            with self._load_lock:
                if self._runtime is None:
                    self._runtime = self._load_runtime()
        return self._runtime

    def _load_runtime(self) -> tuple[Any, Any, Any, Any]:
        """Construct Transformers components and compile forward with OpenVINO."""
        try:
            importlib.import_module("openvino.torch")
            import torch
            from transformers import (
                LightOnOcrForConditionalGeneration,
                LightOnOcrProcessor,
            )

            cache_path = self.cache_directory
            if cache_path is not None:
                cache_path.mkdir(parents=True, exist_ok=True)
            processor = LightOnOcrProcessor.from_pretrained(
                self.model_name,
                cache_dir=cache_path,
            )
            model = LightOnOcrForConditionalGeneration.from_pretrained(
                self.model_name,
                dtype=torch.float32,
                cache_dir=cache_path,
            )
            model.eval()
            eager_forward = model.forward
            compile_options: dict[str, object] = {
                "device": self.device,
                "aot_autograd": True,
            }
            if cache_path is not None:
                openvino_cache = cache_path / "openvino"
                openvino_cache.mkdir(parents=True, exist_ok=True)
                compile_options.update(
                    {
                        "model_caching": True,
                        "cache_dir": str(openvino_cache),
                    }
                )
            model.forward = torch.compile(
                model.forward,
                backend="openvino",
                options=compile_options,
            )
        except Exception as error:
            raise ImageToTextError(
                f"OpenVINO OCR model '{self.model_name}' could not be loaded: "
                f"{type(error).__name__}."
            ) from error
        return processor, model, torch, eager_forward


class TesseractImageToText(ImageToTextInterface):
    """Extract UTF-8 text through the locally installed Tesseract CLI."""

    def __init__(self, *, command: str = "tesseract", timeout_seconds: int = 120) -> None:
        """Configure the executable name and bounded subprocess timeout."""
        self.command = command
        self.timeout_seconds = timeout_seconds

    @property
    def identity(self) -> str:
        """Return the stable implementation identity used by fingerprints."""
        return f"tesseract-cli-v1:{self.command}"

    def extract_text(self, image_png: bytes, *, language: str) -> str:
        """Extract text from PNG bytes or raise an observable backend error."""
        executable = shutil.which(self.command)
        if executable is None:
            raise ImageToTextError(
                f"Tesseract executable '{self.command}' is not installed or not on PATH."
            )
        self._validate_language(executable=executable, language=language)
        try:
            completed = subprocess.run(
                [executable, "stdin", "stdout", "-l", language],
                input=image_png,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
                timeout=self.timeout_seconds,
            )
        except subprocess.TimeoutExpired as error:
            raise ImageToTextError("Tesseract image extraction timed out.") from error
        except OSError as error:
            raise ImageToTextError(
                f"Tesseract could not be executed: {type(error).__name__}."
            ) from error
        if completed.returncode != 0:
            detail = completed.stderr.decode("utf-8", errors="replace").strip()
            raise ImageToTextError(
                f"Tesseract failed with exit code {completed.returncode}: "
                f"{detail or 'no diagnostic output'}"
            )
        text = completed.stdout.decode("utf-8", errors="replace").strip()
        if not text:
            raise ImageToTextError("Tesseract returned no extracted text.")
        return text

    def _validate_language(self, *, executable: str, language: str) -> None:
        """Verify the requested trained-data language before OCR begins."""
        try:
            completed = subprocess.run(
                [executable, "--list-langs"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
                timeout=min(self.timeout_seconds, 15),
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise ImageToTextError(
                "Tesseract languages could not be inspected."
            ) from error
        available = {
            line.strip()
            for line in completed.stdout.decode("utf-8", errors="replace").splitlines()
            if line.strip() and not line.casefold().startswith("list of available")
        }
        requested = {item for item in language.split("+") if item}
        missing = sorted(requested - available)
        if completed.returncode != 0 or missing:
            rendered = ", ".join(missing) if missing else language
            raise ImageToTextError(
                f"Tesseract language data is unavailable: {rendered}."
            )


def _bounded_error_detail(error: Exception, *, limit: int = 240) -> str:
    """Return one compact single-line diagnostic without unbounded output."""
    detail = " ".join(str(error).split())
    if not detail:
        detail = type(error).__name__
    return detail if len(detail) <= limit else f"{detail[: limit - 3]}..."
