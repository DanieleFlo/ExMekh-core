"""Behavior contracts used by the file-inspection capability."""

from __future__ import annotations

from abc import ABC, abstractmethod

from .models import (
    AnalyzerDescriptor,
    AnalyzerResult,
    CacheLookup,
    FileFingerprint,
    FileInspectionContext,
    SourceSymbol,
)


class FileAnalyzerInterface(ABC):
    """Define deterministic detection and analysis for one file family."""

    descriptor: AnalyzerDescriptor

    @abstractmethod
    def supports(self, context: FileInspectionContext) -> bool:
        """Return whether this analyzer owns the supplied file."""

    @abstractmethod
    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Return bounded type-specific information for the supplied file."""


class FilePreprocessingCacheInterface(ABC):
    """Define persistent lookup and storage for analyses and derived artifacts."""

    @abstractmethod
    def get(self, fingerprint: FileFingerprint) -> CacheLookup:
        """Return a completed cached analysis or a miss status."""

    @abstractmethod
    def put(
        self,
        fingerprint: FileFingerprint,
        result: AnalyzerResult,
    ) -> str:
        """Persist one completed analysis and return its cache status."""

    @abstractmethod
    def prune(self) -> None:
        """Evict least-recently-used entries until the cache is bounded."""


FileInspectionCacheInterface = FilePreprocessingCacheInterface


class ImageToTextInterface(ABC):
    """Define replaceable image-to-text extraction for PDF pages and images."""

    @property
    @abstractmethod
    def identity(self) -> str:
        """Return a stable backend identity included in cache fingerprints."""

    @abstractmethod
    def extract_text(self, image_png: bytes, *, language: str) -> str:
        """Extract text from one PNG image."""


class SourceParserInterface(ABC):
    """Define source parsing independently from a parser distribution."""

    @abstractmethod
    def parse_symbols(
        self,
        *,
        language: str,
        content: bytes,
        max_symbols: int,
    ) -> tuple[tuple[SourceSymbol, ...], dict[str, int], int, bool]:
        """Return hierarchy, counts, parse errors, and truncation state."""
