"""Deterministic analyzers for common workspace file families."""

from __future__ import annotations

import csv
import io
import json
import math
import re
import tarfile
import tomllib
import zipfile
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path, PurePosixPath
from typing import Any

import yaml
from charset_normalizer import from_bytes
from lxml import etree, html as lxml_html
from openpyxl import load_workbook
from PIL import Image, ImageOps

from .interfaces import (
    FileAnalyzerInterface,
    ImageToTextInterface,
    SourceParserInterface,
)
from .models import (
    AnalyzerDescriptor,
    AnalyzerResult,
    FileInspectionContext,
    FilePreprocessingResult,
    PreprocessingArtifact,
)
from .navigation import (
    content_region,
    markdown_navigation,
    markup_navigation,
    structured_navigation,
    table_navigation,
    total_physical_lines,
)
from .source import TreeSitterParserBackend
from .ocr import GraniteDoclingImageToText


_SOURCE_LANGUAGES = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".java": "java",
    ".c": "c",
    ".h": "c",
    ".cc": "cpp",
    ".cpp": "cpp",
    ".cxx": "cpp",
    ".hpp": "cpp",
    ".cs": "c_sharp",
    ".go": "go",
    ".rs": "rust",
    ".rb": "ruby",
    ".php": "php",
}
_IMAGE_EXTENSIONS = (
    ".avif",
    ".bmp",
    ".gif",
    ".heic",
    ".jpeg",
    ".jpg",
    ".png",
    ".svg",
    ".tif",
    ".tiff",
    ".webp",
)


class AnalyzerRegistry:
    """Select the first matching analyzer from an explicit precedence order."""

    def __init__(self, analyzers: tuple[FileAnalyzerInterface, ...]) -> None:
        """Store an immutable ordered analyzer collection."""
        self.analyzers = analyzers

    def select(self, context: FileInspectionContext) -> FileAnalyzerInterface:
        """Return the first analyzer that declares support for the file."""
        for analyzer in self.analyzers:
            if analyzer.supports(context):
                return analyzer
        raise RuntimeError("The analyzer registry has no fallback analyzer.")

    @classmethod
    def build_default(
        cls,
        *,
        image_to_text: ImageToTextInterface | None = None,
    ) -> "AnalyzerRegistry":
        """Build the production registry from most-specific to fallback."""
        extractor = image_to_text or GraniteDoclingImageToText()
        return cls(
            (
                PdfAnalyzer(image_to_text=extractor),
                ImageAnalyzer(image_to_text=extractor),
                SourceCodeAnalyzer(parser=TreeSitterParserBackend()),
                MarkdownAnalyzer(),
                StructuredDataAnalyzer(),
                MarkupAnalyzer(),
                DelimitedTableAnalyzer(),
                SpreadsheetAnalyzer(),
                ArchiveAnalyzer(),
                TextAnalyzer(),
                UnsupportedAnalyzer(),
            )
        )


class DeferredFileAnalyzer(FileAnalyzerInterface):
    """Recognize a deferred family without performing format-specific parsing."""

    descriptor = AnalyzerDescriptor("deferred", "deferred", (), ())

    def supports(self, context: FileInspectionContext) -> bool:
        """Match declared extensions or MIME types."""
        return _descriptor_supports(self.descriptor, context=context)

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Report that format-specific analysis is deliberately deferred."""
        return AnalyzerResult(
            status="not_implemented",
            format_name=_format_for(self.descriptor, context.extension),
            warnings=("Format-specific analysis is not implemented in this version.",),
        )


class PdfAnalyzer(FileAnalyzerInterface):
    """Render bounded PDF pages and extract reusable native or OCR text."""

    descriptor = AnalyzerDescriptor(
        "pdf", "document", ("pdf",), (".pdf",), ("application/pdf",), version=2
    )

    def __init__(self, *, image_to_text: ImageToTextInterface) -> None:
        """Initialize the PDF analyzer with one replaceable OCR backend."""
        self.image_to_text = image_to_text

    @property
    def processor_identity(self) -> str:
        """Return the preprocessing implementation identity."""
        return self.image_to_text.identity

    def supports(self, context: FileInspectionContext) -> bool:
        """Match PDF extensions or the standard PDF media type."""
        return _descriptor_supports(self.descriptor, context=context)

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Render every bounded page and extract ordered reusable text."""
        try:
            import fitz
        except ImportError as error:
            raise RuntimeError("PyMuPDF is required for PDF inspection.") from error
        document = fitz.open(context.path)
        try:
            page_count = int(document.page_count)
            if page_count <= 0:
                raise ValueError("PDF source has no pages.")
            if page_count > context.config.pdf_max_pages:
                return AnalyzerResult(
                    status="skipped_limit",
                    analysis={"page_count": page_count},
                    format_name="pdf",
                    warnings=(
                        "PDF page count exceeds the configured preanalysis limit.",
                    ),
                )
            page_texts: list[str] = []
            page_details: list[dict[str, Any]] = []
            artifacts: list[PreprocessingArtifact] = []
            for page_number, page in enumerate(document, start=1):
                pixmap = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False)
                png_bytes = pixmap.tobytes("png")
                native_text = page.get_text("text").strip()
                if _meaningful_characters(native_text) >= (
                    context.config.pdf_native_text_min_chars
                ):
                    extracted = native_text
                    extraction = "native"
                else:
                    extracted = self.image_to_text.extract_text(
                        png_bytes,
                        language=context.config.ocr_language,
                    ).strip()
                    extraction = "ocr"
                name = f"page-{page_number:04d}.png"
                page_texts.append(extracted)
                artifacts.append(
                    PreprocessingArtifact(
                        name=name,
                        media_type="image/png",
                        content=png_bytes,
                        page_number=page_number,
                    )
                )
                page_details.append(
                    {
                        "number": page_number,
                        "width": pixmap.width,
                        "height": pixmap.height,
                        "text_characters": len(extracted),
                        "extraction": extraction,
                        "artifact": name,
                    }
                )
        finally:
            document.close()
        text = "\n\n".join(page_texts).strip()
        analysis = {
            "page_count": page_count,
            "characters": len(text),
            "words": len(re.findall(r"\S+", text)),
            "total_lines": total_physical_lines(text),
            "pages": page_details,
            "artifacts_available": True,
        }
        return AnalyzerResult(
            status="complete",
            analysis=analysis,
            format_name="pdf",
            preprocessing=FilePreprocessingResult(
                text=text,
                page_texts=tuple(page_texts),
                artifacts=tuple(artifacts),
            ),
        )


class ImageAnalyzer(FileAnalyzerInterface):
    """Inspect bounded raster frames and extract reusable OCR text."""

    descriptor = AnalyzerDescriptor(
        "image",
        "image",
        ("image",),
        _IMAGE_EXTENSIONS,
        ("image/",),
        version=2,
    )

    def __init__(self, *, image_to_text: ImageToTextInterface) -> None:
        """Initialize the image analyzer with one replaceable OCR backend."""
        self.image_to_text = image_to_text

    @property
    def processor_identity(self) -> str:
        """Return the preprocessing implementation identity."""
        return self.image_to_text.identity

    def supports(self, context: FileInspectionContext) -> bool:
        """Match declared image extensions or media types."""
        return _descriptor_supports(self.descriptor, context=context)

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Decode raster frames, normalize them to PNG, and run OCR."""
        if context.extension == ".svg":
            raise ValueError("SVG OCR requires a rasterizer and is not supported.")
        with Image.open(context.path) as source:
            frame_count = int(getattr(source, "n_frames", 1))
            if frame_count > context.config.image_max_frames:
                return AnalyzerResult(
                    status="skipped_limit",
                    analysis={"frame_count": frame_count},
                    format_name=(source.format or context.extension.lstrip(".")).casefold(),
                    warnings=(
                        "Image frame count exceeds the configured preanalysis limit.",
                    ),
                )
            source_format = (source.format or context.extension.lstrip(".")).casefold()
            source_mode = source.mode
            page_texts: list[str] = []
            frame_details: list[dict[str, Any]] = []
            artifacts: list[PreprocessingArtifact] = []
            for frame_number in range(1, frame_count + 1):
                source.seek(frame_number - 1)
                normalized = ImageOps.exif_transpose(source.copy()).convert("RGB")
                output = io.BytesIO()
                normalized.save(output, format="PNG")
                png_bytes = output.getvalue()
                extracted = self.image_to_text.extract_text(
                    png_bytes,
                    language=context.config.ocr_language,
                ).strip()
                name = f"frame-{frame_number:04d}.png"
                page_texts.append(extracted)
                artifacts.append(
                    PreprocessingArtifact(
                        name=name,
                        media_type="image/png",
                        content=png_bytes,
                        page_number=frame_number,
                    )
                )
                frame_details.append(
                    {
                        "number": frame_number,
                        "width": normalized.width,
                        "height": normalized.height,
                        "text_characters": len(extracted),
                        "extraction": "ocr",
                        "artifact": name,
                    }
                )
        text = "\n\n".join(page_texts).strip()
        analysis = {
            "source_format": source_format,
            "mode": source_mode,
            "frame_count": frame_count,
            "animated": frame_count > 1,
            "characters": len(text),
            "words": len(re.findall(r"\S+", text)),
            "total_lines": total_physical_lines(text),
            "frames": frame_details,
            "artifacts_available": True,
        }
        return AnalyzerResult(
            status="complete",
            analysis=analysis,
            format_name=source_format,
            preprocessing=FilePreprocessingResult(
                text=text,
                page_texts=tuple(page_texts),
                artifacts=tuple(artifacts),
            ),
        )

class TextAnalyzer(FileAnalyzerInterface):
    """Extract portable character, word, line, and newline statistics."""

    descriptor = AnalyzerDescriptor(
        "text",
        "text",
        ("plain_text",),
        (
            ".cfg",
            ".conf",
            ".env",
            ".ini",
            ".log",
            ".rst",
            ".sql",
            ".txt",
        ),
        ("text/",),
        version=2,
    )

    def supports(self, context: FileInspectionContext) -> bool:
        """Match known text formats or content that decodes as plausible text."""
        if _descriptor_supports(self.descriptor, context=context):
            return True
        if context.size_bytes > context.config.preanalysis_max_bytes:
            return False
        try:
            raw = context.path.read_bytes()
            _, _, chaos = _decode_text(raw)
            return b"\x00" not in raw[:8192] and chaos <= 0.30
        except (OSError, UnicodeError, ValueError):
            return False

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Decode the complete bounded file and calculate text statistics."""
        raw = context.path.read_bytes()
        content, encoding, chaos = _decode_text(raw)
        analysis = _text_statistics(content)
        analysis.update(
            {
                "encoding": encoding,
                "encoding_chaos": round(chaos, 4),
                "bom": _bom_name(raw),
                "total_lines": total_physical_lines(content),
                "navigation": content_region(content),
                "navigation_truncated": False,
            }
        )
        return AnalyzerResult(
            status="complete", analysis=analysis, format_name="plain_text"
        )


class MarkdownAnalyzer(TextAnalyzer):
    """Extend text statistics with a Markdown structural outline."""

    descriptor = AnalyzerDescriptor(
        "markdown",
        "markup",
        ("markdown",),
        (".md", ".markdown", ".mdx"),
        version=2,
    )

    def supports(self, context: FileInspectionContext) -> bool:
        """Match Markdown extensions exactly."""
        return context.extension in self.descriptor.extensions

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Return text statistics plus bounded Markdown structure counts."""
        raw = context.path.read_bytes()
        content, encoding, chaos = _decode_text(raw)
        headings, code_fence_regions, navigation_truncated = markdown_navigation(
            content,
            max_items=context.config.max_symbols,
        )
        fence_markers = re.findall(r"^```([^\s`]*)", content, flags=re.MULTILINE)
        fence_languages = Counter(marker for marker in fence_markers if marker)
        analysis = _text_statistics(content)
        analysis.update(
            {
                "encoding": encoding,
                "encoding_chaos": round(chaos, 4),
                "bom": _bom_name(raw),
                "total_lines": total_physical_lines(content),
                "headings": headings,
                "headings_truncated": navigation_truncated,
                "code_fence_regions": code_fence_regions,
                "navigation": [*headings, *code_fence_regions],
                "navigation_truncated": navigation_truncated,
                "links": len(re.findall(r"(?<!!)\[[^\]]*\]\([^)]*\)", content)),
                "images": len(re.findall(r"!\[[^\]]*\]\([^)]*\)", content)),
                "code_fences": (len(fence_markers) + 1) // 2,
                "code_fence_languages": dict(sorted(fence_languages.items())),
            }
        )
        return AnalyzerResult(
            status="complete", analysis=analysis, format_name="markdown"
        )


class StructuredDataAnalyzer(FileAnalyzerInterface):
    """Parse JSON, YAML, and TOML and summarize their nested data shape."""

    descriptor = AnalyzerDescriptor(
        "structured-data",
        "structured_data",
        ("json", "yaml", "toml"),
        (".json", ".yaml", ".yml", ".toml"),
        version=3,
    )

    def supports(self, context: FileInspectionContext) -> bool:
        """Match supported structured-data extensions."""
        return context.extension in self.descriptor.extensions

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Parse one document safely and return bounded structural statistics."""
        raw = context.path.read_bytes()
        text, encoding, chaos = _decode_text(raw)
        if context.extension == ".json":
            value = json.loads(text)
            format_name = "json"
        elif context.extension in {".yaml", ".yml"}:
            value = yaml.safe_load(text)
            format_name = "yaml"
        else:
            value = tomllib.loads(text)
            format_name = "toml"
        counts: Counter[str] = Counter()
        maximum_depth = _collect_structure(value, counts=counts)
        navigation, navigation_truncated = structured_navigation(
            text,
            format_name=format_name,
            max_items=context.config.max_symbols,
        )
        analysis = {
            "encoding": encoding,
            "encoding_chaos": round(chaos, 4),
            "root_type": _value_type(value),
            "top_level_keys": (
                [str(key) for key in value.keys()][: context.config.max_columns]
                if isinstance(value, dict)
                else []
            ),
            "top_level_keys_truncated": isinstance(value, dict)
            and len(value) > context.config.max_columns,
            "maximum_depth": maximum_depth,
            "counts": dict(sorted(counts.items())),
            "total_lines": total_physical_lines(text),
            "navigation": navigation,
            "navigation_truncated": navigation_truncated,
        }
        return AnalyzerResult(
            status="complete", analysis=analysis, format_name=format_name
        )


class MarkupAnalyzer(FileAnalyzerInterface):
    """Inspect XML and HTML hierarchy without resolving external resources."""

    descriptor = AnalyzerDescriptor(
        "xml-html",
        "markup",
        ("xml", "html"),
        (".xml", ".html", ".htm", ".xhtml"),
        ("application/xml", "text/html", "text/xml"),
        version=2,
    )

    def supports(self, context: FileInspectionContext) -> bool:
        """Match supported XML and HTML formats."""
        return _descriptor_supports(self.descriptor, context=context)

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Return element depth and useful document-control counts."""
        raw = context.path.read_bytes()
        is_html = (
            context.extension in {".html", ".htm"} or context.mime_type == "text/html"
        )
        if is_html:
            root = lxml_html.fromstring(raw or b"<html></html>")
            format_name = "html"
        else:
            parser = etree.XMLParser(
                resolve_entities=False, no_network=True, recover=False
            )
            root = etree.fromstring(raw, parser=parser)
            format_name = "xml"
        elements = list(root.iter())
        maximum_depth = max(
            (_element_depth(element) for element in elements), default=0
        )
        namespaces = sorted(
            {str(uri) for element in elements for uri in element.nsmap.values() if uri}
        )
        text, encoding, chaos = _decode_text(raw)
        navigation, navigation_truncated = markup_navigation(
            text,
            format_name=format_name,
            max_items=context.config.max_symbols,
        )
        analysis: dict[str, Any] = {
            "encoding": encoding,
            "encoding_chaos": round(chaos, 4),
            "total_lines": total_physical_lines(text),
            "navigation": navigation,
            "navigation_truncated": navigation_truncated,
            "root_tag": _local_tag(root.tag),
            "elements": len(elements),
            "maximum_depth": maximum_depth,
            "namespaces": namespaces,
        }
        if is_html:
            analysis.update(
                {
                    "headings": sum(
                        1
                        for element in elements
                        if _local_tag(element.tag) in {f"h{i}" for i in range(1, 7)}
                    ),
                    "links": sum(
                        1 for element in elements if _local_tag(element.tag) == "a"
                    ),
                    "images": sum(
                        1 for element in elements if _local_tag(element.tag) == "img"
                    ),
                    "tables": sum(
                        1 for element in elements if _local_tag(element.tag) == "table"
                    ),
                    "forms": sum(
                        1 for element in elements if _local_tag(element.tag) == "form"
                    ),
                    "controls": sum(
                        1
                        for element in elements
                        if _local_tag(element.tag)
                        in {"button", "input", "select", "textarea"}
                    ),
                }
            )
        return AnalyzerResult(
            status="complete", analysis=analysis, format_name=format_name
        )


@dataclass(slots=True)
class _ColumnAccumulator:
    """Accumulate bounded, non-sample statistics for one table column."""

    name: str
    non_empty: int = 0
    nulls: int = 0
    maximum_length: int = 0
    types: Counter[str] = field(default_factory=Counter)
    distinct: set[str] = field(default_factory=set)
    distinct_truncated: bool = False
    minimum: str | float | int | None = None
    maximum: str | float | int | None = None
    range_type: str | None = None

    def add(self, value: object) -> None:
        """Observe one value without retaining its original sample text."""
        if value is None or (isinstance(value, str) and not value.strip()):
            self.nulls += 1
            return
        text = str(value).strip()
        self.non_empty += 1
        self.maximum_length = max(self.maximum_length, len(text))
        if len(self.distinct) < 100_000:
            self.distinct.add(text)
        elif text not in self.distinct:
            self.distinct_truncated = True
        inferred, normalized = _infer_scalar(text)
        self.types[inferred] += 1
        if inferred in {"integer", "number", "date", "datetime"}:
            range_type = "number" if inferred in {"integer", "number"} else "temporal"
            if self.range_type is None:
                self.range_type = range_type
            elif self.range_type != range_type:
                self.range_type = "mixed"
                self.minimum = None
                self.maximum = None
                return
            if self.range_type == "mixed":
                return
            if self.minimum is None or normalized < self.minimum:
                self.minimum = normalized
            if self.maximum is None or normalized > self.maximum:
                self.maximum = normalized

    def to_dict(self) -> dict[str, Any]:
        """Return one normalized public column profile."""
        inferred_types = [name for name, count in self.types.items() if count]
        inferred_type = inferred_types[0] if len(inferred_types) == 1 else "mixed"
        payload: dict[str, Any] = {
            "name": self.name,
            "inferred_type": inferred_type if inferred_types else "empty",
            "non_empty": self.non_empty,
            "nulls": self.nulls,
            "distinct": len(self.distinct),
            "distinct_truncated": self.distinct_truncated,
            "maximum_length": self.maximum_length,
        }
        if self.minimum is not None:
            payload["minimum"] = self.minimum
            payload["maximum"] = self.maximum
        return payload


class DelimitedTableAnalyzer(FileAnalyzerInterface):
    """Inspect CSV and TSV dialect, dimensions, headers, and column types."""

    descriptor = AnalyzerDescriptor(
        "delimited-table",
        "tabular",
        ("csv", "tsv"),
        (".csv", ".tsv"),
        ("text/csv", "text/tab-separated-values"),
        version=2,
    )

    def supports(self, context: FileInspectionContext) -> bool:
        """Match CSV and TSV extensions or MIME types."""
        return _descriptor_supports(self.descriptor, context=context)

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Stream all bounded rows and return exact dimensions and profiles."""
        raw = context.path.read_bytes()
        text, encoding, chaos = _decode_text(raw)
        sample = text[:8192]
        fallback_delimiter = "\t" if context.extension == ".tsv" else ","
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel_tab if fallback_delimiter == "\t" else csv.excel
        reader = csv.reader(text.splitlines(keepends=True), dialect=dialect)
        rows: list[list[str]] = []
        row_end_lines: list[int] = []
        for row in reader:
            rows.append(row)
            row_end_lines.append(reader.line_num)
        maximum_columns = max((len(row) for row in rows), default=0)
        observed_columns = min(maximum_columns, context.config.max_columns)
        try:
            has_header = bool(rows) and csv.Sniffer().has_header(sample)
        except csv.Error:
            has_header = False
        header = rows[0] if has_header else []
        names = [
            (
                header[index].strip()
                if index < len(header) and header[index].strip()
                else f"column_{index + 1}"
            )
            for index in range(observed_columns)
        ]
        columns = [_ColumnAccumulator(name=name) for name in names]
        data_rows = rows[1:] if has_header else rows
        for row in data_rows:
            for index, column in enumerate(columns):
                column.add(row[index] if index < len(row) else None)
        analysis = {
            "encoding": encoding,
            "encoding_chaos": round(chaos, 4),
            "delimiter": dialect.delimiter,
            "quote_character": dialect.quotechar,
            "has_header": has_header,
            "header": header[: context.config.max_columns],
            "rows": len(data_rows),
            "columns": maximum_columns,
            "column_profiles": [column.to_dict() for column in columns],
            "truncated": maximum_columns > context.config.max_columns,
            "total_lines": total_physical_lines(text),
            "navigation": table_navigation(
                text,
                has_header=has_header,
                header_end_line=row_end_lines[0]
                if has_header and row_end_lines
                else None,
            ),
            "navigation_truncated": False,
        }
        return AnalyzerResult(
            status="complete",
            analysis=analysis,
            format_name="tsv" if dialect.delimiter == "\t" else "csv",
        )


class SpreadsheetAnalyzer(FileAnalyzerInterface):
    """Inspect XLSX/XLSM workbooks without loading editable workbook state."""

    descriptor = AnalyzerDescriptor(
        "spreadsheet",
        "spreadsheet",
        ("xlsx", "xlsm"),
        (".xlsx", ".xlsm"),
        (
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel.sheet.macroenabled.12",
        ),
    )

    def supports(self, context: FileInspectionContext) -> bool:
        """Match modern Office Open XML workbook formats."""
        return _descriptor_supports(self.descriptor, context=context)

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Inspect workbook properties, dimensions, formulas, and column types."""
        expanded = _zip_expanded_bytes(context.path)
        if expanded > context.config.expanded_max_bytes:
            return AnalyzerResult(
                status="skipped_limit",
                analysis={"expanded_bytes": expanded},
                format_name=context.extension.lstrip("."),
                warnings=("Expanded workbook size exceeds the configured limit.",),
            )
        workbook = load_workbook(
            context.path,
            read_only=True,
            data_only=False,
            keep_links=False,
        )
        try:
            sheets = []
            selected = workbook.worksheets[: context.config.max_sheets]
            for worksheet in selected:
                sheets.append(_inspect_worksheet(worksheet, context=context))
            properties = workbook.properties
            analysis = {
                "expanded_bytes": expanded,
                "sheet_count": len(workbook.sheetnames),
                "sheets": sheets,
                "sheets_truncated": len(workbook.sheetnames)
                > context.config.max_sheets,
                "properties": {
                    "title": properties.title,
                    "subject": properties.subject,
                    "creator": properties.creator,
                    "created": _json_scalar(properties.created),
                    "modified": _json_scalar(properties.modified),
                },
            }
        finally:
            workbook.close()
        return AnalyzerResult(
            status="complete",
            analysis=analysis,
            format_name=context.extension.lstrip("."),
        )


class ArchiveAnalyzer(FileAnalyzerInterface):
    """Inspect ZIP and TAR indexes without extracting archive members."""

    descriptor = AnalyzerDescriptor(
        "archive",
        "archive",
        ("zip", "tar", "tar_gzip"),
        (".zip", ".tar", ".tar.gz", ".tgz"),
        ("application/zip", "application/x-tar", "application/gzip"),
    )

    def supports(self, context: FileInspectionContext) -> bool:
        """Match supported archive extensions and MIME types."""
        return _descriptor_supports(self.descriptor, context=context)

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Return bounded central-directory metadata without extraction."""
        if zipfile.is_zipfile(context.path):
            return self._analyze_zip(context)
        if tarfile.is_tarfile(context.path):
            return self._analyze_tar(context)
        raise ValueError(
            "The file extension indicates an archive but its format is invalid."
        )

    def _analyze_zip(self, context: FileInspectionContext) -> AnalyzerResult:
        """Inspect a ZIP central directory."""
        with zipfile.ZipFile(context.path) as archive:
            members = archive.infolist()
            expanded = sum(member.file_size for member in members)
            compressed = sum(member.compress_size for member in members)
            base = _archive_summary(
                names=[member.filename for member in members],
                is_directory=[member.is_dir() for member in members],
                expanded=expanded,
                compressed=compressed,
                encrypted=sum(bool(member.flag_bits & 0x1) for member in members),
                limit=context.config.max_archive_entry_names,
            )
        if expanded > context.config.expanded_max_bytes:
            return AnalyzerResult(
                status="skipped_limit",
                analysis=base,
                format_name="zip",
                warnings=("Expanded archive size exceeds the configured limit.",),
            )
        return AnalyzerResult(status="complete", analysis=base, format_name="zip")

    def _analyze_tar(self, context: FileInspectionContext) -> AnalyzerResult:
        """Inspect a TAR member index."""
        with tarfile.open(context.path, mode="r:*") as archive:
            members = archive.getmembers()
            expanded = sum(member.size for member in members if member.isfile())
            base = _archive_summary(
                names=[member.name for member in members],
                is_directory=[member.isdir() for member in members],
                expanded=expanded,
                compressed=context.size_bytes,
                encrypted=0,
                limit=context.config.max_archive_entry_names,
            )
        format_name = "tar_gzip" if context.extension in {".tar.gz", ".tgz"} else "tar"
        if expanded > context.config.expanded_max_bytes:
            return AnalyzerResult(
                status="skipped_limit",
                analysis=base,
                format_name=format_name,
                warnings=("Expanded archive size exceeds the configured limit.",),
            )
        return AnalyzerResult(status="complete", analysis=base, format_name=format_name)


class SourceCodeAnalyzer(FileAnalyzerInterface):
    """Return text metrics and a normalized Tree-sitter symbol hierarchy."""

    descriptor = AnalyzerDescriptor(
        "source-code",
        "source_code",
        tuple(sorted(set(_SOURCE_LANGUAGES.values()))),
        tuple(_SOURCE_LANGUAGES),
        version=3,
    )

    def __init__(self, *, parser: SourceParserInterface) -> None:
        """Store the parser boundary used by this analyzer."""
        self.parser = parser

    def supports(self, context: FileInspectionContext) -> bool:
        """Match a source extension with an explicit language profile."""
        return context.extension in _SOURCE_LANGUAGES

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Parse a source file and return a bounded nested declaration index."""
        raw = context.path.read_bytes()
        content, encoding, chaos = _decode_text(raw)
        language = _SOURCE_LANGUAGES[context.extension]
        symbols, counts, parse_errors, truncated = self.parser.parse_symbols(
            language=language,
            content=content.encode("utf-8"),
            max_symbols=context.config.max_symbols,
        )
        analysis = _text_statistics(content)
        analysis.update(
            {
                "encoding": encoding,
                "encoding_chaos": round(chaos, 4),
                "total_lines": total_physical_lines(content),
                "language": language,
                "symbols": [symbol.to_dict() for symbol in symbols],
                "symbol_counts": counts,
                "parse_errors": parse_errors,
                "truncated": truncated,
            }
        )
        warnings = (
            ("The parser reported syntax errors; the symbol index may be partial.",)
            if parse_errors
            else ()
        )
        return AnalyzerResult(
            status="complete",
            analysis=analysis,
            warnings=warnings,
            format_name=language,
        )


class UnsupportedAnalyzer(FileAnalyzerInterface):
    """Provide the final generic fallback for every regular file."""

    descriptor = AnalyzerDescriptor("unsupported", "unknown", ("unknown",), ())

    def supports(self, context: FileInspectionContext) -> bool:
        """Always match after every specific analyzer has declined."""
        return True

    def analyze(self, context: FileInspectionContext) -> AnalyzerResult:
        """Return generic-only status without reading file contents."""
        return AnalyzerResult(
            status="unsupported",
            format_name=context.extension.lstrip(".") or "unknown",
            warnings=("No format-specific analyzer is available for this file.",),
        )


def _descriptor_supports(
    descriptor: AnalyzerDescriptor, *, context: FileInspectionContext
) -> bool:
    """Match a descriptor by exact extension or MIME prefix/exact value."""
    if context.extension in descriptor.extensions:
        return True
    if context.mime_type is None:
        return False
    return any(
        context.mime_type.startswith(value)
        if value.endswith("/")
        else context.mime_type == value
        for value in descriptor.mime_types
    )


def _format_for(descriptor: AnalyzerDescriptor, extension: str) -> str:
    """Return the most precise declared format for one extension."""
    if descriptor.analyzer_id == "image":
        return extension.lstrip(".") or "image"
    return descriptor.formats[0] if descriptor.formats else extension.lstrip(".")


def _meaningful_characters(text: str) -> int:
    """Count letters and numbers used to assess native PDF text."""
    return sum(character.isalnum() for character in text)


def _decode_text(raw: bytes) -> tuple[str, str, float]:
    """Decode text using BOM-aware Unicode and charset-normalizer fallback."""
    for marker, encoding in (
        (b"\xef\xbb\xbf", "utf-8-sig"),
        (b"\xff\xfe", "utf-16-le"),
        (b"\xfe\xff", "utf-16-be"),
    ):
        if raw.startswith(marker):
            return raw.decode(encoding), encoding, 0.0
    try:
        return raw.decode("utf-8"), "utf-8", 0.0
    except UnicodeDecodeError:
        match = from_bytes(raw).best()
        if match is None or match.encoding is None:
            raise UnicodeError("The file encoding could not be detected.")
        return str(match), str(match.encoding), float(match.chaos)


def _bom_name(raw: bytes) -> str | None:
    """Return the recognized Unicode byte-order marker name."""
    if raw.startswith(b"\xef\xbb\xbf"):
        return "utf-8"
    if raw.startswith(b"\xff\xfe"):
        return "utf-16-le"
    if raw.startswith(b"\xfe\xff"):
        return "utf-16-be"
    return None


def _text_statistics(content: str) -> dict[str, Any]:
    """Return exact bounded-file text counts and newline style."""
    lines = content.splitlines()
    newline_counts = {
        "crlf": content.count("\r\n"),
        "lf": content.count("\n") - content.count("\r\n"),
        "cr": content.count("\r") - content.count("\r\n"),
    }
    active_newlines = [name for name, count in newline_counts.items() if count]
    return {
        "characters": len(content),
        "words": len(re.findall(r"\S+", content)),
        "lines": len(lines),
        "non_empty_lines": sum(bool(line.strip()) for line in lines),
        "maximum_line_length": max((len(line) for line in lines), default=0),
        "newline_style": active_newlines[0]
        if len(active_newlines) == 1
        else ("mixed" if active_newlines else "none"),
        "newline_counts": newline_counts,
    }


def _collect_structure(value: object, *, counts: Counter[str], depth: int = 1) -> int:
    """Count JSON-compatible value categories and return maximum depth."""
    counts[_value_type(value)] += 1
    if isinstance(value, dict):
        return max(
            [
                depth,
                *(
                    _collect_structure(item, counts=counts, depth=depth + 1)
                    for item in value.values()
                ),
            ]
        )
    if isinstance(value, list):
        return max(
            [
                depth,
                *(
                    _collect_structure(item, counts=counts, depth=depth + 1)
                    for item in value
                ),
            ]
        )
    return depth


def _value_type(value: object) -> str:
    """Return a stable public scalar or container type name."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    return "string"


def _element_depth(element: Any) -> int:
    """Return one XML/HTML element's one-based depth."""
    depth = 1
    parent = element.getparent()
    while parent is not None:
        depth += 1
        parent = parent.getparent()
    return depth


def _local_tag(tag: object) -> str:
    """Return an element tag without its namespace prefix."""
    return str(tag).split("}")[-1].lower()


def _infer_scalar(text: str) -> tuple[str, str | float | int]:
    """Infer one conservative scalar type and a comparable representation."""
    lowered = text.casefold()
    if lowered in {"true", "false", "yes", "no"}:
        return "boolean", lowered
    try:
        return "integer", int(text)
    except ValueError:
        pass
    try:
        number = float(text)
        if math.isfinite(number):
            return "number", number
    except ValueError:
        pass
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return (
            "date" if "T" not in text and " " not in text else "datetime"
        ), parsed.isoformat()
    except ValueError:
        return "string", text


def _zip_expanded_bytes(path: Path) -> int:
    """Return total uncompressed bytes declared by a ZIP container."""
    with zipfile.ZipFile(path) as archive:
        return sum(member.file_size for member in archive.infolist())


def _inspect_worksheet(
    worksheet: Any, *, context: FileInspectionContext
) -> dict[str, Any]:
    """Scan one read-only worksheet and return dimensions and column profiles."""
    rows = 0
    maximum_columns = 0
    non_empty_cells = 0
    formulas = 0
    header: list[str] = []
    columns: list[_ColumnAccumulator] = []
    for row in worksheet.iter_rows(values_only=False):
        rows += 1
        maximum_columns = max(maximum_columns, len(row))
        if not columns:
            observed = min(len(row), context.config.max_columns)
            header = [
                str(row[index].value).strip()
                if row[index].value is not None
                else f"column_{index + 1}"
                for index in range(observed)
            ]
            columns = [_ColumnAccumulator(name=name) for name in header]
        for index, cell in enumerate(row[: context.config.max_columns]):
            value = cell.value
            if value is not None:
                non_empty_cells += 1
            if cell.data_type == "f" or (
                isinstance(value, str) and value.startswith("=")
            ):
                formulas += 1
            if rows > 1 and index < len(columns):
                columns[index].add(value)
    return {
        "name": worksheet.title,
        "state": worksheet.sheet_state,
        "rows": rows,
        "columns": maximum_columns,
        "header": header,
        "non_empty_cells": non_empty_cells,
        "formulas": formulas,
        "column_profiles": [column.to_dict() for column in columns],
        "truncated": maximum_columns > context.config.max_columns,
    }


def _archive_summary(
    *,
    names: list[str],
    is_directory: list[bool],
    expanded: int,
    compressed: int,
    encrypted: int,
    limit: int,
) -> dict[str, Any]:
    """Return normalized archive statistics from a member index."""
    unsafe = sum(_unsafe_archive_name(name) for name in names)
    return {
        "entries": len(names),
        "files": sum(not value for value in is_directory),
        "directories": sum(is_directory),
        "compressed_bytes": compressed,
        "expanded_bytes": expanded,
        "compression_ratio": round(expanded / compressed, 4) if compressed else None,
        "encrypted_entries": encrypted,
        "unsafe_paths": unsafe,
        "entry_names": names[:limit],
        "entry_names_truncated": len(names) > limit,
    }


def _unsafe_archive_name(name: str) -> bool:
    """Return whether an archive member could escape an extraction root."""
    candidate = PurePosixPath(name.replace("\\", "/"))
    return candidate.is_absolute() or ".." in candidate.parts


def _json_scalar(value: object) -> str | int | float | bool | None:
    """Convert workbook property values into JSON scalars."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return str(value)
