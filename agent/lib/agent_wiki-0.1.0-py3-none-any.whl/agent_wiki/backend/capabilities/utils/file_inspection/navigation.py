"""Build bounded line-oriented navigation indexes for textual file formats."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from tree_sitter_language_pack import get_parser


def total_physical_lines(content: str) -> int:
    """Return physical line count without inventing a line after a final newline."""
    return len(content.splitlines())


def content_region(content: str) -> list[dict[str, Any]]:
    """Return one navigation region spanning non-empty text content."""
    total_lines = total_physical_lines(content)
    if total_lines == 0:
        return []
    return [
        {
            "kind": "content",
            "name": "file content",
            "start_line": 1,
            "end_line": total_lines,
        }
    ]


def markdown_navigation(
    content: str,
    *,
    max_items: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], bool]:
    """Return bounded Markdown section and fenced-code navigation indexes."""
    lines = content.splitlines()
    headings: list[dict[str, Any]] = []
    for line_number, line in enumerate(lines, start=1):
        match = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if not match:
            continue
        text = match.group(2).strip().rstrip("#").strip()
        headings.append(
            {
                "kind": "section",
                "name": text,
                "text": text,
                "level": len(match.group(1)),
                "start_line": line_number,
                "end_line": len(lines),
            }
        )
    for index, heading in enumerate(headings):
        for candidate in headings[index + 1 :]:
            if int(candidate["level"]) <= int(heading["level"]):
                heading["end_line"] = int(candidate["start_line"]) - 1
                break

    fences: list[dict[str, Any]] = []
    open_fence: tuple[str, int] | None = None
    for line_number, line in enumerate(lines, start=1):
        match = re.match(r"^\s*```([^\s`]*)", line)
        if not match:
            continue
        if open_fence is None:
            open_fence = (match.group(1), line_number)
            continue
        language, start_line = open_fence
        fences.append(
            {
                "kind": "code_fence",
                "name": language or "untyped",
                "start_line": start_line,
                "end_line": line_number,
            }
        )
        open_fence = None
    if open_fence is not None:
        language, start_line = open_fence
        fences.append(
            {
                "kind": "code_fence",
                "name": language or "untyped",
                "start_line": start_line,
                "end_line": len(lines),
            }
        )

    total_items = len(headings) + len(fences)
    remaining = max_items
    bounded_headings = headings[:remaining]
    remaining -= len(bounded_headings)
    bounded_fences = fences[:remaining]
    return bounded_headings, bounded_fences, total_items > max_items


@dataclass(slots=True)
class _IndexBudget:
    """Track one shared navigation-item limit across a recursive index."""

    maximum: int
    emitted: int = 0
    truncated: bool = False

    def reserve(self) -> bool:
        """Reserve one item or mark the index as truncated."""
        if self.emitted >= self.maximum:
            self.truncated = True
            return False
        self.emitted += 1
        return True


def structured_navigation(
    content: str,
    *,
    format_name: str,
    max_items: int,
) -> tuple[list[dict[str, Any]], bool]:
    """Return a bounded key hierarchy for JSON, YAML, or TOML text."""
    language = "yaml" if format_name == "yaml" else format_name
    root = get_parser(language).parse(content.encode("utf-8")).root_node
    budget = _IndexBudget(maximum=max_items)
    if format_name == "toml":
        items = _toml_items(root, content=content, budget=budget)
    else:
        pair_types = (
            {"pair"} if format_name == "json" else {"block_mapping_pair", "flow_pair"}
        )
        items = _mapping_items(
            root,
            content=content,
            pair_types=pair_types,
            budget=budget,
            parent_path="",
        )
    return items, budget.truncated


def markup_navigation(
    content: str,
    *,
    format_name: str,
    max_items: int,
) -> tuple[list[dict[str, Any]], bool]:
    """Return a bounded nested element outline for HTML or XML."""
    root = get_parser(format_name).parse(content.encode("utf-8")).root_node
    budget = _IndexBudget(maximum=max_items)
    items: list[dict[str, Any]] = []
    for child in root.named_children:
        items.extend(
            _markup_elements(
                child, content=content, format_name=format_name, budget=budget
            )
        )
    return items, budget.truncated


def table_navigation(
    content: str,
    *,
    has_header: bool,
    header_end_line: int | None,
) -> list[dict[str, Any]]:
    """Return total, header, and data regions for delimited text."""
    total_lines = total_physical_lines(content)
    if total_lines == 0:
        return []
    regions = [
        {
            "kind": "table",
            "name": "table",
            "start_line": 1,
            "end_line": total_lines,
        }
    ]
    data_start = 1
    if has_header and header_end_line is not None:
        regions.append(
            {
                "kind": "header",
                "name": "header",
                "start_line": 1,
                "end_line": header_end_line,
            }
        )
        data_start = header_end_line + 1
    if data_start <= total_lines:
        regions.append(
            {
                "kind": "data",
                "name": "data rows",
                "start_line": data_start,
                "end_line": total_lines,
            }
        )
    return regions


def _mapping_items(
    node: Any,
    *,
    content: str,
    pair_types: set[str],
    budget: _IndexBudget,
    parent_path: str,
) -> list[dict[str, Any]]:
    """Collect mapping pairs recursively while preserving their hierarchy."""
    if node.type in {"array", "block_sequence", "flow_sequence"}:
        return _array_items(
            node,
            content=content,
            pair_types=pair_types,
            budget=budget,
            parent_path=parent_path,
        )
    items: list[dict[str, Any]] = []
    for child in node.named_children:
        if child.type not in pair_types:
            items.extend(
                _mapping_items(
                    child,
                    content=content,
                    pair_types=pair_types,
                    budget=budget,
                    parent_path=parent_path,
                )
            )
            continue
        named_children = list(child.named_children)
        if not named_children:
            continue
        name = _clean_key(_node_text(named_children[0], content=content))
        path = f"{parent_path}.{name}" if parent_path else name
        if not budget.reserve():
            continue
        item = {
            "kind": "key",
            "name": name,
            "path": path,
            "value_type": _syntax_value_type(named_children[-1]),
            "start_line": int(child.start_point.row) + 1,
            "end_line": _inclusive_end_line(child),
        }
        descendants = _mapping_items(
            named_children[-1],
            content=content,
            pair_types=pair_types,
            budget=budget,
            parent_path=path,
        )
        if descendants:
            item["children"] = descendants
        items.append(item)
    return items


def _array_items(
    node: Any,
    *,
    content: str,
    pair_types: set[str],
    budget: _IndexBudget,
    parent_path: str,
) -> list[dict[str, Any]]:
    """Collect structured container items from one JSON or YAML sequence."""
    items: list[dict[str, Any]] = []
    for index, child in enumerate(node.named_children):
        value_node = (
            child.named_children[-1]
            if child.type in {"block_sequence_item", "flow_sequence_item"}
            and child.named_children
            else child
        )
        if not _has_mapping_descendant(value_node, pair_types=pair_types):
            continue
        if not budget.reserve():
            continue
        descendants = _mapping_items(
            value_node,
            content=content,
            pair_types=pair_types,
            budget=budget,
            parent_path=f"{parent_path}[{index}]",
        )
        items.append(
            {
                "kind": "array_item",
                "name": f"[{index}]",
                "path": f"{parent_path}[{index}]",
                "value_type": _syntax_value_type(value_node),
                "start_line": int(child.start_point.row) + 1,
                "end_line": _inclusive_end_line(child),
                "children": descendants,
            }
        )
    return items


def _has_mapping_descendant(node: Any, *, pair_types: set[str]) -> bool:
    """Return whether one syntax subtree contains a structured mapping pair."""
    return node.type in pair_types or any(
        _has_mapping_descendant(child, pair_types=pair_types)
        for child in node.named_children
    )


def _toml_items(
    root: Any,
    *,
    content: str,
    budget: _IndexBudget,
) -> list[dict[str, Any]]:
    """Collect TOML tables and pairs with their source ranges."""
    items: list[dict[str, Any]] = []
    for child in root.named_children:
        if child.type in {"table", "table_array_element"}:
            named = list(child.named_children)
            if not named or not budget.reserve():
                continue
            name = _clean_key(_node_text(named[0], content=content))
            item = {
                "kind": "table",
                "name": name,
                "path": name,
                "value_type": "object",
                "start_line": int(child.start_point.row) + 1,
                "end_line": _inclusive_end_line(child),
            }
            children = _toml_pairs(child, content=content, budget=budget, prefix=name)
            if children:
                item["children"] = children
            items.append(item)
        elif child.type == "pair":
            items.extend(_toml_pairs(root, content=content, budget=budget, prefix=""))
            break
    return items


def _toml_pairs(
    node: Any,
    *,
    content: str,
    budget: _IndexBudget,
    prefix: str,
) -> list[dict[str, Any]]:
    """Collect direct TOML key/value pairs below one table."""
    items: list[dict[str, Any]] = []
    for child in node.named_children:
        if child.type != "pair":
            continue
        named = list(child.named_children)
        if not named or not budget.reserve():
            continue
        name = _clean_key(_node_text(named[0], content=content))
        items.append(
            {
                "kind": "key",
                "name": name,
                "path": f"{prefix}.{name}" if prefix else name,
                "value_type": _syntax_value_type(named[-1]),
                "start_line": int(child.start_point.row) + 1,
                "end_line": _inclusive_end_line(child),
            }
        )
    return items


def _markup_elements(
    node: Any,
    *,
    content: str,
    format_name: str,
    budget: _IndexBudget,
) -> list[dict[str, Any]]:
    """Collect nested markup elements from one syntax subtree."""
    if node.type != "element":
        items: list[dict[str, Any]] = []
        for child in node.named_children:
            items.extend(
                _markup_elements(
                    child,
                    content=content,
                    format_name=format_name,
                    budget=budget,
                )
            )
        return items
    if not budget.reserve():
        return []
    opening_types = (
        {"start_tag", "self_closing_tag"}
        if format_name == "html"
        else {"STag", "EmptyElemTag"}
    )
    opening = next(
        (child for child in node.named_children if child.type in opening_types),
        None,
    )
    tag = _markup_tag(opening, content=content, format_name=format_name)
    label = _markup_label(node, opening=opening, content=content, tag=tag)
    item = {
        "kind": "element",
        "name": label,
        "start_line": int(node.start_point.row) + 1,
        "end_line": _inclusive_end_line(node),
    }
    descendants: list[dict[str, Any]] = []
    for child in node.named_children:
        descendants.extend(
            _markup_elements(
                child,
                content=content,
                format_name=format_name,
                budget=budget,
            )
        )
    if descendants:
        item["children"] = descendants
    return [item]


def _markup_tag(node: Any | None, *, content: str, format_name: str) -> str:
    """Extract one opening markup tag name."""
    if node is None:
        return "element"
    expected = "tag_name" if format_name == "html" else "Name"
    tag_node = next(
        (child for child in node.named_children if child.type == expected),
        None,
    )
    return _node_text(tag_node, content=content) if tag_node is not None else "element"


def _markup_label(
    node: Any,
    *,
    opening: Any | None,
    content: str,
    tag: str,
) -> str:
    """Build a compact tag label from id or heading text when available."""
    opening_text = _node_text(opening, content=content) if opening is not None else ""
    id_match = re.search(r"""\bid\s*=\s*["']([^"']+)["']""", opening_text)
    if id_match:
        return f"{tag}#{id_match.group(1)}"
    if tag.lower() in {f"h{level}" for level in range(1, 7)}:
        text = " ".join(
            " ".join(_node_text(child, content=content).split())
            for child in node.named_children
            if child.type in {"text", "CharData"}
        ).strip()
        if text:
            return f"{tag}: {text[:120]}"
    return tag


def _node_text(node: Any, *, content: str) -> str:
    """Return source text covered by one syntax node."""
    encoded = content.encode("utf-8")
    return encoded[node.start_byte : node.end_byte].decode("utf-8", errors="replace")


def _clean_key(value: str) -> str:
    """Normalize one serialized structured-data key for display."""
    stripped = value.strip()
    try:
        decoded = json.loads(stripped)
    except (json.JSONDecodeError, TypeError):
        return stripped.strip("\"'")
    return str(decoded)


def _syntax_value_type(node: Any) -> str:
    """Normalize common syntax-node names into public value types."""
    kind = str(node.type)
    if kind in {"block_node", "flow_node"} and node.named_children:
        return _syntax_value_type(node.named_children[-1])
    if kind in {"object", "block_mapping", "flow_mapping", "inline_table"}:
        return "object"
    if kind in {"array", "block_sequence", "flow_sequence"}:
        return "array"
    if kind in {"true", "false", "boolean"}:
        return "boolean"
    if kind in {"null", "null_scalar"}:
        return "null"
    if kind in {"number", "integer", "float"}:
        return "number"
    if "string" in kind or "scalar" in kind:
        return "string"
    return kind


def _inclusive_end_line(node: Any) -> int:
    """Convert Tree-sitter's exclusive endpoint into a 1-based inclusive line."""
    end_row = int(node.end_point.row)
    end_column = int(node.end_point.column)
    return (
        end_row
        if end_column == 0 and end_row > int(node.start_point.row)
        else end_row + 1
    )
