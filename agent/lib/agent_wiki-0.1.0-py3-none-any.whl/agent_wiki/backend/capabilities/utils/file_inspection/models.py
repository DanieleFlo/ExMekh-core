"""Shared immutable data models for bounded file inspection."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal

from agent_wiki.configs.runtime import FileInspectionConfig

from .projection import compact_file_inspection_payload
from .selection import FileInspectionSelectionError, select_analysis_lists


AnalysisStatus = Literal[
    "complete", "skipped_limit", "not_implemented", "unsupported", "failed"
]


@dataclass(frozen=True, slots=True)
class AnalyzerDescriptor:
    """Describe one analyzer and the file formats it owns."""

    analyzer_id: str
    family: str
    formats: tuple[str, ...]
    extensions: tuple[str, ...]
    mime_types: tuple[str, ...] = ()
    version: int = 1


@dataclass(frozen=True, slots=True)
class FileFingerprint:
    """Identify one file state and the analysis contract used for it."""

    relative_path: str
    size_bytes: int
    modified_ns: int
    changed_ns: int
    analyzer_id: str
    analyzer_version: int
    config_signature: str

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable fingerprint mapping."""
        return asdict(self)


@dataclass(frozen=True, slots=True)
class FileInspectionContext:
    """Provide an analyzer with a resolved file and bounded runtime settings."""

    path: Path
    relative_path: str
    extension: str
    mime_type: str | None
    size_bytes: int
    config: FileInspectionConfig


@dataclass(frozen=True, slots=True)
class PreprocessingArtifact:
    """Describe one generated binary artifact before it enters the cache."""

    name: str
    media_type: str
    content: bytes
    page_number: int | None = None


@dataclass(frozen=True, slots=True)
class CachedPreprocessingArtifact:
    """Expose one cached artifact without leaking it into inspection reports."""

    name: str
    media_type: str
    path: Path
    size_bytes: int
    page_number: int | None = None

    def read_bytes(self) -> bytes:
        """Read and return the cached artifact content."""
        return self.path.read_bytes()


@dataclass(frozen=True, slots=True)
class FilePreprocessingResult:
    """Store reusable extracted text and generated binary artifacts."""

    text: str
    page_texts: tuple[str, ...] = ()
    artifacts: tuple[PreprocessingArtifact, ...] = ()


@dataclass(frozen=True, slots=True)
class CachedFilePreprocessingResult:
    """Store reusable preprocessing data loaded from a cache entry."""

    text: str
    page_texts: tuple[str, ...] = ()
    artifacts: tuple[CachedPreprocessingArtifact, ...] = ()

    def page_text(self, page_number: int) -> str:
        """Return one 1-based cached page text."""
        if page_number <= 0 or page_number > len(self.page_texts):
            raise IndexError("Cached page number is outside the available range.")
        return self.page_texts[page_number - 1]


@dataclass(frozen=True, slots=True)
class AnalyzerResult:
    """Store one analyzer's normalized status, payload, and warnings."""

    status: AnalysisStatus
    analysis: dict[str, Any] = field(default_factory=dict)
    warnings: tuple[str, ...] = ()
    format_name: str | None = None
    preprocessing: FilePreprocessingResult | None = None


@dataclass(frozen=True, slots=True)
class SourceSymbol:
    """Represent one bounded source-code symbol and its nested declarations."""

    kind: str
    name: str
    start_line: int
    end_line: int
    children: tuple["SourceSymbol", ...] = ()

    def to_dict(self) -> dict[str, Any]:
        """Return the recursive symbol hierarchy as plain JSON data."""
        payload: dict[str, Any] = {
            "kind": self.kind,
            "name": self.name,
            "start_line": self.start_line,
            "end_line": self.end_line,
        }
        if self.children:
            payload["children"] = [child.to_dict() for child in self.children]
        return payload


@dataclass(frozen=True, slots=True)
class CacheLookup:
    """Represent a cache lookup without adding filesystem paths to reports."""

    status: str
    analysis: dict[str, Any] | None = None
    format_name: str | None = None
    warnings: tuple[str, ...] = ()
    preprocessing: CachedFilePreprocessingResult | None = None


@dataclass(frozen=True, slots=True)
class FileInspectionReport:
    """Store the complete structured response returned by inspect-file."""

    payload: dict[str, Any]
    model_cache_directory: Path | None = None

    def to_dict(
        self,
        *,
        max_items: int | None = None,
        max_list_items: int = 50,
        query: str | None = None,
        cache_directory: Path | None = None,
    ) -> dict[str, Any]:
        """Return a detached detailed payload with optional list selection."""
        detailed = dict(self.payload)
        if max_items is None:
            return detailed
        resolved_cache = self._selection_cache_directory(
            query=query,
            override=cache_directory,
        )
        return select_analysis_lists(
            detailed,
            max_items=max_items,
            max_list_items=max_list_items,
            query=query,
            cache_directory=resolved_cache,
        )

    def to_compact_dict(
        self,
        *,
        max_items: int | None = None,
        max_list_items: int = 50,
        query: str | None = None,
        cache_directory: Path | None = None,
    ) -> dict[str, Any]:
        """Return the compact payload with optional recursive list selection."""
        compact = compact_file_inspection_payload(self.payload)
        if max_items is None:
            return compact
        resolved_cache = self._selection_cache_directory(
            query=query,
            override=cache_directory,
        )
        return select_analysis_lists(
            compact,
            max_items=max_items,
            max_list_items=max_list_items,
            query=query,
            cache_directory=resolved_cache,
        )

    def _selection_cache_directory(
        self,
        *,
        query: str | None,
        override: Path | None,
    ) -> Path:
        """Resolve a safe semantic-model cache or reject an unbound query."""
        resolved = override or self.model_cache_directory
        if resolved is not None:
            return resolved
        if query is not None:
            raise FileInspectionSelectionError(
                "selection_model_cache_unavailable"
            )
        return Path(".")
