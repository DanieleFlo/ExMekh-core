"""Tree-sitter-backed source symbol extraction behind a narrow interface."""

from __future__ import annotations

import ast
from collections import Counter
from dataclasses import dataclass
from typing import Any

from .interfaces import SourceParserInterface
from .models import SourceSymbol


@dataclass(frozen=True, slots=True)
class _LanguageProfile:
    """Map grammar node names to normalized public symbol kinds."""

    grammar: str
    node_kinds: dict[str, str]


_PROFILES: dict[str, _LanguageProfile] = {
    "python": _LanguageProfile(
        "python", {"class_definition": "class", "function_definition": "function"}
    ),
    "javascript": _LanguageProfile(
        "javascript",
        {
            "class_declaration": "class",
            "function_declaration": "function",
            "method_definition": "method",
        },
    ),
    "typescript": _LanguageProfile(
        "typescript",
        {
            "class_declaration": "class",
            "interface_declaration": "interface",
            "enum_declaration": "enum",
            "function_declaration": "function",
            "method_definition": "method",
            "method_signature": "method",
        },
    ),
    "tsx": _LanguageProfile(
        "tsx",
        {
            "class_declaration": "class",
            "interface_declaration": "interface",
            "enum_declaration": "enum",
            "function_declaration": "function",
            "method_definition": "method",
            "method_signature": "method",
        },
    ),
    "java": _LanguageProfile(
        "java",
        {
            "class_declaration": "class",
            "interface_declaration": "interface",
            "enum_declaration": "enum",
            "method_declaration": "method",
            "constructor_declaration": "constructor",
        },
    ),
    "c": _LanguageProfile(
        "c",
        {
            "struct_specifier": "struct",
            "enum_specifier": "enum",
            "function_definition": "function",
        },
    ),
    "cpp": _LanguageProfile(
        "cpp",
        {
            "class_specifier": "class",
            "struct_specifier": "struct",
            "enum_specifier": "enum",
            "function_definition": "function",
        },
    ),
    "c_sharp": _LanguageProfile(
        "c_sharp",
        {
            "class_declaration": "class",
            "interface_declaration": "interface",
            "struct_declaration": "struct",
            "enum_declaration": "enum",
            "method_declaration": "method",
            "constructor_declaration": "constructor",
        },
    ),
    "go": _LanguageProfile(
        "go",
        {
            "type_spec": "type",
            "function_declaration": "function",
            "method_declaration": "method",
        },
    ),
    "rust": _LanguageProfile(
        "rust",
        {
            "struct_item": "struct",
            "enum_item": "enum",
            "trait_item": "trait",
            "function_item": "function",
        },
    ),
    "ruby": _LanguageProfile(
        "ruby",
        {
            "class": "class",
            "module": "namespace",
            "method": "method",
            "singleton_method": "method",
        },
    ),
    "php": _LanguageProfile(
        "php",
        {
            "class_declaration": "class",
            "interface_declaration": "interface",
            "trait_declaration": "trait",
            "enum_declaration": "enum",
            "function_definition": "function",
            "method_declaration": "method",
        },
    ),
}


class TreeSitterParserBackend(SourceParserInterface):
    """Extract normalized symbols using packaged Tree-sitter grammars."""

    def parse_symbols(
        self,
        *,
        language: str,
        content: bytes,
        max_symbols: int,
    ) -> tuple[tuple[SourceSymbol, ...], dict[str, int], int, bool]:
        """Parse one source and return a bounded nested symbol hierarchy."""
        if language == "python":
            return self._parse_python_symbols(content, max_symbols=max_symbols)
        profile = _PROFILES[language]
        parser = self._build_parser(profile.grammar)
        tree = parser.parse(content)
        counts: Counter[str] = Counter()
        state = {"emitted": 0, "truncated": False, "parse_errors": 0}
        symbols = self._collect_symbols(
            tree.root_node,
            content=content,
            profile=profile,
            counts=counts,
            state=state,
            max_symbols=max_symbols,
            parent_kind=None,
        )
        return (
            tuple(symbols),
            dict(sorted(counts.items())),
            int(state["parse_errors"]),
            bool(state["truncated"]),
        )

    def _parse_python_symbols(
        self,
        content: bytes,
        *,
        max_symbols: int,
    ) -> tuple[tuple[SourceSymbol, ...], dict[str, int], int, bool]:
        """Extract Python symbols with the memory-safe standard-library AST."""
        try:
            root = ast.parse(content.decode("utf-8", errors="replace"))
        except SyntaxError:
            return (), {}, 1, False
        counts: Counter[str] = Counter()
        state = {"emitted": 0, "truncated": False}
        symbols = self._collect_python_symbols(
            root,
            counts=counts,
            state=state,
            max_symbols=max_symbols,
            parent_kind=None,
        )
        return (
            tuple(symbols),
            dict(sorted(counts.items())),
            0,
            bool(state["truncated"]),
        )

    def _collect_python_symbols(
        self,
        node: ast.AST,
        *,
        counts: Counter[str],
        state: dict[str, int | bool],
        max_symbols: int,
        parent_kind: str | None,
    ) -> list[SourceSymbol]:
        """Walk a Python AST and preserve declaration nesting and limits."""
        symbol_kind: str | None = None
        if isinstance(node, ast.ClassDef):
            symbol_kind = "class"
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            symbol_kind = "method" if parent_kind == "class" else "function"
        if symbol_kind is not None and int(state["emitted"]) >= max_symbols:
            state["truncated"] = True
            return []

        next_parent = symbol_kind or parent_kind
        nested: list[SourceSymbol] = []
        if symbol_kind is not None:
            state["emitted"] = int(state["emitted"]) + 1
            counts[symbol_kind] += 1
        for child in ast.iter_child_nodes(node):
            nested.extend(
                self._collect_python_symbols(
                    child,
                    counts=counts,
                    state=state,
                    max_symbols=max_symbols,
                    parent_kind=next_parent,
                )
            )
        if symbol_kind is None:
            return nested
        return [
            SourceSymbol(
                kind=symbol_kind,
                name=str(node.name),
                start_line=int(node.lineno),
                end_line=int(getattr(node, "end_lineno", node.lineno)),
                children=tuple(nested),
            )
        ]

    @staticmethod
    def _build_parser(grammar: str) -> Any:
        """Return a parser without allowing implicit network grammar downloads."""
        if grammar == "c_sharp":
            from tree_sitter import Language, Parser
            import tree_sitter_c_sharp

            return Parser(Language(tree_sitter_c_sharp.language()))
        from tree_sitter_language_pack import get_parser

        return get_parser(grammar)

    def _collect_symbols(
        self,
        node: Any,
        *,
        content: bytes,
        profile: _LanguageProfile,
        counts: Counter[str],
        state: dict[str, int | bool],
        max_symbols: int,
        parent_kind: str | None,
    ) -> list[SourceSymbol]:
        """Walk named nodes and nest declarations beneath enclosing symbols."""
        if bool(getattr(node, "is_error", False)) or bool(
            getattr(node, "is_missing", False)
        ):
            state["parse_errors"] = int(state["parse_errors"]) + 1

        normalized_kind = self._normalized_kind(
            node, profile=profile, parent_kind=parent_kind
        )
        if normalized_kind is not None:
            if int(state["emitted"]) >= max_symbols:
                state["truncated"] = True
                return []
            name = self._symbol_name(node, content=content)
            if name:
                state["emitted"] = int(state["emitted"]) + 1
                counts[normalized_kind] += 1
        else:
            name = ""
        next_parent = normalized_kind if name else parent_kind
        nested: list[SourceSymbol] = []
        for child in getattr(node, "named_children", ()):
            nested.extend(
                self._collect_symbols(
                    child,
                    content=content,
                    profile=profile,
                    counts=counts,
                    state=state,
                    max_symbols=max_symbols,
                    parent_kind=next_parent,
                )
            )
        if normalized_kind is None or not name:
            return nested
        return [
            SourceSymbol(
                kind=normalized_kind,
                name=name,
                start_line=int(node.start_point.row) + 1,
                end_line=int(node.end_point.row) + 1,
                children=tuple(nested),
            )
        ]

    @staticmethod
    def _normalized_kind(
        node: Any,
        *,
        profile: _LanguageProfile,
        parent_kind: str | None,
    ) -> str | None:
        """Normalize context-sensitive grammar node kinds."""
        kind = profile.node_kinds.get(str(node.type))
        if (
            profile.grammar in {"javascript", "typescript", "tsx"}
            and node.type == "variable_declarator"
        ):
            value = node.child_by_field_name("value")
            if value is not None and value.type in {
                "arrow_function",
                "function_expression",
            }:
                kind = "function"
        if (
            profile.grammar == "ruby"
            and kind == "method"
            and parent_kind
            not in {
                "class",
                "namespace",
            }
        ):
            return "function"
        if kind == "function" and parent_kind in {
            "class",
            "interface",
            "struct",
            "trait",
        }:
            return "method"
        if profile.grammar == "rust" and kind == "function":
            ancestor = getattr(node, "parent", None)
            while ancestor is not None:
                if ancestor.type == "impl_item":
                    return "method"
                ancestor = ancestor.parent
        if profile.grammar == "go" and kind == "type":
            child_types = {str(child.type) for child in node.named_children}
            if "struct_type" in child_types:
                return "struct"
            if "interface_type" in child_types:
                return "interface"
        return kind

    @classmethod
    def _symbol_name(cls, node: Any, *, content: bytes) -> str:
        """Extract a declaration name from common grammar fields and nodes."""
        for field_name in ("name", "declarator", "type"):
            candidate = node.child_by_field_name(field_name)
            if candidate is None:
                continue
            identifier = cls._find_identifier(candidate)
            selected = identifier if identifier is not None else candidate
            text = content[selected.start_byte : selected.end_byte].decode(
                "utf-8", errors="replace"
            )
            if normalized := " ".join(text.split()):
                return normalized[:240]
        identifier = cls._find_identifier(node)
        if identifier is None:
            return ""
        return content[identifier.start_byte : identifier.end_byte].decode(
            "utf-8", errors="replace"
        )[:240]

    @classmethod
    def _find_identifier(cls, node: Any) -> Any | None:
        """Return the most specific declaration identifier below one node."""
        if str(node.type) in {
            "identifier",
            "type_identifier",
            "field_identifier",
            "constant",
            "name",
        }:
            return node
        candidates: list[Any] = []
        for child in getattr(node, "named_children", ()):
            found = cls._find_identifier(child)
            if found is not None:
                candidates.append(found)
        return candidates[-1] if candidates else None
