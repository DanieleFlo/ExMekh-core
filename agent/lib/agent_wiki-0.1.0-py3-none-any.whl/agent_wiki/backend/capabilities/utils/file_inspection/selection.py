"""Recursive list selection for inspect-file report projections."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ranking import ListRankingResult, rank_list_items


class FileInspectionSelectionError(ValueError):
    """Represent invalid public list-selection arguments."""

    def __init__(self, catalog_key: str, **values: object) -> None:
        """Store the tool-local catalog key and interpolation values."""
        super().__init__(catalog_key)
        self.catalog_key = catalog_key
        self.values = values


@dataclass(slots=True)
class _SelectionState:
    """Accumulate bounded observability while projecting analysis lists."""

    max_items: int
    query: str | None
    cache_directory: Path
    lists_examined: int = 0
    lists_truncated: int = 0
    truncated_paths: list[str] = field(default_factory=list)
    semantic_ranking_applied: bool = False
    semantic_fallback_applied: bool = False
    semantic_enabled: bool = True


def select_analysis_lists(
    payload: dict[str, Any],
    *,
    max_items: int,
    max_list_items: int,
    query: str | None,
    cache_directory: Path,
) -> dict[str, Any]:
    """Return a detached report with every analysis list selected recursively."""
    normalized_query = validate_list_selection(
        max_items=max_items,
        max_list_items=max_list_items,
        query=query,
    )
    selected = deepcopy(payload)
    state = _SelectionState(
        max_items=max_items,
        query=normalized_query,
        cache_directory=cache_directory,
    )
    if "analysis" in selected:
        selected["analysis"] = _select_value(
            selected["analysis"],
            path="$.analysis",
            state=state,
        )
    selected["list_selection"] = _selection_summary(state)
    return selected


def validate_list_selection(
    *,
    max_items: int,
    max_list_items: int,
    query: str | None,
) -> str | None:
    """Validate the public limit and normalize an optional query."""
    if not isinstance(max_items, int) or isinstance(max_items, bool) or max_items < 1:
        raise FileInspectionSelectionError("selection_max_items_positive")
    if max_items > max_list_items:
        raise FileInspectionSelectionError(
            "selection_max_items_ceiling",
            limit=max_list_items,
        )
    if query is None:
        return None
    if not isinstance(query, str) or not query.strip():
        raise FileInspectionSelectionError("selection_query_empty")
    return query.strip()


def _select_value(value: Any, *, path: str, state: _SelectionState) -> Any:
    """Select nested lists while preserving dictionaries and scalar values."""
    if isinstance(value, dict):
        return {
            key: _select_value(
                item,
                path=f"{path}.{key}",
                state=state,
            )
            for key, item in value.items()
        }
    if not isinstance(value, list):
        return deepcopy(value)
    state.lists_examined += 1
    indices = list(range(len(value)))
    if state.query is not None and len(value) > 1:
        ranking = rank_list_items(
            query=state.query,
            items=value,
            cache_directory=state.cache_directory,
            allow_semantic=state.semantic_enabled,
        )
        _observe_ranking(ranking, state=state)
        indices = list(ranking.indices)
    if len(indices) > state.max_items:
        state.lists_truncated += 1
        if len(state.truncated_paths) < state.max_items:
            state.truncated_paths.append(path)
    selected_indices = indices[: state.max_items]
    return [
        _select_value(
            value[index],
            path=f"{path}[{output_index}]",
            state=state,
        )
        for output_index, index in enumerate(selected_indices)
    ]


def _observe_ranking(
    ranking: ListRankingResult,
    *,
    state: _SelectionState,
) -> None:
    """Record whether semantic ranking ran or fell back for this projection."""
    state.semantic_ranking_applied |= ranking.semantic_applied
    state.semantic_fallback_applied |= ranking.semantic_fallback
    if ranking.semantic_fallback:
        state.semantic_enabled = False


def _selection_summary(state: _SelectionState) -> dict[str, Any]:
    """Build the bounded model-facing list-selection summary."""
    summary: dict[str, Any] = {
        "max_items": state.max_items,
        "query": state.query,
        "lists_examined": state.lists_examined,
        "lists_truncated": state.lists_truncated,
        "truncated_paths": state.truncated_paths,
        "truncated_paths_truncated": (
            state.lists_truncated > len(state.truncated_paths)
        ),
        "semantic_ranking_applied": state.semantic_ranking_applied,
        "semantic_fallback_applied": state.semantic_fallback_applied,
    }
    return summary
