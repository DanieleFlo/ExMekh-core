"""Public report projections for bounded file inspection."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping


_COMMON_FIELDS = (
    "path",
    "name",
    "family",
    "format",
    "total_lines",
    "analysis_status",
    "warnings",
)


def compact_file_inspection_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Return the stable agent-oriented projection of a complete report payload."""
    compact = {
        field: deepcopy(payload[field]) for field in _COMMON_FIELDS if field in payload
    }
    size = payload.get("size")
    if isinstance(size, Mapping) and isinstance(size.get("bytes"), int):
        compact["size"] = {"bytes": size["bytes"]}
    analysis = payload.get("analysis")
    if not isinstance(analysis, Mapping):
        compact["analysis"] = {}
        return compact

    if payload.get("analysis_status") == "skipped_limit":
        compact["analysis"] = deepcopy(dict(analysis))
        return compact
    if payload.get("analysis_status") != "complete":
        compact["analysis"] = {}
        return compact

    analyzer = payload.get("analyzer")
    if analyzer == "xml-html" or payload.get("format") == "toml":
        return compact
    projectors = {
        "text": _compact_text,
        "markdown": _compact_markdown,
        "structured-data": _compact_structured_data,
        "delimited-table": _compact_delimited_table,
        "spreadsheet": _compact_spreadsheet,
        "archive": _compact_archive,
        "source-code": _compact_source_code,
        "pdf": _compact_pdf,
        "image": _compact_image,
    }
    projector = projectors.get(analyzer)
    compact["analysis"] = projector(analysis) if projector is not None else {}
    return compact


def _select(analysis: Mapping[str, Any], fields: tuple[str, ...]) -> dict[str, Any]:
    """Copy selected analysis fields while preserving their declared order."""
    return {field: deepcopy(analysis[field]) for field in fields if field in analysis}


def _compact_text(analysis: Mapping[str, Any]) -> dict[str, Any]:
    """Keep the text properties most useful for choosing a reading strategy."""
    return _select(
        analysis,
        (
            "encoding",
            "words",
            "non_empty_lines",
            "newline_style",
        ),
    )


def _compact_markdown(analysis: Mapping[str, Any]) -> dict[str, Any]:
    """Present Markdown sections and code blocks as one hierarchical outline."""
    outline: list[dict[str, Any]] = []
    stack: list[tuple[int, dict[str, Any]]] = []
    events: list[tuple[int, int, Mapping[str, Any]]] = []
    headings = analysis.get("headings")
    if isinstance(headings, list):
        events.extend(
            (int(item.get("start_line", 0)), 0, item)
            for item in headings
            if isinstance(item, Mapping)
        )
    code_blocks = analysis.get("code_fence_regions")
    if isinstance(code_blocks, list):
        events.extend(
            (int(item.get("start_line", 0)), 1, item)
            for item in code_blocks
            if isinstance(item, Mapping)
        )

    for _start_line, event_kind, item in sorted(events, key=lambda event: event[:2]):
        if event_kind == 0:
            level = int(item.get("level", 1))
            section = _markdown_outline_item(item, kind="section")
            section["level"] = level
            while stack and stack[-1][0] >= level:
                stack.pop()
            _append_outline_item(outline, stack=stack, item=section)
            stack.append((level, section))
            continue
        code_block = _markdown_outline_item(item, kind="code_block")
        code_block.pop("name", None)
        code_block["language"] = str(item.get("name") or "untyped")
        _append_outline_item(outline, stack=stack, item=code_block)

    compact: dict[str, Any] = {"outline": outline}
    for field in ("links", "images"):
        value = analysis.get(field)
        if isinstance(value, int) and value > 0:
            compact[field] = value
    if (
        analysis.get("headings_truncated") is True
        or analysis.get("navigation_truncated") is True
    ):
        compact["outline_truncated"] = True
    return compact


def _markdown_outline_item(
    item: Mapping[str, Any],
    *,
    kind: str,
) -> dict[str, Any]:
    """Project one Markdown region into the compact outline shape."""
    projected: dict[str, Any] = {
        "kind": kind,
        "name": str(item.get("name") or item.get("text") or kind),
    }
    start_line = item.get("start_line")
    end_line = item.get("end_line")
    if isinstance(start_line, int) and isinstance(end_line, int):
        projected["location"] = {
            "start_line": start_line,
            "end_line": end_line,
        }
    return projected


def _append_outline_item(
    outline: list[dict[str, Any]],
    *,
    stack: list[tuple[int, dict[str, Any]]],
    item: dict[str, Any],
) -> None:
    """Append an outline item at the active Markdown section depth."""
    if not stack:
        outline.append(item)
        return
    stack[-1][1].setdefault("children", []).append(item)


def _compact_structured_data(analysis: Mapping[str, Any]) -> dict[str, Any]:
    """Present structured data as a compact navigation-oriented outline."""
    compact = _select(
        analysis,
        (
            "root_type",
            "top_level_keys",
        ),
    )
    navigation = analysis.get("navigation")
    compact["outline"] = (
        [
            _compact_structured_item(item)
            for item in navigation
            if isinstance(item, Mapping)
        ]
        if isinstance(navigation, list)
        else []
    )
    if analysis.get("top_level_keys_truncated") is True:
        compact["top_level_keys_truncated"] = True
    if analysis.get("navigation_truncated") is True:
        compact["outline_truncated"] = True
    return compact


def _compact_structured_item(item: Mapping[str, Any]) -> dict[str, Any]:
    """Project one structured-data item with its location before descendants."""
    compact = _select(item, ("kind", "name", "value_type"))
    start_line = item.get("start_line")
    end_line = item.get("end_line")
    if isinstance(start_line, int) and isinstance(end_line, int):
        compact["location"] = {
            "start_line": start_line,
            "end_line": end_line,
        }
    children = item.get("children")
    if isinstance(children, list) and children:
        compact["children"] = [
            _compact_structured_item(child)
            for child in children
            if isinstance(child, Mapping)
        ]
    return compact


def _compact_delimited_table(analysis: Mapping[str, Any]) -> dict[str, Any]:
    """Keep only useful column names for compact CSV and TSV reports."""
    header = analysis.get("header")
    columns = (
        [str(value) for value in header] if isinstance(header, list) and header else []
    )
    profiles = analysis.get("column_profiles")
    if not columns and isinstance(profiles, list):
        columns = [
            str(profile["name"])
            for profile in profiles
            if isinstance(profile, Mapping) and "name" in profile
        ]
    return {"columns": columns} if columns else {}


def _compact_spreadsheet(analysis: Mapping[str, Any]) -> dict[str, Any]:
    """Keep only sheet identities and column names for compact workbooks."""
    sheets = analysis.get("sheets")
    compact_sheets = (
        [
            {
                "name": str(sheet.get("name", "")),
                "columns": [str(value) for value in sheet.get("header", [])],
            }
            for sheet in sheets
            if isinstance(sheet, Mapping)
            and (
                str(sheet.get("name", ""))
                or (isinstance(sheet.get("header"), list) and sheet["header"])
            )
        ]
        if isinstance(sheets, list)
        else []
    )
    return {"sheets": compact_sheets} if compact_sheets else {}


def _compact_archive(analysis: Mapping[str, Any]) -> dict[str, Any]:
    """Keep archive contents, expansion risk, encryption, and unsafe paths."""
    return _select(
        analysis,
        (
            "entries",
            "files",
            "directories",
            "expanded_bytes",
            "encrypted_entries",
            "unsafe_paths",
            "entry_names",
            "entry_names_truncated",
        ),
    )


def _compact_source_code(analysis: Mapping[str, Any]) -> dict[str, Any]:
    """Present source declarations as a compact navigation-oriented outline."""
    compact = _select(
        analysis,
        ("symbol_counts",),
    )
    symbols = analysis.get("symbols")
    compact["outline"] = (
        [
            _compact_source_symbol(symbol)
            for symbol in symbols
            if isinstance(symbol, Mapping)
        ]
        if isinstance(symbols, list)
        else []
    )
    parse_errors = analysis.get("parse_errors")
    if isinstance(parse_errors, int) and parse_errors > 0:
        compact["parse_errors"] = parse_errors
    if analysis.get("truncated") is True:
        compact["outline_truncated"] = True
    return compact


def _compact_pdf(analysis: Mapping[str, Any]) -> dict[str, Any]:
    """Keep PDF extraction and reusable-cache guidance."""
    return _select(
        analysis,
        (
            "page_count",
            "characters",
            "words",
            "pages",
            "preprocessing_cached",
            "cached_artifacts",
        ),
    )


def _compact_image(analysis: Mapping[str, Any]) -> dict[str, Any]:
    """Keep image geometry, OCR, and reusable-cache guidance."""
    return _select(
        analysis,
        (
            "source_format",
            "mode",
            "frame_count",
            "animated",
            "characters",
            "words",
            "frames",
            "preprocessing_cached",
            "cached_artifacts",
        ),
    )


def _compact_source_symbol(symbol: Mapping[str, Any]) -> dict[str, Any]:
    """Project one source symbol with identity before its line location."""
    compact = _select(symbol, ("kind", "name"))
    start_line = symbol.get("start_line")
    end_line = symbol.get("end_line")
    if isinstance(start_line, int) and isinstance(end_line, int):
        compact["location"] = {
            "start_line": start_line,
            "end_line": end_line,
        }
    children = symbol.get("children")
    if isinstance(children, list) and children:
        compact["children"] = [
            _compact_source_symbol(child)
            for child in children
            if isinstance(child, Mapping)
        ]
    return compact
