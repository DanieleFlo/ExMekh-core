"""Independent hybrid text ranking for inspect-file analysis lists."""

from __future__ import annotations

import hashlib
import json
import logging
import math
import re
import threading
from collections import Counter, OrderedDict
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

import numpy as np
from numpy.typing import NDArray


GRANITE_MODEL_NAME = "ibm-granite/granite-embedding-311m-multilingual-r2"
EMBEDDING_CACHE_SIZE = 2_048
RRF_K = 60
BM25_RRF_WEIGHT = 1.0
SEMANTIC_RRF_WEIGHT = 1.0
ORIGINAL_ORDER_RRF_WEIGHT = 0.25

Embedding = NDArray[np.float32]
_LOGGER = logging.getLogger(__name__)


class TextEmbeddingBackend(Protocol):
    """Encode text batches into normalized semantic vectors."""

    def encode(self, texts: Sequence[str]) -> Embedding:
        """Return one normalized embedding per supplied text."""


class OpenVINOGraniteEmbeddingBackend:
    """Encode list text with IBM's multilingual INT8 Granite artifact."""

    def __init__(
        self,
        *,
        cache_directory: Path,
        model_name: str = GRANITE_MODEL_NAME,
        device: str = "CPU",
    ) -> None:
        """Download and compile the official OpenVINO model inside workroot."""
        import openvino as ov
        from huggingface_hub import hf_hub_download
        from transformers import AutoTokenizer

        cache_directory.mkdir(parents=True, exist_ok=True)
        model_xml = hf_hub_download(
            repo_id=model_name,
            filename="openvino/openvino_model_qint8_quantized.xml",
            cache_dir=cache_directory,
        )
        hf_hub_download(
            repo_id=model_name,
            filename="openvino/openvino_model_qint8_quantized.bin",
            cache_dir=cache_directory,
        )
        self._tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            cache_dir=cache_directory,
        )
        core = ov.Core()
        self._model = core.compile_model(core.read_model(model_xml), device.upper())
        self._input_names = {
            model_input.get_any_name() for model_input in self._model.inputs
        }

    def encode(self, texts: Sequence[str]) -> Embedding:
        """Tokenize, CLS-pool, and L2-normalize one text batch."""
        encoded = self._tokenizer(
            list(texts),
            padding=True,
            truncation=True,
            return_tensors="np",
        )
        inputs = {
            name: np.asarray(value)
            for name, value in encoded.items()
            if name in self._input_names
        }
        outputs = self._model(inputs)
        token_embeddings = np.asarray(
            outputs[self._model.output(0)],
            dtype=np.float32,
        )
        vectors = token_embeddings[:, 0, :]
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        return np.divide(
            vectors,
            np.maximum(norms, np.finfo(np.float32).eps),
            dtype=np.float32,
        )


class EmbeddingLRUCache:
    """Store bounded content-addressed embeddings for analysis-list items."""

    def __init__(self, capacity: int = EMBEDDING_CACHE_SIZE) -> None:
        """Initialize an in-memory cache with a positive capacity."""
        if capacity < 1:
            raise ValueError("Embedding cache capacity must be positive.")
        self.capacity = capacity
        self._entries: OrderedDict[str, Embedding] = OrderedDict()
        self._lock = threading.RLock()

    def get(self, key: str) -> Embedding | None:
        """Return and refresh one cached embedding."""
        with self._lock:
            value = self._entries.get(key)
            if value is not None:
                self._entries.move_to_end(key)
            return value

    def put(self, key: str, value: Embedding) -> None:
        """Store an embedding and evict the least recently used item."""
        with self._lock:
            self._entries[key] = value
            self._entries.move_to_end(key)
            while len(self._entries) > self.capacity:
                self._entries.popitem(last=False)

    def clear(self) -> None:
        """Remove every cached embedding."""
        with self._lock:
            self._entries.clear()


@dataclass(frozen=True, slots=True)
class ListRankingResult:
    """Describe one stable list ranking and its semantic execution mode."""

    indices: tuple[int, ...]
    semantic_applied: bool
    semantic_fallback: bool


_BACKENDS: dict[tuple[str, str], TextEmbeddingBackend] = {}
_BACKEND_LOCK = threading.Lock()
_INFERENCE_LOCK = threading.Lock()
_EMBEDDING_CACHE = EmbeddingLRUCache()


def canonical_item_text(value: Any) -> str:
    """Serialize one complete list item into deterministic searchable text."""
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )


def get_embedding_backend(*, cache_directory: Path) -> TextEmbeddingBackend:
    """Return one lazily initialized Granite backend for a model cache."""
    key = (GRANITE_MODEL_NAME, str(cache_directory.resolve()))
    backend = _BACKENDS.get(key)
    if backend is not None:
        return backend
    with _BACKEND_LOCK:
        backend = _BACKENDS.get(key)
        if backend is None:
            backend = OpenVINOGraniteEmbeddingBackend(
                cache_directory=cache_directory,
            )
            _BACKENDS[key] = backend
    return backend


def rank_list_items(
    *,
    query: str,
    items: Sequence[Any],
    cache_directory: Path,
    backend_factory: Callable[..., TextEmbeddingBackend] = get_embedding_backend,
    cache: EmbeddingLRUCache = _EMBEDDING_CACHE,
    allow_semantic: bool = True,
) -> ListRankingResult:
    """Rank complete list items with BM25, Granite, and original-order RRF."""
    texts = [canonical_item_text(item) for item in items]
    lexical_ranking = _ranking_from_scores(bm25_scores(query, texts))
    rankings: list[tuple[Sequence[int], float]] = [
        (lexical_ranking, BM25_RRF_WEIGHT),
        (list(range(len(items))), ORIGINAL_ORDER_RRF_WEIGHT),
    ]
    semantic_applied = False
    semantic_fallback = False
    if allow_semantic and items:
        try:
            semantic_scores = semantic_similarity(
                query=query,
                texts=texts,
                cache_directory=cache_directory,
                backend_factory=backend_factory,
                cache=cache,
            )
        except Exception as error:  # noqa: BLE001 - semantic ranking is optional.
            _LOGGER.warning(
                "File-inspection Granite ranking unavailable; using BM25: %s",
                error,
            )
            semantic_fallback = True
        else:
            rankings.append(
                (_ranking_from_scores(semantic_scores), SEMANTIC_RRF_WEIGHT)
            )
            semantic_applied = True
    fused = reciprocal_rank_fusion(rankings)
    ordered = tuple(sorted(fused, key=lambda index: (-fused[index], index)))
    return ListRankingResult(
        indices=ordered,
        semantic_applied=semantic_applied,
        semantic_fallback=semantic_fallback,
    )


def bm25_scores(query: str, texts: Sequence[str]) -> list[float]:
    """Score arbitrary Unicode texts with corpus-derived BM25."""
    if not texts:
        return []
    query_terms = Counter(_tokenize(query))
    documents = [_tokenize(text) for text in texts]
    document_sets = [set(tokens) for tokens in documents]
    average_length = sum(len(tokens) for tokens in documents) / len(documents)
    scores: list[float] = []
    for tokens in documents:
        frequencies = Counter(tokens)
        length = max(1, len(tokens))
        score = 0.0
        for term, query_frequency in query_terms.items():
            frequency = frequencies[term]
            if frequency == 0:
                continue
            document_frequency = sum(term in terms for terms in document_sets)
            inverse_frequency = math.log(
                1
                + (len(documents) - document_frequency + 0.5)
                / (document_frequency + 0.5)
            )
            normalization = frequency + 1.2 * (
                0.25 + 0.75 * length / max(1.0, average_length)
            )
            score += (
                inverse_frequency
                * frequency
                * 2.2
                / normalization
                * min(query_frequency, 2)
            )
        scores.append(score)
    return scores


def semantic_similarity(
    *,
    query: str,
    texts: Sequence[str],
    cache_directory: Path,
    backend_factory: Callable[..., TextEmbeddingBackend],
    cache: EmbeddingLRUCache,
) -> list[float]:
    """Return cosine similarities while batching uncached item embeddings."""
    if not texts:
        return []
    with _INFERENCE_LOCK:
        cached: list[Embedding | None] = []
        missing_indices: list[int] = []
        keys = [_content_key(text) for text in texts]
        for index, key in enumerate(keys):
            embedding = cache.get(key)
            cached.append(embedding)
            if embedding is None:
                missing_indices.append(index)
        batch = [query]
        batch.extend(texts[index] for index in missing_indices)
        backend = backend_factory(cache_directory=cache_directory)
        vectors = backend.encode(batch)
        if vectors.ndim != 2 or vectors.shape[0] != len(batch):
            raise ValueError("Embedding backend returned an invalid batch shape.")
        query_embedding = vectors[0]
        for offset, item_index in enumerate(missing_indices, start=1):
            embedding = vectors[offset]
            cached[item_index] = embedding
            cache.put(keys[item_index], embedding)
        return [
            float(np.dot(query_embedding, embedding))
            for embedding in cached
            if embedding is not None
        ]


def reciprocal_rank_fusion(
    rankings: Sequence[tuple[Sequence[int], float]],
    *,
    k: int = RRF_K,
) -> dict[int, float]:
    """Fuse ranked indices using weighted reciprocal rank fusion."""
    if k < 1:
        raise ValueError("RRF k must be positive.")
    scores: dict[int, float] = {}
    for ranking, weight in rankings:
        if weight <= 0:
            continue
        for rank, candidate_index in enumerate(ranking, start=1):
            scores[candidate_index] = scores.get(candidate_index, 0.0) + weight / (
                k + rank
            )
    return scores


def _ranking_from_scores(scores: Sequence[float]) -> list[int]:
    """Convert scores to a stable descending index ranking."""
    return sorted(range(len(scores)), key=lambda index: (-scores[index], index))


def _tokenize(value: object) -> list[str]:
    """Tokenize Unicode words without language-specific stop words."""
    return [
        token
        for token in re.findall(r"[^\W_]+", str(value).casefold(), flags=re.UNICODE)
        if len(token) > 1
    ]


def _content_key(text: str) -> str:
    """Return a stable content-addressed embedding cache key."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
