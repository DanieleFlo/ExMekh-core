"""Public helpers for the inspect-file capability and future file readers."""

from .analyzers import AnalyzerRegistry
from .cache import (
    FilesystemFileInspectionCache,
    FilesystemFilePreprocessingCache,
)
from .interfaces import (
    FileAnalyzerInterface,
    FileInspectionCacheInterface,
    FilePreprocessingCacheInterface,
    ImageToTextInterface,
    SourceParserInterface,
)
from .models import (
    CachedFilePreprocessingResult,
    CachedPreprocessingArtifact,
    FilePreprocessingResult,
    PreprocessingArtifact,
)
from .ocr import (
    GraniteDoclingImageToText,
    ImageToTextError,
    OpenVINOImageToText,
    TesseractImageToText,
)
from .service import FileInspectionError, FileInspectionService
from .selection import FileInspectionSelectionError, validate_list_selection
from .source import TreeSitterParserBackend

__all__ = [
    "AnalyzerRegistry",
    "FileAnalyzerInterface",
    "FileInspectionCacheInterface",
    "FileInspectionError",
    "FileInspectionService",
    "FileInspectionSelectionError",
    "validate_list_selection",
    "FilePreprocessingCacheInterface",
    "FilePreprocessingResult",
    "FilesystemFileInspectionCache",
    "FilesystemFilePreprocessingCache",
    "CachedFilePreprocessingResult",
    "CachedPreprocessingArtifact",
    "ImageToTextError",
    "ImageToTextInterface",
    "GraniteDoclingImageToText",
    "OpenVINOImageToText",
    "PreprocessingArtifact",
    "SourceParserInterface",
    "TesseractImageToText",
    "TreeSitterParserBackend",
]
