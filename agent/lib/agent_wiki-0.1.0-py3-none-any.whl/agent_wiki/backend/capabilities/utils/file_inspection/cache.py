"""Versioned, atomic, size-bounded cache for file preprocessing artifacts."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from filelock import FileLock

from .interfaces import FilePreprocessingCacheInterface
from .models import (
    AnalyzerResult,
    CacheLookup,
    CachedFilePreprocessingResult,
    CachedPreprocessingArtifact,
    FileFingerprint,
)


CACHE_SCHEMA_VERSION = 2
_MANIFEST_NAME = "manifest.json"
_TEXT_NAME = "document.txt"
_PAGE_TEXT_DIRECTORY = "text"
_ARTIFACT_DIRECTORY = "artifacts"


class FilesystemFilePreprocessingCache(FilePreprocessingCacheInterface):
    """Persist completed analyses, extracted text, and generated artifacts."""

    def __init__(
        self,
        *,
        directory: Path,
        max_bytes: int,
        entry_max_bytes: int,
    ) -> None:
        """Initialize one cache rooted inside the active workspace."""
        self.directory = directory
        self.max_bytes = max_bytes
        self.entry_max_bytes = entry_max_bytes
        self._lock = FileLock(str(directory.parent / f".{directory.name}.lock"))

    def get(self, fingerprint: FileFingerprint) -> CacheLookup:
        """Return a valid matching entry and refresh its LRU timestamp."""
        entry_path = self._entry_path(fingerprint)
        with self._lock:
            manifest_path = entry_path / _MANIFEST_NAME
            if not manifest_path.exists():
                return CacheLookup(status="miss")
            try:
                payload = json.loads(manifest_path.read_text(encoding="utf-8"))
                if not self._matches(payload, fingerprint=fingerprint):
                    self._remove_entry(entry_path)
                    return CacheLookup(status="miss")
                preprocessing = self._load_preprocessing(
                    entry_path=entry_path,
                    payload=payload,
                )
                payload["accessed_at"] = _utc_now()
                self._write_atomic(manifest_path, payload)
                return CacheLookup(
                    status="hit",
                    analysis=dict(payload["analysis"]),
                    format_name=payload.get("format_name"),
                    warnings=tuple(payload.get("warnings", [])),
                    preprocessing=preprocessing,
                )
            except (OSError, TypeError, ValueError, json.JSONDecodeError):
                self._remove_entry(entry_path)
                return CacheLookup(status="miss_corrupt")

    def put(self, fingerprint: FileFingerprint, result: AnalyzerResult) -> str:
        """Store a completed result unless its serialized entry is too large."""
        if result.status != "complete":
            return "not_stored_incomplete"
        payload: dict[str, Any] = {
            "schema_version": CACHE_SCHEMA_VERSION,
            "fingerprint": fingerprint.to_dict(),
            "accessed_at": _utc_now(),
            "format_name": result.format_name,
            "analysis": result.analysis,
            "warnings": list(result.warnings),
            "preprocessing": None,
        }
        entry_path = self._entry_path(fingerprint)
        with self._lock:
            self.directory.mkdir(parents=True, exist_ok=True)
            temporary_path = self.directory / (
                f".{entry_path.name}.{uuid.uuid4().hex}.tmp"
            )
            try:
                temporary_path.mkdir()
                self._write_preprocessing(
                    entry_path=temporary_path,
                    payload=payload,
                    result=result,
                )
                self._write_atomic(temporary_path / _MANIFEST_NAME, payload)
                if _directory_size(temporary_path) > self.entry_max_bytes:
                    return "not_stored_entry_too_large"
                self._remove_entry(entry_path)
                temporary_path.replace(entry_path)
            finally:
                self._remove_entry(temporary_path)
            self._prune_locked()
        return "stored"

    def prune(self) -> None:
        """Remove corrupt and least-recently-used entries over the byte cap."""
        with self._lock:
            self._prune_locked()

    def _prune_locked(self) -> None:
        """Prune cache entries while the cross-process lock is held."""
        if not self.directory.exists():
            return
        entries: list[tuple[str, int, Path]] = []
        total_bytes = 0
        for legacy_path in self.directory.glob("*.json"):
            legacy_path.unlink(missing_ok=True)
        for path in self.directory.iterdir():
            if not path.is_dir() or path.name.startswith("."):
                continue
            try:
                size = _directory_size(path)
                payload = json.loads(
                    (path / _MANIFEST_NAME).read_text(encoding="utf-8")
                )
                accessed_at = str(payload["accessed_at"])
            except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
                self._remove_entry(path)
                continue
            total_bytes += size
            entries.append((accessed_at, size, path))
        for _, size, path in sorted(entries):
            if total_bytes <= self.max_bytes:
                break
            self._remove_entry(path)
            total_bytes -= size

    def _entry_path(self, fingerprint: FileFingerprint) -> Path:
        """Return a stable opaque entry path for one fingerprint."""
        digest = hashlib.sha256(
            json.dumps(
                fingerprint.to_dict(), sort_keys=True, separators=(",", ":")
            ).encode("utf-8")
        ).hexdigest()
        return self.directory / digest

    @staticmethod
    def _matches(payload: dict[str, Any], *, fingerprint: FileFingerprint) -> bool:
        """Return whether an entry uses the current schema and fingerprint."""
        return (
            payload.get("schema_version") == CACHE_SCHEMA_VERSION
            and payload.get("fingerprint") == fingerprint.to_dict()
            and isinstance(payload.get("analysis"), dict)
        )

    def _write_preprocessing(
        self,
        *,
        entry_path: Path,
        payload: dict[str, Any],
        result: AnalyzerResult,
    ) -> None:
        """Write optional reusable text and artifacts into a staged entry."""
        preprocessing = result.preprocessing
        if preprocessing is None:
            return
        text_path = entry_path / _TEXT_NAME
        text_path.write_text(preprocessing.text, encoding="utf-8")
        page_records: list[dict[str, Any]] = []
        if preprocessing.page_texts:
            page_directory = entry_path / _PAGE_TEXT_DIRECTORY
            page_directory.mkdir()
            for page_number, text in enumerate(preprocessing.page_texts, start=1):
                name = f"page-{page_number:04d}.txt"
                (page_directory / name).write_text(text, encoding="utf-8")
                page_records.append({"number": page_number, "name": name})
        artifact_records: list[dict[str, Any]] = []
        if preprocessing.artifacts:
            artifact_directory = entry_path / _ARTIFACT_DIRECTORY
            artifact_directory.mkdir()
            for artifact in preprocessing.artifacts:
                safe_name = _safe_name(artifact.name)
                (artifact_directory / safe_name).write_bytes(artifact.content)
                artifact_records.append(
                    {
                        "name": safe_name,
                        "media_type": artifact.media_type,
                        "page_number": artifact.page_number,
                        "size_bytes": len(artifact.content),
                    }
                )
        payload["preprocessing"] = {
            "text": _TEXT_NAME,
            "pages": page_records,
            "artifacts": artifact_records,
        }

    def _load_preprocessing(
        self,
        *,
        entry_path: Path,
        payload: dict[str, Any],
    ) -> CachedFilePreprocessingResult | None:
        """Load reusable preprocessing data from one validated manifest."""
        record = payload.get("preprocessing")
        if record is None:
            return None
        if not isinstance(record, dict):
            raise ValueError("Invalid preprocessing cache manifest.")
        text_path = _safe_entry_child(entry_path, str(record["text"]))
        text = text_path.read_text(encoding="utf-8")
        page_texts: list[str] = []
        for page in record.get("pages", []):
            if not isinstance(page, dict):
                raise ValueError("Invalid cached page record.")
            page_name = _safe_name(str(page["name"]))
            page_texts.append(
                (entry_path / _PAGE_TEXT_DIRECTORY / page_name).read_text(
                    encoding="utf-8"
                )
            )
        artifacts: list[CachedPreprocessingArtifact] = []
        for artifact in record.get("artifacts", []):
            if not isinstance(artifact, dict):
                raise ValueError("Invalid cached artifact record.")
            name = _safe_name(str(artifact["name"]))
            artifact_path = entry_path / _ARTIFACT_DIRECTORY / name
            size_bytes = artifact_path.stat().st_size
            if size_bytes != int(artifact["size_bytes"]):
                raise ValueError("Cached artifact size does not match its manifest.")
            artifacts.append(
                CachedPreprocessingArtifact(
                    name=name,
                    media_type=str(artifact["media_type"]),
                    path=artifact_path,
                    size_bytes=size_bytes,
                    page_number=artifact.get("page_number"),
                )
            )
        return CachedFilePreprocessingResult(
            text=text,
            page_texts=tuple(page_texts),
            artifacts=tuple(artifacts),
        )

    @staticmethod
    def _remove_entry(path: Path) -> None:
        """Remove one exact cache entry or staging directory."""
        if path.is_symlink():
            path.unlink(missing_ok=True)
        elif path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        else:
            path.unlink(missing_ok=True)

    @staticmethod
    def _write_atomic(
        path: Path,
        payload: dict[str, Any],
        *,
        encoded: bytes | None = None,
    ) -> None:
        """Replace one JSON entry atomically in its destination directory."""
        path.parent.mkdir(parents=True, exist_ok=True)
        content = encoded if encoded is not None else _encode(payload)
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
        )
        try:
            with os.fdopen(descriptor, "wb") as temporary:
                temporary.write(content)
                temporary.flush()
                os.fsync(temporary.fileno())
            Path(temporary_name).replace(path)
        finally:
            Path(temporary_name).unlink(missing_ok=True)


def _encode(payload: dict[str, Any]) -> bytes:
    """Serialize one cache payload deterministically as UTF-8 JSON."""
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _utc_now() -> str:
    """Return a sortable UTC timestamp for LRU ordering."""
    return datetime.now(timezone.utc).isoformat()


def _safe_name(value: str) -> str:
    """Return one cache-local basename or reject unsafe manifest data."""
    candidate = Path(value)
    if candidate.name != value or value in {"", ".", ".."}:
        raise ValueError("Cache artifact name must be one safe basename.")
    return value


def _safe_entry_child(entry_path: Path, value: str) -> Path:
    """Resolve one manifest child while keeping it inside the entry."""
    candidate = (entry_path / value).resolve()
    candidate.relative_to(entry_path.resolve())
    return candidate


def _directory_size(path: Path) -> int:
    """Return the combined byte size of regular files in one cache entry."""
    return sum(
        child.stat().st_size
        for child in path.rglob("*")
        if child.is_file() and not child.is_symlink()
    )


FilesystemFileInspectionCache = FilesystemFilePreprocessingCache
