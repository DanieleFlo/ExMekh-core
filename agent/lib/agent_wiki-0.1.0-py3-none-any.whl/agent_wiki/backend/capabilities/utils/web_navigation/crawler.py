"""Crawl4AI lifecycle and output normalization."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import time
from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from .actions import execute_actions
from .ast import build_semantic_ast
from .content import extract_page_dates, select_primary_html
from .errors import WebNavigationError
from .security import NavigationPolicy, build_route_guard, validate_public_url

OutputMode = Literal["markdown", "ast", "hybrid"]
MAX_MARKDOWN_CHARS = 24000
CACHE_TTL_SECONDS = 900
CACHE_FORMAT_VERSION = 2


def crawl_page(
    *,
    url: str,
    output_mode: str,
    timeout_seconds: int,
    workroot: Path | None,
    actions: Sequence[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Run one isolated Crawl4AI browser lifecycle and return normalized output."""
    normalized_url = validate_public_url(url)
    mode = _validate_output_mode(output_mode)
    if timeout_seconds < 1 or timeout_seconds > 120:
        raise WebNavigationError(
            "timeout_seconds must be between 1 and 120.", kind="invalid_timeout"
        )
    root = Path(workroot).resolve() if workroot is not None else Path.cwd().resolve()
    cache_root = root / ".agent-wiki" / "tmp" / "crawl4ai"
    if actions is None:
        cached = _read_page_cache(cache_root=cache_root, url=normalized_url, mode=mode)
        if cached is not None:
            return cached
    payload = asyncio.run(
        _crawl_page(
            url=normalized_url,
            output_mode=mode,
            timeout_seconds=timeout_seconds,
            cache_root=cache_root,
            actions=actions,
        )
    )
    if actions is None:
        _write_page_cache(
            cache_root=cache_root,
            url=normalized_url,
            mode=mode,
            payload=payload,
        )
    return payload


async def _crawl_page(
    *,
    url: str,
    output_mode: OutputMode,
    timeout_seconds: int,
    cache_root: Path,
    actions: Sequence[Mapping[str, Any]] | None,
) -> dict[str, Any]:
    """Execute one asynchronous crawl and optional atomic action sequence."""
    cache_root.mkdir(parents=True, exist_ok=True)
    os.environ["CRAWL4_AI_BASE_DIRECTORY"] = str(cache_root)
    from crawl4ai import (
        AsyncWebCrawler,
        BrowserConfig,
        CacheMode,
        CrawlerRunConfig,
        DefaultMarkdownGenerator,
    )
    from crawl4ai.content_filter_strategy import PruningContentFilter

    browser_config = BrowserConfig(headless=True, verbose=False, text_mode=False)
    markdown_generator = DefaultMarkdownGenerator(
        content_filter=PruningContentFilter(
            threshold=0.48,
            threshold_type="fixed",
            min_word_threshold=20,
        )
    )
    run_config = CrawlerRunConfig(
        cache_mode=CacheMode.DISABLED,
        check_robots_txt=True,
        page_timeout=timeout_seconds * 1000,
        wait_until="domcontentloaded",
        remove_overlay_elements=True,
        remove_consent_popups=True,
        process_iframes=False,
        markdown_generator=markdown_generator,
    )
    outcomes: list[dict[str, Any]] = []
    browser_final_url: str | None = None
    browser_final_html: str | None = None
    browser_final_title: str | None = None
    action_error: WebNavigationError | None = None
    navigation_policy = NavigationPolicy(initial_url=url)
    crawler = AsyncWebCrawler(config=browser_config, base_directory=str(cache_root))

    async def configure_context(page: Any, context: Any, **_: Any) -> Any:
        """Install the network boundary before the first navigation."""
        del context
        await page.context.route(
            "**/*", build_route_guard(page=page, policy=navigation_policy)
        )
        return page

    async def apply_actions(page: Any, **_: Any) -> Any:
        """Execute the validated action list after the initial navigation."""
        nonlocal action_error, browser_final_html, browser_final_title, browser_final_url
        await page.wait_for_load_state("load", timeout=timeout_seconds * 1000)
        if actions:
            try:
                outcomes.extend(
                    await execute_actions(
                        page,
                        actions,
                        timeout_ms=timeout_seconds * 1000,
                        navigation_policy=navigation_policy,
                    )
                )
            except WebNavigationError as error:
                action_error = error
        browser_final_url = str(page.url)
        browser_final_html = str(await page.content())
        browser_final_title = str(await page.title())
        return page

    crawler.crawler_strategy.set_hook("on_page_context_created", configure_context)
    if actions:
        crawler.crawler_strategy.set_hook("before_retrieve_html", apply_actions)
    try:
        await crawler.start()
        result = await crawler.arun(url=url, config=run_config)
    except WebNavigationError:
        raise
    except Exception as error:
        navigation_policy.raise_if_violated()
        raise WebNavigationError(
            f"Browser crawl failed: {type(error).__name__}.", kind="crawl_failed"
        ) from error
    finally:
        await crawler.close()
    if action_error is not None:
        raise action_error
    navigation_policy.raise_if_violated()
    if not result.success:
        message = str(result.error_message or "Unknown Crawl4AI failure.")
        raise WebNavigationError(message, kind="crawl_failed")
    final_url = str(browser_final_url or result.redirected_url or result.url or url)
    validate_public_url(final_url)
    rendered_html = str(browser_final_html or result.html or "")
    primary_html, content_scope = select_primary_html(rendered_html)
    regenerated_markdown = markdown_generator.generate_markdown(
        primary_html,
        base_url=final_url,
    )
    markdown, markdown_truncated = _extract_markdown(
        regenerated_markdown,
        prefer_raw=content_scope in {"main", "article"},
    )
    payload: dict[str, Any] = {
        "requested_url": url,
        "final_url": final_url,
        "title": str(
            browser_final_title or (result.metadata or {}).get("title") or ""
        ),
        "status_code": result.status_code,
        "output_mode": output_mode,
        "untrusted_content": True,
        "retrieved_at": datetime.now(timezone.utc).isoformat(),
        "page_dates": extract_page_dates(result.metadata, rendered_html),
        "content_scope": content_scope,
        "markdown_truncated": markdown_truncated,
    }
    if actions is not None:
        payload["actions"] = outcomes
        payload["actions_completed"] = len(outcomes) == len(actions) and all(
            item["success"] and item["effect_observed"] for item in outcomes
        )
    if output_mode in {"markdown", "hybrid"}:
        payload["markdown"] = markdown
        payload["markdown_chars"] = len(markdown)
    if output_mode in {"ast", "hybrid"}:
        payload["ast"] = build_semantic_ast(rendered_html, base_url=final_url)
    return payload


def _validate_output_mode(value: str) -> OutputMode:
    """Normalize and validate one public output-mode value."""
    mode = str(value).strip().lower()
    if mode not in {"markdown", "ast", "hybrid"}:
        raise WebNavigationError(
            "output_mode must be markdown, ast, or hybrid.", kind="invalid_output_mode"
        )
    return mode  # type: ignore[return-value]


def _extract_markdown(result: Any, *, prefer_raw: bool = False) -> tuple[str, bool]:
    """Select fit Markdown with a raw fallback and apply the context budget."""
    markdown_result = getattr(result, "markdown", result)
    if isinstance(markdown_result, str):
        value = markdown_result
    else:
        fit_markdown = str(getattr(markdown_result, "fit_markdown", "") or "")
        raw_markdown = str(getattr(markdown_result, "raw_markdown", "") or "")
        minimum_fit_chars = min(500, max(120, len(raw_markdown) // 8))
        value = (
            raw_markdown
            if prefer_raw
            else fit_markdown
            if len(fit_markdown.strip()) >= minimum_fit_chars
            else raw_markdown
        )
    stripped = value.strip()
    truncated = len(stripped) > MAX_MARKDOWN_CHARS
    if truncated:
        stripped = stripped[:MAX_MARKDOWN_CHARS].rstrip() + "\n\n[Content truncated]"
    return stripped, truncated


def _cache_path(*, cache_root: Path, url: str, mode: str) -> Path:
    """Return the workroot-local cache path for one normalized page payload."""
    digest = hashlib.sha256(
        f"{CACHE_FORMAT_VERSION}\0{mode}\0{url}".encode("utf-8")
    ).hexdigest()
    return cache_root / "page-cache" / f"{digest}.json"


def _read_page_cache(
    *, cache_root: Path, url: str, mode: str
) -> dict[str, Any] | None:
    """Read one fresh normalized payload from the isolated filesystem cache."""
    path = _cache_path(cache_root=cache_root, url=url, mode=mode)
    try:
        if time.time() - path.stat().st_mtime > CACHE_TTL_SECONDS:
            return None
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return None
    return payload if isinstance(payload, dict) else None


def _write_page_cache(
    *, cache_root: Path, url: str, mode: str, payload: Mapping[str, Any]
) -> None:
    """Persist one normalized page payload atomically beneath the workroot."""
    path = _cache_path(cache_root=cache_root, url=url, mode=mode)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    temporary.replace(path)
