"""Network-boundary validation for browser-backed capabilities."""

from __future__ import annotations

import asyncio
import ipaddress
import socket
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from urllib.parse import urlparse

from .errors import WebNavigationError

MAX_MAIN_FRAME_NAVIGATIONS = 5


def normalized_origin(url: str) -> tuple[str, str, int]:
    """Return the normalized scheme, hostname, and effective port for one URL."""
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise WebNavigationError(
            "Only absolute http and https URLs are supported.", kind="invalid_url"
        )
    default_port = 443 if parsed.scheme == "https" else 80
    return parsed.scheme.lower(), parsed.hostname.lower(), parsed.port or default_port


@dataclass(slots=True)
class NavigationPolicy:
    """Track same-origin main-frame navigation within a finite hop budget."""

    initial_url: str
    max_navigations: int = MAX_MAIN_FRAME_NAVIGATIONS
    navigation_count: int = 0
    violation: WebNavigationError | None = None
    _initial_request_seen: bool = False

    def __post_init__(self) -> None:
        """Validate policy construction and cache the immutable initial origin."""
        if self.max_navigations < 0:
            raise ValueError("max_navigations must not be negative.")
        self.initial_url = validate_public_url(self.initial_url)

    @property
    def initial_origin(self) -> tuple[str, str, int]:
        """Return the exact origin allowed for the browser lifecycle."""
        return normalized_origin(self.initial_url)

    def observe_main_frame_navigation(self, url: str) -> bool:
        """Record one document request and return whether it may continue."""
        try:
            validate_public_url(url)
            if normalized_origin(url) != self.initial_origin:
                raise WebNavigationError(
                    f"Main-frame navigation left the initial origin: {url}.",
                    kind="cross_origin_navigation",
                )
            if not self._initial_request_seen:
                self._initial_request_seen = True
                return True
            self.navigation_count += 1
            if self.navigation_count > self.max_navigations:
                raise WebNavigationError(
                    f"Main-frame navigation exceeded {self.max_navigations} hops.",
                    kind="redirect_limit_exceeded",
                )
        except WebNavigationError as error:
            self.violation = error
            return False
        return True

    def validate_action_url(self, url: str) -> str:
        """Validate an explicit action destination against the initial origin."""
        value = validate_public_url(url)
        if normalized_origin(value) != self.initial_origin:
            raise WebNavigationError(
                f"Navigation action left the initial origin: {value}.",
                kind="cross_origin_navigation",
            )
        return value

    def raise_if_violated(self) -> None:
        """Raise the first navigation-policy violation observed by route handling."""
        if self.violation is not None:
            raise self.violation


def validate_public_url(url: str) -> str:
    """Validate an HTTP(S) URL and require every resolved address to be global."""
    value = str(url).strip()
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise WebNavigationError(
            "Only absolute http and https URLs are supported.", kind="invalid_url"
        )
    if parsed.username is not None or parsed.password is not None:
        raise WebNavigationError(
            "Credentials in URLs are not supported.", kind="invalid_url"
        )
    _validate_host(parsed.hostname, parsed.port)
    return value


def _validate_host(hostname: str, port: int | None) -> None:
    """Reject hostnames that resolve to any non-global network address."""
    try:
        literal = ipaddress.ip_address(hostname)
    except ValueError:
        literal = None
    if literal is not None:
        addresses = {literal}
    else:
        try:
            resolved = socket.getaddrinfo(hostname, port or 443, type=socket.SOCK_STREAM)
        except OSError as error:
            raise WebNavigationError(
                f"Could not resolve URL hostname: {hostname}.", kind="dns_error"
            ) from error
        addresses = {ipaddress.ip_address(item[4][0]) for item in resolved}
    if not addresses or any(not address.is_global for address in addresses):
        raise WebNavigationError(
            f"URL hostname is not publicly routable: {hostname}.", kind="blocked_url"
        )


def build_route_guard(
    *, page: object | None = None, policy: NavigationPolicy | None = None
) -> Callable[[object], Awaitable[None]]:
    """Build a route callback blocking unsafe requests and document navigation."""
    cache: dict[str, bool] = {}

    async def guard(route: object) -> None:
        """Continue safe requests and abort invalid or private destinations."""
        request = getattr(route, "request")
        url = str(getattr(request, "url"))
        is_main_navigation = _is_main_frame_navigation(request=request, page=page)
        if is_main_navigation and policy is not None:
            if not policy.observe_main_frame_navigation(url):
                await getattr(route, "abort")()
                return
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            await getattr(route, "abort")()
            return
        key = f"{parsed.hostname}:{parsed.port or ''}"
        allowed = cache.get(key)
        if allowed is None:
            try:
                await asyncio.to_thread(validate_public_url, url)
            except WebNavigationError:
                allowed = False
            else:
                allowed = True
            cache[key] = allowed
        if allowed:
            await getattr(route, "continue_")()
        else:
            await getattr(route, "abort")()

    return guard


def _is_main_frame_navigation(*, request: object, page: object | None) -> bool:
    """Return whether one routed request navigates the selected page's main frame."""
    is_navigation = getattr(request, "is_navigation_request", None)
    if not callable(is_navigation) or not bool(is_navigation()):
        return False
    if page is None:
        return True
    return getattr(request, "frame", None) is getattr(page, "main_frame", None)
