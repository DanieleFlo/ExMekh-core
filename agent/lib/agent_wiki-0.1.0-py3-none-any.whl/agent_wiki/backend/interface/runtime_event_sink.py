from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from agent_wiki.backend.core.observability.runtime_events import RuntimeEvent


@runtime_checkable
class RuntimeEventSink(Protocol):
    """Define the extension contract for consuming runtime events."""

    def publish(self, event: RuntimeEvent) -> None:
        """Consume one immutable runtime event."""
        ...
