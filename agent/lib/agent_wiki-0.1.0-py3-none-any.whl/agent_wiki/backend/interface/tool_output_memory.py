from __future__ import annotations

from typing import TYPE_CHECKING, Any, Mapping, Protocol, runtime_checkable

if TYPE_CHECKING:
    from agent_wiki.backend.core.capabilities.agent_capabilities import (
        AgentCapabilities,
    )
    from agent_wiki.backend.core.outputs.tool_output_memory import StoredToolOutput


@runtime_checkable
class ToolOutputMemoryInterface(Protocol):
    """Defines reusable tool-output memory behavior for one agent run."""

    def clear(self) -> None:
        """Drop stored output state before a fresh root run starts."""
        ...

    def visible_id_for(self, tool_call_id: str) -> str:
        """Return the model-facing id for a provider tool-call id."""
        ...

    def remember_level_outputs(
        self,
        *,
        chat_agent: Any,
        local_tools: AgentCapabilities,
        level_start_index: int,
        hds_id: str | None = None,
        hds_node_path: tuple[str, ...] | None = None,
    ) -> None:
        """Store reusable outputs produced by a completed local level."""
        ...

    def remember_messages(
        self,
        *,
        local_tool_messages: list[dict[str, Any]],
        local_tools: AgentCapabilities,
        hds_id: str | None = None,
        hds_node_path: tuple[str, ...] | None = None,
    ) -> None:
        """Store normalized local tool messages."""
        ...

    def remember_output(
        self,
        *,
        tool_call_id: Any,
        capability_name: Any,
        content: Any,
        local_tools: AgentCapabilities,
        hds_id: str | None = None,
        hds_node_path: tuple[str, ...] | None = None,
        order: int | None = None,
        visible_tool_call_id: str | None = None,
    ) -> None:
        """Store one normalized capability result for later lookup."""
        ...

    def build_injected_payload(
        self, *, hds_node_path: tuple[str, ...] | None = None
    ) -> dict[str, Any]:
        """Return the full injected memory payload."""
        ...

    def build_awareness_payload(
        self, *, hds_node_path: tuple[str, ...] | None = None
    ) -> dict[str, Any]:
        """Return the payload consumed by output-awareness tools."""
        ...

    def export_outputs(self) -> list[StoredToolOutput]:
        """Return outputs suitable for checkpoint persistence."""
        ...

    def import_outputs(self, payloads: list[Mapping[str, Any]]) -> None:
        """Restore outputs from checkpoint payloads."""
        ...
