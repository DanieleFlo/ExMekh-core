from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol

from agent_wiki.backend.interface.user_question import (
    ChoiceOrTextQuestion,
    ChoiceQuestion,
    FreeTextConfig,
    TextQuestion,
)


@dataclass(frozen=True, slots=True)
class InteractionRequest:
    """Describe one application interaction that requires an external response."""

    id: str
    interaction_type: str
    content: str
    payload: Mapping[str, Any] = field(default_factory=dict)
    allowed_actions: tuple[str, ...] = ()
    turn_id: str | None = None

    def __post_init__(self) -> None:
        """Reject requests that cannot be addressed or rendered safely."""
        if not self.id.strip():
            raise ValueError("Interaction id must contain non-space text.")
        if not self.interaction_type.strip():
            raise ValueError("Interaction type must contain non-space text.")
        if not self.content.strip():
            raise ValueError("Interaction content must contain non-space text.")
        if not self.allowed_actions or any(
            not action.strip() for action in self.allowed_actions
        ):
            raise ValueError("Interaction requests require non-empty allowed actions.")
        if len(set(self.allowed_actions)) != len(self.allowed_actions):
            raise ValueError("Interaction allowed actions must be unique.")

    def to_dict(self) -> dict[str, Any]:
        """Serialize the request for transport clients."""
        return {
            "id": self.id,
            "interaction_type": self.interaction_type,
            "content": self.content,
            "payload": dict(self.payload),
            "allowed_actions": list(self.allowed_actions),
            "turn_id": self.turn_id,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> InteractionRequest:
        """Restore one request from checkpoint-compatible data."""
        allowed_actions = payload.get("allowed_actions")
        if not isinstance(allowed_actions, list) or not all(
            isinstance(action, str) for action in allowed_actions
        ):
            raise ValueError("Interaction allowed_actions must be a string list.")
        request_payload = payload.get("payload")
        if not isinstance(request_payload, Mapping):
            raise ValueError("Interaction payload must be an object.")
        return cls(
            id=str(payload.get("id") or ""),
            interaction_type=str(payload.get("interaction_type") or ""),
            content=str(payload.get("content") or ""),
            payload=dict(request_payload),
            allowed_actions=tuple(allowed_actions),
            turn_id=(
                str(payload["turn_id"])
                if payload.get("turn_id") is not None
                else None
            ),
        )


@dataclass(frozen=True, slots=True)
class InteractionResponse:
    """Represent one external decision for an interaction request."""

    request_id: str
    action: str
    payload: Mapping[str, Any] = field(default_factory=dict)
    content: str | None = None

    def __post_init__(self) -> None:
        """Reject responses without an addressable request and action."""
        if not self.request_id.strip():
            raise ValueError("Interaction response requires a request id.")
        if not self.action.strip():
            raise ValueError("Interaction response requires an action.")

    def to_dict(self) -> dict[str, Any]:
        """Serialize one response for checkpoints and lifecycle events."""
        return {
            "request_id": self.request_id,
            "action": self.action,
            "payload": dict(self.payload),
            "content": self.content,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> InteractionResponse:
        """Restore one response from checkpoint-compatible data."""
        response_payload = payload.get("payload")
        if not isinstance(response_payload, Mapping):
            raise ValueError("Interaction response payload must be an object.")
        return cls(
            request_id=str(payload.get("request_id") or ""),
            action=str(payload.get("action") or ""),
            payload=dict(response_payload),
            content=(
                str(payload["content"])
                if payload.get("content") is not None
                else None
            ),
        )


class InteractionCancelledError(RuntimeError):
    """Signal that an external interaction was cancelled without a response."""


class InteractionHandlerInterface(Protocol):
    """Define the blocking boundary between runtime work and an external client."""

    def request(self, interaction: InteractionRequest) -> InteractionResponse:
        """Publish an interaction and wait until an external response is available."""

    def cancel(self, request_id: str) -> bool:
        """Cancel one pending request and wake its blocked caller."""


def validate_interaction_response(
    *, request: InteractionRequest, action: str, payload: Mapping[str, Any]
) -> None:
    """Validate a response payload against its typed pending interaction."""
    if not request.interaction_type.startswith("user_question."):
        return
    if action != "submit":
        raise ValueError("User questions only accept the submit action.")
    raw_question = request.payload.get("question")
    if not isinstance(raw_question, Mapping):
        raise ValueError("User-question payload is missing its question schema.")
    if request.interaction_type == "user_question.text":
        question = TextQuestion.model_validate(raw_question)
        _validate_response_text(payload.get("text"), question.text)
        return
    if request.interaction_type == "user_question.choice":
        question = ChoiceQuestion.model_validate(raw_question)
        _validate_response_option(payload.get("option_id"), question)
        return
    if request.interaction_type == "user_question.choice_or_text":
        question = ChoiceOrTextQuestion.model_validate(raw_question)
        response_type = payload.get("response_type")
        if response_type == "choice":
            if payload.get("text") is not None:
                raise ValueError("A choice response cannot also contain text.")
            _validate_response_option(payload.get("option_id"), question)
            return
        if response_type == "text":
            if payload.get("option_id") is not None:
                raise ValueError("A text response cannot also contain option_id.")
            _validate_response_text(payload.get("text"), question.text)
            return
        raise ValueError("response_type must be either 'choice' or 'text'.")
    raise ValueError(f"Unsupported user-question type: {request.interaction_type}")


def _validate_response_option(option_id: object, question: ChoiceQuestion) -> None:
    """Validate one option id against a typed question."""
    if not isinstance(option_id, str) or option_id not in {
        option.id for option in question.options
    }:
        raise ValueError("The response must select a declared option_id.")


def _validate_response_text(text: object, config: FreeTextConfig) -> None:
    """Validate one text answer against a typed free-text configuration."""
    if not isinstance(text, str):
        raise ValueError("The response must contain text.")
    if config.required and not text.strip():
        raise ValueError("The response text is required.")
    if len(text) < config.min_length or len(text) > config.max_length:
        raise ValueError(
            f"Response text length must be between {config.min_length} "
            f"and {config.max_length}."
        )
