from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Callable, Mapping, Sequence

from agent_wiki.backend.core.conversation.message import ChatMessage, ToolMessage
from agent_wiki.backend.core.conversation.types import ToolChoice
from agent_wiki.backend.interface.structured_output import StructuredOutputSpec


class ProviderInterface(ABC):
    """
    Common interface implemented by every provider.

    The Chat layer should depend only on the methods exposed by Client,
    which in turn delegates to this interface.
    """

    @property
    @abstractmethod
    def model(self) -> str:
        """Return the model name exposed by the provider."""
        raise NotImplementedError

    def list_available_models(self) -> tuple[str, ...]:
        """Return provider model identifiers when startup discovery is supported."""
        raise NotImplementedError(
            f"{type(self).__name__} does not implement model discovery."
        )

    @abstractmethod
    def build_system_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        """Build a provider-facing system message."""
        raise NotImplementedError

    @abstractmethod
    def build_developer_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        """Build a provider-facing developer message."""
        raise NotImplementedError

    @abstractmethod
    def build_user_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        """Build a provider-facing user message."""
        raise NotImplementedError

    @abstractmethod
    def build_assistant_message(
        self,
        *,
        content: str,
        name: str | None = None,
        tool_calls: Sequence[Mapping[str, Any]] | None = None,
    ) -> ChatMessage:
        """Build a provider-facing assistant message."""
        raise NotImplementedError

    @abstractmethod
    def build_tool_message(
        self,
        *,
        content: str,
        tool_call_id: str,
        name: str | None = None,
    ) -> ToolMessage:
        """Build a provider-facing tool message."""
        raise NotImplementedError

    @abstractmethod
    def build_function_tool(
        self,
        *,
        name: str,
        description: str,
        handler: Callable[..., Any],
        strict: bool = True,
    ) -> dict[str, Any]:
        """Build a provider-facing schema for a regular tool."""
        raise NotImplementedError

    @abstractmethod
    def build_deep_skill_tool(
        self,
        *,
        name: str,
        description: str,
        strict: bool = True,
    ) -> dict[str, Any]:
        """Build a provider-facing schema for a deep skill."""
        raise NotImplementedError

    @abstractmethod
    def build_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        agentic: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Build a provider request without executing it."""
        raise NotImplementedError

    @property
    def supports_thinking(self) -> bool:
        """Return whether this provider can expose model thinking text."""
        return False

    @property
    def supports_thinking_stream(self) -> bool:
        """Return whether this provider can stream model thinking deltas."""
        return False

    @property
    def supports_structured_output(self) -> bool:
        """Return whether this provider can constrain final text to a JSON schema."""
        return False

    @property
    def supports_agentic_capabilities(self) -> bool:
        """Return whether this provider supports the hierarchical agentic extension."""
        return False

    def build_structured_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        structured_output: StructuredOutputSpec[Any],
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
    ) -> dict[str, Any]:
        """Build a structured-output request, falling back to a normal request."""
        return self.build_request(
            messages=messages,
            tools=None,
            tool_choice=None,
            parallel_tool_calls=False,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )

    def create_structured_response(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        structured_output: StructuredOutputSpec[Any],
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        on_thinking_delta: Callable[[str], None] | None = None,
    ) -> Any:
        """Execute a structured-output request, falling back to a normal request."""
        return self.create(
            messages=messages,
            tools=None,
            tool_choice=None,
            parallel_tool_calls=False,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
            on_thinking_delta=on_thinking_delta,
        )

    @abstractmethod
    def create(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        on_thinking_delta: Callable[[str], None] | None = None,
        agentic: Mapping[str, Any] | None = None,
    ) -> Any:
        """Execute a provider request and return the raw response."""
        raise NotImplementedError

    @abstractmethod
    def create_multimodal_text(
        self,
        *,
        prompt: str,
        image_data_urls: Sequence[str],
        model: str | None = None,
        temperature: float | None = None,
        max_output_tokens: int | None = None,
    ) -> str:
        """Execute a text-only response request over image inputs."""
        raise NotImplementedError

    @abstractmethod
    def extract_text(
        self,
        response: Any,
    ) -> str:
        """
        Extract the primary text from a model response.

        This must work independently from the backend implementation.
        """
        raise NotImplementedError

    @abstractmethod
    def extract_tool_calls(
        self,
        response: Any,
    ) -> list[dict[str, Any]]:
        """
        Extract tool calls from the model response.

        Return them in a normalized structure.
        """
        raise NotImplementedError

    @abstractmethod
    def extract_messages(
        self,
        response: Any,
    ) -> list[ChatMessage]:
        """Extract normalized chat messages from a provider response."""
        raise NotImplementedError
