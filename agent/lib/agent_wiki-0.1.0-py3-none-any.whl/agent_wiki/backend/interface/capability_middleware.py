from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from agent_wiki.backend.core.capabilities.deep_skill import DeepSkill
    from agent_wiki.backend.core.capabilities.exit_skill import ExitSkill
    from agent_wiki.backend.core.capabilities.hierarchical_deep_skill import (
        HierarchicalDeepSkill,
    )
    from agent_wiki.backend.core.capabilities.tool import Tool


class CapabilityMiddleware(Protocol):
    """Hook surface used to customize capability construction and execution."""

    def on_tool_loaded(self, *, tool: Tool) -> Tool:
        """Handle one loaded standard tool."""
        ...

    def on_exit_skill_loaded(self, *, exit_skill: ExitSkill) -> ExitSkill:
        """Handle one loaded exit skill."""
        ...

    def on_skill_loaded(self, *, skill: DeepSkill) -> DeepSkill:
        """Handle one loaded deep skill."""
        ...

    def on_hds_loaded(self, *, hds: HierarchicalDeepSkill) -> HierarchicalDeepSkill:
        """Handle one loaded hierarchical deep skill."""
        ...


class PassthroughCapabilityMiddleware:
    """Default no-op middleware implementation useful in tests and extensions."""

    def on_tool_loaded(self, *, tool: Tool) -> Tool:
        """Return a loaded tool unchanged."""
        return tool

    def on_exit_skill_loaded(self, *, exit_skill: ExitSkill) -> ExitSkill:
        """Return a loaded exit skill unchanged."""
        return exit_skill

    def on_skill_loaded(self, *, skill: DeepSkill) -> DeepSkill:
        """Return a loaded deep skill unchanged."""
        return skill

    def on_hds_loaded(self, *, hds: HierarchicalDeepSkill) -> HierarchicalDeepSkill:
        """Return a loaded hierarchical deep skill unchanged."""
        return hds
