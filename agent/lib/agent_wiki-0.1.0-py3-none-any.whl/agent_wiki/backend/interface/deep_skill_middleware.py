from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Protocol, TypeAlias

from agent_wiki.backend.core.conversation.message import ChatMessage
from agent_wiki.backend.interface.envelope import EnvelopeMetadata


DeepSkillHistory: TypeAlias = tuple[ChatMessage, ...]


@dataclass(frozen=True, slots=True, kw_only=True)
class DeepSkillPatch:
    """Describe invocation-local changes applied after a deep skill opens."""

    content: str | None = None
    sub_tool_names: tuple[str, ...] | list[str] | None = None
    sub_skill_names: tuple[str, ...] | list[str] | None = None


@dataclass(frozen=True, slots=True, kw_only=True)
class DeepSkillBeforeResult:
    """Describe optional changes produced before a deep skill opens."""

    message: ChatMessage | None = None


@dataclass(frozen=True, slots=True, kw_only=True)
class DeepSkillAfterResult:
    """Describe optional changes produced after a deep skill opens."""

    patch: DeepSkillPatch | None = None
    metadata: EnvelopeMetadata | None = None


class DeepSkillBeforeHook(Protocol):
    """Define the callable contract for a pre-descent deep-skill hook."""

    def __call__(self, history: DeepSkillHistory) -> DeepSkillBeforeResult | None:
        """Return optional pre-open changes for the child level."""
        ...


class DeepSkillAfterHook(Protocol):
    """Define the callable contract for a post-injection deep-skill hook."""

    def __call__(
        self, history: DeepSkillHistory, metadata: EnvelopeMetadata
    ) -> DeepSkillAfterResult | None:
        """Return optional post-open changes for the child level."""
        ...


DeepSkillBeforeCallable: TypeAlias = Callable[
    [DeepSkillHistory],
    DeepSkillBeforeResult | None,
]
DeepSkillAfterCallable: TypeAlias = Callable[
    [DeepSkillHistory, EnvelopeMetadata],
    DeepSkillAfterResult | None,
]


@dataclass(frozen=True, slots=True, kw_only=True)
class DeepSkillMiddleware:
    """Store the optional runtime hooks owned by one deep skill."""

    before: DeepSkillBeforeCallable | None = None
    after: DeepSkillAfterCallable | None = None
