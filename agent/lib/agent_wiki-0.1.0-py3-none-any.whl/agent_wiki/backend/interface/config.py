from __future__ import annotations

from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Iterator,
    Mapping,
    Protocol,
    Self,
    runtime_checkable,
)

from .checkpoint import CheckpointPolicyInterface, CheckpointStoreInterface
from .tool_output_memory import ToolOutputMemoryInterface
from .loop_detection import LoopDetectorInterface
from agent_wiki.configs.agent import AgentConfig
from agent_wiki.configs.runtime import RuntimeConfigOverrides, RuntimePackageConfig

if TYPE_CHECKING:
    from agent_wiki.backend.core.capabilities.deep_skill import DeepSkill
    from agent_wiki.backend.core.config.hds_config import (
        HDSStructureNode,
        ResolvedHDSNodeConfig,
    )


@runtime_checkable
class SystemConfigInterface(Protocol):
    """Defines the behavior required from internal system configuration."""

    @classmethod
    def load_default(cls) -> Self:
        """Load the default internal system configuration."""
        ...

    def resolve_package_path(self, path: Path | str) -> Path:
        """Resolve one path relative to the installed package root."""
        ...

    def runtime_defaults(self) -> Mapping[str, object]:
        """Return default runtime values inherited by root nodes."""
        ...

    def capability_defaults(self) -> Mapping[str, object]:
        """Return default capability loader values."""
        ...

    def validate(self) -> None:
        """Validate the loaded system configuration."""
        ...


@runtime_checkable
class DynamicSubSkillResolverInterface(Protocol):
    """Resolve invocation-time sub-skills for one configured HDS node."""

    def resolve(
        self,
        *,
        config: Any,
        workroot: Path,
    ) -> list["DeepSkill"]:
        """Return the ordered dynamic sub-skills for the current node state."""
        ...


@runtime_checkable
class GraphNodeConfigInterface(Protocol):
    """Describes user-facing HDS node configuration behavior."""

    name: str
    children: list["GraphNodeConfigInterface"]
    workroot: Path | str | None
    excluded_tool_names: list[str] | None
    preserve_history: bool | None
    prompt_variables: Mapping[str, str] | None
    agent: AgentConfig | None
    runtime: RuntimeConfigOverrides | None
    checkpoint_store: CheckpointStoreInterface | None
    checkpoint_policy: CheckpointPolicyInterface | None
    tool_output_memory: ToolOutputMemoryInterface | None
    dynamic_sub_skill_resolver: DynamicSubSkillResolverInterface | None
    loop_detector: LoopDetectorInterface | None

    def resolve(
        self,
        system_config: SystemConfigInterface,
        parent: "ResolvedHDSNodeConfig | None" = None,
    ) -> "ResolvedHDSNodeConfig":
        """Resolve this node against a parent and system defaults."""
        ...

    def iter_children(self) -> Iterator["GraphNodeConfigInterface"]:
        """Yield child node configs in insertion order."""
        ...

    def to_hds_structure_node(self) -> "HDSStructureNode":
        """Convert the config object into a runtime HDS structure node."""
        ...

    def validate(self) -> None:
        """Validate node configuration before runtime starts."""
        ...


@runtime_checkable
class GraphConfigInterface(Protocol):
    """Describes user-facing HDS graph configuration behavior."""

    main: GraphNodeConfigInterface
    system_config: SystemConfigInterface

    def resolve(self) -> "ResolvedHDSNodeConfig":
        """Resolve the root node and its descendants using system defaults."""
        ...

    def to_hds_structure_node(self) -> "HDSStructureNode":
        """Convert the graph config object into a runtime HDS structure node."""
        ...

    def validate(self) -> None:
        """Validate graph and node configuration before runtime starts."""
        ...
    config: RuntimePackageConfig
