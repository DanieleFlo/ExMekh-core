"""Public contract for resolving tool HITL interactions."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from agent_wiki.backend.core.capabilities.tool import (
        ToolHITLContext,
        ToolHITLResolution,
    )


@runtime_checkable
class ToolHITLResolverInterface(Protocol):
    """Resolve one external HITL decision into a typed tool outcome."""

    def resolve(self, context: ToolHITLContext) -> ToolHITLResolution:
        """Return whether and with which arguments the tool should execute."""
        ...
