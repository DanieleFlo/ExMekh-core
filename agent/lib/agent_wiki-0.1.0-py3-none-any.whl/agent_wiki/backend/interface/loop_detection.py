from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from agent_wiki.backend.core.conversation.message import ChatMessage


@dataclass(frozen=True, slots=True)
class LoopDetectionContext:
    """Describe the bounded runtime state available to a loop detector."""

    history: tuple["ChatMessage", ...]
    latest_thinking: str | None
    tool_names: tuple[str, ...]
    skill_names: tuple[str, ...]
    level_path: tuple[str, ...]
    current_skill: str | None
    system_prompt: str
    client: Any
    model_config: Any


@dataclass(frozen=True, slots=True)
class LoopDetectionResult:
    """Describe a confirmed unwanted loop and its safe closing explanation."""

    explanation: str
    signature: str
    repetitions: int


@runtime_checkable
class LoopDetectorInterface(Protocol):
    """Detect unwanted repetition without mutating agent runtime state."""

    def detect(self, context: LoopDetectionContext) -> LoopDetectionResult | None:
        """Return a result only when the current level should be force-closed."""
        ...
