"""Public control contract for invocation-local dynamic pipelines."""

from __future__ import annotations

from typing import Protocol


class DynamicPipelineRuntimeInterface(Protocol):
    """Create and run text-to-text pipelines in the active skill invocation."""

    def create_pipeline(
        self,
        *,
        name: str,
        kind: str,
        steps: list[dict[str, str]],
        carry_outputs: bool = False,
        success_message: str = "Loop executed successfully.",
        output_prefix: str = "<output>",
        output_suffix: str = "</output>",
    ) -> str:
        """Validate and register one dynamic pipeline."""
        ...

    def run_pipeline(
        self,
        *,
        name: str,
        message: str | None = None,
        messages: list[str] | None = None,
        static_text: str | None = None,
    ) -> str:
        """Run or resume one registered dynamic pipeline."""
        ...
