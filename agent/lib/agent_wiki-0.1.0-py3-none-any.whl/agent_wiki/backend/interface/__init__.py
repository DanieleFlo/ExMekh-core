"""Interface contracts for backend extension points."""

from .capability_middleware import (
    CapabilityMiddleware,
    PassthroughCapabilityMiddleware,
)
from .checkpoint import CheckpointPolicyInterface, CheckpointStoreInterface
from .deep_skill_middleware import (
    DeepSkillAfterHook,
    DeepSkillAfterResult,
    DeepSkillBeforeHook,
    DeepSkillBeforeResult,
    DeepSkillHistory,
    DeepSkillMiddleware,
    DeepSkillPatch,
)
from .envelope import EnvelopeMetadata
from .provider import ProviderInterface
from .pipeline import (
    ToolInputAdapter,
    ToolInputAdapterContext,
    pipeline_tool_input_adapter,
)
from .runtime_event_sink import RuntimeEventSink
from .interaction import (
    InteractionCancelledError,
    InteractionHandlerInterface,
    InteractionRequest,
    InteractionResponse,
)
from .tool_output_memory import ToolOutputMemoryInterface
from .tool_hitl import ToolHITLResolverInterface
from .loop_detection import (
    LoopDetectionContext,
    LoopDetectionResult,
    LoopDetectorInterface,
)

__all__ = [
    "CapabilityMiddleware",
    "CheckpointPolicyInterface",
    "CheckpointStoreInterface",
    "DeepSkillAfterHook",
    "DeepSkillAfterResult",
    "DeepSkillBeforeHook",
    "DeepSkillBeforeResult",
    "DeepSkillHistory",
    "DeepSkillMiddleware",
    "DeepSkillPatch",
    "EnvelopeMetadata",
    "PassthroughCapabilityMiddleware",
    "ToolInputAdapter",
    "ToolInputAdapterContext",
    "ProviderInterface",
    "RuntimeEventSink",
    "InteractionCancelledError",
    "InteractionHandlerInterface",
    "InteractionRequest",
    "InteractionResponse",
    "ToolOutputMemoryInterface",
    "ToolHITLResolverInterface",
    "LoopDetectionContext",
    "LoopDetectionResult",
    "LoopDetectorInterface",
    "pipeline_tool_input_adapter",
]
