"""Typed contracts for application interactions that ask a user a question."""

from __future__ import annotations

from typing import Annotated, Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field, model_validator


MAX_USER_QUESTION_TEXT_LENGTH = 512
NonBlankText = Annotated[
    str,
    Field(
        min_length=1,
        max_length=MAX_USER_QUESTION_TEXT_LENGTH,
        pattern=r".*\S.*",
    ),
]
BoundedText = Annotated[
    str,
    Field(max_length=MAX_USER_QUESTION_TEXT_LENGTH),
]


class StrictQuestionModel(BaseModel):
    """Reject undeclared fields in every user-question transport model."""

    model_config = ConfigDict(extra="forbid")


class QuestionOption(StrictQuestionModel):
    """Describe one selectable answer exposed to the user."""

    id: NonBlankText
    title: NonBlankText
    comment: NonBlankText | None = None


class FreeTextConfig(StrictQuestionModel):
    """Configure the free-text control rendered for one question."""

    label: NonBlankText
    placeholder: NonBlankText | None = None
    required: bool = True
    min_length: int = Field(
        default=1, ge=0, le=MAX_USER_QUESTION_TEXT_LENGTH
    )
    max_length: int = Field(
        default=MAX_USER_QUESTION_TEXT_LENGTH,
        ge=1,
        le=MAX_USER_QUESTION_TEXT_LENGTH,
    )

    @model_validator(mode="after")
    def validate_length_range(self) -> FreeTextConfig:
        """Require the maximum text length to cover the configured minimum."""
        if self.max_length < self.min_length:
            raise ValueError("max_length must be greater than or equal to min_length")
        if self.required and self.min_length < 1:
            raise ValueError("required free text must have min_length of at least 1")
        return self


class TextQuestion(StrictQuestionModel):
    """Describe one question answered exclusively with free text."""

    question_id: NonBlankText
    title: NonBlankText
    question: NonBlankText
    comment: NonBlankText | None = None
    text: FreeTextConfig


class ChoiceQuestion(StrictQuestionModel):
    """Describe one question answered with exactly one predefined option."""

    question_id: NonBlankText
    title: NonBlankText
    question: NonBlankText
    comment: NonBlankText | None = None
    options: list[QuestionOption] = Field(min_length=2)

    @model_validator(mode="after")
    def validate_unique_option_ids(self) -> ChoiceQuestion:
        """Reject duplicate option identifiers within one question."""
        option_ids = [option.id for option in self.options]
        if len(option_ids) != len(set(option_ids)):
            raise ValueError("option identifiers must be unique")
        return self


class ChoiceOrTextQuestion(ChoiceQuestion):
    """Describe a choice question with a mutually exclusive text alternative."""

    text: FreeTextConfig


class TextQuestionAnswer(StrictQuestionModel):
    """Represent a validated free-text answer returned to the agent."""

    question_id: NonBlankText
    response_type: Literal["text"] = "text"
    text: BoundedText


class ChoiceQuestionAnswer(StrictQuestionModel):
    """Represent a validated predefined-option answer."""

    question_id: NonBlankText
    response_type: Literal["choice"] = "choice"
    option_id: NonBlankText


class ChoiceOrTextQuestionAnswer(StrictQuestionModel):
    """Represent either branch of a choice-or-text answer."""

    question_id: NonBlankText
    response_type: Literal["choice", "text"]
    option_id: NonBlankText | None = None
    text: BoundedText | None = None

    @model_validator(mode="after")
    def validate_exclusive_answer(self) -> ChoiceOrTextQuestionAnswer:
        """Require exactly the field selected by response_type."""
        if self.response_type == "choice" and (
            self.option_id is None or self.text is not None
        ):
            raise ValueError("choice responses require only option_id")
        if self.response_type == "text" and (
            self.text is None or self.option_id is not None
        ):
            raise ValueError("text responses require only text")
        return self


class UserQuestionRuntimeInterface(Protocol):
    """Expose blocking typed user questions to regular tool handlers."""

    def ask_text(self, question: TextQuestion) -> TextQuestionAnswer:
        """Ask one free-text question and return its validated answer."""

    def ask_choice(self, question: ChoiceQuestion) -> ChoiceQuestionAnswer:
        """Ask one single-choice question and return its validated answer."""

    def ask_choice_or_text(
        self, question: ChoiceOrTextQuestion
    ) -> ChoiceOrTextQuestionAnswer:
        """Ask one choice-or-text question and return its validated answer."""
