from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

import yaml


@dataclass(frozen=True, slots=True, kw_only=True)
class EnvelopeMetadata:
    """Represent model-facing YAML metadata for a tool result envelope."""

    values: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Store a normalized immutable metadata mapping."""
        normalized_values = _normalize_metadata_mapping(self.values)
        object.__setattr__(self, "values", MappingProxyType(normalized_values))

    def with_level_path(self, *, level_path: tuple[str, ...]) -> "EnvelopeMetadata":
        """Return metadata merged with the authoritative runtime level path."""
        merged_values: dict[str, Any] = {
            "level_path": format_level_path(level_path=level_path)
        }
        merged_values.update(
            {
                str(key): value
                for key, value in self.values.items()
                if str(key) not in {"depth", "level_path"}
            }
        )
        return EnvelopeMetadata(values=merged_values)

    def to_yaml(self) -> str:
        """Serialize metadata as compact YAML."""
        return yaml.safe_dump(
            dict(self.values),
            allow_unicode=True,
            default_flow_style=False,
            sort_keys=False,
        ).strip()

    @classmethod
    def empty(cls) -> "EnvelopeMetadata":
        """Return an empty metadata object."""
        return cls(values={})

    @classmethod
    def from_values(cls, values: Mapping[str, Any]) -> "EnvelopeMetadata | None":
        """Build metadata from non-null values, returning None when empty."""
        normalized_values = {
            str(key): _normalize_metadata_value(value)
            for key, value in values.items()
            if value is not None
        }
        if not normalized_values:
            return None
        return cls(values=normalized_values)


def ensure_envelope_metadata(
    value: EnvelopeMetadata | Mapping[str, Any] | None,
) -> EnvelopeMetadata | None:
    """Normalize optional envelope metadata into the canonical dataclass."""
    if value is None:
        return None
    if isinstance(value, EnvelopeMetadata):
        return value
    if isinstance(value, Mapping):
        return EnvelopeMetadata.from_values(value)
    raise TypeError(
        "Envelope metadata must be EnvelopeMetadata, a mapping, or None, "
        f"got {type(value).__name__}."
    )


def render_envelope_metadata(
    *,
    metadata: EnvelopeMetadata | Mapping[str, Any] | None,
    level_path: tuple[str, ...],
) -> str:
    """Render metadata with runtime level path protected from caller overrides."""
    normalized = ensure_envelope_metadata(metadata) or EnvelopeMetadata.empty()
    return normalized.with_level_path(level_path=level_path).to_yaml()


def compact_metadata_text(value: Any, *, edge_length: int = 20) -> str:
    """Return a first-and-last character preview for model-facing metadata."""
    normalized = str(value)
    normalized_edge_length = max(0, int(edge_length))
    if normalized_edge_length == 0:
        return ""
    if len(normalized) <= normalized_edge_length * 2:
        return normalized
    omitted = len(normalized) - (normalized_edge_length * 2)
    return (
        f"{normalized[:normalized_edge_length]}..."
        f"[{omitted} chars omitted]..."
        f"{normalized[-normalized_edge_length:]}"
    )


def compact_metadata_value(value: Any, *, edge_length: int = 20) -> Any:
    """Recursively compact metadata values while preserving YAML-safe structure."""
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return compact_metadata_text(value, edge_length=edge_length)
    if isinstance(value, Path):
        return compact_metadata_text(str(value), edge_length=edge_length)
    if isinstance(value, tuple):
        return [compact_metadata_value(item, edge_length=edge_length) for item in value]
    if isinstance(value, list):
        return [compact_metadata_value(item, edge_length=edge_length) for item in value]
    if isinstance(value, Mapping):
        return {
            str(key): compact_metadata_value(child_value, edge_length=edge_length)
            for key, child_value in value.items()
            if child_value is not None
        }
    try:
        yaml.safe_dump(value, allow_unicode=True, sort_keys=False)
    except Exception:
        return compact_metadata_text(value, edge_length=edge_length)
    return value


def format_level_path(*, level_path: tuple[str, ...] | list[str] | None) -> str:
    """Format a runtime level path with a leading slash for model-facing text."""
    if not level_path:
        return "/"
    return "/" + "/".join(str(segment).strip("/") for segment in level_path)


def _normalize_metadata_mapping(values: Mapping[str, Any]) -> dict[str, Any]:
    """Normalize and validate one metadata mapping."""
    normalized_values = {
        str(key): _normalize_metadata_value(value)
        for key, value in values.items()
        if value is not None
    }
    yaml.safe_dump(normalized_values, allow_unicode=True, sort_keys=False)
    return normalized_values


def _normalize_metadata_value(value: Any) -> Any:
    """Convert common Python values into YAML-safe metadata values."""
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, tuple):
        return [_normalize_metadata_value(item) for item in value]
    if isinstance(value, list):
        return [_normalize_metadata_value(item) for item in value]
    if isinstance(value, Mapping):
        return {
            str(key): _normalize_metadata_value(child_value)
            for key, child_value in value.items()
            if child_value is not None
        }
    return value
