"""Public contracts for configured-pipeline tool input adapters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class ToolInputAdapterContext:
    """Provide one adapter with detached runtime data for a pipeline tool call."""

    text: str
    tool: Any
    history: tuple[Mapping[str, Any], ...]
    client: Any
    config: Any


@runtime_checkable
class ToolInputAdapter(Protocol):
    """Convert pipeline text into the public arguments accepted by one tool."""

    def adapt(self, context: ToolInputAdapterContext) -> Mapping[str, Any]:
        """Return validated public arguments for the receiving tool."""
        ...


def pipeline_tool_input_adapter(method: Any) -> Any:
    """Mark the one custom method used to adapt configured-pipeline tool input."""
    setattr(method, "__pipeline_tool_input_adapter__", True)
    return method
