from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from agent_wiki.backend.core.checkpoints.checkpoint import CheckpointRecord


@runtime_checkable
class CheckpointStoreInterface(Protocol):
    """Defines persistence behavior for runtime checkpoint records."""

    def save(self, *, record: CheckpointRecord) -> Path | None:
        """Persist one checkpoint record and return a location when available."""
        ...

    def load(self, path: Path | str) -> CheckpointRecord:
        """Load one checkpoint record from an implementation-specific location."""
        ...


@runtime_checkable
class CheckpointPolicyInterface(Protocol):
    """Defines checkpoint trigger decisions for a DeepAgent runtime."""

    def should_save_before_execution(self) -> bool:
        """Return whether to checkpoint before a tool or skill executes."""
        ...

    def should_save_after_skill_close(self) -> bool:
        """Return whether to checkpoint after a child skill closes."""
        ...

    def should_save_after_message_count(
        self,
        *,
        message_count: int,
        last_checkpoint_message_count: int,
    ) -> bool:
        """Return whether the current message count crosses a checkpoint threshold."""
        ...
