"""Backward-compatible import path for provider contracts."""

from ..interface.provider import ProviderInterface

__all__ = ["ProviderInterface"]
