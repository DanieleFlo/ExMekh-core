from __future__ import annotations

from dataclasses import dataclass, field
import logging
from typing import Any, Callable, Mapping, Sequence

from openai import OpenAI

from agent_wiki.backend.core.conversation.message import (
    AssistantMessage,
    ChatMessage,
    DeveloperMessage,
    SystemMessage,
    ToolMessage,
    UserMessage,
)
from agent_wiki.backend.core.capabilities.tool import build_handler_parameters_schema
from agent_wiki.backend.core.conversation.types import (
    ModelResponse,
    ModelThinking,
    ModelTokenUsage,
    ToolChoice,
)
from agent_wiki.backend.interface.structured_output import StructuredOutputSpec
from ..interface.provider import ProviderInterface
from .model_validation import extract_openai_model_ids, validate_configured_model

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class _OpenAIChatCompletionsProvider(ProviderInterface):
    """Provider base for OpenAI-compatible Chat Completions backends."""

    model_name: str
    base_url: str
    api_key: str
    timeout: float | None
    max_retries: int
    default_headers: Mapping[str, str] | None = None

    _sdk_client: OpenAI = field(init=False, repr=False)

    def __post_init__(self) -> None:
        """Initialize the OpenAI SDK client for a Chat Completions endpoint."""
        client_options: dict[str, Any] = {
            "base_url": self.base_url,
            "api_key": self.api_key,
            "max_retries": self.max_retries,
        }

        if self.timeout is not None:
            client_options["timeout"] = self.timeout

        if self.default_headers:
            client_options["default_headers"] = dict(self.default_headers)

        self._sdk_client = OpenAI(**client_options)
        self.validate_model()

    @property
    def provider_name(self) -> str:
        """Return the provider name used in startup validation errors."""
        return type(self).__name__.removeprefix("_").removesuffix(
            "ChatCompletionsProvider"
        )

    @property
    def models_endpoint(self) -> str:
        """Return the OpenAI-compatible model-list endpoint."""
        return f"{self.base_url.rstrip('/')}/models"

    def list_available_models(self) -> tuple[str, ...]:
        """Return model identifiers exposed by the compatible models endpoint."""
        response = self._sdk_client.models.list()
        return extract_openai_model_ids(
            response,
            provider_name=self.provider_name,
            endpoint=self.models_endpoint,
        )

    def validate_model(self) -> None:
        """Require the configured model to exist before serving requests."""
        validate_configured_model(
            provider_name=self.provider_name,
            model_name=self.model_name,
            endpoint=self.models_endpoint,
            fetch_model_ids=self.list_available_models,
        )

    @property
    def model(self) -> str:
        """Return the configured model name."""
        return self.model_name

    def build_system_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        """Build a system message for the Chat Completions schema."""
        return SystemMessage(content=content, name=name)

    def build_developer_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        """Build a developer message for the Chat Completions schema."""
        return DeveloperMessage(content=content, name=name)

    def build_user_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        """Build a user message for the Chat Completions schema."""
        return UserMessage(content=content, name=name)

    def build_assistant_message(
        self,
        *,
        content: str,
        name: str | None = None,
        tool_calls: Sequence[Mapping[str, Any]] | None = None,
    ) -> ChatMessage:
        """Build an assistant message for the Chat Completions schema."""
        return AssistantMessage(
            content=content,
            name=name,
            tool_calls=tool_calls or [],
        )

    def build_tool_message(
        self,
        *,
        content: str,
        tool_call_id: str,
        name: str | None = None,
    ) -> ToolMessage:
        """Build a tool result message for the Chat Completions schema."""
        return ToolMessage(
            content=content,
            tool_call_id=tool_call_id,
            name=name,
        )

    def build_function_tool(
        self,
        *,
        name: str,
        description: str,
        handler: Callable[..., Any],
        strict: bool = True,
    ) -> dict[str, Any]:
        """Build a Chat Completions function tool schema."""
        return {
            "type": "function",
            "function": {
                "name": name,
                "description": description,
                "parameters": build_handler_parameters_schema(handler),
                "strict": strict,
            },
        }

    def build_deep_skill_tool(
        self,
        *,
        name: str,
        description: str,
        strict: bool = True,
    ) -> dict[str, Any]:
        """Build a Chat Completions function schema for a deep skill."""
        return {
            "type": "function",
            "function": {
                "name": name,
                "description": description,
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "additionalProperties": False,
                },
                "strict": strict,
            },
        }

    def build_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
    ) -> dict[str, Any]:
        """Build a Chat Completions request payload without executing it."""
        request: dict[str, Any] = {
            "model": self.model_name,
            "messages": [dict(message) for message in messages],
        }

        if tools:
            request["tools"] = [dict(tool) for tool in tools]
            request["parallel_tool_calls"] = parallel_tool_calls

            if tool_choice is not None:
                request["tool_choice"] = tool_choice

        if temperature is not None:
            request["temperature"] = temperature

        if top_p is not None:
            request["top_p"] = top_p

        if max_output_tokens is not None:
            request["max_tokens"] = max_output_tokens

        if stop is not None:
            request["stop"] = list(stop)

        if seed is not None:
            request["seed"] = seed

        if user is not None:
            request["user"] = user

        return request

    def build_structured_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        structured_output: StructuredOutputSpec[Any],
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
    ) -> dict[str, Any]:
        """Build a Chat Completions request without native schema constraints."""
        return self.build_request(
            messages=messages,
            tools=None,
            tool_choice=None,
            parallel_tool_calls=False,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )

    def create(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        on_thinking_delta: Callable[[str], None] | None = None,
    ) -> ModelResponse:
        """Execute a Chat Completions request and wrap the raw response."""
        request = self.build_request(
            messages=messages,
            tools=tools,
            tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )

        if on_thinking_delta is not None:
            return self._create_streaming_response(
                request=request,
                on_thinking_delta=on_thinking_delta,
            )

        logger.debug(
            "Sending Chat Completions request",
            extra={"request_summary": _summarize_chat_request(request)},
        )

        try:
            raw_response = self._sdk_client.chat.completions.create(**request)
            return ModelResponse(
                response=raw_response,
                thinking=_extract_chat_thinking(raw_response),
                usage=ModelTokenUsage.from_value(_get_value(raw_response, "usage")),
            )
        except Exception:
            logger.exception(
                "Chat Completions request failed",
                extra={"request_summary": _summarize_chat_request(request)},
            )
            raise

    def create_structured_response(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        structured_output: StructuredOutputSpec[Any],
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        on_thinking_delta: Callable[[str], None] | None = None,
    ) -> ModelResponse:
        """Execute a Chat Completions request for structured text output."""
        request = self.build_structured_request(
            messages=messages,
            structured_output=structured_output,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )

        if on_thinking_delta is not None:
            return self._create_streaming_response(
                request=request,
                on_thinking_delta=on_thinking_delta,
            )

        logger.debug(
            "Sending Chat Completions structured-output request",
            extra={"request_summary": _summarize_chat_request(request)},
        )

        try:
            raw_response = self._sdk_client.chat.completions.create(**request)
            return ModelResponse(
                response=raw_response,
                thinking=_extract_chat_thinking(raw_response),
                usage=ModelTokenUsage.from_value(_get_value(raw_response, "usage")),
            )
        except Exception:
            logger.exception(
                "Chat Completions structured-output request failed",
                extra={"request_summary": _summarize_chat_request(request)},
            )
            raise

    def create_multimodal_text(
        self,
        *,
        prompt: str,
        image_data_urls: Sequence[str],
        model: str | None = None,
        temperature: float | None = None,
        max_output_tokens: int | None = None,
    ) -> str:
        """Execute a Chat Completions vision request and return assistant text."""
        content: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
        content.extend(
            {"type": "image_url", "image_url": {"url": image_data_url}}
            for image_data_url in image_data_urls
        )
        request: dict[str, Any] = {
            "model": model or self.model_name,
            "messages": [{"role": "user", "content": content}],
        }
        if temperature is not None:
            request["temperature"] = temperature
        if max_output_tokens is not None:
            request["max_tokens"] = max_output_tokens

        response = self._sdk_client.chat.completions.create(**request)
        choices = getattr(response, "choices", None)
        if not choices:
            return ""
        message = getattr(choices[0], "message", None)
        content_text = (
            getattr(message, "content", None) if message is not None else None
        )
        return content_text if isinstance(content_text, str) else ""

    def extract_text(
        self,
        response: ModelResponse,
    ) -> str:
        """Extract assistant text from a Chat Completions response."""
        choices = _get_value(response.response, "choices") if response else None

        if not choices:
            return ""

        message = _get_value(choices[0], "message")
        if message is None:
            return ""

        content = _get_value(message, "content")
        return content if isinstance(content, str) else ""

    def extract_tool_calls(
        self,
        response: ModelResponse,
    ) -> list[dict[str, Any]]:
        """Extract normalized tool calls from a Chat Completions response."""
        tool_calls: list[dict[str, Any]] = []

        choices = _get_value(response.response, "choices") if response else None
        if not choices:
            return tool_calls

        message = _get_value(choices[0], "message")
        if message is None:
            return tool_calls

        raw_tool_calls = _get_value(message, "tool_calls") if message else None
        if not raw_tool_calls:
            return tool_calls

        for tool_call in raw_tool_calls:
            function = _get_value(tool_call, "function")

            tool_calls.append(
                {
                    "id": _get_value(tool_call, "id"),
                    "type": _get_value(tool_call, "type") or "function",
                    "function": {
                        "name": _get_value(function, "name"),
                        "arguments": _get_value(function, "arguments"),
                    },
                }
            )

        return tool_calls

    def extract_messages(
        self,
        response: ModelResponse,
    ) -> list[ChatMessage]:
        """Extract normalized messages from a Chat Completions response."""
        choices = _get_value(response.response, "choices") if response else None
        if not choices:
            return []

        message = _get_value(choices[0], "message")
        if message is None:
            return []

        role = _get_value(message, "role") or "assistant"
        content = _get_value(message, "content")
        text_content = content if isinstance(content, str) else ""
        tool_calls = self.extract_tool_calls(response)

        if role == "tool":
            tool_call_id = _get_value(message, "tool_call_id")
            if isinstance(tool_call_id, str):
                return [
                    self.build_tool_message(
                        content=text_content,
                        tool_call_id=tool_call_id,
                        name=_get_value(message, "name"),
                    )
                ]

        if not text_content and not tool_calls:
            return []

        return [
            self.build_assistant_message(
                content=text_content,
                name=_get_value(message, "name"),
                tool_calls=tool_calls,
            )
        ]

    def _create_streaming_response(
        self,
        *,
        request: Mapping[str, Any],
        on_thinking_delta: Callable[[str], None],
    ) -> ModelResponse:
        """Execute a streaming request and rebuild one normalized response."""
        streaming_request = dict(request)
        streaming_request["stream"] = True
        streaming_request["stream_options"] = {"include_usage": True}
        content_parts: list[str] = []
        thinking_parts: list[str] = []
        tool_calls_by_index: dict[int, dict[str, Any]] = {}
        finish_reason: str | None = None
        usage: ModelTokenUsage | None = None

        logger.debug(
            "Sending streaming Chat Completions request",
            extra={"request_summary": _summarize_chat_request(streaming_request)},
        )
        try:
            stream = self._sdk_client.chat.completions.create(**streaming_request)
            for chunk in stream:
                chunk_usage = ModelTokenUsage.from_value(_get_value(chunk, "usage"))
                if chunk_usage is not None:
                    usage = chunk_usage
                choices = _get_value(chunk, "choices")
                if not choices:
                    continue
                choice = choices[0]
                finish_reason = _get_value(choice, "finish_reason") or finish_reason
                delta = _get_value(choice, "delta")
                if delta is None:
                    continue
                thinking_delta = _extract_thinking_delta(delta)
                if thinking_delta:
                    thinking_parts.append(thinking_delta)
                    on_thinking_delta(thinking_delta)
                content_delta = _get_value(delta, "content")
                if isinstance(content_delta, str):
                    content_parts.append(content_delta)
                _merge_tool_call_deltas(
                    tool_calls_by_index=tool_calls_by_index,
                    raw_tool_calls=_get_value(delta, "tool_calls"),
                )
        except Exception:
            logger.exception(
                "Streaming Chat Completions request failed",
                extra={"request_summary": _summarize_chat_request(streaming_request)},
            )
            raise

        response = {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "".join(content_parts),
                        "tool_calls": [
                            tool_calls_by_index[index]
                            for index in sorted(tool_calls_by_index)
                        ],
                    },
                    "finish_reason": finish_reason,
                }
            ]
        }
        return ModelResponse(
            response=response,
            thinking=ModelThinking.from_value("".join(thinking_parts)),
            usage=usage,
        )


def _get_value(value: Any, key: str) -> Any:
    """Read one field from either mapping-like or SDK object values."""
    if isinstance(value, Mapping):
        return value.get(key)
    return getattr(value, key, None)


def _extract_chat_thinking(response: Any) -> ModelThinking | None:
    """Extract complete thinking text from known Chat Completions response shapes."""
    choices = _get_value(response, "choices")
    if not choices:
        return None
    message = _get_value(choices[0], "message")
    if message is None:
        return None
    for key in ("reasoning_content", "thinking", "reasoning"):
        thinking = ModelThinking.from_value(_get_value(message, key))
        if thinking is not None:
            return thinking
    return None


def _extract_thinking_delta(delta: Any) -> str:
    """Extract one streaming thinking delta from known provider delta shapes."""
    for key in ("reasoning_content", "thinking", "reasoning"):
        value = _get_value(delta, key)
        if isinstance(value, str) and value:
            return value
    return ""


def _merge_tool_call_deltas(
    *,
    tool_calls_by_index: dict[int, dict[str, Any]],
    raw_tool_calls: Any,
) -> None:
    """Merge OpenAI-compatible streamed tool-call deltas by their index."""
    if not raw_tool_calls:
        return
    for raw_tool_call in raw_tool_calls:
        index = _get_value(raw_tool_call, "index")
        if not isinstance(index, int):
            index = len(tool_calls_by_index)
        tool_call = tool_calls_by_index.setdefault(
            index,
            {
                "id": None,
                "type": "function",
                "function": {"name": "", "arguments": ""},
            },
        )
        tool_call_id = _get_value(raw_tool_call, "id")
        if isinstance(tool_call_id, str) and tool_call_id:
            tool_call["id"] = tool_call_id
        tool_call_type = _get_value(raw_tool_call, "type")
        if isinstance(tool_call_type, str) and tool_call_type:
            tool_call["type"] = tool_call_type
        function = _get_value(raw_tool_call, "function")
        if function is None:
            continue
        name_delta = _get_value(function, "name")
        if isinstance(name_delta, str) and name_delta:
            tool_call["function"]["name"] += name_delta
        argument_delta = _get_value(function, "arguments")
        if isinstance(argument_delta, str) and argument_delta:
            tool_call["function"]["arguments"] += argument_delta


def _summarize_chat_request(request: Mapping[str, Any]) -> dict[str, Any]:
    """Return a compact, non-secret summary of one Chat Completions request."""
    return {
        "model": request.get("model"),
        "tool_choice": request.get("tool_choice"),
        "response_format": _summarize_response_format(
            request.get("response_format")
        ),
        "parallel_tool_calls": request.get("parallel_tool_calls"),
        "message_count": len(request.get("messages") or []),
        "messages": [
            _summarize_message(message)
            for message in request.get("messages") or []
            if isinstance(message, Mapping)
        ],
        "tools": [
            _summarize_tool(tool)
            for tool in request.get("tools") or []
            if isinstance(tool, Mapping)
        ],
    }


def _summarize_message(message: Mapping[str, Any]) -> dict[str, Any]:
    """Return the diagnostic shape of one provider message."""
    content = message.get("content")
    text = content if isinstance(content, str) else ""
    return {
        "role": message.get("role"),
        "name": message.get("name"),
        "tool_call_id": message.get("tool_call_id"),
        "tool_calls": [
            _summarize_tool_call(tool_call)
            for tool_call in message.get("tool_calls") or []
            if isinstance(tool_call, Mapping)
        ],
        "content_preview": text[:240],
        "content_length": len(text),
    }


def _summarize_tool_call(tool_call: Mapping[str, Any]) -> dict[str, Any]:
    """Return the diagnostic shape of one tool call."""
    function = tool_call.get("function")
    function_name = function.get("name") if isinstance(function, Mapping) else None
    return {
        "id": tool_call.get("id"),
        "type": tool_call.get("type"),
        "function": function_name,
    }


def _summarize_tool(tool: Mapping[str, Any]) -> dict[str, Any]:
    """Return the diagnostic shape of one advertised tool schema."""
    function = tool.get("function")
    if not isinstance(function, Mapping):
        return {"type": tool.get("type")}
    parameters = function.get("parameters")
    properties = parameters.get("properties") if isinstance(parameters, Mapping) else {}
    return {
        "type": tool.get("type"),
        "name": function.get("name"),
        "required": parameters.get("required")
        if isinstance(parameters, Mapping)
        else None,
        "properties": sorted(properties) if isinstance(properties, Mapping) else [],
    }


def _summarize_response_format(value: object) -> dict[str, Any] | None:
    """Return a compact response-format summary for diagnostic logging."""
    if not isinstance(value, Mapping):
        return None
    json_schema = value.get("json_schema")
    schema_name = None
    if isinstance(json_schema, Mapping):
        schema_name = json_schema.get("name")
    return {
        "type": value.get("type"),
        "schema_name": schema_name,
    }
