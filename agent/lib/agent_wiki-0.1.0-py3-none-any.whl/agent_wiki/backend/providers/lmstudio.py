"""LM Studio provider implemented through its OpenAI-compatible API."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from agent_wiki.backend.interface.structured_output import StructuredOutputSpec

from .chat_completions import _OpenAIChatCompletionsProvider


LMSTUDIO_BASE_URL = "http://localhost:1234/v1"


@dataclass(slots=True)
class _LMStudioChatCompletionsProvider(_OpenAIChatCompletionsProvider):
    """OpenAI-compatible Chat Completions provider for LM Studio."""

    @property
    def supports_thinking(self) -> bool:
        """Return whether LM Studio exposes reasoning in chat responses."""
        return True

    @property
    def supports_thinking_stream(self) -> bool:
        """Return whether LM Studio streams standard reasoning deltas."""
        return True

    @property
    def supports_structured_output(self) -> bool:
        """Return whether LM Studio accepts JSON Schema response formats."""
        return True

    def build_structured_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        structured_output: StructuredOutputSpec[Any],
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
    ) -> dict[str, Any]:
        """Build an LM Studio request constrained by a JSON schema."""
        request = self.build_request(
            messages=messages,
            tools=None,
            tool_choice=None,
            parallel_tool_calls=False,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )
        request["response_format"] = structured_output.to_chat_response_format()
        return request
