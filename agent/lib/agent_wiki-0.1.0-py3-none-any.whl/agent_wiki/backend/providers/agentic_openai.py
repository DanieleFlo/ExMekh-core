from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from agent_wiki.backend.core.conversation.types import (
    ModelResponse,
    ModelThinking,
    ModelTokenUsage,
    ToolChoice,
)
from agent_wiki.backend.providers.openai import _OpenAIResponsesProvider

logger = logging.getLogger(__name__)

AGENTIC_OPENAI_DEFAULT_BASE_URL = "https://api.openai.com/v1"


@dataclass(slots=True)
class _AgenticOpenAIProvider(_OpenAIResponsesProvider):
    """OpenAI Responses-compatible provider with hierarchical agentic state."""

    @property
    def supports_agentic_capabilities(self) -> bool:
        """Report support for the hierarchical agentic request extension."""
        return True

    @property
    def supports_thinking(self) -> bool:
        """Report support for model thinking returned by the agentic endpoint."""
        return True

    @property
    def supports_thinking_stream(self) -> bool:
        """Report support for streaming model-thinking deltas."""
        return True

    @property
    def provider_name(self) -> str:
        """Return the provider name used in startup validation errors."""
        return "AgenticOpenAI"

    def build_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        agentic: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Build a Responses API request including the agentic extension."""
        request = _OpenAIResponsesProvider.build_request(
            self,
            messages=messages,
            tools=tools,
            tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )
        if thinking:
            request["reasoning"] = {
                "effort": "medium",
                "summary": "auto",
            }
        if agentic is not None:
            request["agentic"] = dict(agentic)
        return request

    def create(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        on_thinking_delta: Callable[[str], None] | None = None,
        agentic: Mapping[str, Any] | None = None,
    ) -> ModelResponse:
        """Execute an agentic Responses request, streaming thinking when requested."""
        request = self.build_request(
            messages=messages,
            tools=tools,
            tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
            agentic=agentic,
        )

        api_kwargs = dict(request)
        agentic_payload = api_kwargs.pop("agentic", None)
        extra_body: dict[str, Any] = {}
        if agentic_payload is not None:
            extra_body["agentic"] = agentic_payload
        if extra_body:
            api_kwargs["extra_body"] = extra_body

        try:
            if on_thinking_delta is not None:
                return self._create_streaming_response(
                    api_kwargs=api_kwargs,
                    on_thinking_delta=on_thinking_delta,
                )
            raw_response = self._sdk_client.responses.create(**api_kwargs)
            return ModelResponse(
                response=raw_response,
                thinking=_extract_response_thinking(raw_response),
                usage=ModelTokenUsage.from_value(getattr(raw_response, "usage", None)),
            )
        except Exception:
            logger.exception("Agentic OpenAI Responses request failed")
            raise

    def _create_streaming_response(
        self,
        *,
        api_kwargs: Mapping[str, Any],
        on_thinking_delta: Callable[[str], None],
    ) -> ModelResponse:
        """Consume Responses events and return the completed SDK response."""
        streaming_kwargs = dict(api_kwargs)
        streaming_kwargs["stream"] = True
        stream = self._sdk_client.responses.create(**streaming_kwargs)
        thinking_parts: list[str] = []
        completed_response: Any = None

        for event in stream:
            thinking_delta = _extract_stream_thinking_delta(event)
            if thinking_delta:
                thinking_parts.append(thinking_delta)
                on_thinking_delta(thinking_delta)

            event_type = _get_value(event, "type")
            if event_type == "response.completed":
                completed_response = _get_value(event, "response")
            elif event_type in {"error", "response.failed"}:
                raise RuntimeError(_stream_error_message(event))

        if completed_response is None:
            get_final_response = getattr(stream, "get_final_response", None)
            if callable(get_final_response):
                completed_response = get_final_response()
        if completed_response is None:
            raise RuntimeError(
                "Agentic OpenAI stream ended without a completed response."
            )

        streamed_thinking = ModelThinking.from_value("".join(thinking_parts))
        return ModelResponse(
            response=completed_response,
            thinking=streamed_thinking
            or _extract_response_thinking(completed_response),
            usage=ModelTokenUsage.from_value(_get_value(completed_response, "usage")),
        )


def _get_value(value: Any, key: str) -> Any:
    """Read a field from either an SDK object or a mapping."""
    if isinstance(value, Mapping):
        return value.get(key)
    return getattr(value, key, None)


def _extract_stream_thinking_delta(event: Any) -> str:
    """Extract thinking text from compatible Responses streaming events."""
    event_type = _get_value(event, "type")
    if not isinstance(event_type, str) or not event_type.endswith(".delta"):
        return ""
    if "reasoning" not in event_type and "thinking" not in event_type:
        return ""
    delta = _get_value(event, "delta")
    if isinstance(delta, str):
        return delta
    for key in ("text", "content", "reasoning_content", "thinking"):
        value = _get_value(delta, key)
        if isinstance(value, str):
            return value
    return ""


def _extract_response_thinking(response: Any) -> ModelThinking | None:
    """Extract complete reasoning text from a non-streamed Responses result."""
    parts: list[str] = []
    for item in _get_value(response, "output") or []:
        item_type = _get_value(item, "type")
        if item_type not in {"reasoning", "thinking"}:
            continue
        for field_name in ("summary", "content"):
            for part in _get_value(item, field_name) or []:
                text = _get_value(part, "text")
                if isinstance(text, str) and text:
                    parts.append(text)
        direct_text = _get_value(item, "text")
        if isinstance(direct_text, str) and direct_text:
            parts.append(direct_text)
    return ModelThinking.from_value("".join(parts))


def _stream_error_message(event: Any) -> str:
    """Build a useful exception message from a failed stream event."""
    error = _get_value(event, "error")
    message = _get_value(error, "message") or _get_value(event, "message")
    if isinstance(message, str) and message:
        return f"Agentic OpenAI stream failed: {message}"
    return "Agentic OpenAI stream failed."
