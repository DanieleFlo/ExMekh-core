from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from .chat_completions import _OpenAIChatCompletionsProvider


OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"


@dataclass(slots=True)
class _OpenRouterChatCompletionsProvider(_OpenAIChatCompletionsProvider):
    """OpenAI-compatible Chat Completions provider for OpenRouter."""


def build_openrouter_headers(
    *,
    referer: str | None = None,
    title: str | None = None,
) -> Mapping[str, str] | None:
    """Build optional OpenRouter attribution headers."""
    headers: dict[str, str] = {}

    if referer:
        headers["HTTP-Referer"] = referer

    if title:
        headers["X-OpenRouter-Title"] = title

    return headers or None
