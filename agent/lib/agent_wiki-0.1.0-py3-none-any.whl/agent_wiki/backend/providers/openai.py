from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence

from openai import OpenAI

from agent_wiki.backend.core.conversation.message import (
    AssistantMessage,
    ChatMessage,
    DeveloperMessage,
    SystemMessage,
    ToolMessage,
    UserMessage,
)
from ..interface.provider import ProviderInterface
from agent_wiki.backend.interface.structured_output import StructuredOutputSpec
from agent_wiki.backend.core.capabilities.tool import build_handler_parameters_schema
from agent_wiki.backend.core.conversation.types import (
    ModelResponse,
    ModelTokenUsage,
    ToolChoice,
)
from agent_wiki.backend.providers.model_validation import (
    extract_openai_model_ids,
    validate_configured_model,
)


@dataclass(slots=True)
class _OpenAIResponsesProvider(ProviderInterface):
    model_name: str
    api_key: str
    base_url: str | None
    timeout: float | None
    max_retries: int

    _sdk_client: OpenAI = field(init=False, repr=False)

    def __post_init__(self) -> None:
        """Initialize the OpenAI SDK and validate the configured model."""
        client_options: dict[str, Any] = {
            "api_key": self.api_key,
            "max_retries": self.max_retries,
        }

        if self.base_url is not None:
            client_options["base_url"] = self.base_url

        if self.timeout is not None:
            client_options["timeout"] = self.timeout

        self._sdk_client = OpenAI(**client_options)
        self.validate_model()

    @property
    def models_endpoint(self) -> str:
        """Return the model-list endpoint used by the configured OpenAI client."""
        base_url = self.base_url or "https://api.openai.com/v1"
        return f"{base_url.rstrip('/')}/models"

    def list_available_models(self) -> tuple[str, ...]:
        """Return model identifiers available to the OpenAI credentials."""
        response = self._sdk_client.models.list()
        return extract_openai_model_ids(
            response,
            provider_name="OpenAI",
            endpoint=self.models_endpoint,
        )

    def validate_model(self) -> None:
        """Require the configured OpenAI model to exist during initialization."""
        validate_configured_model(
            provider_name="OpenAI",
            model_name=self.model_name,
            endpoint=self.models_endpoint,
            fetch_model_ids=self.list_available_models,
        )

    @property
    def model(self) -> str:
        return self.model_name

    def build_system_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        return SystemMessage(content=content, name=name)

    def build_developer_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        return DeveloperMessage(content=content, name=name)

    def build_user_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        return UserMessage(content=content, name=name)

    def build_assistant_message(
        self,
        *,
        content: str,
        name: str | None = None,
        tool_calls: Sequence[Mapping[str, Any]] | None = None,
    ) -> ChatMessage:
        return AssistantMessage(
            content=content,
            name=name,
            tool_calls=tool_calls or [],
        )

    def build_tool_message(
        self,
        *,
        content: str,
        tool_call_id: str,
        name: str | None = None,
    ) -> ToolMessage:
        return ToolMessage(
            content=content,
            tool_call_id=tool_call_id,
            name=name,
        )

    def build_function_tool(
        self,
        *,
        name: str,
        description: str,
        handler: Callable[..., Any],
        strict: bool = True,
    ) -> dict[str, Any]:
        return {
            "type": "function",
            "name": name,
            "description": description,
            "parameters": build_handler_parameters_schema(handler),
            "strict": strict,
        }

    def build_deep_skill_tool(
        self,
        *,
        name: str,
        description: str,
        strict: bool = True,
    ) -> dict[str, Any]:
        return {
            "type": "function",
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            "strict": strict,
        }

    def build_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
    ) -> dict[str, Any]:
        """Build a Responses API request from runtime chat messages."""
        request: dict[str, Any] = {
            "model": self.model_name,
            "input": self._to_response_input(messages),
            "store": False,
        }

        if tools:
            request["tools"] = [dict(tool) for tool in tools]
            request["parallel_tool_calls"] = parallel_tool_calls

            if tool_choice is not None:
                request["tool_choice"] = tool_choice

        if temperature is not None:
            request["temperature"] = temperature

        if top_p is not None:
            request["top_p"] = top_p

        if max_output_tokens is not None:
            request["max_output_tokens"] = max_output_tokens

        if stop is not None:
            request["stop"] = list(stop)

        if seed is not None:
            request["seed"] = seed

        if user is not None:
            request["user"] = user

        return request

    @property
    def supports_structured_output(self) -> bool:
        """Return whether Responses API structured text output is available."""
        return True

    def build_structured_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        structured_output: StructuredOutputSpec[Any],
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
    ) -> dict[str, Any]:
        """Build a Responses API request constrained by a JSON schema."""
        request = self.build_request(
            messages=messages,
            tools=None,
            tool_choice=None,
            parallel_tool_calls=False,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )
        request["text"] = {"format": structured_output.to_openai_text_format()}
        return request

    def create(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        on_thinking_delta: Callable[[str], None] | None = None,
    ) -> ModelResponse:
        """Execute a Responses API request and ignore unsupported thinking streams."""
        request = self.build_request(
            messages=messages,
            tools=tools,
            tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )

        raw_response = self._sdk_client.responses.create(**request)
        return ModelResponse(
            response=raw_response,
            usage=ModelTokenUsage.from_value(getattr(raw_response, "usage", None)),
        )

    def create_structured_response(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        structured_output: StructuredOutputSpec[Any],
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        on_thinking_delta: Callable[[str], None] | None = None,
    ) -> ModelResponse:
        """Execute a Responses API request constrained by a JSON schema."""
        request = self.build_structured_request(
            messages=messages,
            structured_output=structured_output,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )
        raw_response = self._sdk_client.responses.create(**request)
        return ModelResponse(
            response=raw_response,
            usage=ModelTokenUsage.from_value(getattr(raw_response, "usage", None)),
        )

    def create_multimodal_text(
        self,
        *,
        prompt: str,
        image_data_urls: Sequence[str],
        model: str | None = None,
        temperature: float | None = None,
        max_output_tokens: int | None = None,
    ) -> str:
        """Execute a Responses API vision request and return its text output."""
        content: list[dict[str, Any]] = [{"type": "input_text", "text": prompt}]
        content.extend(
            {"type": "input_image", "image_url": image_data_url}
            for image_data_url in image_data_urls
        )
        request: dict[str, Any] = {
            "model": model or self.model_name,
            "input": [{"role": "user", "content": content}],
            "store": False,
        }
        if temperature is not None:
            request["temperature"] = temperature
        if max_output_tokens is not None:
            request["max_output_tokens"] = max_output_tokens

        response = self._sdk_client.responses.create(**request)
        output_text = getattr(response, "output_text", None)
        return output_text if isinstance(output_text, str) else ""

    @classmethod
    def _to_response_input(
        cls,
        messages: Sequence[Mapping[str, Any]],
    ) -> list[dict[str, Any]]:
        """Convert runtime chat history into Responses API input items."""
        input_items: list[dict[str, Any]] = []
        for message in messages:
            input_items.extend(cls._to_response_input_items(message))
        return input_items

    @staticmethod
    def _to_response_input_items(
        message: Mapping[str, Any],
    ) -> list[dict[str, Any]]:
        """Convert one runtime message into one or more Responses API items."""
        role = message["role"]

        if role == "tool":
            return [
                {
                    "type": "function_call_output",
                    "call_id": message["tool_call_id"],
                    "output": message["content"],
                }
            ]

        if role == "assistant" and message.get("tool_calls"):
            items: list[dict[str, Any]] = []
            content = str(message.get("content") or "")
            if content:
                items.append(
                    _response_text_item(
                        role=role,
                        content=content,
                        message=message,
                    )
                )
            for tool_call in message["tool_calls"]:
                items.append(_response_function_call_item(tool_call))
            return items

        content_type = "output_text" if role == "assistant" else "input_text"

        return [
            _response_text_item(
                role=role,
                content=message["content"],
                message=message,
                content_type=content_type,
            )
        ]

    def extract_text(
        self,
        response: ModelResponse,
    ) -> str:
        """
        For the Responses API, the aggregated text is already available
        as `response.output_text`.
        """
        output_text = (
            getattr(response.response, "output_text", None) if response else None
        )
        return output_text if isinstance(output_text, str) else ""

    def extract_tool_calls(
        self,
        response: ModelResponse,
    ) -> list[dict[str, Any]]:
        """Extract Responses API function calls using call_id as the runtime id."""
        tool_calls: list[dict[str, Any]] = []

        output_items = getattr(response.response, "output", None) if response else None
        if not output_items:
            return tool_calls

        for item in output_items:
            if getattr(item, "type", None) != "function_call":
                continue

            response_item_id = getattr(item, "id", None)
            call_id = getattr(item, "call_id", None)
            tool_calls.append(
                {
                    "id": call_id,
                    "response_item_id": response_item_id,
                    "call_id": call_id,
                    "type": "function",
                    "function": {
                        "name": getattr(item, "name", None),
                        "arguments": getattr(item, "arguments", None),
                    },
                }
            )

        return tool_calls

    def extract_messages(
        self,
        response: ModelResponse,
    ) -> list[ChatMessage]:
        messages: list[ChatMessage] = []

        output_items = getattr(response.response, "output", None) if response else None
        if not output_items:
            return messages

        response_text = self.extract_text(response)
        tool_calls = self.extract_tool_calls(response)

        if response_text or tool_calls:
            messages.append(
                self.build_assistant_message(
                    content=response_text,
                    tool_calls=tool_calls,
                )
            )

        for item in output_items:
            if getattr(item, "type", None) != "function_call_output":
                continue

            call_id = getattr(item, "call_id", None)
            output = getattr(item, "output", None)
            if not isinstance(call_id, str):
                continue

            if not isinstance(output, str):
                output = "" if output is None else str(output)

            messages.append(
                self.build_tool_message(
                    content=output,
                    tool_call_id=call_id,
                )
            )

        return messages


def _response_text_item(
    *,
    role: str,
    content: str,
    message: Mapping[str, Any],
    content_type: str = "output_text",
) -> dict[str, Any]:
    """Build one Responses API text item from a runtime chat message."""
    item: dict[str, Any] = {
        "role": role,
        "content": [
            {
                "type": content_type,
                "text": content,
            }
        ],
    }

    if "name" in message:
        item["name"] = message["name"]

    return item


def _response_function_call_item(tool_call: Mapping[str, Any]) -> dict[str, Any]:
    """Build one Responses API function-call item from a runtime tool call."""
    function = tool_call.get("function", {})
    return {
        "type": "function_call",
        "call_id": tool_call.get("call_id") or tool_call.get("id"),
        "name": function.get("name"),
        "arguments": function.get("arguments"),
    }
