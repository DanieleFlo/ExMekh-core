"""Shared model discovery and startup validation for provider clients."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from difflib import get_close_matches
from typing import Any

import httpx
from openai import APIConnectionError, APIStatusError, APITimeoutError, AuthenticationError


class ModelValidationError(RuntimeError):
    """Base error raised when startup model validation cannot succeed."""


class ModelListRequestError(ModelValidationError):
    """Report that the provider model-list request failed."""


class ModelListTimeoutError(ModelListRequestError):
    """Report that model discovery exceeded its request timeout."""


class ModelListConnectionError(ModelListRequestError):
    """Report that model discovery could not connect to the provider."""


class ModelListAuthenticationError(ModelListRequestError):
    """Report that provider credentials cannot list available models."""


class ModelListHTTPError(ModelListRequestError):
    """Report a non-authentication HTTP failure during model discovery."""


class ModelListResponseError(ModelValidationError):
    """Report that a provider returned an unusable model-list response."""


class EmptyModelListError(ModelValidationError):
    """Report that a provider returned a valid but empty model list."""


class ModelNotAvailableError(ModelValidationError):
    """Report that the configured model is absent from the provider list."""


def validate_configured_model(
    *,
    provider_name: str,
    model_name: str,
    endpoint: str,
    fetch_model_ids: Callable[[], Iterable[str]],
) -> tuple[str, ...]:
    """Fetch available models and require an exact configured-model match."""
    try:
        raw_model_ids = fetch_model_ids()
    except ModelValidationError:
        raise
    except Exception as exc:
        _raise_model_list_request_error(
            exc,
            provider_name=provider_name,
            endpoint=endpoint,
        )

    model_ids = _normalize_model_ids(
        raw_model_ids,
        provider_name=provider_name,
        endpoint=endpoint,
    )
    if model_name in model_ids:
        return model_ids

    suggestion = get_close_matches(model_name, model_ids, n=1, cutoff=0.0)[0]
    raise ModelNotAvailableError(
        f"Model '{model_name}' is not available from {provider_name}. "
        f"Did you mean '{suggestion}'? Endpoint: {endpoint}."
    )


def extract_openai_model_ids(
    response: Any,
    *,
    provider_name: str,
    endpoint: str,
) -> tuple[str, ...]:
    """Extract model identifiers from an OpenAI-compatible models response."""
    data = getattr(response, "data", None)
    if data is None and isinstance(response, dict):
        data = response.get("data")
    if not isinstance(data, (list, tuple)):
        raise ModelListResponseError(
            f"{provider_name} returned a malformed model list from {endpoint}: "
            "expected a 'data' array."
        )

    identifiers: list[str] = []
    for item in data:
        identifier = getattr(item, "id", None)
        if identifier is None and isinstance(item, dict):
            identifier = item.get("id")
        if not isinstance(identifier, str) or not identifier.strip():
            raise ModelListResponseError(
                f"{provider_name} returned a malformed model list from {endpoint}: "
                "every entry must contain a non-empty 'id'."
            )
        identifiers.append(identifier.strip())
    return tuple(identifiers)


def extract_ollama_model_ids(
    response: Any,
    *,
    endpoint: str,
) -> tuple[str, ...]:
    """Extract model identifiers from Ollama's native tags response."""
    if not isinstance(response, dict) or not isinstance(response.get("models"), list):
        raise ModelListResponseError(
            f"Ollama returned a malformed model list from {endpoint}: "
            "expected a 'models' array."
        )

    models = response["models"]
    identifiers: list[str] = []
    for item in models:
        if not isinstance(item, dict):
            raise ModelListResponseError(
                f"Ollama returned a malformed model entry from {endpoint}."
            )
        identifier = item.get("model") or item.get("name")
        if not isinstance(identifier, str) or not identifier.strip():
            raise ModelListResponseError(
                f"Ollama returned a malformed model list from {endpoint}: "
                "every entry must contain a non-empty 'model' or 'name'."
            )
        identifiers.append(identifier.strip())
    return tuple(identifiers)


def _normalize_model_ids(
    model_ids: Iterable[str],
    *,
    provider_name: str,
    endpoint: str,
) -> tuple[str, ...]:
    """Validate, strip, and de-duplicate provider model identifiers."""
    if isinstance(model_ids, (str, bytes)) or not isinstance(model_ids, Iterable):
        raise ModelListResponseError(
            f"{provider_name} returned a malformed model list from {endpoint}."
        )

    normalized: list[str] = []
    seen: set[str] = set()
    for model_id in model_ids:
        if not isinstance(model_id, str) or not model_id.strip():
            raise ModelListResponseError(
                f"{provider_name} returned a malformed model identifier from "
                f"{endpoint}."
            )
        stripped = model_id.strip()
        if stripped not in seen:
            normalized.append(stripped)
            seen.add(stripped)

    if not normalized:
        raise EmptyModelListError(
            f"{provider_name} returned an empty model list from {endpoint}."
        )
    return tuple(normalized)


def _raise_model_list_request_error(
    exc: Exception,
    *,
    provider_name: str,
    endpoint: str,
) -> None:
    """Translate SDK and HTTP failures into stable discovery error categories."""
    prefix = f"Could not list models for {provider_name} from {endpoint}"
    if isinstance(exc, (APITimeoutError, httpx.TimeoutException, TimeoutError)):
        raise ModelListTimeoutError(f"{prefix}: request timed out. {exc}") from exc
    if isinstance(exc, (AuthenticationError,)) or (
        isinstance(exc, httpx.HTTPStatusError)
        and exc.response.status_code in {401, 403}
    ):
        raise ModelListAuthenticationError(
            f"{prefix}: authentication failed. {exc}"
        ) from exc
    if isinstance(exc, (APIConnectionError, httpx.ConnectError, ConnectionError)):
        raise ModelListConnectionError(f"{prefix}: connection failed. {exc}") from exc
    if isinstance(exc, (APIStatusError, httpx.HTTPStatusError)):
        raise ModelListHTTPError(f"{prefix}: provider HTTP error. {exc}") from exc
    raise ModelListRequestError(f"{prefix}: {exc}") from exc
