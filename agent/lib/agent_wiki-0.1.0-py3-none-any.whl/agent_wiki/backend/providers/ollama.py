from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence
from urllib.parse import urlsplit, urlunsplit

import httpx

from agent_wiki.backend.interface.structured_output import StructuredOutputSpec
from .chat_completions import _OpenAIChatCompletionsProvider
from .model_validation import extract_ollama_model_ids


@dataclass(slots=True)
class _OllamaChatCompletionsProvider(_OpenAIChatCompletionsProvider):
    """OpenAI-compatible Chat Completions provider for Ollama."""

    @property
    def models_endpoint(self) -> str:
        """Return Ollama's native tags endpoint derived from the inference URL."""
        parsed = urlsplit(self.base_url)
        path = parsed.path.rstrip("/")
        if path.endswith("/v1"):
            path = path[:-3]
        return urlunsplit(
            (parsed.scheme, parsed.netloc, f"{path}/api/tags", "", "")
        )

    def list_available_models(self) -> tuple[str, ...]:
        """Return model identifiers from Ollama's native tags endpoint."""
        response = httpx.get(
            self.models_endpoint,
            timeout=self.timeout if self.timeout is not None else 10.0,
        )
        response.raise_for_status()
        return extract_ollama_model_ids(
            response.json(),
            endpoint=self.models_endpoint,
        )

    @property
    def supports_thinking(self) -> bool:
        """Return whether Ollama can expose thinking output."""
        return True

    @property
    def supports_thinking_stream(self) -> bool:
        """Return whether Ollama can stream thinking deltas."""
        return True

    def build_request(self, **values: Any) -> dict[str, Any]:
        """Build an Ollama request with its provider-specific thinking flag."""
        thinking = bool(values.get("thinking", False))
        request = _OpenAIChatCompletionsProvider.build_request(self, **values)
        request["extra_body"] = {"think": thinking}
        return request

    @property
    def supports_structured_output(self) -> bool:
        """Return whether local Ollama can constrain JSON schema output."""
        return True

    def build_structured_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        structured_output: StructuredOutputSpec[Any],
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
    ) -> dict[str, Any]:
        """Build an Ollama structured-output request through OpenAI compatibility."""
        request = self.build_request(
            messages=messages,
            tools=None,
            tool_choice=None,
            parallel_tool_calls=False,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )
        request["response_format"] = structured_output.to_chat_response_format()
        return request
