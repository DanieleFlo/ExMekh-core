from __future__ import annotations

from html import escape
from typing import Any, Mapping, Sequence

from .tool_output_records import collect_tool_output_records


class ToolInputReferenceError(ValueError):
    """Report one invalid model-facing reusable input reference declaration."""


def build_tool_output_references_schema(fields: Sequence[str]) -> dict[str, Any]:
    """Build the public JSON schema for reusable content-field references."""
    selector = {
        "type": "object",
        "properties": {
            "tool_output_id": {"type": "string"},
            "tool_name": {"type": "string"},
        },
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "properties": {field: selector for field in fields},
        "additionalProperties": False,
    }


def resolve_tool_input_references(
    *,
    arguments: Mapping[str, Any],
    reusable_input_fields: Sequence[str],
    chat_history: list[dict[str, Any]] | None,
    tool_output_awareness: Mapping[str, Any] | None,
    description_token_limit: int,
    ignored_tools: list[str] | None,
) -> dict[str, Any]:
    """Replace declared content fields with current-node reusable output content."""
    resolved = dict(arguments)
    references = resolved.pop("tool_output_references", None)
    if references is None:
        return resolved
    if not isinstance(references, Mapping) or not references:
        raise ToolInputReferenceError(
            "tool_output_references must be a non-empty object"
        )

    allowed = set(reusable_input_fields)
    unknown_fields = [str(field) for field in references if field not in allowed]
    if unknown_fields:
        raise ToolInputReferenceError(
            "tool_output_references contains unsupported fields: "
            + ", ".join(unknown_fields)
        )

    records = collect_tool_output_records(
        chat_history=chat_history,
        tool_output_awareness=tool_output_awareness,
        description_token_limit=description_token_limit,
        ignored_tools=ignored_tools,
    )
    by_id = {record.visible_tool_call_id: record for record in records}

    for field, raw_selector in references.items():
        if field in resolved and resolved[field] is not None:
            raise ToolInputReferenceError(
                f"'{field}' cannot contain both a literal value and a tool output reference"
            )
        if not isinstance(raw_selector, Mapping):
            raise ToolInputReferenceError(
                f"tool_output_references.{field} must be an object"
            )
        output_id = _non_empty_string(raw_selector.get("tool_output_id"))
        tool_name = _non_empty_string(raw_selector.get("tool_name"))
        if (output_id is None) == (tool_name is None):
            raise ToolInputReferenceError(
                f"tool_output_references.{field} must provide exactly one of "
                "tool_output_id or tool_name"
            )
        if output_id is not None:
            record = by_id.get(output_id)
            if record is None:
                raise ToolInputReferenceError(
                    f"visible tool output id '{output_id}' is not available"
                )
            resolved[field] = record.content
            continue

        matches = [record for record in records if record.tool_name == tool_name]
        if not matches:
            raise ToolInputReferenceError(
                f"tool name '{tool_name}' has no reusable local outputs"
            )
        resolved[field] = "\n".join(
            _xml_output(
                tool_name=record.tool_name or "",
                tool_id=record.visible_tool_call_id,
                content=record.content,
            )
            for record in matches
        )
    return resolved


def _non_empty_string(value: object) -> str | None:
    """Normalize one optional non-empty selector string."""
    return value.strip() if isinstance(value, str) and value.strip() else None


def _xml_output(*, tool_name: str, tool_id: str, content: str) -> str:
    """Render one provenance-preserving XML output block."""
    return (
        f'<output tool_name="{escape(tool_name, quote=True)}" '
        f'tool_id="{escape(tool_id, quote=True)}">'
        f"{escape(content)}</output>"
    )
