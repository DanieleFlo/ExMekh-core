from __future__ import annotations

from typing import Any, Mapping

from agent_wiki.configs.text_catalog import get_runtime_text

from .tool_output_memory import (
    StoredToolOutput,
    _extract_visible_tool_call_id,
    _preview_content,
    _record_sort_key,
)
from .tool_result_renderer import strip_tool_result_envelope


def collect_tool_output_records(
    *,
    chat_history: list[dict[str, Any]] | None,
    tool_output_awareness: Mapping[str, Any] | None,
    description_token_limit: int,
    ignored_tools: list[str] | None = None,
) -> list[StoredToolOutput]:
    """Return the current-level and persisted reusable output records."""
    records_by_id: dict[str, StoredToolOutput] = {}
    for record in current_level_tool_output_records(
        chat_history=chat_history,
        description_token_limit=description_token_limit,
        ignored_tools=ignored_tools,
    ):
        records_by_id[record.visible_tool_call_id] = record

    ignored_set = set(ignored_tools or [])
    for record in stored_tool_output_records(
        tool_output_awareness=tool_output_awareness,
        description_token_limit=description_token_limit,
    ):
        if record.tool_name in ignored_set:
            continue
        records_by_id[record.visible_tool_call_id] = record

    return sorted(records_by_id.values(), key=_record_sort_key)


def stored_tool_output_records(
    *,
    tool_output_awareness: Mapping[str, Any] | None,
    description_token_limit: int,
) -> list[StoredToolOutput]:
    """Normalize persisted awareness payload entries into record objects."""
    if tool_output_awareness is None:
        return []
    raw_entries = tool_output_awareness.get("entries")
    if not isinstance(raw_entries, list):
        return []

    records: list[StoredToolOutput] = []
    for index, entry in enumerate(raw_entries):
        if not isinstance(entry, Mapping):
            continue
        record = StoredToolOutput.from_payload(
            entry,
            fallback_order=index,
            preview_token_limit=description_token_limit,
        )
        if record is not None:
            records.append(record)
    return records


def current_level_tool_output_records(
    *,
    chat_history: list[dict[str, Any]] | None,
    description_token_limit: int,
    ignored_tools: list[str] | None = None,
) -> list[StoredToolOutput]:
    """Normalize current-level tool messages into reusable output records."""
    if not isinstance(chat_history, list):
        return []

    ignored_set = set(ignored_tools or [])
    formatted_entries: list[StoredToolOutput] = []
    for order, message in enumerate(chat_history):
        if not isinstance(message, Mapping):
            continue
        if message.get("role") != "tool":
            continue

        tool_call_id = message.get("tool_call_id")
        tool_name = message.get("name")
        if not isinstance(tool_call_id, str) or not tool_call_id.strip():
            continue
        if not isinstance(tool_name, str) or not tool_name.strip():
            continue
        if tool_name in ignored_set:
            continue

        raw_content = str(message.get("content", ""))
        content = strip_tool_result_envelope(raw_content).strip()
        if not content:
            continue

        formatted_entries.append(
            StoredToolOutput(
                tool_call_id=tool_call_id.strip(),
                visible_tool_call_id=(
                    _extract_visible_tool_call_id(raw_content) or tool_call_id.strip()
                ),
                tool_name=tool_name.strip(),
                short_description=tool_name.strip(),
                content=content,
                preview=_preview_content(content, token_limit=description_token_limit)
                or get_runtime_text("model_awareness.empty_preview"),
                capability_kind="tool",
                order=order,
            )
        )
    return formatted_entries
