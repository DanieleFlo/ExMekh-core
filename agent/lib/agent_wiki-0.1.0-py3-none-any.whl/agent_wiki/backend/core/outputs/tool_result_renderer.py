from __future__ import annotations

from dataclasses import dataclass
import json
import inspect
import logging
import re
from types import SimpleNamespace
from typing import Any, Mapping, Sequence

from jinja2 import Environment, StrictUndefined, TemplateError
from agent_wiki.configs.text_catalog import get_runtime_text
from agent_wiki.backend.interface.envelope import (
    EnvelopeMetadata,
    compact_metadata_text,
    compact_metadata_value,
)

from ..capabilities.agent_capabilities import AgentCapabilities
from ..conversation.chat_agent import ChatAgent
from ..capabilities.tool import Tool
from .exit_validation import (
    ExitErrorSuggestion,
    ExitErrorSuggestionGenerator,
    ExitSuggestionContext,
    ExitValidationError,
    compact_exit_message,
    rank_similar_references,
)

_TOOL_RESULT_TEMPLATE_ENV = Environment(undefined=StrictUndefined, autoescape=False)
_TOOL_RESULT_SHORTHAND_PATTERN = re.compile(r"\{\{\s*([A-Za-z0-9_-]+)\s*\}\}")
_NULL_MESSAGE_MARKER_PATTERN = re.compile(
    r"\{\{\s*null\s*\}\}|\{\{\s*\}\}|\[\[null\]\]|\[null\]"
)
_EMBEDDED_SELECTION_FIELD_PATTERN = re.compile(r"""["']selected_tool_outputs["']\s*:""")
logger = logging.getLogger(__name__)


@dataclass(slots=True)
class ExitSkillResult:
    """Represents the validated result of an exit-skill execution."""

    response: str | None
    tool_feedback: str
    is_valid: bool
    metadata: EnvelopeMetadata | None = None


@dataclass(slots=True)
class _LocalToolMessage:
    """Normalized local tool message used for exit-skill selection validation."""

    tool_call_id: str | None
    visible_tool_call_id: str | None
    tool_name: str | None
    content: str


@dataclass(slots=True)
class _NormalizedExitPayload:
    """Normalized exit payload fields used for validation and rendering."""

    message: str
    selected_outputs: list[str | None]


def resolve_exit_skill_result(
    *,
    tool: Tool,
    tool_result: str,
    chat_agent: ChatAgent,
    local_tools: AgentCapabilities,
    level_start_index: int,
    error_suggestion_generator: ExitErrorSuggestionGenerator | None = None,
    excluded_tool_names: list[str] | tuple[str, ...] | None = None,
    runtime_tool_call_id: str | None = None,
    metadata_preview_char_limit: int = 20,
    reference_similarity_mode: str = "characters",
    tool_output_id_aliases: Mapping[str, str] | None = None,
    reusable_tool_outputs: Sequence[Mapping[str, Any]] | None = None,
) -> ExitSkillResult:
    """Validate an exit-skill payload and render its promoted response."""
    payload = _parse_exit_payload(tool_result=tool_result)
    if payload is None:
        logger.debug(
            "Exit skill returned invalid JSON payload", extra={"tool_name": tool.name}
        )
        return _invalid_exit_result(
            error=ExitValidationError(
                code="invalid_payload",
                message=get_runtime_text("tool_result_renderer.errors.invalid_payload"),
            ),
            payload=None,
            local_references=(),
            error_suggestion_generator=error_suggestion_generator,
            metadata_preview_char_limit=metadata_preview_char_limit,
            reference_similarity_mode=reference_similarity_mode,
        )

    message = payload.get("message")
    if not isinstance(message, str):
        logger.debug(
            "Exit payload is missing string message",
            extra={"tool_name": tool.name, "payload": payload},
        )
        return _invalid_exit_result(
            error=ExitValidationError(
                code="missing_message",
                message=get_runtime_text(
                    "tool_result_renderer.errors.missing_message",
                    tool_name=tool.name,
                ),
            ),
            payload=payload,
            local_references=(),
            error_suggestion_generator=error_suggestion_generator,
            metadata_preview_char_limit=metadata_preview_char_limit,
            reference_similarity_mode=reference_similarity_mode,
        )

    unsupported_fields = [
        field_name for field_name in ("require_selection",) if field_name in payload
    ]
    if unsupported_fields:
        logger.debug(
            "Exit payload used unsupported fields",
            extra={"tool_name": tool.name, "unsupported_fields": unsupported_fields},
        )
        joined_fields = ", ".join(
            f"'{field_name}'" for field_name in unsupported_fields
        )
        return _invalid_exit_result(
            error=ExitValidationError(
                code="unsupported_fields",
                message=get_runtime_text(
                    "tool_result_renderer.errors.unsupported_fields",
                    tool_name=tool.name,
                    joined_fields=joined_fields,
                ),
                details={"fields": tuple(unsupported_fields)},
            ),
            payload=payload,
            local_references=(),
            error_suggestion_generator=error_suggestion_generator,
            metadata_preview_char_limit=metadata_preview_char_limit,
            reference_similarity_mode=reference_similarity_mode,
        )

    local_tool_messages = get_local_tool_messages(
        chat_agent=chat_agent,
        local_tools=local_tools,
        level_start_index=level_start_index,
        excluded_tool_names=excluded_tool_names,
    )
    available_tool_messages = _merge_available_tool_messages(
        local_tool_messages=local_tool_messages,
        reusable_tool_outputs=reusable_tool_outputs,
    )
    local_tool_lookup = _build_local_tool_result_lookup(
        local_tool_messages=available_tool_messages
    )
    local_references = _collect_visible_local_references(
        local_tool_messages=available_tool_messages
    )
    canonical_payload = _canonicalize_exit_payload_references(
        payload=payload,
        local_tool_messages=available_tool_messages,
        tool_output_id_aliases=tool_output_id_aliases,
    )
    normalized_payload, selection_error = _normalize_exit_payload(
        payload=canonical_payload,
        local_tool_messages=available_tool_messages,
    )
    if selection_error is not None:
        logger.debug(
            "Exit payload failed selection validation",
            extra={
                "tool_name": tool.name,
                "error": selection_error,
                "payload": canonical_payload,
            },
        )
        return _invalid_exit_result(
            error=selection_error,
            payload=canonical_payload,
            local_references=local_references,
            error_suggestion_generator=error_suggestion_generator,
            metadata_preview_char_limit=metadata_preview_char_limit,
            reference_similarity_mode=reference_similarity_mode,
        )

    rendered_message, render_error = render_text_with_local_tool_results(
        text=normalized_payload.message,
        chat_agent=chat_agent,
        local_tools=local_tools,
        level_start_index=level_start_index,
        require_non_empty=True,
        prebuilt_tool_results=local_tool_lookup,
        excluded_tool_names=excluded_tool_names,
    )
    if render_error is not None:
        logger.debug(
            "Exit payload failed rendering",
            extra={
                "tool_name": tool.name,
                "error": render_error,
                "payload": canonical_payload,
            },
        )
        return _invalid_exit_result(
            error=render_error,
            payload=canonical_payload,
            local_references=local_references,
            error_suggestion_generator=error_suggestion_generator,
            metadata_preview_char_limit=metadata_preview_char_limit,
            reference_similarity_mode=reference_similarity_mode,
        )

    output_format = canonical_payload.get("output_format", "text")
    if output_format == "json":
        try:
            parsed = json.loads(rendered_message)
            rendered_message = f"```json\n{json.dumps(parsed, indent=2)}\n```"
        except json.JSONDecodeError:
            rendered_message = f"```json\n{rendered_message}\n```"

    logger.debug(
        "Resolved exit payload",
        extra={
            "tool_name": tool.name,
            "placeholders": _extract_tool_result_tokens(normalized_payload.message),
            "selected_tool_outputs": canonical_payload.get(
                "selected_tool_outputs"
            ),
            "normalized_selected_tool_outputs": normalized_payload.selected_outputs,
            "output_format": output_format,
        },
    )

    return ExitSkillResult(
        response=rendered_message,
        tool_feedback=json.dumps(canonical_payload, ensure_ascii=False),
        is_valid=True,
        metadata=build_used_capabilities_metadata(
            chat_agent=chat_agent,
            local_tools=local_tools,
            level_start_index=level_start_index,
            runtime_tool_call_id=runtime_tool_call_id,
            excluded_tool_names=excluded_tool_names,
            metadata_preview_char_limit=metadata_preview_char_limit,
        ),
    )


def build_used_capabilities_metadata(
    *,
    chat_agent: ChatAgent,
    local_tools: AgentCapabilities,
    level_start_index: int,
    runtime_tool_call_id: str | None,
    excluded_tool_names: list[str] | tuple[str, ...] | None = None,
    metadata_preview_char_limit: int = 20,
) -> EnvelopeMetadata | None:
    """Build parent-visible metadata for successful local capability calls."""
    from ..capabilities.exit_tool_summary import collect_used_capabilities

    runtime_history = chat_agent.get_messages()
    hds_context = SimpleNamespace(
        level_start_index=level_start_index,
        local_tools=local_tools,
    )
    used_capabilities = collect_used_capabilities(
        runtime_history=runtime_history,
        hds_context=hds_context,
        runtime_tool_call_id=runtime_tool_call_id,
    )
    local_tool_messages = get_local_tool_messages(
        chat_agent=chat_agent,
        local_tools=local_tools,
        level_start_index=level_start_index,
        excluded_tool_names=excluded_tool_names,
    )
    messages_by_call_id = {
        normalized.tool_call_id: normalized
        for normalized in (
            _normalize_local_tool_message(message) for message in local_tool_messages
        )
        if normalized.tool_call_id
        and normalized.visible_tool_call_id
        and normalized.content.strip()
    }

    records: list[dict[str, str]] = []
    for capability in used_capabilities:
        if capability.kind in {"exit_skill", "exit_tool"}:
            continue
        local_message = messages_by_call_id.get(capability.call_id)
        if local_message is None or local_message.visible_tool_call_id is None:
            continue
        records.append(
            {
                "tool_id": local_message.visible_tool_call_id,
                "tool_name": capability.name,
                "args": compact_metadata_value(
                    capability.arguments,
                    edge_length=metadata_preview_char_limit,
                ),
                "content_resume": _resume_content(
                    local_message.content,
                    edge_length=metadata_preview_char_limit,
                ),
            }
        )

    if not records:
        return None
    return EnvelopeMetadata.from_values({"used_capabilities": records})


def _resume_content(content: str, *, edge_length: int = 20) -> str:
    """Return a compact first-and-last character resume for metadata."""
    return compact_metadata_text(content, edge_length=edge_length)


def render_text_with_local_tool_results(
    *,
    text: str,
    chat_agent: ChatAgent,
    local_tools: AgentCapabilities,
    level_start_index: int,
    require_non_empty: bool,
    prebuilt_tool_results: dict[str, str] | None = None,
    excluded_tool_names: list[str] | tuple[str, ...] | None = None,
) -> tuple[str, ExitValidationError | None]:
    """Render one exit-tool message against results visible in the current level."""
    tool_results = prebuilt_tool_results
    if tool_results is None:
        local_tool_messages = get_local_tool_messages(
            chat_agent=chat_agent,
            local_tools=local_tools,
            level_start_index=level_start_index,
            excluded_tool_names=excluded_tool_names,
        )
        tool_results = _build_local_tool_result_lookup(
            local_tool_messages=local_tool_messages
        )
    template = _rewrite_tool_result_template_shorthand(text)

    try:
        rendered = _TOOL_RESULT_TEMPLATE_ENV.from_string(template).render(
            tool_results=tool_results
        )
    except TemplateError as exc:
        logger.debug("Failed to render tool result template", exc_info=True)
        details: dict[str, Any] = {"exception": str(exc)}
        line_number = getattr(exc, "lineno", None)
        location = ""
        if isinstance(line_number, int):
            details["line"] = line_number
            location = get_runtime_text(
                "tool_result_renderer.errors.render_template_line",
                line=line_number,
            )
        return "", ExitValidationError(
            code="render_template",
            message=get_runtime_text(
                "tool_result_renderer.errors.render_template",
                details=exc,
                location=location,
            ),
            details=details,
        )

    if require_non_empty and not rendered.strip():
        return "", ExitValidationError(
            code="non_empty_message",
            message=get_runtime_text("tool_result_renderer.errors.non_empty_message"),
        )

    logger.debug(
        "Rendered tool result template",
        extra={
            "original_text": text,
            "template": template,
            "rendered_preview": rendered[:200],
        },
    )

    return rendered, None


def _parse_exit_payload(*, tool_result: str) -> Mapping[str, Any] | None:
    """Parse the JSON payload returned by an exit skill."""
    try:
        payload = json.loads(tool_result)
    except json.JSONDecodeError:
        return None

    if not isinstance(payload, Mapping):
        return None

    return payload


def _build_local_tool_result_lookup(
    *, local_tool_messages: list[dict[str, Any]]
) -> dict[str, str]:
    """Index local tool results by both tool name and tool-call identifier."""
    tool_results: dict[str, str] = {"null": ""}
    results_by_name: dict[str, list[str]] = {}

    for item in local_tool_messages:
        normalized = _normalize_local_tool_message(item)
        content = normalized.content
        if not content:
            continue

        if normalized.tool_call_id:
            tool_results[normalized.tool_call_id] = content
        if normalized.visible_tool_call_id:
            tool_results[normalized.visible_tool_call_id] = content

        if normalized.tool_name:
            results_by_name.setdefault(normalized.tool_name, []).append(content)

    for tool_name, contents in results_by_name.items():
        tool_results[tool_name] = "\n---\n".join(contents)

    return tool_results


def _merge_available_tool_messages(
    *,
    local_tool_messages: list[dict[str, Any]],
    reusable_tool_outputs: Sequence[Mapping[str, Any]] | None,
) -> list[dict[str, Any]]:
    """Merge local messages with reusable outputs while preserving stable order."""
    merged = [dict(item) for item in local_tool_messages]
    seen_ids: set[str] = set()
    for item in merged:
        normalized = _normalize_local_tool_message(item)
        seen_ids.update(
            reference
            for reference in (
                normalized.tool_call_id,
                normalized.visible_tool_call_id,
            )
            if reference
        )

    for output in reusable_tool_outputs or ():
        provider_id = output.get("real_tool_call_id")
        visible_id = output.get("visible_tool_call_id", output.get("tool_call_id"))
        if not isinstance(provider_id, str) or not provider_id.strip():
            provider_id = output.get("tool_call_id")
        if not isinstance(visible_id, str) or not visible_id.strip():
            visible_id = provider_id
        normalized_ids = {
            value.strip()
            for value in (provider_id, visible_id)
            if isinstance(value, str) and value.strip()
        }
        if normalized_ids & seen_ids:
            continue

        merged.append(
            {
                "tool_call_id": provider_id,
                "visible_tool_call_id": visible_id,
                "name": output.get("tool_name", output.get("name")),
                "content": output.get("content", ""),
            }
        )
        seen_ids.update(normalized_ids)
    return merged


def _collect_visible_local_references(
    *, local_tool_messages: list[dict[str, Any]]
) -> tuple[str, ...]:
    """Return stable model-facing names and identifiers for local tool outputs."""
    references: list[str] = []
    for item in local_tool_messages:
        normalized = _normalize_local_tool_message(item)
        candidates = [normalized.tool_name, normalized.visible_tool_call_id]
        if normalized.visible_tool_call_id is None:
            candidates.append(normalized.tool_call_id)
        for candidate in candidates:
            if candidate and candidate not in references:
                references.append(candidate)
    return tuple(references)


def _invalid_exit_result(
    *,
    error: ExitValidationError,
    payload: Mapping[str, Any] | None,
    local_references: Sequence[str],
    error_suggestion_generator: ExitErrorSuggestionGenerator | None,
    metadata_preview_char_limit: int = 20,
    reference_similarity_mode: str = "characters",
) -> ExitSkillResult:
    """Build invalid exit feedback with optional tool-local corrective examples."""
    feedback = error.message
    raw_message = payload.get("message") if payload is not None else None
    has_embedded_selection = isinstance(raw_message, str) and bool(
        _EMBEDDED_SELECTION_FIELD_PATTERN.search(raw_message)
    )
    if (
        payload is not None
        and error_suggestion_generator is not None
        and not has_embedded_selection
    ):
        suggestions = _generate_exit_error_suggestions(
            generator=error_suggestion_generator,
            error=error,
            payload=payload,
            local_references=local_references,
            context=ExitSuggestionContext(
                local_references=local_references,
                metadata_preview_char_limit=metadata_preview_char_limit,
                similarity_mode=(
                    "tokens" if reference_similarity_mode == "tokens" else "characters"
                ),
            ),
        )
        if suggestions:
            feedback = _format_exit_error_suggestions(
                error_message=feedback,
                suggestions=suggestions,
            )
    return ExitSkillResult(response=None, tool_feedback=feedback, is_valid=False)


def _generate_exit_error_suggestions(
    *,
    generator: ExitErrorSuggestionGenerator,
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
    context: ExitSuggestionContext,
) -> list[ExitErrorSuggestion]:
    """Run one exit-local suggestion generator and discard invalid results safely."""
    try:
        prepared_payload = dict(payload)
        prepared_payload["message"] = compact_exit_message(
            prepared_payload.get("message", ""), context=context
        )
        prepared_references = local_references
        if error.code == "unknown_local_reference":
            prepared_references = rank_similar_references(
                str(error.details.get("token", "")), context=context
            )
        if len(inspect.signature(generator).parameters) >= 4:
            generated = generator(error, prepared_payload, prepared_references, context)
        else:
            generated = generator(error, prepared_payload, prepared_references)  # type: ignore[call-arg]
    except Exception:
        logger.exception(
            "Exit error suggestion generator failed",
            extra={"error_code": error.code},
        )
        return []
    if not isinstance(generated, Sequence) or isinstance(generated, (str, bytes)):
        logger.warning(
            "Ignoring invalid exit error suggestion collection",
            extra={"error_code": error.code},
        )
        return []

    suggestions: list[ExitErrorSuggestion] = []
    seen_payloads: set[str] = set()
    for suggestion in generated:
        if not isinstance(suggestion, ExitErrorSuggestion):
            logger.warning(
                "Ignoring invalid exit error suggestion",
                extra={"error_code": error.code},
            )
            continue
        try:
            serialized_payload = json.dumps(
                suggestion.payload,
                ensure_ascii=False,
                sort_keys=True,
            )
        except (TypeError, ValueError):
            logger.warning(
                "Ignoring non-serializable exit error suggestion",
                extra={"error_code": error.code},
            )
            continue
        if not _is_valid_exit_suggestion_payload(
            payload=suggestion.payload,
            local_references=local_references,
        ):
            logger.warning(
                "Ignoring semantically invalid exit error suggestion",
                extra={"error_code": error.code},
            )
            continue
        if serialized_payload in seen_payloads:
            continue
        seen_payloads.add(serialized_payload)
        suggestions.append(suggestion)
    return suggestions


def _is_valid_exit_suggestion_payload(
    *,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> bool:
    """Return whether a corrective example satisfies the public exit contract."""
    message = payload.get("message")
    if not isinstance(message, str) or not message.strip():
        return False
    if _EMBEDDED_SELECTION_FIELD_PATTERN.search(message):
        return False

    synthetic_messages = [
        {
            "tool_call_id": reference,
            "name": reference,
            "content": "suggestion validation result",
        }
        for reference in local_references
    ]
    normalized, validation_error = _normalize_exit_payload(
        payload=payload,
        local_tool_messages=synthetic_messages,
    )
    if validation_error is not None or normalized is None:
        return False
    return bool(normalized.message.strip())


def _format_exit_error_suggestions(
    *,
    error_message: str,
    suggestions: Sequence[ExitErrorSuggestion],
) -> str:
    """Append ordered JSON corrective examples to an existing validation error."""
    sections = [
        error_message,
        get_runtime_text("tool_result_renderer.suggestions.header"),
    ]
    for index, suggestion in enumerate(suggestions, start=1):
        payload_json = json.dumps(
            suggestion.payload,
            ensure_ascii=False,
            indent=2,
        )
        sections.append(
            get_runtime_text(
                "tool_result_renderer.suggestions.item",
                index=index,
                description=suggestion.description,
                payload=payload_json,
            )
        )
    return "\n\n".join(sections)


def _canonicalize_exit_payload_references(
    *,
    payload: Mapping[str, Any],
    local_tool_messages: list[dict[str, Any]],
    tool_output_id_aliases: Mapping[str, str] | None,
) -> dict[str, Any]:
    """Replace registered provider ids with local model-facing output ids."""
    normalized_messages = [
        _normalize_local_tool_message(item) for item in local_tool_messages
    ]
    local_visible_ids = {
        message.visible_tool_call_id
        for message in normalized_messages
        if message.visible_tool_call_id
    }
    aliases = {
        message.tool_call_id: message.visible_tool_call_id
        for message in normalized_messages
        if message.tool_call_id and message.visible_tool_call_id
    }
    for provider_id, visible_id in (tool_output_id_aliases or {}).items():
        if (
            isinstance(provider_id, str)
            and provider_id.strip()
            and isinstance(visible_id, str)
            and visible_id.strip() in local_visible_ids
        ):
            aliases[provider_id.strip()] = visible_id.strip()

    canonical = dict(payload)
    message = canonical.get("message")
    if isinstance(message, str):
        canonical["message"] = _TOOL_RESULT_SHORTHAND_PATTERN.sub(
            lambda match: "{{" + aliases.get(match.group(1), match.group(1)) + "}}",
            message,
        )

    selected = canonical.get("selected_tool_outputs")
    if isinstance(selected, list):
        canonical["selected_tool_outputs"] = _canonicalize_selected_output_aliases(
            selected=selected,
            aliases=aliases,
        )
    return canonical


def _canonicalize_selected_output_aliases(
    *, selected: list[Any], aliases: Mapping[str, str]
) -> list[Any]:
    """Canonicalize selected output aliases and remove duplicate string references."""
    canonical: list[Any] = []
    seen_references: set[str] = set()
    for item in selected:
        canonical_item = item
        if isinstance(item, str):
            token = item.strip()
            if token.startswith("{{") and token.endswith("}}"):
                token = token[2:-2].strip()
            canonical_item = aliases.get(token, item)
            if isinstance(canonical_item, str):
                reference = canonical_item.strip()
                if reference in seen_references:
                    continue
                seen_references.add(reference)
        canonical.append(canonical_item)
    return canonical


def _normalize_exit_payload(
    *,
    payload: Mapping[str, Any],
    local_tool_messages: list[dict[str, Any]],
) -> tuple[_NormalizedExitPayload | None, ExitValidationError | None]:
    """Normalize and validate the local output selections declared by the exit skill."""
    raw_message = payload.get("message", "")
    has_null_marker = bool(_NULL_MESSAGE_MARKER_PATTERN.search(raw_message))
    message, null_marker_error = _normalize_null_markers_in_message(raw_message)
    if null_marker_error is not None:
        return None, null_marker_error

    placeholder_tokens = _extract_tool_result_tokens(message)
    selected_outputs, selected_outputs_error = _normalize_selected_outputs(
        payload.get("selected_tool_outputs"),
        placeholder_tokens=placeholder_tokens,
    )
    if selected_outputs_error is not None:
        return None, selected_outputs_error

    normalized_messages = [
        _normalize_local_tool_message(item) for item in local_tool_messages
    ]
    placeholders = set(placeholder_tokens)
    if placeholders and not selected_outputs:
        return None, ExitValidationError(
            code="selected_outputs_required",
            message=get_runtime_text(
                "tool_result_renderer.errors.selected_outputs_required"
            ),
            details={
                "message": message,
                "placeholder_tokens": tuple(placeholder_tokens),
            },
        )

    declared_tokens: set[str] = set()
    saw_null = False

    for item in selected_outputs:
        if item is None:
            saw_null = True
            declared_tokens.add("null")
            continue

        token = item

        matching_messages = [
            message
            for message in normalized_messages
            if message.tool_call_id == token
            or message.visible_tool_call_id == token
            or message.tool_name == token
        ]
        if not matching_messages:
            replacement_tokens = tuple(
                dict.fromkeys(
                    message.visible_tool_call_id or message.tool_name
                    for message in normalized_messages
                    if message.visible_tool_call_id or message.tool_name
                )
            )[:5]
            return None, ExitValidationError(
                code="unknown_local_reference",
                message=get_runtime_text(
                    "tool_result_renderer.errors.unknown_local_reference",
                    token=token,
                ),
                details={
                    "token": token,
                    "replacement_tokens": replacement_tokens,
                },
            )

        declared_tokens.add(token)

    if saw_null and len(selected_outputs) != 1:
        return None, ExitValidationError(
            code="null_only_item",
            message=get_runtime_text("tool_result_renderer.errors.null_only_item"),
            details={"selected_outputs": tuple(selected_outputs)},
        )

    if not placeholders and not any(item is not None for item in selected_outputs):
        if not has_null_marker:
            return None, ExitValidationError(
                code="null_marker_required",
                message=get_runtime_text(
                    "tool_result_renderer.errors.null_marker_required"
                ),
                details={"selected_outputs": tuple(selected_outputs)},
            )

    missing_tokens = sorted(
        token for token in placeholders if token not in declared_tokens
    )
    if missing_tokens:
        joined_tokens = ", ".join(missing_tokens)
        return None, ExitValidationError(
            code="missing_tokens",
            message=get_runtime_text(
                "tool_result_renderer.errors.missing_tokens",
                joined_tokens=joined_tokens,
            ),
            details={
                "missing_tokens": tuple(missing_tokens),
                "selected_outputs": tuple(selected_outputs),
                "placeholder_tokens": tuple(placeholder_tokens),
            },
        )

    extra_tokens = []
    for token in selected_outputs:
        if token is None:
            continue
        if token in placeholders:
            continue

        # Check for camouflaged token using brackets or braces
        # Patterns like [[token]], [token], {token}
        pattern = re.compile(
            r"(?:\[\[|\[|\{)\s*" + re.escape(token) + r"\s*(?:\]\]|\]|\})"
        )
        if pattern.search(message):
            # Rewrite camouflaged token to {{token}} so it gets correctly rendered
            message = pattern.sub(f"{{{{{token}}}}}", message)
        else:
            extra_tokens.append(token)

    if extra_tokens:
        joined_tokens = ", ".join(extra_tokens)
        return None, ExitValidationError(
            code="extra_tokens",
            message=get_runtime_text(
                "tool_result_renderer.errors.extra_tokens",
                joined_tokens=joined_tokens,
            ),
            details={
                "extra_tokens": tuple(extra_tokens),
                "selected_outputs": tuple(selected_outputs),
                "placeholder_tokens": tuple(placeholder_tokens),
            },
        )

    return (
        _NormalizedExitPayload(
            message=message,
            selected_outputs=selected_outputs,
        ),
        None,
    )


def _normalize_null_markers_in_message(
    message: str,
) -> tuple[str, ExitValidationError | None]:
    """Remove a single supported null marker from an exit message."""
    marker_matches = list(_NULL_MESSAGE_MARKER_PATTERN.finditer(message))
    if len(marker_matches) > 1:
        return "", ExitValidationError(
            code="multiple_null_markers",
            message=get_runtime_text(
                "tool_result_renderer.errors.multiple_null_markers"
            ),
            details={"marker_count": len(marker_matches)},
        )
    if not marker_matches:
        return message, None

    normalized_message = _NULL_MESSAGE_MARKER_PATTERN.sub("", message, count=1)
    return normalized_message, None


def _normalize_selected_outputs(
    value: Any,
    *,
    placeholder_tokens: Sequence[str],
) -> tuple[list[str | None], ExitValidationError | None]:
    """Normalize model-friendly variants of selected_tool_outputs."""
    if value is None:
        return [], None

    if isinstance(value, str):
        normalized_value = value.strip()
        if not normalized_value or normalized_value in {"null", "[null]"}:
            return [None], None
        if normalized_value in {"[{{null}}]", "[{{}}]", "[[]]"}:
            return [None], None
        return [], ExitValidationError(
            code="selected_outputs_array",
            message=get_runtime_text(
                "tool_result_renderer.errors.selected_outputs_array"
            ),
            details={
                "value": value,
                "placeholder_tokens": tuple(placeholder_tokens),
            },
        )

    if not isinstance(value, list):
        return [], ExitValidationError(
            code="selected_outputs_array",
            message=get_runtime_text(
                "tool_result_renderer.errors.selected_outputs_array"
            ),
            details={
                "value": value,
                "placeholder_tokens": tuple(placeholder_tokens),
            },
        )

    if not value:
        return [], None

    normalized_outputs: list[str | None] = []
    for item in value:
        normalized_item, item_error = _normalize_selected_output_item(
            item,
            placeholder_tokens=placeholder_tokens,
        )
        if item_error is not None:
            return [], item_error
        normalized_outputs.append(normalized_item)

    return normalized_outputs, None


def _normalize_selected_output_item(
    item: Any,
    *,
    placeholder_tokens: Sequence[str],
) -> tuple[str | None, ExitValidationError | None]:
    """Normalize one selected_tool_outputs item."""
    if item is None:
        return None, None

    if item == []:
        return None, None

    if not isinstance(item, str) or not item.strip():
        return None, ExitValidationError(
            code="selected_item_type",
            message=get_runtime_text("tool_result_renderer.errors.selected_item_type"),
            details={
                "item": item,
                "placeholder_tokens": tuple(placeholder_tokens),
            },
        )

    token = item.strip()
    if token in {"null", "{{null}}", "{{}}"}:
        return None, None
    if token.startswith("{{") and token.endswith("}}"):
        token = token[2:-2].strip()
    if not token:
        return None, ExitValidationError(
            code="selected_item_type",
            message=get_runtime_text("tool_result_renderer.errors.selected_item_type"),
            details={
                "item": item,
                "placeholder_tokens": tuple(placeholder_tokens),
            },
        )

    return token, None


def _normalize_local_tool_message(item: dict[str, Any]) -> _LocalToolMessage:
    """Normalize a raw tool message into a compact validation record."""
    tool_call_id = item.get("tool_call_id")
    tool_name = item.get("name")
    content = str(item.get("content", ""))
    explicit_visible_id = item.get("visible_tool_call_id")
    visible_tool_call_id = (
        explicit_visible_id.strip()
        if isinstance(explicit_visible_id, str) and explicit_visible_id.strip()
        else _extract_envelope_tool_call_id(content)
    )
    return _LocalToolMessage(
        tool_call_id=tool_call_id.strip()
        if isinstance(tool_call_id, str) and tool_call_id.strip()
        else None,
        visible_tool_call_id=visible_tool_call_id,
        tool_name=tool_name.strip()
        if isinstance(tool_name, str) and tool_name.strip()
        else None,
        content=strip_tool_result_envelope(content),
    )


def _extract_tool_result_tokens(template: str) -> list[str]:
    """Return shorthand tokens referenced inside the exit message template."""
    if not isinstance(template, str):
        return []
    return [
        match.group(1) for match in _TOOL_RESULT_SHORTHAND_PATTERN.finditer(template)
    ]


def _rewrite_tool_result_template_shorthand(template: str) -> str:
    """Rewrite shorthand placeholders into canonical Jinja lookups."""

    def replace(match: re.Match[str]) -> str:
        token = match.group(1)
        if token == "tool_results":
            return match.group(0)
        return "{{ tool_results[" + json.dumps(token) + "] }}"

    return _TOOL_RESULT_SHORTHAND_PATTERN.sub(replace, template)


def strip_tool_result_envelope(content: str) -> str:
    """Remove the YAML-like metadata envelope added to tool result messages."""
    if not content.startswith("----\n"):
        return content

    marker = "\n----\n"
    end_index = content.find(marker, len("----\n"))
    if end_index == -1:
        return content

    return content[end_index + len(marker) :]


def _extract_envelope_tool_call_id(content: str) -> str | None:
    """Extract the model-facing tool id from a YAML-like tool result envelope."""
    if not content.startswith("----\n"):
        return None

    marker = "\n----\n"
    end_index = content.find(marker, len("----\n"))
    if end_index == -1:
        return None

    for line in content[len("----\n") : end_index].splitlines():
        if not line.startswith("tool_call_id:"):
            continue
        raw_value = line.split(":", 1)[1].strip()
        try:
            value = json.loads(raw_value)
        except json.JSONDecodeError:
            value = raw_value.strip("'\"")
        return value if isinstance(value, str) and value.strip() else None

    return None


def get_local_tool_messages(
    *,
    chat_agent: ChatAgent,
    local_tools: AgentCapabilities,
    level_start_index: int,
    excluded_tool_names: list[str] | tuple[str, ...] | None = None,
) -> list[dict[str, Any]]:
    """Collect only tool messages produced inside the current level scope."""
    exit_skill_names = local_tools.get_exit_capability_names()
    excluded_names = set(excluded_tool_names or ())
    return [
        message
        for message in chat_agent.get_messages()[level_start_index:]
        if message.get("role") == "tool"
        and message.get("name") not in exit_skill_names
        and message.get("name") not in excluded_names
    ]
