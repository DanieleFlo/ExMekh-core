from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Literal

from agent_wiki.backend.interface.envelope import compact_metadata_text


@dataclass(frozen=True, slots=True)
class ExitValidationError:
    """Describe one exit-payload validation failure without prescribing a fix."""

    code: str
    message: str
    details: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ExitErrorSuggestion:
    """Describe one exit-tool-specific corrective payload."""

    description: str
    payload: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class ExitSuggestionContext:
    """Provide runtime preview and matching policy to an exit-local generator."""

    local_references: Sequence[str]
    metadata_preview_char_limit: int = 20
    similarity_mode: Literal["characters", "tokens"] = "characters"


def compact_exit_message(message: object, *, context: ExitSuggestionContext) -> str:
    """Return a stable first-and-last preview of one attempted exit message."""
    return compact_metadata_text(
        str(message), edge_length=context.metadata_preview_char_limit
    )


def rank_similar_references(
    token: str, *, context: ExitSuggestionContext, limit: int = 5
) -> list[str]:
    """Rank local names and visible ids deterministically by character or token match."""
    from difflib import SequenceMatcher

    def units(value: str) -> list[str] | str:
        """Return comparison units for the configured similarity mode."""
        if context.similarity_mode == "tokens":
            try:
                import tiktoken

                return [
                    str(item)
                    for item in tiktoken.get_encoding("cl100k_base").encode(value)
                ]
            except Exception:
                return value.split()
        return value

    needle = units(token)
    ranked = sorted(
        enumerate(dict.fromkeys(context.local_references)),
        key=lambda item: (
            -SequenceMatcher(None, needle, units(item[1])).ratio(),
            item[0],
        ),
    )
    return [reference for _, reference in ranked[: max(0, limit)]]


ExitErrorSuggestionGenerator = Callable[
    [ExitValidationError, Mapping[str, Any], Sequence[str], ExitSuggestionContext],
    Sequence[ExitErrorSuggestion],
]
