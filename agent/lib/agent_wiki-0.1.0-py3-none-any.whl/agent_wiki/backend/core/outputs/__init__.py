"""Reusable tool-output storage and rendering helpers."""
