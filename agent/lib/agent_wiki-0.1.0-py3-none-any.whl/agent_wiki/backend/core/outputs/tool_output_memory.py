from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import logging
import re
from pathlib import Path
import shutil
from typing import Any, Iterable, Mapping

from ..capabilities.agent_capabilities import AgentCapabilities
from ..utils import safe_hds_node_path
from .tool_result_renderer import get_local_tool_messages, strip_tool_result_envelope
from ..capabilities.deep_skill import DeepSkill
from ..capabilities.tool import Tool
from .tool_output_id_mapper import ToolOutputIdMapper
from agent_wiki.backend.interface.tool_output_memory import ToolOutputMemoryInterface

try:
    import tiktoken
except ImportError:  # pragma: no cover - fallback stays covered through behavior tests.
    tiktoken = None


logger = logging.getLogger(__name__)


@dataclass(slots=True)
class StoredToolOutput:
    """Store one reusable capability result persisted across skill ascents."""

    tool_call_id: str
    visible_tool_call_id: str
    tool_name: str | None
    short_description: str
    content: str
    preview: str
    capability_kind: str = "tool"
    hds_id: str | None = None
    hds_node_path: tuple[str, ...] = ()
    order: int = 0

    @classmethod
    def from_payload(
        cls,
        payload: Mapping[str, Any],
        *,
        fallback_order: int,
        preview_token_limit: int | None = None,
    ) -> "StoredToolOutput | None":
        """Normalize one serialized output payload into a stored output record."""
        tool_call_id = payload.get("tool_call_id")
        visible_tool_call_id = payload.get("visible_tool_call_id")
        short_description = payload.get("short_description")
        content = payload.get("content")
        preview = payload.get("preview")
        if not isinstance(tool_call_id, str) or not isinstance(short_description, str):
            return None
        if not isinstance(content, str):
            return None
        if not isinstance(preview, str):
            if preview_token_limit is None:
                return None
            preview = _preview_content(content, token_limit=preview_token_limit)

        tool_name = payload.get("tool_name")
        capability_kind = payload.get("capability_kind")
        hds_id = payload.get("hds_id")
        hds_node_path = payload.get("hds_node_path")
        order = payload.get("order")
        return cls(
            tool_call_id=tool_call_id,
            visible_tool_call_id=(
                visible_tool_call_id
                if isinstance(visible_tool_call_id, str)
                and visible_tool_call_id.strip()
                else tool_call_id
            ),
            tool_name=tool_name if isinstance(tool_name, str) else None,
            short_description=short_description,
            content=content,
            preview=preview,
            capability_kind=(
                capability_kind
                if isinstance(capability_kind, str) and capability_kind.strip()
                else "tool"
            ),
            hds_id=hds_id if isinstance(hds_id, str) and hds_id.strip() else None,
            hds_node_path=(
                tuple(hds_node_path)
                if isinstance(hds_node_path, (list, tuple))
                and all(isinstance(item, str) for item in hds_node_path)
                else ()
            ),
            order=order if isinstance(order, int) else fallback_order,
        )

    def to_payload(self) -> dict[str, Any]:
        """Serialize one stored output for runtime injection into tools."""
        return asdict(self)


class ToolOutputMemory(ToolOutputMemoryInterface):
    """Keep inherited tool outputs available across ascents within one run."""

    def __init__(
        self,
        *,
        storage_dir: Path | None = None,
        description_token_limit: int,
        id_mapper: ToolOutputIdMapper | None = None,
    ) -> None:
        """Initialize the inherited-output registry and optional temp storage."""
        self._outputs_by_id: dict[str, StoredToolOutput] = {}
        self._storage_dir = storage_dir.resolve() if storage_dir is not None else None
        self._description_token_limit = max(1, description_token_limit)
        self._id_mapper = id_mapper or ToolOutputIdMapper()

    def clear(self) -> None:
        """Drop every stored output for a fresh agent run."""
        self._outputs_by_id.clear()
        self._id_mapper = ToolOutputIdMapper()
        if self._storage_dir is None:
            logger.debug("Cleared in-memory tool-output memory")
            return

        shutil.rmtree(self._storage_dir, ignore_errors=True)
        self._storage_dir.mkdir(parents=True, exist_ok=True)
        logger.debug(
            "Cleared filesystem tool-output memory",
            extra={"storage_dir": str(self._storage_dir)},
        )

    def visible_id_for(self, tool_call_id: str) -> str:
        """Return the model-facing id assigned to one real provider tool-call id."""
        return self._id_mapper.visible_for(tool_call_id)

    def remember_level_outputs(
        self,
        *,
        chat_agent: Any,
        local_tools: AgentCapabilities,
        level_start_index: int,
        hds_id: str | None = None,
        hds_node_path: tuple[str, ...] | None = None,
    ) -> None:
        """Store the local tool messages produced by one completed child level."""
        local_tool_messages = get_local_tool_messages(
            chat_agent=chat_agent,
            local_tools=local_tools,
            level_start_index=level_start_index,
        )
        self.remember_messages(
            local_tool_messages=local_tool_messages,
            local_tools=local_tools,
            hds_id=hds_id,
            hds_node_path=hds_node_path,
        )

    def remember_messages(
        self,
        *,
        local_tool_messages: list[dict[str, Any]],
        local_tools: AgentCapabilities,
        hds_id: str | None = None,
        hds_node_path: tuple[str, ...] | None = None,
    ) -> None:
        """Store normalized tool messages using their tool call id as the key."""
        for order, item in enumerate(local_tool_messages):
            self.remember_output(
                tool_call_id=item.get("tool_call_id"),
                capability_name=item.get("name"),
                content=item.get("content", ""),
                local_tools=local_tools,
                hds_id=hds_id,
                hds_node_path=hds_node_path,
                order=order,
            )

    def remember_output(
        self,
        *,
        tool_call_id: Any,
        capability_name: Any,
        content: Any,
        local_tools: AgentCapabilities,
        hds_id: str | None = None,
        hds_node_path: tuple[str, ...] | None = None,
        order: int | None = None,
        visible_tool_call_id: str | None = None,
    ) -> None:
        """Store one normalized capability result for later awareness and lookup."""
        if not isinstance(tool_call_id, str) or not tool_call_id.strip():
            return

        normalized_content = strip_tool_result_envelope(str(content)).strip()
        if not normalized_content:
            return

        normalized_name = (
            capability_name.strip()
            if isinstance(capability_name, str) and capability_name.strip()
            else None
        )
        capability = (
            local_tools.get_tool_by_name(normalized_name)
            if normalized_name is not None
            else None
        )
        if isinstance(capability, DeepSkill):
            capability_kind = "skill"
        elif isinstance(capability, Tool):
            capability_kind = "tool"
        else:
            capability_kind = "tool"

        current_order = order if isinstance(order, int) else len(self._outputs_by_id)
        normalized_tool_call_id = tool_call_id.strip()
        visible_id = (
            self._id_mapper.register(
                real_tool_call_id=normalized_tool_call_id,
                visible_tool_call_id=visible_tool_call_id,
            )
            if isinstance(visible_tool_call_id, str)
            else self._id_mapper.visible_for(normalized_tool_call_id)
        )
        stored_output = StoredToolOutput(
            tool_call_id=normalized_tool_call_id,
            visible_tool_call_id=visible_id,
            tool_name=normalized_name,
            short_description=self._resolve_short_description(
                local_tools=local_tools,
                tool_name=normalized_name,
            ),
            content=normalized_content,
            preview=_preview_content(
                normalized_content,
                token_limit=self._description_token_limit,
            ),
            capability_kind=capability_kind,
            hds_id=hds_id,
            hds_node_path=tuple(hds_node_path or ()),
            order=current_order,
        )
        self._outputs_by_id[_record_key(stored_output)] = stored_output
        self._persist_output(stored_output)
        logger.debug(
            "Remembered reusable tool output",
            extra={
                "tool_name": normalized_name,
                "tool_call_id": normalized_tool_call_id,
                "visible_tool_call_id": visible_id,
                "hds_id": hds_id,
                "hds_node_path": list(hds_node_path or ()),
            },
        )

    def build_injected_payload(
        self, *, hds_node_path: tuple[str, ...] | None = None
    ) -> dict[str, Any]:
        """Return the reusable-output awareness structure for one HDS node."""
        return self.build_awareness_payload(hds_node_path=hds_node_path)

    def build_awareness_payload(
        self, *, hds_node_path: tuple[str, ...] | None = None
    ) -> dict[str, Any]:
        """Return the injected structure consumed by the awareness tool."""
        outputs = self._load_outputs()
        ordered_outputs = sorted(
            _filter_outputs_by_hds_node_path(
                outputs.values(),
                hds_node_path=hds_node_path,
            ),
            key=_record_sort_key,
        )
        entries = [_to_visible_payload(item) for item in ordered_outputs]
        return {
            "entries": entries,
            "by_id": {
                item.visible_tool_call_id: item.content for item in ordered_outputs
            },
        }

    def export_outputs(self) -> list[StoredToolOutput]:
        """Return all stored outputs in stable order for checkpoint persistence."""
        outputs = sorted(self._load_outputs().values(), key=_record_sort_key)
        logger.debug("Exported tool-output memory", extra={"count": len(outputs)})
        return outputs

    def import_outputs(self, payloads: list[Mapping[str, Any]]) -> None:
        """Restore stored outputs from checkpoint payloads."""
        self._outputs_by_id.clear()
        imported_count = 0
        for index, payload in enumerate(payloads):
            output = StoredToolOutput.from_payload(
                payload,
                fallback_order=index,
            )
            if output is None:
                continue
            self._id_mapper.register(
                real_tool_call_id=output.tool_call_id,
                visible_tool_call_id=output.visible_tool_call_id,
            )
            self._outputs_by_id[_record_key(output)] = output
            self._persist_output(output)
            imported_count += 1
        logger.debug("Imported tool-output memory", extra={"count": imported_count})

    def _persist_output(self, output: StoredToolOutput) -> None:
        """Persist one inherited output inside the configured temp directory."""
        if self._storage_dir is None:
            return

        self._storage_path(output).parent.mkdir(parents=True, exist_ok=True)
        self._storage_path(output).write_text(
            json.dumps(output.to_payload(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        logger.debug(
            "Persisted reusable tool output",
            extra={
                "tool_call_id": output.tool_call_id,
                "visible_tool_call_id": output.visible_tool_call_id,
                "path": str(self._storage_path(output)),
            },
        )

    def _load_outputs(self) -> dict[str, StoredToolOutput]:
        """Load persisted outputs when a temp directory is configured."""
        if self._storage_dir is None:
            return dict(self._outputs_by_id)

        loaded_outputs = dict(self._outputs_by_id)
        if not self._storage_dir.exists():
            return loaded_outputs

        for payload_path in _iter_payload_paths(self._storage_dir):
            try:
                raw_payload = json.loads(payload_path.read_text(encoding="utf-8"))
            except Exception:
                continue

            if not isinstance(raw_payload, Mapping):
                continue

            output = StoredToolOutput.from_payload(
                raw_payload,
                fallback_order=len(loaded_outputs),
            )
            if output is None:
                continue
            self._id_mapper.register(
                real_tool_call_id=output.tool_call_id,
                visible_tool_call_id=output.visible_tool_call_id,
            )
            loaded_outputs[_record_key(output)] = output

        self._outputs_by_id = loaded_outputs
        return loaded_outputs

    def _storage_path(self, output: StoredToolOutput) -> Path:
        """Return the stable temp file path for one stored tool output."""
        file_name = _safe_storage_name(output.tool_call_id)
        node_segment = safe_hds_node_path(output.hds_node_path)
        if output.hds_id:
            return self._storage_dir / output.hds_id / node_segment / file_name
        return self._storage_dir / node_segment / file_name


class FilesystemToolOutputMemory(ToolOutputMemory):
    """Default filesystem-backed reusable tool-output memory implementation."""

    @staticmethod
    def _resolve_short_description(
        *,
        local_tools: AgentCapabilities,
        tool_name: str | None,
    ) -> str:
        """Derive the short human-facing description for one stored output."""
        if tool_name is None:
            return "tool output"

        capability = local_tools.get_tool_by_name(tool_name)
        description = (
            getattr(capability, "description", "") if capability is not None else ""
        )
        if not isinstance(description, str) or not description.strip():
            return tool_name

        first_line = description.strip().splitlines()[0].strip()
        return first_line or tool_name


def _record_sort_key(record: StoredToolOutput) -> tuple[int, str]:
    """Provide a stable ordering key for persisted and live awareness records."""
    return (record.order, record.tool_call_id)


def _record_key(record: StoredToolOutput) -> str:
    """Return the in-memory key for one stored output record."""
    return f"{safe_hds_node_path(record.hds_node_path)}::{record.tool_call_id}"


def _filter_outputs_by_hds_node_path(
    records: Iterable[StoredToolOutput], *, hds_node_path: tuple[str, ...] | None
) -> list[StoredToolOutput]:
    """Return records that belong to the requested HDS node path."""
    if hds_node_path is None:
        return list(records)
    expected = tuple(hds_node_path)
    return [record for record in records if tuple(record.hds_node_path) == expected]


def _to_visible_payload(record: StoredToolOutput) -> dict[str, Any]:
    """Serialize one record for model-facing awareness and lookup payloads."""
    payload = record.to_payload()
    payload["real_tool_call_id"] = record.tool_call_id
    payload["tool_call_id"] = record.visible_tool_call_id
    return payload


def _extract_visible_tool_call_id(content: str) -> str | None:
    """Read the model-facing id from a tool-result envelope when present."""
    if not content.startswith("----\n"):
        return None
    marker = "\n----\n"
    end_index = content.find(marker, len("----\n"))
    if end_index == -1:
        return None
    for line in content[len("----\n") : end_index].splitlines():
        if not line.startswith("tool_call_id:"):
            continue
        raw_value = line.split(":", 1)[1].strip()
        try:
            value = json.loads(raw_value)
        except json.JSONDecodeError:
            value = raw_value.strip("'\"")
        return value if isinstance(value, str) and value.strip() else None
    return None


def _iter_payload_paths(storage_dir: Path) -> list[Path]:
    """Return persisted output payload files, including legacy `.json` payloads."""
    return sorted(path for path in storage_dir.rglob("*") if path.is_file())


def _safe_storage_name(tool_call_id: str) -> str:
    """Convert one tool call id into a readable path segment."""
    normalized = re.sub(r"[^A-Za-z0-9_.-]+", "-", tool_call_id.strip())
    file_stem = normalized.strip(".-") or "tool-output"
    if file_stem.endswith(".json"):
        return file_stem
    return f"{file_stem}.json"


def _preview_content(content: str, *, token_limit: int) -> str:
    """Produce a short token-based preview for awareness messages."""
    if not content.strip():
        return ""

    effective_token_limit = max(1, token_limit)
    if tiktoken is not None:
        try:
            encoding = tiktoken.get_encoding("cl100k_base")
            token_ids = encoding.encode(content, disallowed_special=())
            if len(token_ids) > effective_token_limit:
                return (
                    encoding.decode(token_ids[:effective_token_limit]).strip()
                    + "...[continue]"
                )
            return encoding.decode(token_ids[:effective_token_limit]).strip()
        except Exception:
            pass

    words = content.split()
    if len(words) > effective_token_limit:
        return " ".join(words[:effective_token_limit]).strip() + "...[continue]"
    return " ".join(words[:effective_token_limit]).strip()
