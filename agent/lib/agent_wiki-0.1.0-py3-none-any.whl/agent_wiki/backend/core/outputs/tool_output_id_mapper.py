from __future__ import annotations

from dataclasses import dataclass, field
import random
import re
from typing import Mapping, Sequence

import tiktoken

from agent_wiki.backend.static.tool_output_ids import (
    clear_tool_output_ids_file,
    read_tool_output_ids_file,
    write_tool_output_ids_file,
)

_TOKEN_WORD_PATTERN = re.compile(r"^[a-z][a-z0-9]{2,11}$")
_FALLBACK_TOKEN_WORDS: tuple[str, ...] = (
    "table",
    "river",
    "paper",
    "house",
    "water",
    "music",
    "school",
    "garden",
    "window",
    "family",
    "letter",
    "picture",
)
_TOKEN_WORD_POOL_CACHE: tuple[str, ...] | None = None


@dataclass(slots=True)
class ToolOutputIdMapper:
    """Map provider tool-call ids to generated model-facing output ids."""

    token_words: Sequence[str] | None = None
    reset_static_file: bool = True
    _visible_by_real: dict[str, str] = field(default_factory=dict)
    _real_by_visible: dict[str, str] = field(default_factory=dict)
    _generated_ids: list[str] = field(default_factory=list)
    _random: random.Random = field(default_factory=random.SystemRandom)

    def __post_init__(self) -> None:
        """Initialize the static JSON list for this mapper lifecycle."""
        if self.reset_static_file:
            clear_tool_output_ids_file()
        self._generated_ids = read_tool_output_ids_file()

    def visible_for(self, real_tool_call_id: str) -> str:
        """Return the stable visible id for one real provider tool-call id."""
        real_id = real_tool_call_id.strip()
        if not real_id:
            raise ValueError("real_tool_call_id must be a non-empty string.")
        existing = self._visible_by_real.get(real_id)
        if existing is not None:
            return existing

        visible_id = self._next_visible_id()
        self.register(real_tool_call_id=real_id, visible_tool_call_id=visible_id)
        return visible_id

    def real_for(self, visible_tool_call_id: str) -> str | None:
        """Return the real provider id mapped to one visible output id."""
        visible_id = visible_tool_call_id.strip()
        if not visible_id:
            return None
        return self._real_by_visible.get(visible_id)

    def register(self, *, real_tool_call_id: str, visible_tool_call_id: str) -> str:
        """Preserve an existing real-to-visible mapping and return the visible id."""
        real_id = real_tool_call_id.strip()
        visible_id = visible_tool_call_id.strip()
        if not real_id:
            raise ValueError("real_tool_call_id must be a non-empty string.")
        if not visible_id:
            visible_id = self._next_visible_id()

        existing_visible = self._visible_by_real.get(real_id)
        if existing_visible is not None:
            return existing_visible

        existing_real = self._real_by_visible.get(visible_id)
        if existing_real is not None and existing_real != real_id:
            visible_id = self._next_visible_id()

        self._visible_by_real[real_id] = visible_id
        self._real_by_visible[visible_id] = real_id
        self._record_generated_id(visible_id)
        return visible_id

    def import_mappings(self, mappings: Mapping[str, str]) -> None:
        """Restore a batch of visible ids keyed by real provider ids."""
        for real_id, visible_id in mappings.items():
            if not isinstance(real_id, str) or not isinstance(visible_id, str):
                continue
            if not real_id.strip() or not visible_id.strip():
                continue
            self.register(
                real_tool_call_id=real_id,
                visible_tool_call_id=visible_id,
            )

    def export_mappings(self) -> dict[str, str]:
        """Return all real-to-visible mappings in insertion order."""
        return dict(self._visible_by_real)

    def _next_visible_id(self) -> str:
        """Generate a new id from three random tiktoken tokens joined by underscores."""
        used = set(self._real_by_visible) | set(self._generated_ids)
        for _ in range(1000):
            candidate = "_".join(self._random.sample(self._token_word_pool(), 3))
            if candidate not in used:
                return candidate

        index = len(used) + 1
        while True:
            candidate = "_".join(self._random.sample(self._token_word_pool(), 3))
            suffixed_candidate = f"{candidate}_{index}"
            if suffixed_candidate not in used:
                return suffixed_candidate
            index += 1

    def _token_word_pool(self) -> tuple[str, ...]:
        """Return candidate word tokens decoded from the best available GPT encoding."""
        global _TOKEN_WORD_POOL_CACHE
        if self.token_words is not None:
            words = tuple(
                word.strip().lower()
                for word in self.token_words
                if isinstance(word, str)
                and _TOKEN_WORD_PATTERN.match(word.strip().lower())
            )
            if len(words) >= 3:
                return words

        if _TOKEN_WORD_POOL_CACHE is not None:
            return _TOKEN_WORD_POOL_CACHE

        try:
            encoding = _encoding_for_best_gpt_model()
            words: list[str] = []
            seen: set[str] = set()
            for token_id in range(min(encoding.n_vocab, 50000)):
                try:
                    token = encoding.decode([token_id]).strip().lower()
                except Exception:
                    continue
                if not _TOKEN_WORD_PATTERN.match(token):
                    continue
                if token in seen:
                    continue
                seen.add(token)
                words.append(token)
                if len(words) >= 2000:
                    break
            if len(words) >= 3:
                _TOKEN_WORD_POOL_CACHE = tuple(words)
                return _TOKEN_WORD_POOL_CACHE
        except Exception:
            pass

        _TOKEN_WORD_POOL_CACHE = _FALLBACK_TOKEN_WORDS
        return _TOKEN_WORD_POOL_CACHE

    def _record_generated_id(self, visible_id: str) -> None:
        """Append a visible id to the static JSON list when it is new."""
        if visible_id in self._generated_ids:
            return
        self._generated_ids.append(visible_id)
        write_tool_output_ids_file(self._generated_ids)


def _encoding_for_best_gpt_model() -> tiktoken.Encoding:
    """Return a tiktoken encoding for GPT-5 when known, then GPT-4, then base."""
    for model_name in ("gpt-5", "gpt-4", "gpt-4o"):
        try:
            return tiktoken.encoding_for_model(model_name)
        except KeyError:
            continue
    try:
        return tiktoken.get_encoding("o200k_base")
    except ValueError:
        return tiktoken.get_encoding("cl100k_base")
