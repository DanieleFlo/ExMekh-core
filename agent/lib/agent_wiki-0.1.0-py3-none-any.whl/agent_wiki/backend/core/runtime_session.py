from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from threading import Condition, Lock, RLock
from typing import Any, Mapping
from uuid import uuid4

from agent_wiki.backend.interface.runtime_event_sink import RuntimeEventSink
from agent_wiki.backend.interface.interaction import (
    InteractionCancelledError,
    InteractionHandlerInterface,
    InteractionRequest,
    InteractionResponse,
    validate_interaction_response,
)

from .agent.deep_agent import DeepAgent
from .agent.deep_agent_loop import AgentRunCancelled
from .conversation.history_graph import HistoryGraph
from .conversation.result import AgentResult
from .conversation.types import TokenUsageSummary
from .observability.event_bus import RuntimeEventBus
from .observability.runtime_events import RuntimeEvent, TransportEvent


@dataclass(frozen=True, slots=True)
class EventBatch:
    """Return retained transport events or request a full client resynchronization."""

    events: tuple[TransportEvent, ...]
    resync_required: bool
    latest_event_id: int


class RuntimeEventStore(RuntimeEventSink):
    """Persist bounded transport replay and a session-complete structural trace."""

    def __init__(self, *, session_id: str, retention: int = 1000) -> None:
        """Initialize a bounded event store for one runtime session."""
        if retention < 1:
            raise ValueError("Event retention must be positive.")
        self.session_id = session_id
        self.retention = retention
        self._events: deque[TransportEvent] = deque(maxlen=retention)
        self._trace_events: list[dict[str, Any]] = []
        self._thinking_events: dict[str, dict[str, Any]] = {}
        self._next_id = 1
        self._condition = Condition(RLock())

    def publish(self, event: RuntimeEvent) -> None:
        """Store one runtime event in the shared transport envelope."""
        event_data = event.to_dict()
        with self._condition:
            if event.event_type == "model_thinking_delta":
                self._record_thinking_event(event_data)
            else:
                self._trace_events.append(dict(event_data))
            self.append(
                event_type="runtime.event",
                data=event_data,
                turn_id=event.turn_id,
            )

    def append(
        self,
        *,
        event_type: str,
        data: Mapping[str, Any],
        turn_id: str | None,
    ) -> TransportEvent:
        """Append one transport event and notify waiting consumers."""
        with self._condition:
            event = TransportEvent(
                id=self._next_id,
                session_id=self.session_id,
                turn_id=turn_id,
                type=event_type,
                data=dict(data),
            )
            self._next_id += 1
            self._events.append(event)
            self._condition.notify_all()
            return event

    def events_after(self, event_id: int) -> EventBatch:
        """Return retained events newer than an event id."""
        with self._condition:
            return self._events_after_locked(event_id)

    def wait_after(self, *, event_id: int, timeout: float) -> EventBatch:
        """Wait until newer events exist, retention expires, or timeout elapses."""
        with self._condition:
            batch = self._events_after_locked(event_id)
            if not batch.events and not batch.resync_required:
                self._condition.wait(timeout=timeout)
                batch = self._events_after_locked(event_id)
            return batch

    def all_events(self) -> tuple[TransportEvent, ...]:
        """Return a stable snapshot of retained transport events."""
        with self._condition:
            return tuple(self._events)

    def trace_events(self) -> tuple[dict[str, Any], ...]:
        """Return structural events plus one aggregated event per thinking request."""
        with self._condition:
            events = [*self._trace_events, *self._thinking_events.values()]
            return tuple(
                dict(event) for event in sorted(events, key=lambda item: item["sequence"])
            )

    def _record_thinking_event(self, event_data: Mapping[str, Any]) -> None:
        """Aggregate transient thinking chunks without growing the structural trace."""
        payload = event_data.get("payload")
        request_id = (
            payload.get("model_request_id")
            if isinstance(payload, Mapping)
            else None
        )
        key = str(request_id or event_data.get("span_id") or event_data["sequence"])
        existing = self._thinking_events.get(key)
        if existing is None:
            self._thinking_events[key] = dict(event_data)
            return
        existing["content"] = (
            f"{existing.get('content') or ''}{event_data.get('content') or ''}"
        )

    def _events_after_locked(self, event_id: int) -> EventBatch:
        """Resolve replay state while the event-store condition is held."""
        latest_event_id = self._next_id - 1
        if not self._events:
            return EventBatch((), False, latest_event_id)
        oldest_event_id = self._events[0].id
        if event_id < oldest_event_id - 1:
            return EventBatch((), True, latest_event_id)
        return EventBatch(
            tuple(event for event in self._events if event.id > event_id),
            False,
            latest_event_id,
        )


class RuntimeInteractionBroker(InteractionHandlerInterface):
    """Publish generic interaction requests and synchronize external responses."""

    def __init__(self, *, event_store: RuntimeEventStore) -> None:
        """Initialize an interaction broker backed by one session event store."""
        self._event_store = event_store
        self._condition = Condition(RLock())
        self._pending: dict[str, InteractionRequest] = {}
        self._responses: dict[str, InteractionResponse] = {}
        self._cancelled: set[str] = set()

    def request(self, interaction: InteractionRequest) -> InteractionResponse:
        """Publish a request and block the runtime until a response arrives."""
        with self._condition:
            if interaction.id in self._pending:
                raise ValueError(f"Duplicate interaction id: {interaction.id}")
            self._pending[interaction.id] = interaction
            self._event_store.append(
                event_type="session.interaction.requested",
                data=interaction.to_dict(),
                turn_id=interaction.turn_id,
            )
            while (
                interaction.id not in self._responses
                and interaction.id not in self._cancelled
            ):
                self._condition.wait()
            if interaction.id in self._cancelled:
                self._cancelled.remove(interaction.id)
                self._pending.pop(interaction.id, None)
                raise InteractionCancelledError(
                    f"Interaction '{interaction.id}' was cancelled."
                )
            response = self._responses.pop(interaction.id)
            self._pending.pop(interaction.id, None)
            return response

    def respond(
        self,
        *,
        request_id: str,
        action: str,
        payload: Mapping[str, Any] | None = None,
        content: str | None = None,
    ) -> InteractionResponse:
        """Validate and deliver one external interaction response."""
        with self._condition:
            request = self._pending.get(request_id)
            if request is None:
                raise KeyError(f"Unknown or completed interaction: {request_id}")
            if request_id in self._responses:
                raise KeyError(f"Interaction already has a response: {request_id}")
            if action not in request.allowed_actions:
                raise ValueError(
                    f"Interaction '{request_id}' does not allow action '{action}'."
                )
            validate_interaction_response(
                request=request,
                action=action,
                payload=payload or {},
            )
            response = InteractionResponse(
                request_id=request_id,
                action=action,
                payload=dict(payload or {}),
                content=content,
            )
            self._responses[request_id] = response
            self._event_store.append(
                event_type="session.interaction.resolved",
                data=response.to_dict(),
                turn_id=request.turn_id,
            )
            self._condition.notify_all()
            return response

    def cancel(self, request_id: str) -> bool:
        """Cancel one pending interaction and wake its blocked runtime caller."""
        with self._condition:
            request = self._pending.get(request_id)
            if (
                request is None
                or request_id in self._responses
                or request_id in self._cancelled
            ):
                return False
            self._cancelled.add(request_id)
            self._event_store.append(
                event_type="session.interaction.cancelled",
                data={"request_id": request_id},
                turn_id=request.turn_id,
            )
            self._condition.notify_all()
            return True

    def cancel_all(self) -> None:
        """Cancel every unresolved interaction in stable insertion order."""
        for request_id in [request["id"] for request in self.pending()]:
            self.cancel(request_id)

    def pending(self) -> list[dict[str, Any]]:
        """Return stable serialized copies of unresolved requests."""
        with self._condition:
            return [request.to_dict() for request in self._pending.values()]


class AgentRuntimeSession:
    """Own one DeepAgent and expose thread-safe runtime projections."""

    def __init__(
        self,
        *,
        session_id: str,
        agent: DeepAgent,
        event_retention: int = 1000,
    ) -> None:
        """Initialize backend-owned execution, event, and history state."""
        self.session_id = session_id
        self.agent = agent
        self.event_store = RuntimeEventStore(
            session_id=session_id,
            retention=event_retention,
        )
        self.interactions = RuntimeInteractionBroker(event_store=self.event_store)
        self.event_bus = RuntimeEventBus()
        if agent.event_sink is not None:
            self.event_bus.add_sink(agent.event_sink)
        self.event_bus.add_sink(self.event_store)
        self.agent.event_sink = self.event_bus
        self.agent.interaction_handler = self.interactions
        self._state_lock = RLock()
        self._execution_lock = Lock()
        self._busy = False
        self._turn_id: str | None = None
        self._last_result: AgentResult | None = None
        self._session_token_usage = TokenUsageSummary()
        self._last_error: str | None = None

    @property
    def busy(self) -> bool:
        """Return whether one turn is currently executing."""
        with self._state_lock:
            return self._busy

    @property
    def turn_id(self) -> str | None:
        """Return the current or most recently completed turn id."""
        with self._state_lock:
            return self._turn_id

    def run_turn(self, message: str) -> AgentResult:
        """Execute one turn while keeping conversation memory in DeepAgent."""
        if not message.strip():
            raise ValueError("A runtime turn requires a non-empty message.")
        if not self._execution_lock.acquire(blocking=False):
            raise RuntimeError("A turn is already running for this session.")

        turn_id = str(uuid4())
        try:
            self.agent.reset_stop_request()
            with self._state_lock:
                self._busy = True
                self._turn_id = turn_id
                self._last_error = None
            self.publish_session_event(
                event_type="session.turn.started",
                data={"busy": True, "status": "running", "message": message},
                turn_id=turn_id,
            )
            result = self.agent.run(user_message=message, turn_id=turn_id)
            with self._state_lock:
                self._last_result = result
                self._session_token_usage = self._combine_token_usage(
                    self._session_token_usage,
                    result.token_usage,
                )
                self._busy = False
            self.publish_session_event(
                event_type="session.turn.completed",
                data={
                    "busy": False,
                    "status": "completed",
                    "token_usage": result.token_usage.to_dict(),
                },
                turn_id=turn_id,
            )
            return result
        except AgentRunCancelled:
            with self._state_lock:
                self._busy = False
                self._last_error = None
            self.publish_session_event(
                event_type="session.turn.cancelled",
                data={"busy": False, "status": "cancelled"},
                turn_id=turn_id,
            )
            raise
        except Exception as exc:
            with self._state_lock:
                self._busy = False
                self._last_error = str(exc)
            self.publish_session_event(
                event_type="session.turn.failed",
                data={
                    "busy": False,
                    "status": "error",
                    "error": str(exc),
                    "model_request_id": self.agent._active_model_request_id,
                },
                turn_id=turn_id,
            )
            raise
        finally:
            self._execution_lock.release()

    def request_stop(self) -> bool:
        """Request cancellation and report whether a turn was active."""
        with self._state_lock:
            if not self._busy:
                return False
            turn_id = self._turn_id
        self.agent.request_stop()
        self.interactions.cancel_all()
        self.publish_session_event(
            event_type="session.stop.requested",
            data={"busy": True, "status": "stopping"},
            turn_id=turn_id,
        )
        return True

    def snapshot(self) -> dict[str, Any]:
        """Return UI projections derived from backend-owned runtime state."""
        pending_interactions = self.interactions.pending()
        interaction_is_suspending = self.agent._pending_interaction is not None
        if pending_interactions or interaction_is_suspending:
            chat_messages = self._chat_projection()
            raw_chat_messages = self.history_view()["messages"]
        else:
            with self._execution_lock:
                chat_messages = self._chat_projection()
                raw_chat_messages = self.history_view()["messages"]
        with self._state_lock:
            busy = self._busy
            turn_id = self._turn_id
            last_error = self._last_error
            last_turn_token_usage = (
                self._last_result.token_usage.to_dict()
                if self._last_result is not None
                else TokenUsageSummary().to_dict()
            )
            session_token_usage = self._session_token_usage.to_dict()
        trace_events = list(self.event_store.trace_events())
        return {
            "session_id": self.session_id,
            "busy": busy,
            "turn_id": turn_id,
            "last_error": last_error,
            "latest_event_id": self.event_store.events_after(0).latest_event_id,
            "trace_events": trace_events,
            "hds_nodes": self._hds_node_projection(),
            "chat_messages": chat_messages,
            "raw_chat_messages": raw_chat_messages,
            "pending_interactions": pending_interactions,
            "last_turn_token_usage": last_turn_token_usage,
            "session_token_usage": session_token_usage,
        }

    def _hds_node_projection(self) -> list[dict[str, Any]]:
        """Return configured HDS nodes in stable depth-first order."""
        return [
            {
                "name": node.name,
                "hds_name": node.hds_name,
                "path": list(node._path),
                "parent": node._path[-2] if len(node._path) > 1 else None,
            }
            for node in self.agent.hds_config.iter_nodes()
        ]

    def history_view(
        self,
        step_id: str | None = None,
        event_sequence: int | None = None,
    ) -> dict[str, Any]:
        """Project provider messages from the canonical backend history graph."""
        chat_agent = self.agent._root_chat_agent
        if chat_agent is None:
            return {"step_id": step_id, "messages": []}

        graph = chat_agent.history_graph
        message_ids = self._history_message_ids(
            graph=graph,
            root_message_ids=chat_agent.get_message_ids(),
            step_id=step_id,
        )
        if event_sequence is not None:
            message_ids = self._history_ids_through_event(
                graph=graph,
                message_ids=message_ids,
                step_id=step_id,
                event_sequence=event_sequence,
            )
        return {
            "step_id": step_id,
            "event_sequence": event_sequence,
            "messages": [
                {
                    "id": message_id,
                    "kind": graph.get_message(message_id).kind,
                    **graph.message_to_dict(message_id),
                    **self._message_observability(graph=graph, message_id=message_id),
                }
                for message_id in message_ids
            ],
        }

    def events_after(self, event_id: int) -> EventBatch:
        """Return replayable transport events after one event id."""
        return self.event_store.events_after(event_id)

    def wait_for_events(self, *, event_id: int, timeout: float) -> EventBatch:
        """Wait for transport events newer than one event id."""
        return self.event_store.wait_after(event_id=event_id, timeout=timeout)

    def publish_session_event(
        self,
        *,
        event_type: str,
        data: Mapping[str, Any],
        turn_id: str | None = None,
    ) -> TransportEvent:
        """Publish a session lifecycle event into the backend event store."""
        return self.event_store.append(
            event_type=event_type,
            data=data,
            turn_id=turn_id,
        )

    def respond_to_interaction(
        self,
        *,
        request_id: str,
        action: str,
        payload: Mapping[str, Any] | None = None,
        content: str | None = None,
    ) -> InteractionResponse:
        """Deliver one frontend response to a pending generic interaction."""
        return self.interactions.respond(
            request_id=request_id,
            action=action,
            payload=payload,
            content=content,
        )

    def _chat_projection(self) -> list[dict[str, Any]]:
        """Return user-facing chat messages from the root backend cursor."""
        chat_agent = self.agent._root_chat_agent
        if chat_agent is None:
            return []
        projected: list[dict[str, Any]] = []
        for message_id in chat_agent.get_message_ids():
            payload = chat_agent.history_graph.message_to_dict(message_id)
            payload["kind"] = chat_agent.history_graph.get_message(message_id).kind
            payload.update(
                self._message_observability(
                    graph=chat_agent.history_graph,
                    message_id=message_id,
                )
            )
            if payload["role"] in {"system", "developer"}:
                continue
            if payload["role"] == "assistant" and not str(payload["content"]).strip():
                continue
            projected.append(
                {
                    "id": message_id,
                    "message_type": f"{str(payload['role']).title()}Message",
                    **payload,
                }
            )
        return projected

    @staticmethod
    def _message_observability(
        *,
        graph: HistoryGraph,
        message_id: str,
    ) -> dict[str, Any]:
        """Return client-only metadata for one history message."""
        node = graph.get_message(message_id)
        if node.role != "assistant":
            return {}
        token_usage = node.provider_metadata.get("token_usage")
        return (
            {"token_usage": token_usage}
            if isinstance(token_usage, Mapping)
            else {}
        )

    @staticmethod
    def _combine_token_usage(
        left: TokenUsageSummary,
        right: TokenUsageSummary,
    ) -> TokenUsageSummary:
        """Return the sum of two token usage summaries."""
        return TokenUsageSummary(
            request_count=left.request_count + right.request_count,
            input_tokens=left.input_tokens + right.input_tokens,
            output_tokens=left.output_tokens + right.output_tokens,
            total_tokens=left.total_tokens + right.total_tokens,
            reasoning_tokens=left.reasoning_tokens + right.reasoning_tokens,
            cache_read_tokens=left.cache_read_tokens + right.cache_read_tokens,
            cache_write_tokens=left.cache_write_tokens + right.cache_write_tokens,
        )

    @staticmethod
    def _history_message_ids(
        *,
        graph: HistoryGraph,
        root_message_ids: list[str],
        step_id: str | None,
    ) -> list[str]:
        """Resolve ordered message ids for the root cursor or a selected step."""
        if step_id is None:
            return list(root_message_ids)
        if step_id not in graph.steps:
            raise KeyError(f"Unknown history step: {step_id}")
        step = graph.get_step(step_id)
        ordered: list[str] = []
        seen: set[str] = set()
        for message_id in [*step.input_message_ids, *step.output_message_ids]:
            if message_id in graph.messages and message_id not in seen:
                seen.add(message_id)
                ordered.append(message_id)
        return ordered

    def _history_ids_through_event(
        self,
        *,
        graph: HistoryGraph,
        message_ids: list[str],
        step_id: str | None,
        event_sequence: int,
    ) -> list[str]:
        """Return cumulative message ids through one concrete runtime event."""
        selected_event = self._runtime_event_by_sequence(event_sequence)
        if selected_event is None:
            return message_ids
        if (
            selected_event.get("event_type") == "skill_exit"
            and selected_event.get("payload", {}).get("kind") == "deep-skill"
            and step_id is not None
            and step_id in graph.steps
        ):
            return self._skill_exit_history_ids(
                graph=graph,
                step_id=step_id,
                selected_event=selected_event,
            )
        return self._append_unique_message_ids(
            message_ids,
            selected_event.get("added_message_ids", []),
        )

    def _skill_exit_history_ids(
        self,
        *,
        graph: HistoryGraph,
        step_id: str,
        selected_event: Mapping[str, Any],
    ) -> list[str]:
        """Project the child timeline plus its parsed result at a skill merge."""
        merge_step = graph.get_step(step_id)
        child_step = next(
            (
                graph.get_step(previous_step_id)
                for previous_step_id in reversed(merge_step.previous_step_ids)
                if previous_step_id in graph.steps
                and graph.get_step(previous_step_id).depth > merge_step.depth
            ),
            None,
        )
        ordered = (
            [*child_step.input_message_ids, *child_step.output_message_ids]
            if child_step is not None
            else list(merge_step.input_message_ids)
        )
        skill_span_id = selected_event.get("span_id")
        exit_sequence = selected_event.get("sequence")
        if not isinstance(exit_sequence, int):
            return self._append_unique_message_ids(
                ordered, merge_step.output_message_ids
            )
        for envelope in self.event_store.all_events():
            if envelope.type != "runtime.event":
                continue
            event = envelope.data
            sequence = event.get("sequence")
            if not isinstance(sequence, int) or sequence > exit_sequence:
                continue
            belongs_to_skill = event.get("parent_span_id") == skill_span_id
            if belongs_to_skill and event.get("event_type") == "tool_result":
                ordered = self._append_unique_message_ids(
                    ordered,
                    event.get("added_message_ids", []),
                )
        return self._append_unique_message_ids(ordered, merge_step.output_message_ids)

    def _runtime_event_by_sequence(
        self, event_sequence: int
    ) -> Mapping[str, Any] | None:
        """Return one retained runtime-event payload by sequence number."""
        for envelope in self.event_store.all_events():
            if envelope.type != "runtime.event":
                continue
            if envelope.data.get("sequence") != event_sequence:
                continue
            return envelope.data
        return None

    @staticmethod
    def _append_unique_message_ids(
        message_ids: list[str], additions: object
    ) -> list[str]:
        """Append valid unseen message ids while preserving timeline order."""
        ordered = list(message_ids)
        seen = set(ordered)
        if not isinstance(additions, list):
            return ordered
        for message_id in additions:
            if isinstance(message_id, str) and message_id not in seen:
                seen.add(message_id)
                ordered.append(message_id)
        return ordered
