from __future__ import annotations

from dataclasses import dataclass, field
import logging
from pathlib import Path
from typing import Any, Iterator, Mapping

from ..capabilities.hierarchical_deep_skill import HierarchicalDeepSkill
from agent_wiki.configs.settings import SystemConfig
from agent_wiki.backend.interface.checkpoint import (
    CheckpointPolicyInterface,
    CheckpointStoreInterface,
)
from agent_wiki.backend.interface.config import (
    DynamicSubSkillResolverInterface,
    GraphConfigInterface,
    GraphNodeConfigInterface,
    SystemConfigInterface,
)
from agent_wiki.backend.interface.tool_output_memory import ToolOutputMemoryInterface
from agent_wiki.backend.interface.loop_detection import LoopDetectorInterface
from agent_wiki.configs.agent import AgentConfig
from agent_wiki.configs.runtime import (
    RuntimeConfigOverrides,
    RuntimePackageConfig,
    UNSET,
    clone_runtime_config,
)


logger = logging.getLogger(__name__)


@dataclass(slots=True)
class ResolvedNodeConfig:
    """Stores fully resolved runtime configuration for one HDS node."""

    name: str
    system_config: SystemConfigInterface
    config: RuntimePackageConfig
    client: Any
    workroot: Path
    tool_choice: Any
    parallel_tool_calls: bool
    excluded_tool_names: tuple[str, ...]
    preserve_history: bool
    checkpoint_store: CheckpointStoreInterface
    checkpoint_policy: CheckpointPolicyInterface
    tool_output_memory: ToolOutputMemoryInterface
    dynamic_sub_skill_resolver: DynamicSubSkillResolverInterface | None
    loop_detector: LoopDetectorInterface | None
    prompt_variables: dict[str, str]
    path: tuple[str, ...] = ()


@dataclass
class HDSStructureNode:
    """Represents one node in the configured hierarchical deep-skill tree."""

    name: str
    children: list["HDSStructureNode"] = field(default_factory=list)
    hds_name: str | None = None
    workroot: Path | str | None = None
    excluded_tool_names: list[str] | None = None
    preserve_history: bool | None = None
    prompt_variables: dict[str, str] | None = None
    pipeline_steps: tuple[object, ...] | None = None
    pipeline_description: str | None = None
    pipeline_for_each: bool = False
    pipeline_carry_outputs: bool = False
    pipeline_success_message: str = "Loop executed successfully."
    pipeline_output_prefix: str = "<output>"
    pipeline_output_suffix: str = "</output>"
    _hds: HierarchicalDeepSkill | None = field(default=None, init=False, repr=False)
    _resolved_workroot: Path | None = field(default=None, init=False, repr=False)
    _resolved_excluded_tool_names: list[str] = field(
        default_factory=list,
        init=False,
        repr=False,
    )
    _resolved_preserve_history: bool = field(default=True, init=False, repr=False)
    _resolved_node_config: ResolvedNodeConfig | None = field(
        default=None,
        init=False,
        repr=False,
    )
    _path: tuple[str, ...] = field(default_factory=tuple, init=False, repr=False)
    _compiled_pipeline: object | None = field(default=None, init=False, repr=False)
    _children_by_name: dict[str, "HDSStructureNode"] = field(
        default_factory=dict,
        init=False,
        repr=False,
    )

    def __post_init__(self) -> None:
        """Build the private direct-child lookup index."""
        self._children_by_name = {child.name: child for child in self.children}

    def get_child(self, name: str) -> "HDSStructureNode | None":
        """Return one direct child by its configured public name."""
        return self._children_by_name.get(name)

    def to_hds_structure_node(self) -> "HDSStructureNode":
        """Return this node because it already is the runtime structure node."""
        return self


@dataclass(slots=True)
class GraphNodeConfigBase(GraphNodeConfigInterface):
    """Provide configuration shared by HDS and pipeline graph nodes."""

    name: str
    children: list[GraphNodeConfigInterface] = field(default_factory=list)
    client: Any = None
    workroot: Path | str | None = None
    workroot_base: Path | str | None = None
    tool_choice: Any = None
    parallel_tool_calls: bool | None = None
    agent: AgentConfig | None = None
    runtime: RuntimeConfigOverrides | None = None
    capability_builtin_roots: list[Path | str] | None = None
    capability_extra_roots: list[Path | str] | None = None
    workroot_bridge_dir: str | None = None
    excluded_tool_names: list[str] | None = None
    preserve_history: bool | None = None
    prompt_variables: Mapping[str, str] | None = None
    checkpoint_store: CheckpointStoreInterface | None = None
    checkpoint_policy: CheckpointPolicyInterface | None = None
    tool_output_memory: ToolOutputMemoryInterface | None = None
    dynamic_sub_skill_resolver: DynamicSubSkillResolverInterface | None = None
    loop_detector: LoopDetectorInterface | None = None

    def __post_init__(self) -> None:
        """Normalize the public node name and reject the removed mapping shape."""
        if not isinstance(self.children, list):
            raise TypeError("Graph node children must be provided as a list of nodes.")
        if not isinstance(self.name, str):
            raise TypeError("Graph node name must be a string.")
        self.name = self.name.strip()

    def resolve(
        self,
        system_config: SystemConfigInterface,
        parent: ResolvedNodeConfig | None = None,
    ) -> ResolvedNodeConfig:
        """Resolve this node against a parent and system defaults."""
        logger.debug(
            "Resolving HDS node config",
            extra={
                "node": self.name,
                "parent_path": list(parent.path) if parent is not None else [],
            },
        )
        self.validate()
        inherited_config = (
            clone_runtime_config(parent.config)
            if parent is not None
            else clone_runtime_config(system_config.config)
        )

        client = (
            self.client if self.client is not None else getattr(parent, "client", None)
        )
        workroot = self._resolve_workroot(parent=parent)
        if client is None:
            raise ValueError(
                f"Node '{self.name}' requires a client before runtime start."
            )
        if workroot is None:
            raise ValueError(
                f"Node '{self.name}' requires a workroot before runtime start."
            )

        resolved_runtime = inherited_config.runtime
        if self.agent is not None:
            resolved_runtime = self.agent.to_runtime_overrides().apply(
                resolved_runtime
            )
        if self.runtime is not None:
            resolved_runtime = self.runtime.apply(resolved_runtime)

        capabilities = inherited_config.capabilities
        if capabilities is None:
            raise ValueError("Node resolution requires capability layout settings.")
        capabilities = capabilities.with_overrides(
            builtin_roots=self.capability_builtin_roots,
            extra_roots=self.capability_extra_roots,
            workroot_bridge_dir=(
                self.workroot_bridge_dir
                if self.workroot_bridge_dir is not None
                else UNSET
            ),
        )

        config = inherited_config.with_runtime(resolved_runtime).with_capabilities(
            capabilities
        )
        config = self._apply_feature_config(config)
        resolved_workroot = workroot
        resolved = ResolvedNodeConfig(
            name=self.name,
            system_config=system_config,
            config=config,
            client=client,
            workroot=resolved_workroot,
            tool_choice=(
                self.tool_choice
                if self.tool_choice is not None
                else getattr(parent, "tool_choice", "auto")
            ),
            parallel_tool_calls=bool(
                self.parallel_tool_calls
                if self.parallel_tool_calls is not None
                else getattr(parent, "parallel_tool_calls", False)
            ),
            excluded_tool_names=tuple(self._resolve_excluded_tool_names()),
            preserve_history=(
                self.preserve_history
                if self.preserve_history is not None
                else getattr(parent, "preserve_history", True)
            ),
            checkpoint_store=self._resolve_checkpoint_store(
                config=config,
                workroot=resolved_workroot,
                parent=parent,
            ),
            checkpoint_policy=self._resolve_checkpoint_policy(
                config=config,
                parent=parent,
            ),
            tool_output_memory=self._resolve_tool_output_memory(
                config=config,
                workroot=resolved_workroot,
                parent=parent,
            ),
            dynamic_sub_skill_resolver=self.dynamic_sub_skill_resolver,
            loop_detector=(
                self.loop_detector
                if self.loop_detector is not None
                else getattr(parent, "loop_detector", None)
            ),
            prompt_variables=self._resolve_prompt_variables(parent=parent),
            path=((*parent.path, self.name) if parent is not None else (self.name,)),
        )
        logger.debug(
            "Resolved HDS node config",
            extra={
                "node": resolved.name,
                "path": list(resolved.path),
                "workroot": str(resolved.workroot),
                "diagnostic_logs_enabled": (
                    resolved.config.runtime.diagnostic_logs.enabled
                ),
            },
        )
        return resolved

    def iter_children(self) -> Iterator[GraphNodeConfigInterface]:
        """Yield child node configs in insertion order."""
        yield from self.children

    def to_hds_structure_node(self) -> HDSStructureNode:
        """Convert this node config and its children into runtime HDS nodes."""
        return HDSStructureNode(
            name=self.name,
            hds_name=self._resolved_hds_name(),
            workroot=self.workroot,
            excluded_tool_names=list(self.excluded_tool_names)
            if self.excluded_tool_names is not None
            else None,
            preserve_history=self.preserve_history,
            prompt_variables=(
                dict(self.prompt_variables) if self.prompt_variables is not None else None
            ),
            children=[child.to_hds_structure_node() for child in self.children],
        )

    def _resolved_hds_name(self) -> str | None:
        """Return the capability name loaded for this node, when applicable."""
        return None

    def validate(self) -> None:
        """Validate node-local values that can be checked before resolution."""
        if not self.name.strip():
            raise ValueError("Node configuration requires a non-empty HDS name.")
        if self.preserve_history is not None and not isinstance(
            self.preserve_history, bool
        ):
            raise TypeError(
                f"Node '{self.name}' preserve_history must be a boolean or None."
            )
        if self.loop_detector is not None and not isinstance(
            self.loop_detector, LoopDetectorInterface
        ):
            raise TypeError(
                f"Node '{self.name}' loop_detector must implement LoopDetectorInterface."
            )
        from ..capabilities.prompt_templates import validate_custom_prompt_variables

        validate_custom_prompt_variables(
            self.prompt_variables or {}, owner=f"node '{self.name}'"
        )
        for child in self.iter_children():
            child.validate()

    def _resolve_prompt_variables(
        self, *, parent: ResolvedNodeConfig | None
    ) -> dict[str, str]:
        """Merge inheritable custom prompt variables for this node."""
        resolved = dict(parent.prompt_variables) if parent is not None else {}
        resolved.update(dict(self.prompt_variables or {}))
        return resolved

    def _apply_feature_config(
        self, config: RuntimePackageConfig
    ) -> RuntimePackageConfig:
        """Return config with subclass-owned feature settings applied."""
        return config

    def _resolve_workroot(self, *, parent: ResolvedNodeConfig | None) -> Path | None:
        """Resolve this node workroot against its parent."""
        if self.workroot is None:
            return parent.workroot if parent is not None else None
        configured = Path(self.workroot).expanduser()
        if configured.is_absolute():
            return configured.resolve()
        if parent is None:
            if self.workroot_base is not None:
                return (Path(self.workroot_base).expanduser() / configured).resolve()
            return configured.resolve()
        return (parent.workroot / configured).resolve()

    def _resolve_excluded_tool_names(self) -> list[str]:
        """Return node-local tool names whose outputs should stay non-reusable."""
        configured_names = self.excluded_tool_names or []
        names = [name for name in configured_names if isinstance(name, str) and name]
        return list(dict.fromkeys(names))

    def _resolve_checkpoint_store(
        self,
        *,
        config: RuntimePackageConfig,
        workroot: Path,
        parent: ResolvedNodeConfig | None,
    ) -> CheckpointStoreInterface:
        """Resolve the checkpoint store from local, parent, or default behavior."""
        if self.checkpoint_store is not None:
            return self.checkpoint_store
        if parent is not None:
            return parent.checkpoint_store

        from ..checkpoints.checkpoint import FilesystemCheckpointStore

        return FilesystemCheckpointStore(
            checkpoint_dir=_resolve_optional_runtime_path(
                config.runtime.checkpoint.directory,
                workroot=workroot,
            )
        )

    def _resolve_checkpoint_policy(
        self,
        *,
        config: RuntimePackageConfig,
        parent: ResolvedNodeConfig | None,
    ) -> CheckpointPolicyInterface:
        """Resolve the checkpoint policy from local, parent, or default behavior."""
        if self.checkpoint_policy is not None:
            return self.checkpoint_policy
        if parent is not None:
            return parent.checkpoint_policy

        from ..checkpoints.checkpoint import DefaultCheckpointPolicy

        return DefaultCheckpointPolicy(
            enabled=bool(config.runtime.checkpoint.enabled),
            message_threshold=_positive_int_or_none(
                config.runtime.checkpoint.message_threshold
            ),
            on_tool_or_skill_before_execution=bool(
                config.runtime.checkpoint.on_tool_or_skill_before_execution
            ),
            on_skill_close=bool(config.runtime.checkpoint.on_skill_close),
        )

    def _resolve_tool_output_memory(
        self,
        *,
        config: RuntimePackageConfig,
        workroot: Path,
        parent: ResolvedNodeConfig | None,
    ) -> ToolOutputMemoryInterface:
        """Resolve reusable output memory from local, parent, or default behavior."""
        if self.tool_output_memory is not None:
            return self.tool_output_memory
        if parent is not None:
            return parent.tool_output_memory

        from ..outputs.tool_output_memory import FilesystemToolOutputMemory

        return FilesystemToolOutputMemory(
            storage_dir=_resolve_optional_runtime_path(
                config.runtime.tool_output.memory_dir,
                workroot=workroot,
            ),
            description_token_limit=_positive_int_or_default(
                config.runtime.tool_output.description_token_limit,
                default=10,
            ),
        )


@dataclass(slots=True)
class GraphNodeConfig(GraphNodeConfigBase):
    """Configure an HDS graph node with separate public and capability names."""

    hds_name: str | None = None

    def __post_init__(self) -> None:
        """Normalize the public name and optional HDS capability name."""
        GraphNodeConfigBase.__post_init__(self)
        if self.hds_name is not None and not isinstance(self.hds_name, str):
            raise TypeError(f"Node '{self.name}' HDS name must be a string or None.")
        if self.hds_name is not None:
            self.hds_name = self.hds_name.strip()

    def validate(self) -> None:
        """Validate the public node name and resolved HDS capability name."""
        GraphNodeConfigBase.validate(self)
        if not self._resolved_hds_name():
            raise ValueError(f"Node '{self.name}' requires a non-empty HDS name.")

    def _resolved_hds_name(self) -> str:
        """Return the configured capability name, defaulting to the public name."""
        return self.name if self.hds_name is None else self.hds_name


@dataclass(slots=True)
class PipelineGraphNodeConfig(GraphNodeConfigBase):
    """Configure a child graph node that executes a fixed sequential pipeline."""

    steps: list[object] = field(default_factory=list)
    description: str = "Execute a configured sequential pipeline."

    def to_hds_structure_node(self) -> HDSStructureNode:
        """Convert this pipeline config into a specialized structure node."""
        return HDSStructureNode(
            name=self.name,
            workroot=self.workroot,
            prompt_variables=(
                dict(self.prompt_variables) if self.prompt_variables is not None else None
            ),
            excluded_tool_names=list(self.excluded_tool_names)
            if self.excluded_tool_names is not None
            else None,
            preserve_history=self.preserve_history,
            children=[child.to_hds_structure_node() for child in self.children],
            pipeline_steps=tuple(self.steps),
            pipeline_description=self.description,
        )

    def validate(self) -> None:
        """Validate the pipeline name, description, steps, and child configs."""
        GraphNodeConfigBase.validate(self)
        if not self.description.strip():
            raise ValueError(f"Pipeline node '{self.name}' requires a description.")
        if not self.steps:
            raise ValueError(f"Pipeline node '{self.name}' requires at least one step.")
        from ..pipeline import PipelineHDSStep, PipelineToolStep

        child_names = {child.name for child in self.children}
        for index, step in enumerate(self.steps):
            if not isinstance(step, (PipelineToolStep, PipelineHDSStep)):
                raise TypeError(
                    f"Pipeline node '{self.name}' step {index} must be a tool or HDS step."
                )
            if isinstance(step, PipelineHDSStep) and step.child_name not in child_names:
                raise ValueError(
                    f"Pipeline node '{self.name}' step {index} references unavailable "
                    f"direct child '{step.child_name}'."
                )


@dataclass(slots=True)
class ForPipelineGraphNodeConfig(PipelineGraphNodeConfig):
    """Configure a sequential pipeline that runs once for every input text."""

    carry_outputs: bool = False
    success_message: str = "Loop executed successfully."
    output_prefix: str = "<output>"
    output_suffix: str = "</output>"
    description: str = "Execute a configured sequential pipeline for every input text."

    def to_hds_structure_node(self) -> HDSStructureNode:
        """Convert this for-pipeline config into a specialized structure node."""
        node = PipelineGraphNodeConfig.to_hds_structure_node(self)
        node.pipeline_for_each = True
        node.pipeline_carry_outputs = self.carry_outputs
        node.pipeline_success_message = self.success_message
        node.pipeline_output_prefix = self.output_prefix
        node.pipeline_output_suffix = self.output_suffix
        return node

    def validate(self) -> None:
        """Validate the common pipeline fields and for-loop text configuration."""
        PipelineGraphNodeConfig.validate(self)
        for field_name, value in (
            ("success_message", self.success_message),
            ("output_prefix", self.output_prefix),
            ("output_suffix", self.output_suffix),
        ):
            if not isinstance(value, str) or not value.strip():
                raise ValueError(
                    f"For-pipeline node '{self.name}' requires non-empty "
                    f"{field_name}."
                )


@dataclass(slots=True)
class GraphConfig(GraphConfigInterface):
    """Container for the top-level HDS node and system configuration."""

    main: GraphNodeConfigInterface
    system_config: SystemConfigInterface = field(default_factory=SystemConfig)

    def resolve(self) -> ResolvedNodeConfig:
        """Resolve the root node and its descendants using system defaults."""
        self.validate()
        return self.main.resolve(system_config=self.system_config, parent=None)

    def to_hds_structure_node(self) -> HDSStructureNode:
        """Convert the graph config object into a runtime HDS structure node."""
        return self.main.to_hds_structure_node()

    def validate(self) -> None:
        """Validate graph and node configuration before runtime starts."""
        self.system_config.validate()
        self.main.validate()
        self._validate_unique_node_names()

    def _validate_unique_node_names(self) -> None:
        """Reject case-insensitive public-name duplicates across the full graph."""
        seen: dict[str, tuple[str, ...]] = {}

        def visit(node: GraphNodeConfigInterface, parent: tuple[str, ...]) -> None:
            """Visit one configured node and record its public path."""
            path = (*parent, node.name)
            normalized = node.name.casefold()
            previous = seen.get(normalized)
            if previous is not None:
                raise ValueError(
                    f"Duplicate graph node name '{node.name}' at "
                    f"'{('/'.join(path))}'; it is already used at "
                    f"'{('/'.join(previous))}'."
                )
            seen[normalized] = path
            for child in node.iter_children():
                visit(child, path)

        visit(self.main, ())

    @classmethod
    def single(
        cls,
        hds_name: str,
        *,
        system_config: SystemConfigInterface | None = None,
        **values: Any,
    ) -> "GraphConfig":
        """Return a single-node HDS config for generic selections."""
        return cls(
            system_config=system_config or SystemConfig(),
            main=GraphNodeConfig(name=hds_name, **values),
        )


HDSNodeConfig = GraphNodeConfig
HDSGraphConfig = GraphConfig
ResolvedHDSNodeConfig = ResolvedNodeConfig


@dataclass
class HDSConfig:
    """Loads and stores the configured hierarchical deep-skill structure."""

    node_config: GraphConfigInterface
    _config: RuntimePackageConfig | None = field(init=False, repr=False)
    structure: HDSStructureNode = field(init=False)
    capability_roots: object | None = field(init=False, repr=False, default=None)

    def __post_init__(self) -> None:
        """Resolve the root structure node and load hierarchical skills."""
        self.node_config.validate()
        self.structure = self.node_config.to_hds_structure_node()
        root_resolved = self.node_config.resolve()
        self._config = root_resolved.config
        self._init_hds(
            self.structure,
            node_config=self.node_config.main,
            resolved_config=root_resolved,
            path=(),
        )

    def _init_hds(
        self,
        node: HDSStructureNode,
        *,
        node_config: GraphNodeConfigInterface,
        resolved_config: ResolvedNodeConfig,
        path: tuple[str, ...],
    ) -> None:
        """Recursively attach loaded hierarchical skills to structure nodes."""
        node._path = (*path, node.name)
        resolved_config.path = node._path
        node._resolved_node_config = resolved_config
        node._resolved_workroot = resolved_config.workroot
        node._resolved_excluded_tool_names = list(resolved_config.excluded_tool_names)
        node._resolved_preserve_history = resolved_config.preserve_history
        from ..capabilities.capability_roots import resolve_capability_roots

        node_capability_roots = resolve_capability_roots(
            config=resolved_config.config,
            workroot=resolved_config.workroot,
        )
        logger.debug(
            "Resolved capability roots for HDS node",
            extra={
                "node": node.name,
                "path": list(node._path),
                "capability_roots": [
                    str(path) for path in node_capability_roots.capability_roots
                ],
            },
        )
        if path == ():
            self.capability_roots = node_capability_roots
        is_pipeline = node.pipeline_steps is not None
        if not is_pipeline:
            if not node.hds_name:
                raise ValueError(f"HDS node '{node.name}' has no capability name.")
            node._hds = HierarchicalDeepSkill.load_hierarchical_deep_skill(
                name=node.hds_name,
                config=resolved_config.config,
                capability_roots=node_capability_roots,
            )
        child_configs = {child.name: child for child in node_config.children}
        for child_node in node.children:
            child_config = child_configs.get(child_node.name)
            if child_config is None:
                raise ValueError(f"Missing node config for child '{child_node.name}'.")
            child_resolved = child_config.resolve(
                system_config=resolved_config.system_config, parent=resolved_config
            )
            self._init_hds(
                child_node,
                node_config=child_config,
                resolved_config=child_resolved,
                path=node._path,
            )
        if is_pipeline:
            node._compiled_pipeline = self._compile_pipeline(
                node=node,
                capability_roots=node_capability_roots,
            )

    def _compile_pipeline(self, *, node: HDSStructureNode, capability_roots: Any) -> Any:
        """Resolve configured tools, child HDS nodes, and tool input adapters."""
        from ..capabilities.capability_roots import find_named_capability_dir
        from ..capabilities.pipeline_adapter import load_tool_input_adapter
        from ..capabilities.tool import Tool
        from ..pipeline import (
            CompiledPipeline,
            CompiledPipelineStep,
            PipelineHDSStep,
            PipelineToolStep,
        )
        compiled: list[CompiledPipelineStep] = []
        for step in node.pipeline_steps or ():
            if isinstance(step, PipelineToolStep):
                directory = find_named_capability_dir(
                    roots=capability_roots.tool_roots,
                    name=step.tool_name,
                )
                tool = Tool.load_tool(path=directory)
                compiled.append(
                    CompiledPipelineStep(
                        kind="tool",
                        name=step.tool_name,
                        input_adapter=load_tool_input_adapter(directory),
                        tool=tool,
                    )
                )
                continue
            if isinstance(step, PipelineHDSStep):
                child = node.get_child(step.child_name)
                if (
                    child is None
                    or child._hds is None
                    or child._hds.exit_skill is None
                    or child._resolved_node_config is None
                ):
                    raise ValueError(
                        f"Pipeline node '{node.name}' references unavailable child HDS "
                        f"'{step.child_name}'."
                    )
                compiled.append(
                    CompiledPipelineStep(
                        kind="hds",
                        name=step.child_name,
                    )
                )
                continue
            raise TypeError(f"Unsupported pipeline step: {step!r}")

        return CompiledPipeline(steps=tuple(compiled))

    def get_main_hds(self) -> HierarchicalDeepSkill:
        """Return the loaded hierarchical deep skill attached to the root node."""
        if self.structure._hds is None:
            raise ValueError(
                f"No hierarchical deep skill found for the root node '{self.structure.name}'."
            )
        return self.structure._hds

    def get_main_node(self) -> HDSStructureNode:
        """Return the configured root structure node."""
        return self.structure

    def iter_nodes(self) -> Iterator[HDSStructureNode]:
        """Yield every configured HDS structure node in depth-first order."""
        yield from self._iter_nodes(self.structure)

    def get_node_by_path(self, path: tuple[str, ...]) -> HDSStructureNode | None:
        """Return one configured node by its resolved path."""
        for node in self.iter_nodes():
            if node._path == path:
                return node
        return None

    def get_child_node(
        self, parent_path: tuple[str, ...], child_name: str
    ) -> HDSStructureNode | None:
        """Return the direct child node with the requested name."""
        parent = self.get_node_by_path(parent_path)
        if parent is None:
            return None
        return parent.get_child(child_name)

    def get_child_names(self, parent_path: tuple[str, ...]) -> list[str]:
        """Return direct child names for one configured HDS node."""
        parent = self.get_node_by_path(parent_path)
        if parent is None or not parent.children:
            return []
        return [child.name for child in parent.children]

    def get_node_names(self) -> list[str]:
        """Return every configured public node name in depth-first order."""
        return [node.name for node in self.iter_nodes()]

    def get_child_descriptions(
        self, parent_path: tuple[str, ...]
    ) -> list[tuple[str, str]]:
        """Return direct child names with their loaded HDS descriptions."""
        parent = self.get_node_by_path(parent_path)
        if parent is None or not parent.children:
            return []
        descriptions: list[tuple[str, str]] = []
        for child_node in parent.children:
            description = (
                child_node.pipeline_description
                if child_node.pipeline_steps is not None
                else child_node._hds.description if child_node._hds else ""
            )
            descriptions.append((child_node.name, description))
        return descriptions

    @staticmethod
    def _iter_nodes(node: HDSStructureNode) -> Iterator[HDSStructureNode]:
        """Yield one node and all descendants in depth-first order."""
        yield node
        for child_node in node.children:
            yield from HDSConfig._iter_nodes(child_node)


def _resolve_optional_runtime_path(value: object, *, workroot: Path) -> Path | None:
    """Resolve an optional runtime path relative to the configured workroot."""
    if isinstance(value, Path):
        candidate = value.expanduser()
    elif isinstance(value, str) and value.strip():
        candidate = Path(value).expanduser()
    else:
        return None
    if candidate.is_absolute():
        return candidate.resolve()
    return (workroot / candidate).resolve()


def _positive_int_or_none(value: object) -> int | None:
    """Return a positive integer value or None when the input is invalid."""
    if not isinstance(value, int) or value < 1:
        return None
    return value


def _positive_int_or_default(value: object, *, default: int) -> int:
    """Return a positive integer value or a positive fallback."""
    if not isinstance(value, int) or value < 1:
        return max(1, default)
    return value


def _validate_positive(name: str, value: int | None) -> None:
    """Validate an optional positive integer."""
    if value is not None and value <= 0:
        raise ValueError(f"Node configuration key '{name}' must be greater than zero.")


def _validate_non_negative(name: str, value: int | None) -> None:
    """Validate an optional non-negative integer."""
    if value is not None and value < 0:
        raise ValueError(f"Node configuration key '{name}' must be zero or greater.")


def _validate_probability(name: str, value: int | float | None) -> None:
    """Validate an optional probability value."""
    if value is not None and not 0 <= value <= 1:
        raise ValueError(f"Node configuration key '{name}' must be between 0 and 1.")
