"""Validated runtime definitions for sequential pipeline graph nodes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, TypeAlias

from .capabilities.pipeline_adapter import LoadedToolInputAdapter
from .capabilities.tool import Tool


@dataclass(frozen=True, slots=True)
class PipelineToolStep:
    """Reference one immediate tool in a sequential pipeline."""

    tool_name: str
    kind: Literal["tool"] = "tool"


@dataclass(frozen=True, slots=True)
class PipelineHDSStep:
    """Reference one child HDS in a sequential pipeline."""

    child_name: str
    kind: Literal["hds"] = "hds"


PipelineStepConfig: TypeAlias = PipelineToolStep | PipelineHDSStep


@dataclass(frozen=True, slots=True)
class CompiledPipelineStep:
    """Store one validated text step and its optional tool input adapter."""

    kind: Literal["tool", "hds"]
    name: str
    input_adapter: LoadedToolInputAdapter | None = None
    tool: Tool | None = None


@dataclass(frozen=True, slots=True)
class CompiledPipeline:
    """Store a finite ordered sequence ready for runtime execution."""

    steps: tuple[CompiledPipelineStep, ...]
