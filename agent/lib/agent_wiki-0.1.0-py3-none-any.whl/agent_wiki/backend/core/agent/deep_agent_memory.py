from __future__ import annotations

import re

from .deep_agent_state import _LevelContext


class DeepAgentMemoryMixin:
    """Manages reusable callable outputs and level execution identifiers."""

    def _remember_callable_output(
        self,
        *,
        context: _LevelContext,
        tool_call_id: str,
        capability_name: str,
        content: str,
        visible_tool_call_id: str | None = None,
    ) -> None:
        """Persist one callable non-structural result for later awareness and lookup."""
        if self._is_tool_output_excluded(context=context, tool_name=capability_name):
            return

        capability = context.local_tools.get_tool_by_name(capability_name)
        if capability is None:
            return

        self._tool_output_memory.remember_output(
            tool_call_id=tool_call_id,
            capability_name=capability_name,
            content=content,
            local_tools=context.local_tools,
            hds_id=context.memory_hds_id,
            hds_node_path=context.hds_node_path,
            visible_tool_call_id=visible_tool_call_id,
        )

    @staticmethod
    def _is_tool_output_excluded(
        *, context: _LevelContext, tool_name: str | None
    ) -> bool:
        """Return whether a tool output should stay out of reusable runtime memory."""
        if not isinstance(tool_name, str) or not tool_name.strip():
            return False
        return tool_name.strip() in set(context.excluded_tool_names)

    def _next_level_execution_id(self, skill_name: str | None) -> str:
        """Create a stable per-run execution id for one opened runtime level."""
        self._level_execution_sequence += 1
        normalized_name = re.sub(r"[^a-z0-9]+", "-", (skill_name or "level").lower())
        normalized_name = normalized_name.strip("-") or "level"
        return f"{normalized_name}-{self._level_execution_sequence:04d}"
