from __future__ import annotations

import logging
import json
from typing import Any, Mapping
from uuid import uuid4

from ..capabilities.agent_capabilities import AgentCapabilities
from ..conversation.chat_agent import ChatAgent
from .deep_agent_state import _LevelContext
from ..capabilities.deep_skill import DeepSkill
from ..observability.events import LevelEventData
from ..capabilities.exit_skill import ExitSkill
from ..capabilities.tool import Tool, ToolOutput
from ..capabilities.tool import ToolHITLContext, ToolHITLResolution
from agent_wiki.backend.interface.interaction import (
    InteractionCancelledError,
    InteractionRequest,
    InteractionResponse,
)
from agent_wiki.configs.text_catalog import get_runtime_text
from .hds_child_tool import HDS_CHILD_TOOL_NAME
from .user_questions import UserQuestionRuntime

logger = logging.getLogger(__name__)


class DeepAgentToolingMixin:
    """Handles concrete tool, exit-skill, and deep-skill capability calls."""

    def _handle_tool_call(
        self,
        *,
        tool_call: Mapping[str, Any],
        chat_agent: ChatAgent,
        context: _LevelContext,
    ) -> str | None:
        """Execute one pending tool call and return a level result when it exits."""
        tool_name = self._extract_tool_name(tool_call)
        if tool_name is None:
            return None

        tool_call_id = self._extract_tool_call_id(tool_call)
        if tool_call_id is None:
            feedback_message = self._invalid_tool_call_feedback(
                context=context,
                tool_name=tool_name,
                details=get_runtime_text("agent.errors.missing_tool_call_id"),
                assistant_text=self._latest_assistant_text(chat_agent=chat_agent),
            )
            self._append_user_feedback(
                chat_agent=chat_agent,
                context=context,
                message=feedback_message,
                event_kind="invalid-tool-call",
                discard_latest_assistant=True,
            )
            return None
        provider = getattr(context.client, "provider", None)
        if bool(getattr(provider, "supports_agentic_capabilities", False)):
            tool = context.local_tools.get_agentic_capability_by_name(tool_name)
        else:
            tool = context.local_tools.get_tool_by_name(tool_name)
        logger.debug(
            "Resolved tool presence",
            extra={
                "tool_name": tool_name,
                "found": tool is not None,
            },
        )
        if tool is None:
            error_message = get_runtime_text(
                "agent.errors.missing_tool",
                tool_name=tool_name,
            )
            feedback_message = self._invalid_tool_call_feedback(
                context=context,
                tool_name=tool_name,
                details=error_message,
                assistant_text=self._latest_assistant_text(chat_agent=chat_agent),
            )
            self._record_tool_error(
                chat_agent=chat_agent,
                context=context,
                tool_name=tool_name,
                tool_call_id=tool_call_id,
                message=feedback_message,
                error_kind="missing_tool",
            )
            logging.warning(error_message)
            return None

        if isinstance(tool, DeepSkill):
            if self._reject_invalid_structural_capability_call(
                tool_call=tool_call,
                tool_name=tool_name,
                chat_agent=chat_agent,
                context=context,
            ):
                return None
            logger.info(
                "Opening deep skill",
                extra={
                    "skill_name": tool_name,
                    "tool_call_id": tool_call_id,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                },
            )
            self._checkpoint_before_execution(
                reason="before-deep-skill",
                pending_tool_call=tool_call,
            )
            skill_result = self._run_deep_skill(
                deep_skill=tool,
                tool_call_id=tool_call_id,
                chat_history=chat_agent.chat_history,
                parent_chat_agent=chat_agent,
                parent_context=context,
            )
            self._record_skill_result(
                chat_agent=chat_agent,
                context=context,
                tool_call_id=tool_call_id,
                tool_name=tool_name,
                content=skill_result.response,
                metadata=skill_result.metadata,
            )
            self._checkpoint_after_skill_close()
            return None

        if isinstance(tool, ExitSkill):
            if self._reject_invalid_structural_capability_call(
                tool_call=tool_call,
                tool_name=tool_name,
                chat_agent=chat_agent,
                context=context,
            ):
                return None
            logger.info(
                "Activating exit skill",
                extra={
                    "exit_skill": tool_name,
                    "tool_call_id": tool_call_id,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                },
            )
            self._checkpoint_before_execution(
                reason="before-exit-skill",
                pending_tool_call=tool_call,
            )
            context.local_tools.activate_exit_tool()
            exit_skill_context = tool.render_skill_context()
            exit_skill_message = chat_agent.add_tool_result(
                content=exit_skill_context,
                tool_call_id=tool_call_id,
                name=tool_name,
                depth=context.depth,
                level_path=context.level_path,
            )
            self._record_capability_result_step(
                chat_agent=chat_agent,
                context=context,
                message_id=chat_agent.get_message_ids()[-1],
                response_text=exit_skill_context,
                tool_name=tool_name,
                tool_call_id=tool_call_id,
                kind="exit-skill-context",
            )
            self._emit_level_event(
                chat_agent=chat_agent,
                context=context,
                event_data=LevelEventData(
                    event_type="tool_result",
                    content=exit_skill_message.content,
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    payload={
                        "kind": "exit-skill-context",
                        "exit_tool": tool.get_exit_tool_name(),
                    },
                ),
            )
            return None

        if isinstance(tool, Tool):
            if context.local_tools.is_exit_tool(tool_name):
                logger.info(
                    "Running exit tool",
                    extra={
                        "tool_name": tool_name,
                        "tool_call_id": tool_call_id,
                        "current_skill": context.current_skill,
                        "depth": context.depth,
                    },
                )
                self._checkpoint_before_execution(
                    reason="before-exit-tool",
                    pending_tool_call=tool_call,
                )
                tool_result = self._run_exit_tool(
                    exit_skill=context.local_tools.exit,
                    tool_call=tool_call,
                    chat_agent=chat_agent,
                    context=context,
                )
                exit_result = self._resolve_exit_skill_result(
                    exit_skill=context.local_tools.exit,
                    tool_result=tool_result,
                    chat_agent=chat_agent,
                    context=context,
                    runtime_tool_call_id=tool_call_id,
                )
                if not exit_result.is_valid:
                    logger.warning(
                        "Invalid exit tool call returned local feedback",
                        extra={
                            "tool_name": tool_name,
                            "tool_call_id": tool_call_id,
                            "current_skill": context.current_skill,
                            "depth": context.depth,
                        },
                    )
                    self._record_tool_error(
                        chat_agent=chat_agent,
                        context=context,
                        tool_name=tool_name,
                        tool_call_id=tool_call_id,
                        message=exit_result.tool_feedback,
                        error_kind="invalid_exit_tool_call",
                    )
                    return None
                exit_tool_message = chat_agent.add_tool_result(
                    content=exit_result.tool_feedback,
                    tool_call_id=tool_call_id,
                    name=tool_name,
                    depth=context.depth,
                    level_path=context.level_path,
                    include_envelope=not self._is_tool_output_excluded(
                        context=context,
                        tool_name=tool_name,
                    ),
                )
                self._record_capability_result_step(
                    chat_agent=chat_agent,
                    context=context,
                    message_id=chat_agent.get_message_ids()[-1],
                    response_text=exit_result.response,
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    kind="exit-tool",
                )
                self._emit_level_event(
                    chat_agent=chat_agent,
                    context=context,
                    event_data=LevelEventData(
                        event_type="tool_result",
                        content=exit_tool_message.content,
                        tool_name=tool_name,
                        tool_call_id=tool_call_id,
                        payload={
                            "kind": "exit-tool",
                            "valid": exit_result.is_valid,
                        },
                    ),
                )
                logger.info(
                    "Exit tool completed level",
                    extra={
                        "tool_name": tool_name,
                        "tool_call_id": tool_call_id,
                        "current_skill": context.current_skill,
                        "depth": context.depth,
                    },
                )
                context.promoted_metadata = exit_result.metadata
                return exit_result.response

            injected_arguments = self._build_tool_runtime_arguments(
                tool_name=tool.name,
                chat_agent=chat_agent,
                local_tools=context.local_tools,
                current_skill=context.current_skill,
                context=context,
                runtime_tool_call_id=tool_call_id,
                runtime_tool_call=tool_call,
            )
            original_arguments, validation_error = tool.validate_call_arguments(
                arguments=tool_call.get("function", {}).get("arguments"),
                injected_arguments=injected_arguments,
            )
            if validation_error is not None:
                return self._record_regular_tool_result(
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    tool_result=validation_error,
                    chat_agent=chat_agent,
                    context=context,
                )
            if tool.hitl is None:
                self._checkpoint_before_execution(
                    reason="before-tool",
                    pending_tool_call=tool_call,
                )
            approved_tool_call, denied_result = self._resolve_tool_hitl(
                tool=tool,
                tool_call=tool_call,
                tool_call_id=tool_call_id,
                original_arguments=original_arguments or {},
            )
            if denied_result is not None:
                return self._record_regular_tool_result(
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    tool_result=denied_result,
                    chat_agent=chat_agent,
                    context=context,
                )
            tool_call = approved_tool_call
            executed_arguments, execution_validation_error = (
                tool.validate_call_arguments(
                    arguments=tool_call.get("function", {}).get("arguments"),
                    injected_arguments=injected_arguments,
                )
            )
            if execution_validation_error is not None:
                return self._record_regular_tool_result(
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    tool_result=execution_validation_error,
                    chat_agent=chat_agent,
                    context=context,
                )
            logger.info(
                "Running tool",
                extra={
                    "tool_name": tool_name,
                    "tool_call_id": tool_call_id,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                },
            )
            tool_result = self._run_tool(
                tool=tool,
                tool_call=tool_call,
                chat_agent=chat_agent,
                context=context,
            )
            return self._record_regular_tool_result(
                tool_name=tool_name,
                tool_call_id=tool_call_id,
                tool_result=tool_result,
                chat_agent=chat_agent,
                context=context,
                call_arguments=executed_arguments,
            )

        raise ValueError(
            get_runtime_text(
                "agent.errors.invalid_capability_type",
                tool_name=tool_name,
            )
        )

    def _resolve_tool_hitl(
        self,
        *,
        tool: Tool,
        tool_call: Mapping[str, Any],
        tool_call_id: str,
        original_arguments: Mapping[str, Any],
    ) -> tuple[Mapping[str, Any], ToolOutput | None]:
        """Wait for HITL approval and return a possibly modified tool call."""
        if tool.hitl is None:
            return tool_call, None
        if self.interaction_handler is None:
            raise RuntimeError(
                f"Tool '{tool.name}' requires HITL, but no interaction handler is configured."
            )
        actions = (
            ("approve", "deny", "modify")
            if tool.hitl.allow_argument_modification
            else ("approve", "deny")
        )
        interaction = self._pending_interaction
        if interaction is None:
            interaction = InteractionRequest(
                id=str(uuid4()),
                interaction_type="hitl",
                content=tool.hitl.title or f"Approval required for {tool.name}",
                allowed_actions=actions,
                turn_id=self._current_turn_id,
                payload={
                    "tool_name": tool.name,
                    "tool_description": tool.description,
                    "tool_call_id": tool_call_id,
                    "arguments": dict(original_arguments),
                    "allow_argument_modification": (
                        tool.hitl.allow_argument_modification
                    ),
                    "allow_denial_override": tool.hitl.allow_denial_override,
                },
            )
            self._pending_interaction = interaction
            self._interaction_response = None
            self._save_checkpoint(
                reason="before-interaction",
                pending_tool_call=dict(tool_call),
            )
        elif interaction.payload.get("tool_call_id") != tool_call_id:
            raise RuntimeError(
                "The restored interaction does not match the pending tool call."
            )

        response = self._request_application_interaction(
            interaction=interaction,
            pending_tool_call=tool_call,
        )

        resolution = tool.hitl.resolver.resolve(
            ToolHITLContext(
                request=interaction,
                response=response,
                original_arguments=dict(original_arguments),
                policy=tool.hitl,
            )
        )
        if not isinstance(resolution, ToolHITLResolution):
            raise TypeError("A HITL resolver must return ToolHITLResolution.")
        self._pending_interaction = None
        self._interaction_response = None
        if not resolution.execute:
            return tool_call, ToolOutput(
                result=resolution.denial_message,
                error_kind="tool_execution",
            )
        approved_arguments = dict(resolution.arguments or original_arguments)
        approved_call = dict(tool_call)
        approved_function = dict(tool_call.get("function", {}))
        approved_function["arguments"] = json.dumps(
            approved_arguments,
            ensure_ascii=False,
        )
        approved_call["function"] = approved_function
        return approved_call, None

    def _request_application_interaction(
        self,
        *,
        interaction: InteractionRequest,
        pending_tool_call: Mapping[str, Any],
    ) -> InteractionResponse:
        """Persist, publish, and resume one generic application interaction."""
        if self.interaction_handler is None:
            raise RuntimeError("No application interaction handler is configured.")
        if self._pending_interaction is None:
            self._pending_interaction = interaction
            self._interaction_response = None
            self._save_checkpoint(
                reason="before-interaction",
                pending_tool_call=dict(pending_tool_call),
            )
        response = self._interaction_response
        if response is None:
            try:
                response = self.interaction_handler.request(interaction)
            except InteractionCancelledError as exc:
                self._pending_interaction = None
                self._interaction_response = None
                self._raise_if_stop_requested()
                raise RuntimeError(str(exc)) from exc
            self._interaction_response = response
            self._save_checkpoint(
                reason="after-interaction-response",
                pending_tool_call=dict(pending_tool_call),
            )
        return response

    def _record_regular_tool_result(
        self,
        *,
        tool_name: str,
        tool_call_id: str,
        tool_result: ToolOutput,
        chat_agent: ChatAgent,
        context: _LevelContext,
        call_arguments: Mapping[str, Any] | None = None,
    ) -> None:
        """Record one regular tool result after execution or HITL denial."""
        previous_step_id = chat_agent.last_step_id
        if tool_result.error_kind is not None:
            logger.warning(
                "Invalid tool call returned local feedback",
                extra={
                    "tool_name": tool_name,
                    "tool_call_id": tool_call_id,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                },
            )
            error_message = tool_result.result or str(tool_result)
            if tool_result.error_kind == "invalid_tool_call":
                error_message = self._invalid_tool_call_feedback(
                    context=context,
                    tool_name=tool_name,
                    details=error_message,
                    assistant_text=self._latest_assistant_text(chat_agent=chat_agent),
                )
            self._record_tool_error(
                chat_agent=chat_agent,
                context=context,
                tool_name=tool_name,
                tool_call_id=tool_call_id,
                message=error_message,
                error_kind=tool_result.error_kind,
            )
            return None
        visible_tool_call_id = self._tool_output_memory.visible_id_for(tool_call_id)
        tool_message = chat_agent.add_tool_result(
            content=tool_result,
            tool_call_id=tool_call_id,
            name=tool_name,
            visible_tool_call_id=visible_tool_call_id,
            metadata=tool_result.metadata,
            call_arguments=call_arguments,
            metadata_preview_char_limit=self._resolve_metadata_preview_char_limit(
                context=context
            ),
            depth=context.depth,
            level_path=context.level_path,
            include_envelope=not self._is_tool_output_excluded(
                context=context,
                tool_name=tool_name,
            ),
        )
        self._remember_callable_output(
            context=context,
            tool_call_id=tool_call_id,
            capability_name=tool_name,
            content=tool_message.content,
            visible_tool_call_id=visible_tool_call_id,
        )
        logger.info(
            "Recorded tool result",
            extra={
                "tool_name": tool_name,
                "tool_call_id": tool_call_id,
                "visible_tool_call_id": visible_tool_call_id,
                "current_skill": context.current_skill,
                "depth": context.depth,
            },
        )
        output_message_ids = chat_agent.get_message_ids()
        previous_step_ids = [
            step_id
            for step_id in (
                previous_step_id,
                self._pending_hds_child_merge_step_id,
            )
            if step_id
        ]
        tool_step = chat_agent.history_graph.add_step(
            depth=context.depth,
            current_skill=context.current_skill,
            input_message_ids=output_message_ids[:-1],
            output_message_ids=output_message_ids[-1:],
            previous_step_ids=previous_step_ids,
            response_text=tool_result.result,
            tool_names=[tool_name],
            event_type="tool_result",
            metadata={
                "tool_call_id": tool_call_id,
                "tool_name": tool_name,
                "kind": "tool",
            },
        )
        chat_agent.last_step_id = tool_step.id
        self._pending_hds_child_merge_step_id = None
        self._emit_level_event(
            chat_agent=chat_agent,
            context=context,
            event_data=LevelEventData(
                event_type="tool_result",
                content=tool_message.content,
                tool_name=tool_name,
                tool_call_id=tool_call_id,
                payload={
                    "kind": (
                        "hds-child-delegation"
                        if tool_name == HDS_CHILD_TOOL_NAME
                        else "tool"
                    )
                },
            ),
        )
        return None

    @staticmethod
    def _record_capability_result_step(
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
        message_id: str,
        response_text: str,
        tool_name: str,
        tool_call_id: str,
        kind: str,
    ) -> None:
        """Record one structural capability result and advance the level cursor."""
        message_ids = chat_agent.get_message_ids()
        previous_step_id = chat_agent.last_step_id
        step = chat_agent.history_graph.add_step(
            depth=context.depth,
            current_skill=context.current_skill,
            input_message_ids=[
                visible_id for visible_id in message_ids if visible_id != message_id
            ],
            output_message_ids=[message_id],
            previous_step_ids=[previous_step_id] if previous_step_id else [],
            response_text=response_text,
            tool_names=[tool_name],
            event_type="tool_result",
            metadata={
                "tool_call_id": tool_call_id,
                "tool_name": tool_name,
                "kind": kind,
            },
        )
        chat_agent.last_step_id = step.id

    def _reject_invalid_structural_capability_call(
        self,
        *,
        tool_call: Mapping[str, Any],
        tool_name: str,
        chat_agent: ChatAgent,
        context: _LevelContext,
    ) -> bool:
        """Reject invalid arguments for argument-free skill capabilities locally."""
        arguments = tool_call.get("function", {}).get("arguments")
        try:
            parsed_arguments = Tool.parse_arguments(arguments)
        except (TypeError, ValueError) as error:
            details = str(error)
        else:
            if not parsed_arguments:
                return False
            details = get_runtime_text(
                "agent.errors.structural_capability_arguments",
                tool_name=tool_name,
            )
        feedback_message = self._invalid_tool_call_feedback(
            context=context,
            tool_name=tool_name,
            details=details,
            assistant_text=self._latest_assistant_text(chat_agent=chat_agent),
        )
        tool_call_id = self._extract_tool_call_id(tool_call)
        if tool_call_id is None:
            self._append_user_feedback(
                chat_agent=chat_agent,
                context=context,
                message=feedback_message,
                event_kind="invalid-capability-call",
            )
            return True
        self._record_tool_error(
            chat_agent=chat_agent,
            context=context,
            tool_name=tool_name,
            tool_call_id=tool_call_id,
            message=feedback_message,
            error_kind="invalid_capability_call",
        )
        return True

    def _record_tool_error(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
        tool_name: str,
        tool_call_id: str,
        message: str,
        error_kind: str,
    ) -> None:
        """Record a correlated non-reusable tool error and its runtime step."""
        previous_step_id = chat_agent.last_step_id
        tool_message = chat_agent.add_tool_result(
            content=message,
            tool_call_id=tool_call_id,
            name=tool_name,
            kind="error",
            depth=context.depth,
            level_path=context.level_path,
            include_envelope=False,
        )
        output_message_ids = chat_agent.get_message_ids()
        tool_step = chat_agent.history_graph.add_step(
            depth=context.depth,
            current_skill=context.current_skill,
            input_message_ids=output_message_ids[:-1],
            output_message_ids=output_message_ids[-1:],
            previous_step_ids=[previous_step_id] if previous_step_id else [],
            response_text=message,
            tool_names=[tool_name],
            event_type="tool_result",
            metadata={
                "tool_call_id": tool_call_id,
                "tool_name": tool_name,
                "kind": "error",
                "error_kind": error_kind,
            },
        )
        chat_agent.last_step_id = tool_step.id
        self._tool_call_feedback_inserted = True
        self._emit_level_event(
            chat_agent=chat_agent,
            context=context,
            event_data=LevelEventData(
                event_type="tool_result",
                content=tool_message.content,
                tool_name=tool_name,
                tool_call_id=tool_call_id,
                payload={"kind": "tool-error", "error_kind": error_kind},
            ),
        )

    @staticmethod
    def _latest_assistant_text(*, chat_agent: ChatAgent) -> str:
        """Return the latest assistant content visible in the current level."""
        if not chat_agent.chat_history:
            return ""
        latest_message = chat_agent.chat_history[-1]
        if getattr(latest_message, "role", None) != "assistant":
            return ""
        return str(getattr(latest_message, "content", "") or "")

    def _run_tool(
        self,
        tool: Tool,
        tool_call: Mapping[str, Any],
        *,
        chat_agent: ChatAgent,
        context: _LevelContext | None = None,
        local_tools: AgentCapabilities | None = None,
        current_skill: str | None = None,
    ) -> ToolOutput:
        """Execute a concrete tool call with injected runtime arguments."""
        local_tools, current_skill = self._resolve_tool_runtime_scope(
            context=context,
            local_tools=local_tools,
            current_skill=current_skill,
        )
        tool_result = tool.execute(
            arguments=tool_call.get("function", {}).get("arguments"),
            injected_arguments=self._build_tool_runtime_arguments(
                tool_name=tool.name,
                chat_agent=chat_agent,
                local_tools=local_tools,
                current_skill=current_skill,
                context=context,
                runtime_tool_call_id=self._extract_tool_call_id(tool_call),
                runtime_tool_call=tool_call,
            ),
        )
        logger.debug(
            "Executed tool",
            extra={
                "tool_name": tool.name,
                "current_skill": current_skill,
                "result_preview": tool_result[:200],
            },
        )
        return tool_result

    @staticmethod
    def _resolve_metadata_preview_char_limit(*, context: _LevelContext) -> int:
        """Return the configured character edge length for envelope metadata."""
        configured = getattr(
            context.config.runtime.tool_output,
            "metadata_preview_char_limit",
            20,
        )
        try:
            value = int(configured)
        except (TypeError, ValueError):
            return 20
        return value if value > 0 else 20

    def _run_exit_tool(
        self,
        exit_skill: ExitSkill,
        tool_call: Mapping[str, Any],
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
    ) -> str:
        """Execute an exit skill's owned closing tool with injected runtime arguments."""
        tool_result = exit_skill.execute(
            arguments=tool_call.get("function", {}).get("arguments"),
            injected_arguments=self._build_tool_runtime_arguments(
                tool_name=exit_skill.get_exit_tool_name(),
                chat_agent=chat_agent,
                local_tools=context.local_tools,
                current_skill=context.current_skill,
                context=context,
                runtime_tool_call_id=self._extract_tool_call_id(tool_call),
            ),
        )
        logger.debug(
            "Executed exit tool",
            extra={
                "exit_skill": exit_skill.name,
                "exit_tool": exit_skill.get_exit_tool_name(),
                "current_skill": context.current_skill,
                "result_preview": tool_result[:200],
            },
        )
        return tool_result.result or ""

    @staticmethod
    def _resolve_tool_runtime_scope(
        *,
        context: _LevelContext | None,
        local_tools: AgentCapabilities | None,
        current_skill: str | None,
    ) -> tuple[AgentCapabilities | None, str | None]:
        """Normalize runtime scope from either an explicit context or loose fields."""
        if context is not None:
            return context.local_tools, context.current_skill
        return local_tools, current_skill

    def _build_tool_runtime_arguments(
        self,
        *,
        tool_name: str | None,
        chat_agent: ChatAgent,
        local_tools: AgentCapabilities | None,
        current_skill: str | None,
        context: _LevelContext | None = None,
        runtime_tool_call_id: str | None = None,
        runtime_tool_call: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Build the injected runtime arguments exposed to tool handlers."""
        tool_output_memory = getattr(self, "_tool_output_memory", None)
        hds_scope = self._build_hds_scope_arguments(context=context)
        injected_arguments = {
            "chat_history": chat_agent.get_messages(),
            "model_name": context.client.model
            if context is not None
            else self.client.model,
            "client": context.client if context is not None else self.client,
            "config": context.config
            if context is not None
            else getattr(self, "_config", None),
            "available_tools": local_tools.get_tool_names() if local_tools else [],
            "current_skill": current_skill,
            **hds_scope,
            "workroot": context.workroot if context is not None else self.workroot,
            "hds_context": context,
            "runtime_chat_history": self._build_runtime_chat_history(
                chat_agent=chat_agent
            ),
            "runtime_tool_call_id": runtime_tool_call_id,
        }
        if runtime_tool_call is not None:
            injected_arguments["user_question_runtime"] = UserQuestionRuntime(
                agent=self,
                tool_call=runtime_tool_call,
            )
        if context is not None and tool_name in {"create-pipeline", "run-pipeline"}:
            injected_arguments["dynamic_pipeline_runtime"] = (
                self._dynamic_pipeline_controller(
                    context=context,
                    chat_agent=chat_agent,
                    tool_call_id=runtime_tool_call_id or "dynamic-pipeline",
                )
            )
        if tool_output_memory is None:
            return injected_arguments

        hds_node_path = (
            tuple(context.hds_node_path or ()) if context is not None else None
        )
        active_tool = (
            local_tools.get_tool_by_name(tool_name)
            if local_tools and tool_name
            else None
        )
        if isinstance(active_tool, Tool) and active_tool.reusable_input_fields:
            injected_arguments["tool_output_awareness"] = (
                tool_output_memory.build_awareness_payload(hds_node_path=hds_node_path)
            )
            injected_arguments["tool_output_description_token_limit"] = (
                self._resolve_tool_output_description_token_limit(
                    context.config if context is not None else None
                )
            )
            injected_arguments["tool_output_ignored_tools"] = (
                list(context.excluded_tool_names) if context is not None else []
            )
        if tool_name in {"list-tool-outputs", "read-tool-output"}:
            injected_arguments["tool_output_awareness"] = (
                tool_output_memory.build_awareness_payload(hds_node_path=hds_node_path)
            )
            if tool_name == "list-tool-outputs":
                injected_arguments["tool_output_awareness_default_page_size"] = (
                    self._resolve_awareness_default_page_size(
                        context.config if context is not None else None
                    )
                )
                injected_arguments["tool_output_awareness_max_page_size"] = (
                    self._resolve_awareness_max_page_size(
                        context.config if context is not None else None
                    )
                )
            injected_arguments["tool_output_description_token_limit"] = (
                self._resolve_tool_output_description_token_limit(
                    context.config if context is not None else None
                )
            )
            if tool_name == "list-tool-outputs":
                injected_arguments["tool_output_content_token_limit"] = (
                    self._resolve_tool_output_content_token_limit(
                        context.config if context is not None else None
                    )
                )
            injected_arguments["tool_output_ignored_tools"] = (
                list(context.excluded_tool_names) if context is not None else []
            )

        return injected_arguments

    @staticmethod
    def _build_runtime_chat_history(*, chat_agent: ChatAgent) -> list[dict[str, Any]]:
        """Return current cursor messages with semantic runtime metadata included."""
        if not hasattr(chat_agent, "get_message_ids") or not hasattr(
            chat_agent, "history_graph"
        ):
            return list(chat_agent.get_messages())
        return [
            chat_agent.history_graph.get_message(message_id).to_dict()
            for message_id in chat_agent.get_message_ids()
        ]

    def _build_hds_scope_arguments(
        self, *, context: _LevelContext | None
    ) -> dict[str, Any]:
        """Return HDS structure metadata for runtime-aware tools."""
        node_path = context.hds_node_path if context is not None else None
        if not node_path:
            return {
                "current_hds": None,
                "parent_hds": None,
                "child_hds_nodes": [],
                "hds_node_path": [],
            }

        return {
            "current_hds": node_path[-1],
            "parent_hds": node_path[-2] if len(node_path) > 1 else None,
            "child_hds_nodes": self.hds_config.get_child_names(node_path),
            "hds_node_path": list(node_path),
        }

    @staticmethod
    def _extract_tool_name(tool_call: Mapping[str, Any]) -> str | None:
        """Extract the public tool name from a provider-specific tool call payload."""
        function_payload = tool_call.get("function")
        if not isinstance(function_payload, Mapping):
            return None

        tool_name = function_payload.get("name")
        return tool_name if isinstance(tool_name, str) else None

    @staticmethod
    def _extract_tool_call_id(tool_call: Mapping[str, Any]) -> str | None:
        """Extract a non-empty stable tool call identifier from a provider payload."""
        tool_call_id = tool_call.get("id")
        if isinstance(tool_call_id, str) and tool_call_id.strip():
            return tool_call_id

        call_id = tool_call.get("call_id")
        if isinstance(call_id, str) and call_id.strip():
            return call_id

        return None
