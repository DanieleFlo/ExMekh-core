from __future__ import annotations

from pathlib import Path


class AgentConfigMixin:
    """Resolves user-configurable runtime values used by DeepAgent."""

    def _resolve_tool_output_memory_dir(self) -> Path | None:
        """Resolve the configured temp directory used for inherited tool outputs."""
        if self._config is None:
            return None

        configured_path = self._config.runtime.tool_output.memory_dir
        if isinstance(configured_path, Path):
            candidate = configured_path
        elif isinstance(configured_path, str) and configured_path.strip():
            candidate = Path(configured_path)
        else:
            return None
        if candidate.is_absolute():
            return candidate
        return self.workroot / candidate

    def _resolve_awareness_max_page_size(self, config: object | None = None) -> int:
        """Resolve the configured maximum page size for output awareness."""
        active_config = config or self._config
        if active_config is None:
            return 20

        configured_value = active_config.runtime.tool_output.awareness_max_page_size
        if not isinstance(configured_value, int):
            return 20
        return max(1, min(configured_value, 20))

    def _resolve_awareness_default_page_size(self, config: object | None = None) -> int:
        """Resolve the configured default page size for output awareness."""
        active_config = config or self._config
        if active_config is None:
            return 20

        configured_value = active_config.runtime.tool_output.awareness_default_page_size
        if not isinstance(configured_value, int):
            return 20
        return max(
            1,
            min(configured_value, self._resolve_awareness_max_page_size(active_config)),
        )

    def _resolve_tool_output_description_token_limit(
        self, config: object | None = None
    ) -> int:
        """Resolve the configured token limit for stored output descriptions."""
        active_config = config or self._config
        if active_config is None:
            return 10

        configured_value = active_config.runtime.tool_output.description_token_limit
        if not isinstance(configured_value, int):
            return 10
        return max(1, configured_value)

    def _resolve_tool_output_content_token_limit(
        self, config: object | None = None
    ) -> int:
        """Resolve the configured token limit for stored output contents."""
        active_config = config or self._config
        if active_config is None:
            return 20

        configured_value = active_config.runtime.tool_output.content_token_limit
        if not isinstance(configured_value, int):
            return 20
        return max(1, configured_value)

    def _resolve_checkpoint_dir(self) -> Path | None:
        """Resolve the configured checkpoint storage directory."""
        if self._config is None:
            return None

        configured_path = self._config.runtime.checkpoint.directory
        if isinstance(configured_path, Path):
            candidate = configured_path
        elif isinstance(configured_path, str) and configured_path.strip():
            candidate = Path(configured_path)
        else:
            return None
        if candidate.is_absolute():
            return candidate
        return self.workroot / candidate

    def _resolve_checkpoint_enabled(self) -> bool:
        """Return whether automatic checkpoint persistence is enabled."""
        if self._config is None:
            return False
        return bool(self._config.runtime.checkpoint.enabled)

    def _resolve_checkpoint_message_threshold(self) -> int | None:
        """Resolve the message-count interval used for automatic checkpoints."""
        if self._config is None:
            return None
        configured_value = self._config.runtime.checkpoint.message_threshold
        if not isinstance(configured_value, int) or configured_value < 1:
            return None
        return configured_value

    def _resolve_checkpoint_before_execution_enabled(self) -> bool:
        """Return whether checkpoints are saved before capability execution."""
        if self._config is None:
            return False
        return bool(
            self._config.runtime.checkpoint.on_tool_or_skill_before_execution
        )

    def _resolve_checkpoint_on_skill_close_enabled(self) -> bool:
        """Return whether checkpoints are saved after child skill closure."""
        if self._config is None:
            return False
        return bool(self._config.runtime.checkpoint.on_skill_close)
