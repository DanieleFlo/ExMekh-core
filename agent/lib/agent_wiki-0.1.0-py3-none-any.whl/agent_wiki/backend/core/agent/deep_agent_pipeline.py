"""Sequential pipeline execution for specialized graph nodes."""

from __future__ import annotations

import json
import logging
from html import escape
from typing import Any

from agent_wiki.backend.interface.pipeline import ToolInputAdapterContext

from ..capabilities.pipeline_adapter import public_tool_fields
from ..config.hds_config import HDSStructureNode
from ..conversation.chat_agent import ChatAgent
from ..observability.events import LevelEventData
from .deep_agent_state import _LevelContext
from .hds_child_tool import HDS_CHILD_TOOL_NAME


logger = logging.getLogger(__name__)


class DeepAgentPipelineMixin:
    """Execute validated finite pipelines called through child-HDS delegation."""

    def _run_pipeline_message(
        self,
        *,
        pipeline_node: HDSStructureNode,
        message: str,
        parent_context: _LevelContext,
        preserve_state: bool = False,
        state_metadata: dict[str, object] | None = None,
        iteration_index: int | None = None,
        iteration_total: int | None = None,
        delegation_messages: list[str] | None = None,
        delegation_static_text: str | None = None,
    ) -> str:
        """Run or resume one configured pipeline and return its final text."""
        compiled = pipeline_node._compiled_pipeline
        if compiled is None or pipeline_node._resolved_node_config is None:
            raise ValueError(f"Pipeline node '{pipeline_node.name}' is not compiled.")

        node_config = pipeline_node._resolved_node_config
        state_key = pipeline_node._path
        stored = self._active_pipeline_states.get(state_key)
        metadata = dict(state_metadata or {})
        if stored is not None:
            metadata.update(
                {
                    key: value
                    for key, value in stored.items()
                    if key not in {"next_step", "text", "accumulating_outputs"}
                }
            )
        if stored is None:
            current_text = message
            next_step = 0
            accumulating_outputs = False
        else:
            current_text = str(stored["text"])
            next_step = int(stored["next_step"])
            accumulating_outputs = bool(stored.get("accumulating_outputs", False))

        pipeline_context = _LevelContext(
            current_skill=pipeline_node.name,
            execution_id=self._next_level_execution_id(pipeline_node.name),
            memory_hds_id=parent_context.memory_hds_id,
            agent_context_namespace=parent_context.agent_context_namespace,
            depth=parent_context.depth + 1,
            level_path=pipeline_node._path,
            local_tools=parent_context.local_tools,
            level_start_index=0,
            parallel_tool_calls=False,
            workroot=node_config.workroot,
            client=node_config.client,
            config=node_config.config,
            tool_choice=node_config.tool_choice,
            hds_node_path=pipeline_node._path,
            parent_span_id=self._active_tool_span_id,
            excluded_tool_names=tuple(pipeline_node._resolved_excluded_tool_names),
            agentic_tool_registry=self._agentic_tool_registry,
        )
        chat_agent = self._active_levels[-1].chat_agent
        self._emit_pipeline_event(
            context=pipeline_context,
            kind="pipeline-start",
            phase="start",
            content=message,
            step_index=next_step,
            iteration_index=iteration_index,
            iteration_total=iteration_total,
        )
        try:
            for index in range(next_step, len(compiled.steps)):
                step = compiled.steps[index]
                self._active_pipeline_states[state_key] = {
                    **metadata,
                    "next_step": index,
                    "text": current_text,
                    "accumulating_outputs": accumulating_outputs,
                }
                self._save_pipeline_checkpoint(
                    pipeline_node=pipeline_node,
                    message=message if delegation_messages is None else None,
                    messages=delegation_messages,
                    static_text=delegation_static_text,
                    reason="before-pipeline-step",
                )
                if step.kind == "tool":
                    if step.input_adapter is None or step.tool is None:
                        raise ValueError(
                            f"Pipeline tool step '{step.name}' is not fully compiled."
                        )
                    public_fields = public_tool_fields(step.tool.handler)
                    prepared = step.input_adapter.adapt(
                        ToolInputAdapterContext(
                            text=current_text,
                            tool=step.tool,
                            history=tuple(
                                dict(message) for message in chat_agent.get_messages()
                            ),
                            client=pipeline_context.client,
                            config=pipeline_context.config,
                        )
                    )
                    self._emit_pipeline_event(
                        context=pipeline_context,
                        kind="pipeline-adapter",
                        phase="instant",
                        content=current_text,
                        step_index=index,
                        step_name=step.name,
                        iteration_index=iteration_index,
                        iteration_total=iteration_total,
                    )
                    raw_output = self._run_pipeline_tool_step(
                        step=step,
                        prepared=prepared,
                        chat_agent=chat_agent,
                        context=pipeline_context,
                    )
                    current_text = (
                        self._append_non_consuming_tool_output(
                            current_text=current_text,
                            tool_name=step.name,
                            output=raw_output,
                            already_accumulating=accumulating_outputs,
                        )
                        if not public_fields
                        else raw_output
                    )
                    accumulating_outputs = not public_fields
                else:
                    current_text = self._run_hds_child_message(
                        child_name=step.name,
                        message=current_text,
                        parent_context=pipeline_context,
                        complete_on_assistant_text=False,
                        fail_fast=True,
                    )
                    accumulating_outputs = False
                self._active_pipeline_states[state_key] = {
                    **metadata,
                    "next_step": index + 1,
                    "text": current_text,
                    "accumulating_outputs": accumulating_outputs,
                }
                self._emit_pipeline_event(
                    context=pipeline_context,
                    kind="pipeline-step",
                    phase="end",
                    content=current_text,
                    step_index=index,
                    step_name=step.name,
                    iteration_index=iteration_index,
                    iteration_total=iteration_total,
                )
                self._save_pipeline_checkpoint(
                    pipeline_node=pipeline_node,
                    message=message if delegation_messages is None else None,
                    messages=delegation_messages,
                    static_text=delegation_static_text,
                    reason="after-pipeline-step",
                )
        except Exception as error:
            self._emit_pipeline_event(
                context=pipeline_context,
                kind="pipeline-failure",
                phase="end",
                content=str(error),
                step_index=int(
                    self._active_pipeline_states.get(state_key, {}).get(
                        "next_step", next_step
                    )
                ),
                iteration_index=iteration_index,
                iteration_total=iteration_total,
            )
            logger.exception(
                "Sequential pipeline failed",
                extra={"pipeline": pipeline_node.name, "path": list(state_key)},
            )
            raise RuntimeError(
                f"Pipeline '{pipeline_node.name}' failed at step "
                f"{self._active_pipeline_states.get(state_key, {}).get('next_step', next_step)}: "
                f"{error}"
            ) from error

        if not preserve_state:
            self._active_pipeline_states.pop(state_key, None)
        self._emit_pipeline_event(
            context=pipeline_context,
            kind="pipeline-complete",
            phase="end",
            content=current_text,
            step_index=len(compiled.steps),
            iteration_index=iteration_index,
            iteration_total=iteration_total,
        )
        return current_text

    def _run_for_pipeline_message(
        self,
        *,
        pipeline_node: HDSStructureNode,
        message: str | None,
        messages: list[str] | None,
        static_text: str | None,
        parent_context: _LevelContext,
    ) -> str:
        """Run or resume a configured sequential pipeline for every input text."""
        validation_error = self._validate_for_pipeline_input(
            message=message,
            messages=messages,
            static_text=static_text,
        )
        if validation_error is not None:
            return f"Error: {validation_error}"

        state_key = pipeline_node._path
        stored = self._active_pipeline_states.get(state_key)
        input_messages = list(messages or [])
        input_static_text = static_text
        outputs: list[str] = []
        iteration_index = 0
        if stored is not None and stored.get("pipeline_kind") == "for":
            input_messages = [str(item) for item in stored.get("messages", [])]
            raw_static_text = stored.get("static_text")
            input_static_text = (
                str(raw_static_text) if raw_static_text is not None else None
            )
            outputs = [str(item) for item in stored.get("outputs", [])]
            iteration_index = int(stored.get("iteration_index", 0))

        total = len(input_messages)
        while iteration_index < total:
            metadata: dict[str, object] = {
                "pipeline_kind": "for",
                "iteration_index": iteration_index,
                "iteration_total": total,
                "messages": input_messages,
                "static_text": input_static_text,
                "outputs": outputs,
            }
            active_state = self._active_pipeline_states.get(state_key)
            active_payload_text = (
                str(active_state.get("text", "")) if active_state is not None else ""
            )
            if (
                active_state is None
                or int(active_state.get("iteration_index", -1)) != iteration_index
                or not active_payload_text
            ):
                iteration_input = self._compose_for_pipeline_input(
                    item=input_messages[iteration_index],
                    static_text=input_static_text,
                    outputs=outputs if pipeline_node.pipeline_carry_outputs else [],
                    output_prefix=pipeline_node.pipeline_output_prefix,
                    output_suffix=pipeline_node.pipeline_output_suffix,
                )
                self._active_pipeline_states[state_key] = {
                    **metadata,
                    "next_step": 0,
                    "text": iteration_input,
                    "accumulating_outputs": False,
                }
            else:
                iteration_input = active_payload_text

            output = self._run_pipeline_message(
                pipeline_node=pipeline_node,
                message=iteration_input,
                parent_context=parent_context,
                preserve_state=True,
                state_metadata=metadata,
                iteration_index=iteration_index,
                iteration_total=total,
                delegation_messages=input_messages,
                delegation_static_text=input_static_text,
            )
            outputs.append(output)
            iteration_index += 1
            self._active_pipeline_states[state_key] = {
                "pipeline_kind": "for",
                "iteration_index": iteration_index,
                "iteration_total": total,
                "messages": input_messages,
                "static_text": input_static_text,
                "outputs": outputs,
                "next_step": 0,
                "text": "",
                "accumulating_outputs": False,
            }
            self._save_pipeline_checkpoint(
                pipeline_node=pipeline_node,
                message=None,
                messages=input_messages,
                static_text=input_static_text,
                reason="after-pipeline-iteration",
            )

        self._active_pipeline_states.pop(state_key, None)
        if pipeline_node.pipeline_carry_outputs:
            return outputs[-1]
        return pipeline_node.pipeline_success_message

    @staticmethod
    def _validate_for_pipeline_input(
        *,
        message: str | None,
        messages: list[str] | None,
        static_text: str | None,
    ) -> str | None:
        """Return a model-facing validation error for invalid for-loop input."""
        if message is not None:
            return "for-pipeline children accept 'messages', not 'message'."
        if not isinstance(messages, list) or not messages:
            return "for-pipeline children require a non-empty 'messages' list."
        if any(not isinstance(item, str) or not item.strip() for item in messages):
            return "for-pipeline 'messages' must contain only non-empty text."
        if static_text is not None and not isinstance(static_text, str):
            return "for-pipeline 'static_text' must be text when provided."
        return None

    @staticmethod
    def _compose_for_pipeline_input(
        *,
        item: str,
        static_text: str | None,
        outputs: list[str],
        output_prefix: str,
        output_suffix: str,
    ) -> str:
        """Compose one loop iteration input from fixed and accumulated text."""
        parts = [item]
        if static_text is not None:
            parts.append(static_text)
        parts.extend(f"{output_prefix}{output}{output_suffix}" for output in outputs)
        return "\n".join(parts)

    def _run_pipeline_tool_step(
        self,
        *,
        step: Any,
        prepared: dict[str, Any],
        chat_agent: ChatAgent,
        context: _LevelContext,
    ) -> str:
        """Execute one pipeline tool through the normal tool runtime contract."""
        if step.tool is None:
            raise ValueError(f"Pipeline tool step '{step.name}' is not loaded.")
        arguments = dict(prepared)
        result = self._run_tool(
            tool=step.tool,
            tool_call={
                "id": f"pipeline-{step.name}",
                "function": {
                    "name": step.name,
                    "arguments": json.dumps(arguments),
                },
            },
            chat_agent=chat_agent,
            context=context,
        )
        if result.error_kind is not None:
            raise ValueError(result.result or f"Pipeline tool '{step.name}' failed.")
        return result.result or ""

    @staticmethod
    def _append_non_consuming_tool_output(
        *,
        current_text: str,
        tool_name: str,
        output: str,
        already_accumulating: bool,
    ) -> str:
        """Append one zero-argument tool output to a flat XML text accumulator."""
        if already_accumulating:
            prefix = current_text
        else:
            prefix = f"<input>{escape(current_text)}</input>"
        return (
            f'{prefix}\n<output source="{escape(tool_name, quote=True)}">'
            f"{escape(output)}</output>"
        )

    def _save_pipeline_checkpoint(
        self,
        *,
        pipeline_node: HDSStructureNode,
        message: str | None,
        messages: list[str] | None = None,
        static_text: str | None = None,
        reason: str,
    ) -> None:
        """Persist pipeline progress with the parent delegation call pending."""
        tool_call_id = self._active_hds_child_tool_call_id or "pipeline-delegation"
        self._save_checkpoint(
            reason=reason,
            pending_tool_call={
                "id": tool_call_id,
                "function": {
                    "name": HDS_CHILD_TOOL_NAME,
                    "arguments": json.dumps(
                        {
                            "child_name": pipeline_node.name,
                            **({"message": message} if message is not None else {}),
                            **({"messages": messages} if messages is not None else {}),
                            **(
                                {"static_text": static_text}
                                if static_text is not None
                                else {}
                            ),
                        }
                    ),
                },
            },
        )

    def _emit_pipeline_event(
        self,
        *,
        context: _LevelContext,
        kind: str,
        phase: str,
        content: str,
        step_index: int,
        step_name: str | None = None,
        iteration_index: int | None = None,
        iteration_total: int | None = None,
    ) -> None:
        """Publish one pipeline lifecycle event through the existing event sink."""
        self._emit_event(
            context=context,
            event_data=LevelEventData(
                event_type="pipeline",
                operation="pipeline",
                phase=phase,
                content=content,
                payload={
                    "kind": kind,
                    "step_index": step_index,
                    "step_name": step_name,
                    "iteration_index": iteration_index,
                    "iteration_total": iteration_total,
                },
            ),
        )
