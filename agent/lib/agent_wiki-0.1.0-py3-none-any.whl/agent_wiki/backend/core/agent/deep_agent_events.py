from __future__ import annotations

from ..conversation.chat_agent import ChatAgent
from ..observability.events import LevelEventData
from ..observability.runtime_events import (
    RuntimeEvent,
    RuntimeEventPhase,
    RuntimeOperation,
)
from .deep_agent_state import _LevelContext


class DeepAgentEventMixin:
    """Emit compact runtime events without exporting conversation memory."""

    def _emit_level_event(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
        event_data: LevelEventData,
    ) -> RuntimeEvent | None:
        """Build and publish an event using the current backend level state."""
        if context.suppress_events:
            return None
        message_ids = chat_agent.get_message_ids()
        previous_ids = self._event_message_ids_by_level.get(context.execution_id, set())
        added_message_ids = tuple(
            message_id for message_id in message_ids if message_id not in previous_ids
        )
        self._event_message_ids_by_level[context.execution_id] = set(message_ids)
        previous_step_ids = (
            tuple(
                chat_agent.history_graph.get_step(
                    chat_agent.last_step_id
                ).previous_step_ids
            )
            if chat_agent.last_step_id
            and chat_agent.last_step_id in chat_agent.history_graph.steps
            else ()
        )
        return self._emit_event(
            context=context,
            event_data=event_data,
            step_id=chat_agent.last_step_id,
            previous_step_ids=previous_step_ids,
            added_message_ids=added_message_ids,
        )

    def _emit_event(
        self,
        *,
        context: _LevelContext,
        event_data: LevelEventData,
        step_id: str | None = None,
        previous_step_ids: tuple[str, ...] = (),
        added_message_ids: tuple[str, ...] = (),
    ) -> RuntimeEvent | None:
        """Publish one correlated event when an external sink is configured."""
        if self.event_sink is None:
            return None

        self._event_sequence += 1
        operation, phase = self._resolve_event_semantics(event_data=event_data)
        span_id = event_data.span_id or self._resolve_span_id(
            event_data=event_data,
            operation=operation,
        )
        parent_span_id = (
            event_data.parent_span_id
            if event_data.parent_span_id is not None
            else self._resolve_parent_span_id(
                context=context,
                event_data=event_data,
                operation=operation,
            )
        )
        event = RuntimeEvent(
            sequence=self._event_sequence,
            turn_id=self._current_turn_id,
            event_type=event_data.event_type,
            phase=event_data.phase or phase,
            operation=event_data.operation or operation,
            depth=context.depth,
            level_path=context.level_path,
            level_id=context.execution_id,
            span_id=span_id,
            parent_span_id=parent_span_id,
            current_skill=context.current_skill,
            hds_name=(context.hds_node_path[-1] if context.hds_node_path else None),
            hds_node_path=tuple(context.hds_node_path or ()),
            capabilities=context.snapshot(),
            content=event_data.content,
            tool_name=event_data.tool_name,
            tool_call_id=event_data.tool_call_id,
            payload=event_data.payload or {},
            step_id=step_id,
            previous_step_ids=previous_step_ids,
            added_message_ids=added_message_ids,
        )
        self.event_sink.publish(event)
        return event

    def _resolve_span_id(
        self,
        *,
        event_data: LevelEventData,
        operation: RuntimeOperation,
    ) -> str:
        """Return a stable span id for paired operations and unique instant events."""
        if event_data.tool_call_id:
            return f"{self._current_turn_id}:{operation}:{event_data.tool_call_id}"
        return f"{self._current_turn_id}:{operation}:{self._event_sequence}"

    def _resolve_parent_span_id(
        self,
        *,
        context: _LevelContext,
        event_data: LevelEventData,
        operation: RuntimeOperation,
    ) -> str | None:
        """Resolve the structural parent span for one runtime event."""
        if operation in {"skill", "hds-child"} and event_data.tool_call_id:
            return f"{self._current_turn_id}:tool:{event_data.tool_call_id}"
        return context.parent_span_id

    @staticmethod
    def _resolve_event_semantics(
        *,
        event_data: LevelEventData,
    ) -> tuple[RuntimeOperation, RuntimeEventPhase]:
        """Map the domain event name to its operation and lifecycle phase."""
        if event_data.event_type == "tool_call":
            return "tool", "start"
        if event_data.event_type == "tool_result":
            return "tool", "end"
        if event_data.event_type == "skill_enter":
            operation: RuntimeOperation = (
                "hds-child"
                if (event_data.payload or {}).get("kind") == "hds-child"
                else "skill"
            )
            return operation, "start"
        if event_data.event_type == "skill_exit":
            operation = (
                "hds-child"
                if (event_data.payload or {}).get("kind") == "hds-child"
                else "skill"
            )
            return operation, "end"
        if event_data.event_type == "assistant_response":
            return "model", "instant"
        if event_data.event_type == "model_thinking_delta":
            return "model", "update"
        return "user", "instant"
