"""Runtime adapter for typed user-question application interactions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping
from uuid import uuid4

from agent_wiki.backend.interface.interaction import InteractionRequest
from agent_wiki.backend.interface.user_question import (
    ChoiceOrTextQuestion,
    ChoiceOrTextQuestionAnswer,
    ChoiceQuestion,
    ChoiceQuestionAnswer,
    TextQuestion,
    TextQuestionAnswer,
    UserQuestionRuntimeInterface,
)


@dataclass(slots=True)
class UserQuestionRuntime(UserQuestionRuntimeInterface):
    """Bind question tools to one active DeepAgent tool call."""

    agent: Any
    tool_call: Mapping[str, Any]

    def ask_text(self, question: TextQuestion) -> TextQuestionAnswer:
        """Ask and validate one free-text question."""
        response = self._request("user_question.text", question)
        text = response.payload.get("text")
        self._validate_text(text=text, config=question.text)
        return TextQuestionAnswer(question_id=question.question_id, text=text)

    def ask_choice(self, question: ChoiceQuestion) -> ChoiceQuestionAnswer:
        """Ask and validate one single-choice question."""
        response = self._request("user_question.choice", question)
        option_id = response.payload.get("option_id")
        self._validate_option(option_id=option_id, question=question)
        return ChoiceQuestionAnswer(
            question_id=question.question_id,
            option_id=option_id,
        )

    def ask_choice_or_text(
        self, question: ChoiceOrTextQuestion
    ) -> ChoiceOrTextQuestionAnswer:
        """Ask and validate a mutually exclusive choice-or-text question."""
        response = self._request("user_question.choice_or_text", question)
        response_type = response.payload.get("response_type")
        option_id = response.payload.get("option_id")
        text = response.payload.get("text")
        if response_type == "choice":
            if text is not None:
                raise ValueError("A choice response cannot also contain text.")
            self._validate_option(option_id=option_id, question=question)
        elif response_type == "text":
            if option_id is not None:
                raise ValueError("A text response cannot also contain option_id.")
            self._validate_text(text=text, config=question.text)
        else:
            raise ValueError("response_type must be either 'choice' or 'text'.")
        return ChoiceOrTextQuestionAnswer(
            question_id=question.question_id,
            response_type=response_type,
            option_id=option_id,
            text=text,
        )

    def _request(self, interaction_type: str, question: Any) -> Any:
        """Publish one typed question through the generic runtime interaction path."""
        tool_call_id = str(self.tool_call.get("id") or "")
        interaction = self.agent._pending_interaction
        if interaction is None:
            interaction = InteractionRequest(
                id=str(uuid4()),
                interaction_type=interaction_type,
                content=question.question,
                payload={
                    "tool_call_id": tool_call_id,
                    "question": question.model_dump(mode="json"),
                },
                allowed_actions=("submit",),
                turn_id=self.agent._current_turn_id,
            )
        elif (
            interaction.interaction_type != interaction_type
            or interaction.payload.get("tool_call_id") != tool_call_id
        ):
            raise RuntimeError(
                "The restored user question does not match the pending tool call."
            )
        response = self.agent._request_application_interaction(
            interaction=interaction,
            pending_tool_call=self.tool_call,
        )
        if response.action != "submit":
            raise ValueError("User-question interactions only accept submit responses.")
        self.agent._pending_interaction = None
        self.agent._interaction_response = None
        return response

    @staticmethod
    def _validate_option(*, option_id: object, question: ChoiceQuestion) -> None:
        """Require one option identifier declared by the active question."""
        valid_ids = {option.id for option in question.options}
        if not isinstance(option_id, str) or option_id not in valid_ids:
            raise ValueError("The response must select a declared option_id.")

    @staticmethod
    def _validate_text(*, text: object, config: Any) -> None:
        """Validate free text against the question's declared length contract."""
        if not isinstance(text, str):
            raise ValueError("The response must contain text.")
        length = len(text)
        if config.required and not text.strip():
            raise ValueError("The response text is required.")
        if length < config.min_length or length > config.max_length:
            raise ValueError(
                f"Response text length must be between {config.min_length} "
                f"and {config.max_length}."
            )
