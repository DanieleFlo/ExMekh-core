from __future__ import annotations

import hashlib
import json
import logging
import re
from dataclasses import dataclass
from typing import Mapping, Sequence

from pydantic import BaseModel, Field

from agent_wiki.backend.core.conversation.message import AssistantMessage, ChatMessage
from agent_wiki.backend.interface.loop_detection import (
    LoopDetectionContext,
    LoopDetectionResult,
)
from agent_wiki.configs.text_catalog import get_runtime_text


logger = logging.getLogger(__name__)

_SPACE_PATTERN = re.compile(r"\s+")
_VOLATILE_ID_PATTERN = re.compile(
    r"\b(?:call|toolu|fc)_[A-Za-z0-9_-]+\b|"
    r"\b[0-9a-f]{8}-[0-9a-f-]{27,36}\b",
    re.IGNORECASE,
)


class _ModelLoopAssessment(BaseModel):
    """Validate the model's advisory classification of a repeated failure."""

    is_unwanted_loop: bool
    reason: str = Field(min_length=1, max_length=500)


@dataclass(frozen=True, slots=True)
class _FailedAttempt:
    """Store one normalized capability failure observed in local history."""

    signature: str
    summary: str
    public_summary: str


@dataclass(frozen=True, slots=True)
class DefaultLoopDetector:
    """Detect consecutive equivalent failures and optionally ask the active model."""

    repetition_threshold: int = 3
    history_window: int = 24
    max_content_chars: int = 1200
    confirm_with_model: bool = True

    def __post_init__(self) -> None:
        """Validate limits that bound work and model-visible diagnostic data."""
        if self.repetition_threshold < 2:
            raise ValueError("Loop detection repetition_threshold must be at least 2.")
        if self.history_window < self.repetition_threshold * 2:
            raise ValueError(
                "Loop detection history_window is too small for its threshold."
            )
        if self.max_content_chars < 100:
            raise ValueError("Loop detection max_content_chars must be at least 100.")

    def detect(self, context: LoopDetectionContext) -> LoopDetectionResult | None:
        """Confirm a loop after the latest equivalent failure repeats consecutively."""
        attempts = self._failed_attempts(context.history[-self.history_window :])
        if not attempts:
            return None
        latest = attempts[-1]
        repetitions = 0
        for attempt in reversed(attempts):
            if attempt.signature != latest.signature:
                break
            repetitions += 1
        if repetitions < self.repetition_threshold:
            return None

        if self.confirm_with_model:
            assessment = self._model_assessment(
                context=context,
                attempt=latest,
                repetitions=repetitions,
            )
            if assessment is not None and not assessment.is_unwanted_loop:
                return None

        explanation = get_runtime_text(
            "agent.errors.loop_force_closed",
            repetitions=repetitions,
            reason=latest.public_summary,
        )
        return LoopDetectionResult(
            explanation=explanation,
            signature=latest.signature,
            repetitions=repetitions,
        )

    def _failed_attempts(self, history: Sequence[ChatMessage]) -> list[_FailedAttempt]:
        """Extract normalized error attempts without retaining provider call ids."""
        attempts: list[_FailedAttempt] = []
        previous_assistant: AssistantMessage | None = None
        for message in history:
            if isinstance(message, AssistantMessage):
                previous_assistant = message
                continue
            if message.kind != "error":
                if message.role in {"tool", "user"}:
                    attempts.clear()
                continue
            error_content = message.content
            tool_call_id = getattr(message, "tool_call_id", "")
            if tool_call_id:
                error_content = error_content.replace(tool_call_id, "<runtime-id>")
            payload = {
                "source_role": message.role,
                "source_name": message.name or "",
                "tool_calls": self._canonical_tool_calls(previous_assistant),
                "error": self._normalize_text(error_content),
            }
            serialized = json.dumps(payload, sort_keys=True, separators=(",", ":"))
            signature = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
            attempts.append(
                _FailedAttempt(
                    signature=signature,
                    summary=self._compact_summary(payload),
                    public_summary=self._public_summary(payload),
                )
            )
        return attempts

    def _canonical_tool_calls(
        self, message: AssistantMessage | None
    ) -> list[dict[str, object]]:
        """Return stable tool-call data while excluding volatile correlation ids."""
        if message is None:
            return []
        canonical: list[dict[str, object]] = []
        for call in message.tool_calls[:8]:
            function = call.get("function", {})
            if not isinstance(function, Mapping):
                function = {}
            raw_arguments = function.get("arguments")
            try:
                parsed_arguments = (
                    json.loads(raw_arguments)
                    if isinstance(raw_arguments, str)
                    else raw_arguments
                )
            except json.JSONDecodeError:
                parsed_arguments = self._normalize_text(str(raw_arguments or ""))
            canonical.append(
                {
                    "name": str(function.get("name") or call.get("name") or ""),
                    "arguments": self._canonical_argument_value(parsed_arguments),
                }
            )
        return canonical

    def _canonical_argument_value(self, value: object, *, depth: int = 0) -> object:
        """Bound nested model arguments before hashing or diagnostic exposure."""
        if depth >= 5:
            return "<max-depth>"
        if isinstance(value, Mapping):
            return {
                str(key)[:100]: self._canonical_argument_value(item, depth=depth + 1)
                for key, item in list(value.items())[:50]
            }
        if isinstance(value, Sequence) and not isinstance(
            value, (str, bytes, bytearray)
        ):
            return [
                self._canonical_argument_value(item, depth=depth + 1)
                for item in value[:50]
            ]
        if isinstance(value, str):
            return self._normalize_text(value)
        if value is None or isinstance(value, (bool, int, float)):
            return value
        return self._normalize_text(repr(value))

    def _normalize_text(self, value: str) -> str:
        """Normalize bounded failure text and erase volatile runtime identifiers."""
        compact = _SPACE_PATTERN.sub(" ", value).strip().casefold()
        compact = _VOLATILE_ID_PATTERN.sub("<runtime-id>", compact)
        return compact[: self.max_content_chars]

    def _compact_summary(self, payload: Mapping[str, object]) -> str:
        """Build a bounded human-readable summary for diagnostics and ascent."""
        calls = payload.get("tool_calls") or []
        names = [
            str(call.get("name") or "") for call in calls if isinstance(call, Mapping)
        ]
        prefix = f"capability {', '.join(filter(None, names))}: " if names else ""
        return f"{prefix}{payload.get('error', '')}"[: self.max_content_chars]

    @staticmethod
    def _public_summary(payload: Mapping[str, object]) -> str:
        """Describe the failure without promoting local error content upward."""
        calls = payload.get("tool_calls") or []
        if calls:
            return "the same capability attempt repeatedly returned the same error"
        return "the model repeatedly produced the same invalid response"

    def _model_assessment(
        self,
        *,
        context: LoopDetectionContext,
        attempt: _FailedAttempt,
        repetitions: int,
    ) -> _ModelLoopAssessment | None:
        """Ask the active model once for advisory confirmation of the candidate."""
        detector_prompt = get_runtime_text("agent.loop_detection.system_prompt")
        active_prompt = context.system_prompt[: self.max_content_chars]
        system_message = (
            f"{detector_prompt}\n\n"
            f"<active-level-system-prompt>{active_prompt}</active-level-system-prompt>"
        )
        diagnostic = {
            "level_path": list(context.level_path),
            "current_skill": context.current_skill,
            "repetitions": repetitions,
            "failed_attempt": attempt.summary,
            "latest_thinking": (context.latest_thinking or "")[
                : self.max_content_chars
            ],
            "available_tools": list(context.tool_names),
            "available_skills": list(context.skill_names),
        }
        try:
            return context.client.create_structured(
                messages=[
                    {"role": "system", "content": system_message},
                    {
                        "role": "user",
                        "content": json.dumps(
                            diagnostic, ensure_ascii=False, sort_keys=True
                        ),
                    },
                ],
                config=context.model_config,
                output_model=_ModelLoopAssessment,
                schema_name="loop_detection_assessment",
                strict=True,
            )
        except Exception:
            logger.exception(
                "Loop confirmation model request failed; using deterministic result"
            )
            return None
