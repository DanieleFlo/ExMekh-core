"""Invocation-scoped dynamic text pipeline creation and execution."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from typing import Any

from ..capabilities.deep_skill import DeepSkill
from ..conversation.chat_agent import ChatAgent
from .deep_agent_state import _LevelContext


@dataclass(frozen=True, slots=True)
class DynamicPipelineStep:
    """Reference one visible text-to-text skill or child HDS."""

    kind: str
    name: str


@dataclass(frozen=True, slots=True)
class DynamicPipelineDefinition:
    """Store one validated invocation-local dynamic pipeline definition."""

    owner_execution_id: str
    name: str
    kind: str
    steps: tuple[DynamicPipelineStep, ...]
    carry_outputs: bool = False
    success_message: str = "Loop executed successfully."
    output_prefix: str = "<output>"
    output_suffix: str = "</output>"

    def to_payload(self) -> dict[str, Any]:
        """Return a JSON-compatible checkpoint representation."""
        payload = asdict(self)
        payload["steps"] = [asdict(step) for step in self.steps]
        return payload

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "DynamicPipelineDefinition":
        """Restore a definition from checkpoint data."""
        return cls(
            owner_execution_id=str(payload["owner_execution_id"]),
            name=str(payload["name"]),
            kind=str(payload["kind"]),
            steps=tuple(
                DynamicPipelineStep(kind=str(step["kind"]), name=str(step["name"]))
                for step in payload.get("steps", [])
            ),
            carry_outputs=bool(payload.get("carry_outputs", False)),
            success_message=str(
                payload.get("success_message", "Loop executed successfully.")
            ),
            output_prefix=str(payload.get("output_prefix", "<output>")),
            output_suffix=str(payload.get("output_suffix", "</output>")),
        )


@dataclass(slots=True)
class DynamicPipelineController:
    """Bind the narrow dynamic-pipeline API to one active runtime level."""

    agent: Any
    context: _LevelContext
    chat_agent: ChatAgent
    tool_call_id: str

    def create_pipeline(self, **values: Any) -> str:
        """Create one pipeline owned by the bound skill invocation."""
        return self.agent._create_dynamic_pipeline(context=self.context, **values)

    def run_pipeline(self, **values: Any) -> str:
        """Run one pipeline owned by the bound skill invocation."""
        return self.agent._run_dynamic_pipeline(
            context=self.context,
            chat_agent=self.chat_agent,
            tool_call_id=self.tool_call_id,
            **values,
        )


class DeepAgentDynamicPipelineMixin:
    """Manage invocation-local dynamic text-to-text pipelines."""

    def _dynamic_pipeline_controller(
        self, *, context: _LevelContext, chat_agent: ChatAgent, tool_call_id: str
    ) -> DynamicPipelineController:
        """Return a narrow controller bound to the active skill level."""
        return DynamicPipelineController(self, context, chat_agent, tool_call_id)

    def _create_dynamic_pipeline(
        self,
        *,
        context: _LevelContext,
        name: str,
        kind: str,
        steps: list[dict[str, str]],
        carry_outputs: bool = False,
        success_message: str = "Loop executed successfully.",
        output_prefix: str = "<output>",
        output_suffix: str = "</output>",
    ) -> str:
        """Validate visible nodes and register one immutable definition."""
        normalized_name = name.strip()
        if not normalized_name:
            raise ValueError("Dynamic pipeline name must contain non-space text.")
        normalized_kind = kind.strip().lower()
        if normalized_kind not in {"sequential", "for"}:
            raise ValueError("Dynamic pipeline kind must be 'sequential' or 'for'.")
        if not steps:
            raise ValueError("Dynamic pipeline requires at least one step.")
        if normalized_kind == "for" and any(
            not isinstance(value, str) or not value.strip()
            for value in (success_message, output_prefix, output_suffix)
        ):
            raise ValueError("Dynamic for-pipeline text options must be non-empty.")

        registry = self._dynamic_pipeline_registry.setdefault(context.execution_id, {})
        normalized_key = normalized_name.casefold()
        existing_pipeline_names = {name.casefold() for name in registry}
        if normalized_key in existing_pipeline_names:
            raise ValueError(f"Dynamic pipeline '{normalized_name}' already exists.")
        graph_names = {
            node_name.casefold() for node_name in self.hds_config.get_node_names()
        }
        if normalized_key in graph_names:
            raise ValueError(
                f"Dynamic pipeline name '{normalized_name}' conflicts with a "
                "configured graph node."
            )
        visible_names = {
            capability_name.casefold()
            for capability_name in context.local_tools.get_tool_names()
        }
        if normalized_key in visible_names:
            raise ValueError(
                f"Dynamic pipeline name '{normalized_name}' conflicts with a visible "
                "tool or skill."
            )
        resolved_steps: list[DynamicPipelineStep] = []
        child_names = set(self.hds_config.get_child_names(context.hds_node_path or ()))
        visible_skill_names = set(context.local_tools.get_skill_names())
        for index, raw_step in enumerate(steps):
            if not isinstance(raw_step, dict):
                raise ValueError(f"Dynamic pipeline step {index} must be an object.")
            step_name = str(raw_step.get("name", "")).strip()
            if not step_name:
                raise ValueError(
                    f"Dynamic pipeline step {index} is missing a non-empty 'name'."
                )
            capability = context.local_tools.get_tool_by_name(step_name)
            is_skill = isinstance(capability, DeepSkill)
            is_hds = step_name in child_names
            if is_skill and is_hds:
                raise ValueError(
                    f"Dynamic pipeline step name '{step_name}' is ambiguous because "
                    "it identifies both a visible skill and a child HDS."
                )
            if is_skill:
                step_kind = "skill"
            elif is_hds:
                step_kind = "hds"
            else:
                if capability is not None:
                    raise ValueError(
                        f"Dynamic pipeline step '{step_name}' resolves to an immediate "
                        "tool; dynamic pipelines support only skills and child HDS nodes."
                    )
                available_skills = ", ".join(sorted(visible_skill_names)) or "none"
                available_hds = ", ".join(sorted(child_names)) or "none"
                raise ValueError(
                    f"Dynamic pipeline step '{step_name}' is not visible. Visible "
                    f"skills: {available_skills}. Visible child HDS nodes: {available_hds}."
                )
            resolved_steps.append(DynamicPipelineStep(step_kind, step_name))
        registry[normalized_name] = DynamicPipelineDefinition(
            owner_execution_id=context.execution_id,
            name=normalized_name,
            kind=normalized_kind,
            steps=tuple(resolved_steps),
            carry_outputs=carry_outputs,
            success_message=success_message,
            output_prefix=output_prefix,
            output_suffix=output_suffix,
        )
        return f"Dynamic pipeline '{normalized_name}' created with {len(resolved_steps)} steps."

    def _run_dynamic_pipeline(
        self,
        *,
        context: _LevelContext,
        chat_agent: ChatAgent,
        tool_call_id: str,
        name: str,
        message: str | None = None,
        messages: list[str] | None = None,
        static_text: str | None = None,
    ) -> str:
        """Run or resume one pipeline from its owning invocation registry."""
        definition = self._dynamic_pipeline_registry.get(context.execution_id, {}).get(
            name
        )
        if not isinstance(definition, DynamicPipelineDefinition):
            raise ValueError(
                f"Dynamic pipeline '{name}' does not exist in this skill invocation."
            )
        if definition.kind == "sequential":
            if (
                not isinstance(message, str)
                or not message.strip()
                or messages is not None
                or static_text is not None
            ):
                raise ValueError(
                    "Sequential dynamic pipelines require only non-empty 'message'."
                )
            return self._run_dynamic_pipeline_steps(
                definition=definition,
                input_text=message,
                context=context,
                chat_agent=chat_agent,
                tool_call_id=tool_call_id,
                pending_arguments={"name": name, "message": message},
            )
        error = self._validate_for_pipeline_input(
            message=message, messages=messages, static_text=static_text
        )
        if error is not None:
            raise ValueError(error)
        outputs: list[str] = []
        for index, item in enumerate(messages or []):
            iteration_input = self._compose_for_pipeline_input(
                item=item,
                static_text=static_text,
                outputs=outputs if definition.carry_outputs else [],
                output_prefix=definition.output_prefix,
                output_suffix=definition.output_suffix,
            )
            outputs.append(
                self._run_dynamic_pipeline_steps(
                    definition=definition,
                    input_text=iteration_input,
                    context=context,
                    chat_agent=chat_agent,
                    tool_call_id=f"{tool_call_id}:{index}",
                    pending_tool_call_id=tool_call_id,
                    pending_arguments={
                        "name": name,
                        "messages": messages,
                        **(
                            {"static_text": static_text}
                            if static_text is not None
                            else {}
                        ),
                    },
                    iteration_index=index,
                    iteration_total=len(messages or []),
                )
            )
        return outputs[-1] if definition.carry_outputs else definition.success_message

    def _run_dynamic_pipeline_steps(
        self,
        *,
        definition: DynamicPipelineDefinition,
        input_text: str,
        context: _LevelContext,
        chat_agent: ChatAgent,
        tool_call_id: str,
        pending_tool_call_id: str | None = None,
        pending_arguments: dict[str, Any] | None = None,
        iteration_index: int | None = None,
        iteration_total: int | None = None,
    ) -> str:
        """Execute one ordered dynamic text-to-text step sequence."""
        state_key = ("__dynamic__", context.execution_id, definition.name, tool_call_id)
        state = self._active_pipeline_states.get(state_key)
        payload = str(state.get("text", input_text)) if state else input_text
        next_step = int(state.get("next_step", 0)) if state else 0
        self._emit_pipeline_event(
            context=context,
            kind="dynamic-pipeline-start",
            phase="start",
            content=payload,
            step_index=next_step,
            iteration_index=iteration_index,
            iteration_total=iteration_total,
        )
        try:
            for index in range(next_step, len(definition.steps)):
                step = definition.steps[index]
                self._active_pipeline_states[state_key] = {
                    "next_step": index,
                    "text": payload,
                    "accumulating_outputs": False,
                    "pipeline_kind": f"dynamic-{definition.kind}",
                    "iteration_index": iteration_index or 0,
                    "iteration_total": iteration_total or 0,
                }
                pending_tool_call = {
                    "id": pending_tool_call_id or tool_call_id,
                    "function": {
                        "name": "run-pipeline",
                        "arguments": json.dumps(pending_arguments or {}),
                    },
                }
                self._emit_pipeline_event(
                    context=context,
                    kind="dynamic-pipeline-step",
                    phase="end",
                    content=payload,
                    step_index=index,
                    step_name=step.name,
                    iteration_index=iteration_index,
                    iteration_total=iteration_total,
                )
                self._save_checkpoint(
                    reason="before-dynamic-pipeline-step",
                    pending_tool_call=pending_tool_call,
                )
                if step.kind == "skill":
                    capability = context.local_tools.get_tool_by_name(step.name)
                    if not isinstance(capability, DeepSkill):
                        raise ValueError(
                            f"Dynamic pipeline skill '{step.name}' is no longer visible."
                        )
                    parent = ChatAgent(
                        client=context.client, history_graph=chat_agent.history_graph
                    )
                    parent.add_user_message(message=payload)
                    skill_outcome = self._run_deep_skill(
                        deep_skill=capability,
                        tool_call_id=f"{tool_call_id}:{index}:{step.name}",
                        chat_history=parent.chat_history,
                        parent_chat_agent=parent,
                        parent_context=context,
                    )
                    payload = getattr(skill_outcome, "response", skill_outcome)
                else:
                    payload = self._run_hds_child_message(
                        child_name=step.name,
                        message=payload,
                        parent_context=context,
                        complete_on_assistant_text=False,
                        fail_fast=True,
                    )
                self._active_pipeline_states[state_key] = {
                    "next_step": index + 1,
                    "text": payload,
                    "accumulating_outputs": False,
                    "pipeline_kind": f"dynamic-{definition.kind}",
                    "iteration_index": iteration_index or 0,
                    "iteration_total": iteration_total or 0,
                }
                self._save_checkpoint(
                    reason="after-dynamic-pipeline-step",
                    pending_tool_call=pending_tool_call,
                )
        except Exception as error:
            self._emit_pipeline_event(
                context=context,
                kind="dynamic-pipeline-failure",
                phase="end",
                content=str(error),
                step_index=int(
                    self._active_pipeline_states.get(state_key, {}).get(
                        "next_step", next_step
                    )
                ),
                iteration_index=iteration_index,
                iteration_total=iteration_total,
            )
            raise
        else:
            self._active_pipeline_states.pop(state_key, None)
        self._emit_pipeline_event(
            context=context,
            kind="dynamic-pipeline-complete",
            phase="end",
            content=payload,
            step_index=len(definition.steps),
            iteration_index=iteration_index,
            iteration_total=iteration_total,
        )
        return payload

    def _discard_dynamic_pipelines(self, *, owner_execution_id: str) -> None:
        """Discard definitions and execution state owned by a closing skill."""
        self._dynamic_pipeline_registry.pop(owner_execution_id, None)
        for key in list(self._active_pipeline_states):
            if (
                len(key) > 1
                and key[0] == "__dynamic__"
                and key[1] == owner_execution_id
            ):
                self._active_pipeline_states.pop(key, None)

    def _export_dynamic_pipeline_definitions(self) -> list[dict[str, Any]]:
        """Serialize every active invocation-local pipeline definition."""
        return [
            definition.to_payload()
            for registry in self._dynamic_pipeline_registry.values()
            for definition in registry.values()
            if isinstance(definition, DynamicPipelineDefinition)
        ]

    def _import_dynamic_pipeline_definitions(
        self, payloads: list[dict[str, Any]]
    ) -> None:
        """Restore pipeline definitions from checkpoint payloads."""
        self._dynamic_pipeline_registry = {}
        for payload in payloads:
            definition = DynamicPipelineDefinition.from_payload(payload)
            self._dynamic_pipeline_registry.setdefault(
                definition.owner_execution_id, {}
            )[definition.name] = definition
