from __future__ import annotations

import copy
import logging
from collections.abc import Iterable
from typing import Any
from uuid import uuid4

from tenacity import (
    Retrying,
    before_sleep_log,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from ..conversation.chat_agent import ChatAgent
from ..capabilities.tool import Tool
from .deep_agent_state import LevelOutcome, _ActiveLevel, _LevelContext
from ..observability.events import LevelEventData
from ..conversation.result import AgentResult
from ..conversation.types import ModelRequestUsage, ModelResponse, TokenUsageSummary
from agent_wiki.configs.text_catalog import get_runtime_text
from .hds_child_tool import HDS_CHILD_TOOL_NAME
from .runtime_error_log import write_runtime_error_log
from agent_wiki.backend.interface.loop_detection import (
    LoopDetectionContext,
    LoopDetectionResult,
)

logger = logging.getLogger(__name__)


class AgentRunCancelled(RuntimeError):
    """Signal that the active agent turn was cancelled by its owning session."""


def _diagnostic_messages(
    messages: list[dict[str, object]], *, limit: int = 12
) -> list[dict[str, object]]:
    """Return compact recent provider messages for runtime error diagnostics."""
    records: list[dict[str, object]] = []
    for message in messages[-limit:]:
        payload = dict(message)
        content = str(payload.get("content") or "")
        payload["content"] = content[:4000]
        if len(content) > 4000:
            payload["content_truncated"] = True
        records.append(payload)
    return records


class DeepAgentLoopMixin:
    """Runs root and child model loops for the multi-level runtime."""

    def reset_stop_request(self) -> None:
        """Prepare the runtime to execute a new turn after any previous stop."""
        self._stop_event.clear()

    def request_stop(self) -> None:
        """Request cooperative cancellation of the active runtime turn."""
        self._stop_event.set()
        pending_interaction = getattr(self, "_pending_interaction", None)
        interaction_handler = getattr(self, "interaction_handler", None)
        if pending_interaction is not None and interaction_handler is not None:
            interaction_handler.cancel(pending_interaction.id)

    def _raise_if_stop_requested(self) -> None:
        """Abort at a safe runtime boundary when cancellation was requested."""
        if self._stop_event.is_set():
            raise AgentRunCancelled("The agent turn was stopped by the user.")

    def run(self, *, user_message: str, turn_id: str | None = None) -> AgentResult:
        """Execute the root level starting from the configured bootstrap skill."""
        logger.info("Starting DeepAgent root run")
        self._current_turn_id = turn_id or str(uuid4())
        self._event_message_ids_by_level.clear()
        self._current_turn_thinking_history.clear()
        self._last_model_thinking_by_level.clear()
        self._current_turn_token_usage_requests.clear()
        self._model_request_sequence = 0
        self._active_model_request_id = None
        self._last_model_request_id_by_level.clear()
        self._last_checkpoint_message_count = 0
        if not self._main_hds:
            raise ValueError(get_runtime_text("agent.errors.main_hds_missing"))
        root_node = self.hds_config.get_main_node()
        system_prompt = self._render_hds_prompt(node=root_node)
        if not system_prompt:
            raise ValueError(get_runtime_text("agent.errors.system_prompt_required"))
        if not self._main_hds.exit_skill:
            raise ValueError(get_runtime_text("agent.errors.exit_skill_required"))

        if root_node._resolved_node_config is None:
            raise ValueError("Root node configuration was not resolved.")
        root_node_config = root_node._resolved_node_config
        history_was_reset = False
        if self._root_chat_agent is None:
            chat_hds = ChatAgent(
                client=root_node_config.client, system_prompt=system_prompt
            )
            # Automatic developer-message injection is intentionally suspended.
            # if developer_message := self._main_hds.developer_message:
            #     chat_hds.add_developer_message(message=developer_message)
            self._root_chat_agent = chat_hds
        else:
            chat_hds = self._root_chat_agent
            if not root_node_config.preserve_history:
                chat_hds.reset_history()
                history_was_reset = True
                self._pending_child_merge_step_ids.clear()
                self._pending_hds_child_merge_step_id = None
                logger.info(
                    "Reset root HDS history",
                    extra={"hds_node_path": list(root_node._path)},
                )
        chat_hds.add_user_message(message=user_message)

        exit_skill = self._main_hds.exit_skill
        if exit_skill is None:
            raise ValueError(get_runtime_text("agent.errors.exit_skill_required"))

        root_execution_id = self._next_level_execution_id(root_node.name)
        root_workroot = root_node._resolved_workroot or self.workroot
        local_tools = self._hds_capabilities(
            hds=self._main_hds,
            node_path=root_node._path,
        )
        root_context = _LevelContext(
            current_skill=root_node.name,
            execution_id=root_execution_id,
            memory_hds_id=root_execution_id,
            agent_context_namespace=self._agent_context_namespace,
            depth=0,
            level_path=root_node._path,
            local_tools=local_tools,
            level_start_index=len(chat_hds.chat_history),
            parallel_tool_calls=(
                self._main_hds.parallel_tool_calls
                if self._main_hds.parallel_tool_calls is not None
                else root_node_config.parallel_tool_calls
            ),
            workroot=root_workroot,
            client=root_node_config.client,
            config=root_node_config.config,
            tool_choice=root_node_config.tool_choice,
            hds_node_path=root_node._path,
            parent_span_id=None,
            excluded_tool_names=tuple(root_node._resolved_excluded_tool_names),
            loop_detector=root_node_config.loop_detector,
            agentic_tool_registry=self._agentic_tool_registry,
        )
        root_context.sync_capability_summary(chat_agent=chat_hds)

        self._emit_level_event(
            chat_agent=chat_hds,
            context=root_context,
            event_data=LevelEventData(
                event_type="user_message",
                content=user_message,
                payload={"history_reset": history_was_reset},
            ),
        )
        self._active_levels = [
            _ActiveLevel(
                chat_agent=chat_hds,
                context=root_context,
                frame_kind="root_hds",
            ),
        ]
        outcome = self._run_level(
            chat_agent=chat_hds,
            context=root_context,
        )
        return AgentResult(
            response=outcome.response,
            chat_history=outcome.chat_history,
            thinking_history=list(self._current_turn_thinking_history),
            token_usage=TokenUsageSummary.from_requests(
                self._current_turn_token_usage_requests
            ),
            token_usage_requests=list(self._current_turn_token_usage_requests),
        )

    def _run_level(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
    ) -> LevelOutcome:
        """Run a level until root text completion or the active exit skill closes it."""
        step_counter = 0
        if context.config is None:
            raise ValueError(get_runtime_text("agent.errors.config_not_loaded"))

        while True:
            self._raise_if_stop_requested()
            step_counter += 1
            if step_counter > context.config.runtime.loop.max_steps:
                logger.warning(
                    "DeepAgent step limit reached",
                    extra={
                        "current_skill": context.current_skill,
                        "depth": context.depth,
                        "max_steps": context.config.runtime.loop.max_steps,
                    },
                )
                return LevelOutcome(
                    response=get_runtime_text("agent.errors.step_limit_reached"),
                    chat_history=copy.deepcopy(chat_agent.chat_history),
                )
            loop_result = self._detect_unwanted_loop(
                chat_agent=chat_agent,
                context=context,
            )
            if loop_result is not None:
                chat_agent.add_assistant_message(text=loop_result.explanation)
                self._emit_level_event(
                    chat_agent=chat_agent,
                    context=context,
                    event_data=LevelEventData(
                        event_type="assistant_response",
                        content=loop_result.explanation,
                        payload={
                            "kind": "loop-force-close",
                            "signature": loop_result.signature,
                            "repetitions": loop_result.repetitions,
                        },
                    ),
                )
                logger.warning(
                    "Force-closing level after unwanted loop detection",
                    extra={
                        "current_skill": context.current_skill,
                        "depth": context.depth,
                        "repetitions": loop_result.repetitions,
                        "signature": loop_result.signature,
                    },
                )
                return LevelOutcome(
                    response=loop_result.explanation,
                    chat_history=copy.deepcopy(chat_agent.chat_history),
                )

            logger.debug(
                "Running DeepAgent step",
                extra={
                    "step": step_counter,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                },
            )
            model_response = self._run_step(chat_agent=chat_agent, context=context)
            self._raise_if_stop_requested()
            tool_calls = context.client.extract_tool_calls(model_response)
            assistant_text = context.client.extract_text(model_response)
            if not tool_calls and not assistant_text.strip():
                error_message = self._empty_assistant_response_error(context=context)
                logger.warning(
                    "Replacing empty assistant response with feedback",
                    extra={
                        "current_skill": context.current_skill,
                        "depth": context.depth,
                    },
                )
                self._replace_empty_assistant_with_user_feedback(
                    chat_agent=chat_agent,
                    message=error_message,
                )
                self._sync_latest_debug_local_history(chat_agent=chat_agent)
                self._emit_level_event(
                    chat_agent=chat_agent,
                    context=context,
                    event_data=LevelEventData(
                        event_type="user_message",
                        content=error_message,
                        payload={"kind": "empty-assistant-response"},
                    ),
                )
                continue
            if tool_calls:
                self._emit_level_event(
                    chat_agent=chat_agent,
                    context=context,
                    event_data=LevelEventData(
                        event_type="assistant_response",
                        content=assistant_text,
                        payload=self._payload_with_model_request_id(
                            context=context,
                            payload={"tool_calls": tool_calls},
                        ),
                    ),
                )
            handled_response = self._run_handler(
                response=model_response,
                chat_agent=chat_agent,
                context=context,
            )
            if handled_response is not None:
                previous_step_id = chat_agent.last_step_id
                chat_agent.add_assistant_message(text=handled_response)
                visible_message_ids = chat_agent.get_message_ids()
                completion_message_id = visible_message_ids[-1]
                completion_step = chat_agent.history_graph.add_step(
                    depth=context.depth,
                    current_skill=context.current_skill,
                    input_message_ids=[
                        message_id
                        for message_id in visible_message_ids
                        if message_id != completion_message_id
                    ],
                    output_message_ids=[completion_message_id],
                    previous_step_ids=(
                        [previous_step_id] if previous_step_id else []
                    ),
                    response_text=handled_response,
                    event_type="level_completion",
                    metadata={"kind": "exit-response"},
                )
                chat_agent.last_step_id = completion_step.id
                promoted_metadata = context.promoted_metadata
                context.promoted_metadata = None
                return LevelOutcome(
                    response=handled_response,
                    chat_history=copy.deepcopy(chat_agent.chat_history),
                    metadata=promoted_metadata,
                )

            if not tool_calls:
                if (
                    context.depth > 1
                    and not context.complete_on_assistant_text
                    and len(chat_agent.chat_history) >= 2
                ):
                    last_msg_before_resp = chat_agent.chat_history[-2]
                    is_tool_response = (
                        getattr(last_msg_before_resp, "role", None) == "tool"
                    )
                    if is_tool_response:
                        error_message = get_runtime_text(
                            "agent.errors.tool_call_required_after_tool_response"
                        )
                        logger.warning(
                            "Tool call required after tool response",
                            extra={
                                "current_skill": context.current_skill,
                                "depth": context.depth,
                            },
                        )
                        chat_agent.add_user_message(
                            message=error_message,
                            kind="error",
                        )
                        self._sync_latest_debug_local_history(chat_agent=chat_agent)
                        self._emit_level_event(
                            chat_agent=chat_agent,
                            context=context,
                            event_data=LevelEventData(
                                event_type="user_message",
                                content=error_message,
                                payload={"kind": "missing-tool-call"},
                            ),
                        )
                        continue

                self._replace_last_assistant_content(
                    chat_agent=chat_agent,
                    content=assistant_text,
                )
                self._emit_level_event(
                    chat_agent=chat_agent,
                    context=context,
                    event_data=LevelEventData(
                        event_type="assistant_response",
                        content=assistant_text,
                        payload=self._payload_with_model_request_id(
                            context=context,
                            payload={"tool_calls": []},
                        ),
                    ),
                )
                if context.complete_on_assistant_text:
                    return LevelOutcome(
                        response=assistant_text,
                        chat_history=copy.deepcopy(chat_agent.chat_history),
                    )
                if context.depth > 0:
                    continue
                return LevelOutcome(
                    response=assistant_text,
                    chat_history=copy.deepcopy(chat_agent.chat_history),
                )

    def _detect_unwanted_loop(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
    ) -> LoopDetectionResult | None:
        """Run the configured detector against only this invocation's local slice."""
        detector = context.loop_detector
        if detector is None:
            return None
        snapshot = context.snapshot()
        history = tuple(chat_agent.chat_history[context.level_start_index :])
        level_thinking = self._last_model_thinking_by_level.get(context.execution_id)
        latest_thinking = level_thinking.content if level_thinking is not None else None
        system_prompt = next(
            (
                message.content
                for message in chat_agent.chat_history
                if message.role == "system"
            ),
            "",
        )
        return detector.detect(
            LoopDetectionContext(
                history=history,
                latest_thinking=latest_thinking,
                tool_names=tuple(snapshot.tools),
                skill_names=tuple(snapshot.skills),
                level_path=tuple(context.level_path),
                current_skill=context.current_skill,
                system_prompt=system_prompt,
                client=context.client,
                model_config=context.config,
            )
        )

    def _run_step(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
    ) -> ModelResponse:
        """Send the current level state to the model and record the response."""
        if context.config is None:
            raise ValueError(get_runtime_text("agent.errors.config_not_loaded"))

        def _is_parsing_error(error: BaseException) -> bool:
            """Return whether a provider error should be retried as transient."""
            error_str = str(error)
            return ("XML syntax error" in error_str) or (
                "api_error" in error_str and "500" in error_str
            )

        input_message_ids: list[str] = []
        messages: list[dict[str, object]] = []
        tools: list[dict[str, Any]] | None = None

        def _send_model_request() -> ModelResponse:
            """Send one model request and preserve diagnostics on failure."""
            nonlocal input_message_ids, messages, tools
            self._raise_if_stop_requested()
            context.sync_capability_summary(chat_agent=chat_agent)
            input_message_ids = chat_agent.get_message_ids()
            messages = chat_agent.get_messages()
            tools = context.local_tools.get_tools_for_llm(client=context.client)
            model_request_id = self._next_model_request_id(context=context)
            self._active_model_request_id = model_request_id
            logger.debug(
                "Sending model request",
                extra={
                    "model_request_id": model_request_id,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                    "message_count": len(messages),
                    "tool_count": len(tools or []),
                    "tool_choice": context.tool_choice,
                    "parallel_tool_calls": context.parallel_tool_calls,
                },
            )
            try:
                model_response = context.call(
                    chat_agent=chat_agent,
                    on_thinking_delta=lambda delta: self._emit_model_thinking_delta(
                        chat_agent=chat_agent,
                        context=context,
                        delta=delta,
                        model_request_id=model_request_id,
                    ),
                )
                self._raise_if_stop_requested()
                self._last_model_request_id_by_level[context.execution_id] = (
                    model_request_id
                )
                self._active_model_request_id = None
                logger.debug(
                    "Received model response",
                    extra={
                        "model_request_id": model_request_id,
                        "current_skill": context.current_skill,
                        "depth": context.depth,
                    },
                )
                return model_response
            except AgentRunCancelled:
                raise
            except Exception as error:
                logger.exception(
                    "Model request failed",
                    extra={
                        "current_skill": context.current_skill,
                        "depth": context.depth,
                    },
                )
                write_runtime_error_log(
                    workroot=context.workroot,
                    event="model_request_failed",
                    error=error,
                    context={
                        "model_request_id": model_request_id,
                        "current_skill": context.current_skill,
                        "depth": context.depth,
                        "execution_id": context.execution_id,
                        "memory_hds_id": context.memory_hds_id,
                        "hds_node_path": list(context.hds_node_path or ()),
                        "active_exit_tool": context.snapshot().exit_tool,
                        "tool_choice": context.tool_choice,
                        "parallel_tool_calls": context.parallel_tool_calls,
                        "visible_tools": context.snapshot().tools,
                        "visible_skills": context.snapshot().skills,
                        "message_count": len(messages),
                        "tool_count": len(tools or []),
                    },
                    messages=_diagnostic_messages(messages),
                )
                raise

        try:
            for attempt in Retrying(
                stop=stop_after_attempt(context.config.runtime.retry.max_retries),
                wait=wait_exponential(
                    multiplier=context.config.runtime.retry.multiplier,
                    min=context.config.runtime.retry.min_seconds,
                    max=context.config.runtime.retry.max_seconds,
                ),
                retry=retry_if_exception(_is_parsing_error),
                before_sleep=before_sleep_log(logger, logging.WARNING),
                reraise=True,
            ):
                with attempt:
                    response = _send_model_request()
        except Exception as error:
            if not _is_parsing_error(error):
                raise
            self._insert_model_parsing_recovery_feedback(
                chat_agent=chat_agent,
                context=context,
                retry_error=error,
            )
            self._run_retry_recovery_tool(
                chat_agent=chat_agent,
                context=context,
                retry_error=error,
            )
            response = _send_model_request()

        thinking = ModelResponse.normalized_thinking(response)
        if thinking is not None:
            self._current_turn_thinking_history.append(thinking)
            self._last_model_thinking_by_level[context.execution_id] = thinking

        request_usage = self._record_model_response_usage(
            response=response,
            chat_agent=chat_agent,
            context=context,
        )

        output_message_ids = chat_agent.add_response(response=response)
        if request_usage is not None:
            self._attach_usage_to_assistant_messages(
                chat_agent=chat_agent,
                output_message_ids=output_message_ids,
                request_usage=request_usage,
            )
        step_metadata = (
            {"token_usage": request_usage.to_dict()}
            if request_usage is not None
            else None
        )
        self.debug_history.add_step(
            current_skill=context.current_skill,
            deep_agent=self,
            chat_agent=chat_agent,
            response=response,
            tools=context.local_tools._capabilities,
            tool_payloads=context.local_tools.get_tools_for_llm(client=context.client),
            parallel_tool_calls=context.parallel_tool_calls,
            client=context.client,
            tool_choice=context.tool_choice,
            depth=context.depth,
            input_message_ids=input_message_ids,
            output_message_ids=output_message_ids,
            metadata=step_metadata,
        )
        self._checkpoint_after_message_threshold(chat_agent=chat_agent)

        return response

    def _record_model_response_usage(
        self,
        *,
        response: ModelResponse,
        chat_agent: ChatAgent,
        context: _LevelContext,
    ) -> ModelRequestUsage | None:
        """Store provider-reported token usage for one model response."""
        usage = ModelResponse.normalized_usage(response)
        if usage is None:
            return None
        model_request_id = self._last_model_request_id_by_level.get(
            context.execution_id
        )
        if not model_request_id:
            return None
        request_usage = ModelRequestUsage(
            model_request_id=model_request_id,
            model=context.client.model,
            level_path=tuple(context.level_path),
            hds_node_path=tuple(context.hds_node_path or ()),
            current_skill=context.current_skill,
            usage=usage,
        )
        self._current_turn_token_usage_requests.append(request_usage)
        return request_usage

    def _attach_usage_to_assistant_messages(
        self,
        *,
        chat_agent: ChatAgent,
        output_message_ids: list[str],
        request_usage: ModelRequestUsage,
    ) -> None:
        """Attach token usage metadata to assistant messages only."""
        serialized = request_usage.to_dict()
        for message_id in output_message_ids:
            node = chat_agent.history_graph.get_message(message_id)
            if node.role != "assistant":
                continue
            node.provider_metadata["token_usage"] = serialized

    def _emit_model_thinking_delta(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
        delta: str,
        model_request_id: str,
    ) -> None:
        """Emit one provider thinking delta as transient runtime observability."""
        if not delta.strip():
            return
        self._emit_level_event(
            chat_agent=chat_agent,
            context=context,
            event_data=LevelEventData(
                event_type="model_thinking_delta",
                content=delta,
                operation="model",
                phase="update",
                payload={
                    "kind": "model-thinking-delta",
                    "model_request_id": model_request_id,
                },
            ),
        )

    def _next_model_request_id(self, *, context: _LevelContext) -> str:
        """Return a stable observability id for one provider model attempt."""
        self._model_request_sequence += 1
        level_key = context.level_path or context.hds_node_path or ("root",)
        safe_level = "__".join(str(part) for part in level_key)
        return f"{self._current_turn_id}:model:{safe_level}:{self._model_request_sequence}"

    def _payload_with_model_request_id(
        self,
        *,
        context: _LevelContext,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Attach the latest model request id and usage to an event payload."""
        enriched = dict(payload)
        model_request_id = self._last_model_request_id_by_level.get(
            context.execution_id
        )
        if model_request_id:
            enriched["model_request_id"] = model_request_id
            request_usage = next(
                (
                    item
                    for item in reversed(self._current_turn_token_usage_requests)
                    if item.model_request_id == model_request_id
                ),
                None,
            )
            if request_usage is not None:
                enriched["token_usage"] = {
                    key: value
                    for key, value in request_usage.usage.to_dict().items()
                    if key != "raw_details"
                }
        return enriched

    def _insert_model_parsing_recovery_feedback(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
        retry_error: BaseException,
    ) -> None:
        """Append and trace mandatory feedback after parsing retries are exhausted."""
        input_message_ids = chat_agent.get_message_ids()
        snapshot = context.snapshot()
        message = get_runtime_text(
            "agent.errors.model_parsing_recovery",
            details=str(retry_error).strip() or type(retry_error).__name__,
            available_tools=self._format_capability_list(snapshot.tools),
            available_skills=self._format_capability_list(snapshot.skills),
        )
        previous_step_id = chat_agent.last_step_id
        chat_agent.add_user_message(message=message, kind="error")
        output_message_ids = chat_agent.get_message_ids()[len(input_message_ids) :]
        recovery_step = chat_agent.history_graph.add_step(
            depth=context.depth,
            current_skill=context.current_skill,
            input_message_ids=input_message_ids,
            output_message_ids=output_message_ids,
            previous_step_ids=[previous_step_id] if previous_step_id else [],
            tool_names=[
                capability.name for capability in context.local_tools._capabilities
            ],
            tool_payloads=context.local_tools.get_tools_for_llm(client=context.client)
            or [],
            tool_choice=context.tool_choice,
            parallel_tool_calls=context.parallel_tool_calls,
            event_type="model_parsing_recovery",
            metadata={"retry_error": str(retry_error)},
        )
        chat_agent.last_step_id = recovery_step.id
        self.debug_history.history_graph = chat_agent.history_graph
        self.debug_history.steps.append(recovery_step)
        self._emit_level_event(
            chat_agent=chat_agent,
            context=context,
            event_data=LevelEventData(
                event_type="user_message",
                content=message,
                payload={
                    "kind": "model-parsing-recovery",
                    "retry_error": str(retry_error),
                },
            ),
        )
        self._checkpoint_after_message_threshold(chat_agent=chat_agent)
        logger.warning(
            "Inserted model parsing recovery feedback",
            extra={
                "current_skill": context.current_skill,
                "depth": context.depth,
                "retry_error": str(retry_error),
                "step_id": recovery_step.id,
            },
        )

    def _run_retry_recovery_tool(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
        retry_error: BaseException,
    ) -> bool:
        """Run the configured no-argument recovery tool after retry exhaustion."""
        recovery_tool = context.config.runtime.retry.recovery_tool
        if recovery_tool is None:
            return False
        tool_name = recovery_tool.tool_name.strip()
        capability = context.local_tools.get_tool_by_name(tool_name)
        if (
            not isinstance(capability, Tool)
            or context.local_tools.is_exit_tool(tool_name)
            or self._required_model_arguments(capability)
        ):
            logger.warning(
                "Skipping retry recovery tool because it is not currently executable",
                extra={
                    "tool_name": tool_name,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                },
            )
            return False

        tool_call_id = f"retry-recovery-{uuid4().hex}"
        history_tool_call = {
            "id": tool_call_id,
            "type": "function",
            "function": {
                "name": tool_name,
                "arguments": "{}",
            },
        }
        execution_tool_call = {
            "id": tool_call_id,
            "type": "function",
            "function": {
                "name": tool_name,
                "arguments": None,
            },
        }
        previous_step_id = chat_agent.last_step_id
        input_message_ids = chat_agent.get_message_ids()
        assistant_message = context.client.build_assistant_message(
            content="",
            tool_calls=[history_tool_call],
        )
        chat_agent.add_message(message=assistant_message)
        output_message_ids = chat_agent.get_message_ids()[len(input_message_ids) :]
        recovery_step = chat_agent.history_graph.add_step(
            depth=context.depth,
            current_skill=context.current_skill,
            input_message_ids=input_message_ids,
            output_message_ids=output_message_ids,
            previous_step_ids=[previous_step_id] if previous_step_id else [],
            tool_calls=[history_tool_call],
            tool_names=[tool_name],
            tool_payloads=context.local_tools.get_tools_for_llm(client=context.client)
            or [],
            tool_choice=context.tool_choice,
            parallel_tool_calls=context.parallel_tool_calls,
            event_type="retry_recovery_tool_call",
            metadata={"retry_error": str(retry_error)},
        )
        chat_agent.last_step_id = recovery_step.id
        self.debug_history.history_graph = chat_agent.history_graph
        self.debug_history.steps.append(recovery_step)
        self._emit_level_event(
            chat_agent=chat_agent,
            context=context,
            event_data=LevelEventData(
                event_type="assistant_response",
                content="",
                payload={
                    "kind": "retry-recovery",
                    "tool_calls": [history_tool_call],
                    "retry_error": str(retry_error),
                },
            ),
        )
        self._tool_call_feedback_inserted = False
        handled_response = self._handle_tool_call(
            tool_call=execution_tool_call,
            chat_agent=chat_agent,
            context=context,
        )
        if self._tool_call_feedback_inserted:
            logger.warning(
                "Retry recovery tool returned invalid-call feedback",
                extra={
                    "tool_name": tool_name,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                },
            )
            return False
        if handled_response is not None:
            logger.warning(
                "Retry recovery tool unexpectedly completed the level",
                extra={
                    "tool_name": tool_name,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                },
            )
            return False
        logger.info(
            "Executed retry recovery tool",
            extra={
                "tool_name": tool_name,
                "tool_call_id": tool_call_id,
                "current_skill": context.current_skill,
                "depth": context.depth,
            },
        )
        return True

    def _run_handler(
        self,
        *,
        response: ModelResponse,
        chat_agent: ChatAgent,
        context: _LevelContext,
    ) -> str | None:
        """Resolve every tool call emitted by the model for the current level."""
        tool_calls = context.client.extract_tool_calls(response)

        for tool_call in tool_calls:
            tool_name = self._extract_tool_name(tool_call)
            if tool_name is None:
                tool_call_id = self._extract_tool_call_id(tool_call)
                feedback_message = self._invalid_tool_call_feedback(
                    context=context,
                    tool_name="<unknown>",
                    details=get_runtime_text("agent.errors.missing_tool_name"),
                    assistant_text=self._latest_assistant_text(chat_agent=chat_agent),
                )
                if tool_call_id is None:
                    self._append_user_feedback(
                        chat_agent=chat_agent,
                        context=context,
                        message=feedback_message,
                        event_kind="invalid-tool-call",
                        discard_latest_assistant=True,
                    )
                else:
                    self._record_tool_error(
                        chat_agent=chat_agent,
                        context=context,
                        tool_name="<unknown>",
                        tool_call_id=tool_call_id,
                        message=feedback_message,
                        error_kind="missing_tool_name",
                    )
                return None

            tool_call_id = self._extract_tool_call_id(tool_call)
            logger.debug(
                "Handling tool call",
                extra={
                    "tool_name": tool_name,
                    "tool_call_id": tool_call_id,
                    "current_skill": context.current_skill,
                    "depth": context.depth,
                },
            )
            self._emit_level_event(
                chat_agent=chat_agent,
                context=context,
                event_data=LevelEventData(
                    event_type="tool_call",
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    payload={
                        "arguments": tool_call.get("function", {}).get("arguments"),
                        "kind": (
                            "hds-child-delegation"
                            if tool_name == HDS_CHILD_TOOL_NAME
                            else "tool"
                        ),
                    },
                ),
            )

            previous_active_tool_span_id = self._active_tool_span_id
            self._active_tool_span_id = f"{self._current_turn_id}:tool:{tool_call_id}"
            previous_hds_child_tool_call_id = self._active_hds_child_tool_call_id
            self._active_hds_child_tool_call_id = (
                tool_call_id if tool_name == HDS_CHILD_TOOL_NAME else None
            )
            self._tool_call_feedback_inserted = False
            try:
                handled_response = self._handle_tool_call(
                    tool_call=tool_call,
                    chat_agent=chat_agent,
                    context=context,
                )
            finally:
                self._active_hds_child_tool_call_id = previous_hds_child_tool_call_id
                self._active_tool_span_id = previous_active_tool_span_id
            if self._tool_call_feedback_inserted:
                logger.debug(
                    "Tool call feedback inserted",
                    extra={
                        "tool_name": tool_name,
                        "tool_call_id": tool_call_id,
                        "current_skill": context.current_skill,
                        "depth": context.depth,
                    },
                )
                return None
            if handled_response is not None:
                return handled_response

        return None

    def _empty_assistant_response_error(self, *, context: _LevelContext) -> str:
        """Build model-facing feedback for an empty assistant response."""
        snapshot = context.snapshot()
        return get_runtime_text(
            "agent.errors.empty_assistant_response",
            current_skill=context.current_skill or "<root>",
            exit_skill=context.local_tools.get_exit_skill_name(),
            exit_tool=snapshot.exit_tool or "<not activated>",
            available_tools=self._format_capability_list(
                tool.name for tool in context.local_tools.get_tools(include_exit=False)
            ),
            available_skills=self._format_capability_list(
                context.local_tools.get_skill_names()
            ),
        )

    def _invalid_tool_call_feedback(
        self,
        *,
        context: _LevelContext,
        tool_name: str,
        details: str,
        assistant_text: str,
    ) -> str:
        """Build model-facing feedback for a tool call the runtime cannot execute."""
        return get_runtime_text(
            "agent.errors.invalid_tool_call_feedback",
            tool_name=tool_name,
            details=details.strip() or "<none>",
            assistant_text=assistant_text.strip() or "<none>",
            available_tools=self._format_capability_list(
                tool.name for tool in context.local_tools.get_tools(include_exit=True)
            ),
            available_skills=self._format_capability_list(
                context.local_tools.get_skill_names()
            ),
        )

    def _append_user_feedback(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
        message: str,
        event_kind: str,
        discard_latest_assistant: bool = False,
    ) -> None:
        """Append local user-style feedback when no tool call can be correlated."""
        if discard_latest_assistant and chat_agent.chat_history:
            last_message = chat_agent.chat_history[-1]
            if getattr(last_message, "role", None) == "assistant":
                chat_agent.chat_history.pop()
        chat_agent.add_user_message(message=message, kind="error")
        self._tool_call_feedback_inserted = True
        self._sync_latest_debug_local_history(chat_agent=chat_agent)
        self._emit_level_event(
            chat_agent=chat_agent,
            context=context,
            event_data=LevelEventData(
                event_type="user_message",
                content=message,
                payload={"kind": event_kind},
            ),
        )

    @staticmethod
    def _format_capability_list(names: Iterable[str]) -> str:
        """Render visible capability names in a compact, stable format."""
        rendered_names = [str(name) for name in names if str(name).strip()]
        if not rendered_names:
            return "<none>"
        return ", ".join(rendered_names)

    def _sync_latest_debug_local_history(self, *, chat_agent: ChatAgent) -> None:
        """Refresh the latest debug step after runtime response post-processing."""
        if not self.debug_history.steps:
            return
        self.debug_history.steps[-1].output_message_ids = chat_agent.get_message_ids()

    @staticmethod
    def _replace_empty_assistant_with_user_feedback(
        *, chat_agent: ChatAgent, message: str
    ) -> None:
        """Replace an invalid empty assistant turn with corrective user feedback."""
        if chat_agent.chat_history:
            last_message = chat_agent.chat_history[-1]
            if (
                getattr(last_message, "role", None) == "assistant"
                and not str(getattr(last_message, "content", "")).strip()
                and not getattr(last_message, "tool_calls", [])
            ):
                chat_agent.chat_history.pop()
        chat_agent.add_user_message(message=message, kind="error")
