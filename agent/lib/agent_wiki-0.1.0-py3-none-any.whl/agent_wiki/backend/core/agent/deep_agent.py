from __future__ import annotations

from dataclasses import dataclass, field
import inspect
from pathlib import Path
from threading import Event
from typing import Iterable, Mapping
from uuid import uuid4

from agent_wiki.configs.runtime import RuntimePackageConfig
from ..capabilities.tool import INJECTED_TOOL_ARGUMENTS, Tool
from ..client import Client
from ..conversation.chat_agent import ChatAgent
from ..conversation.types import ModelRequestUsage, ModelThinking
from ..observability.debug_history import DebugHistory
from ..observability.diagnostic_logging import configure_diagnostic_logging
from agent_wiki.backend.interface.runtime_event_sink import RuntimeEventSink
from agent_wiki.backend.interface.interaction import (
    InteractionHandlerInterface,
    InteractionRequest,
    InteractionResponse,
)
from .deep_agent_checkpoints import DeepAgentCheckpointMixin
from .deep_agent_config import AgentConfigMixin
from .deep_agent_events import DeepAgentEventMixin
from .deep_agent_loop import DeepAgentLoopMixin
from .deep_agent_memory import DeepAgentMemoryMixin
from .deep_agent_pipeline import DeepAgentPipelineMixin
from .dynamic_pipeline import DeepAgentDynamicPipelineMixin
from .deep_agent_skills import DeepAgentSkillsMixin
from .deep_agent_state import _ActiveLevel
from .deep_agent_tooling import DeepAgentToolingMixin
from ..config.hds_config import HDSConfig
from agent_wiki.backend.interface.config import GraphConfigInterface
from ..capabilities.hierarchical_deep_skill import HierarchicalDeepSkill
from ..capabilities.prompt_templates import (
    PromptTemplateContext,
    build_capability_catalog,
    render_prompt_template,
    validate_loaded_prompt_templates,
)
from ..conversation.types import ToolChoice
from agent_wiki.backend.utils.handler_files_dirs import check_dir
from agent_wiki.backend.interface.checkpoint import (
    CheckpointPolicyInterface,
    CheckpointStoreInterface,
)
from agent_wiki.backend.interface.tool_output_memory import ToolOutputMemoryInterface


@dataclass(slots=True)
class DeepAgent(
    DeepAgentLoopMixin,
    DeepAgentToolingMixin,
    DeepAgentSkillsMixin,
    DeepAgentCheckpointMixin,
    AgentConfigMixin,
    DeepAgentMemoryMixin,
    DeepAgentPipelineMixin,
    DeepAgentDynamicPipelineMixin,
    DeepAgentEventMixin,
):
    """Orchestrates the multi-level agent runtime around tools and deep skills."""

    node_config: GraphConfigInterface
    event_sink: RuntimeEventSink | None = None
    interaction_handler: InteractionHandlerInterface | None = None

    client: Client = field(init=False)
    workroot: Path = field(init=False)
    hds_config: HDSConfig = field(init=False)
    debug_history: DebugHistory = field(init=False, repr=False)
    _agent_context_namespace: str = field(
        init=False, default_factory=lambda: uuid4().hex, repr=False
    )
    _event_sequence: int = field(init=False, default=0, repr=False)
    _current_turn_id: str = field(init=False, default="", repr=False)
    _event_message_ids_by_level: dict[str, set[str]] = field(
        init=False,
        default_factory=dict,
        repr=False,
    )
    _active_tool_span_id: str | None = field(
        init=False,
        default=None,
        repr=False,
    )
    _active_hds_child_tool_call_id: str | None = field(
        init=False,
        default=None,
        repr=False,
    )
    _level_execution_sequence: int = field(init=False, default=0, repr=False)
    _config: RuntimePackageConfig | None = field(init=False, repr=False)
    _tool_output_memory: ToolOutputMemoryInterface = field(init=False, repr=False)
    _checkpoint_store: CheckpointStoreInterface = field(init=False, repr=False)
    _checkpoint_policy: CheckpointPolicyInterface = field(init=False, repr=False)
    _checkpoint_sequence: int = field(init=False, default=0, repr=False)
    _last_checkpoint_message_count: int = field(init=False, default=0, repr=False)
    _active_levels: list[_ActiveLevel] = field(
        init=False, default_factory=list, repr=False
    )

    _main_hds: HierarchicalDeepSkill | None = field(
        init=False, default=None, repr=False
    )
    _hds_child_chats: dict[tuple[str, ...], ChatAgent] = field(
        init=False, default_factory=dict, repr=False
    )
    _root_chat_agent: ChatAgent | None = field(init=False, default=None, repr=False)
    _pending_child_merge_step_ids: dict[str, str | None] = field(
        init=False, default_factory=dict, repr=False
    )
    _pending_hds_child_merge_step_id: str | None = field(
        init=False, default=None, repr=False
    )
    _tool_call_feedback_inserted: bool = field(init=False, default=False, repr=False)
    _active_pipeline_states: dict[tuple[str, ...], dict[str, object]] = field(
        init=False, default_factory=dict, repr=False
    )
    _dynamic_pipeline_registry: dict[str, dict[str, object]] = field(
        init=False, default_factory=dict, repr=False
    )
    _stop_event: Event = field(init=False, default_factory=Event, repr=False)
    _pending_interaction: InteractionRequest | None = field(
        init=False, default=None, repr=False
    )
    _interaction_response: InteractionResponse | None = field(
        init=False, default=None, repr=False
    )
    _current_turn_thinking_history: list[ModelThinking] = field(
        init=False, default_factory=list, repr=False
    )
    _last_model_thinking_by_level: dict[str, ModelThinking] = field(
        init=False, default_factory=dict, repr=False
    )
    _current_turn_token_usage_requests: list[ModelRequestUsage] = field(
        init=False, default_factory=list, repr=False
    )
    _model_request_sequence: int = field(init=False, default=0, repr=False)
    _active_model_request_id: str | None = field(
        init=False, default=None, repr=False
    )
    _last_model_request_id_by_level: dict[str, str] = field(
        init=False,
        default_factory=dict,
        repr=False,
    )
    _prompt_capability_catalog: dict[str, set[str]] = field(
        init=False, default_factory=dict, repr=False
    )
    _agentic_tool_registry: list[dict[str, object]] | None = field(
        init=False, default=None, repr=False
    )

    tool_choice: ToolChoice | Mapping[str, object] | None = field(init=False)
    parallel_tool_calls: bool = field(init=False)

    def __post_init__(self) -> None:
        """Load runtime configuration and validate the working root."""
        self.hds_config = HDSConfig(node_config=self.node_config)
        root_node = self.hds_config.get_main_node()
        if root_node._resolved_node_config is None:
            raise ValueError("Root node configuration was not resolved.")
        root_config = root_node._resolved_node_config
        self.client = root_config.client
        self.workroot = root_config.workroot
        self.tool_choice = root_config.tool_choice
        self.parallel_tool_calls = root_config.parallel_tool_calls
        check_dir(self.workroot)
        self._config = root_config.config
        configure_diagnostic_logging(
            config=root_config.config.runtime.diagnostic_logs,
            workroot=self.workroot,
        )
        self._main_hds = self.hds_config.get_main_hds()
        self._prompt_capability_catalog = build_capability_catalog(self.hds_config)
        validate_loaded_prompt_templates(self.hds_config)
        self.debug_history = DebugHistory(agent=self)
        self._tool_output_memory = root_config.tool_output_memory
        self._tool_output_memory.clear()
        self._checkpoint_store = root_config.checkpoint_store
        self._checkpoint_policy = root_config.checkpoint_policy
        self._validate_retry_recovery_tools()
        self._validate_hitl_configuration()
        self._agentic_tool_registry = self._build_agentic_tool_registry()

    def _render_prompt_body(
        self,
        *,
        body: str,
        source: str,
        skill_name: str,
        level_path: tuple[str, ...],
        hds_node_path: tuple[str, ...],
        workroot: Path,
    ) -> str:
        """Render one capability body against its owning HDS node context."""
        node = self.hds_config.get_node_by_path(hds_node_path)
        if node is None or node._resolved_node_config is None:
            raise ValueError(f"Prompt template HDS node is unavailable: {source}")
        return render_prompt_template(
            body=body,
            source=source,
            context=PromptTemplateContext(
                skill_name=skill_name,
                hds_name=node.name,
                hds_capability_name=node.hds_name or node.name,
                level_path=level_path,
                workroot=workroot,
                custom_variables=node._resolved_node_config.prompt_variables,
            ),
            capability_catalog=self._prompt_capability_catalog,
        )

    def _render_hds_prompt(self, *, node: object) -> str:
        """Render the system prompt for one configured HDS node."""
        hds = getattr(node, "_hds", None)
        resolved = getattr(node, "_resolved_node_config", None)
        path = tuple(getattr(node, "_path", ()))
        if hds is None or resolved is None:
            raise ValueError("Cannot render a prompt for an unresolved HDS node.")
        return self._render_prompt_body(
            body=hds.system_prompt,
            source=str(
                hds.source_path
                or f"HDS '{getattr(node, 'hds_name', None) or node.name}'"
            ),
            skill_name=node.name,
            level_path=path,
            hds_node_path=path,
            workroot=resolved.workroot,
        )

    def _validate_hitl_configuration(self) -> None:
        """Require persistent checkpoints when any configured HDS exposes HITL."""
        for node in self.hds_config.iter_nodes():
            hds = node._hds
            hitl_tools = list(
                self._iter_hitl_tools(
                    [*(hds.sub_tools if hds is not None else [])],
                    [*(hds.sub_skills or [])] if hds is not None else [],
                )
            )
            if not hitl_tools:
                continue
            resolved = node._resolved_node_config
            if resolved is None or not resolved.config.runtime.checkpoint.enabled:
                joined = ", ".join(sorted({tool.name for tool in hitl_tools}))
                raise ValueError(
                    "Persistent checkpoints must be enabled for HITL tools in "
                    f"HDS node '{'/'.join(node._path)}': {joined}"
                )

    @classmethod
    def _iter_hitl_tools(
        cls,
        tools: Iterable[Tool],
        skills: Iterable[object],
    ) -> Iterable[Tool]:
        """Yield protected regular tools from one complete capability subtree."""
        for tool in tools:
            if isinstance(tool, Tool) and tool.hitl is not None:
                yield tool
        for skill in skills:
            sub_tools = getattr(skill, "sub_tools", ())
            sub_skills = getattr(skill, "sub_skills", ()) or ()
            yield from cls._iter_hitl_tools(sub_tools, sub_skills)

    def _validate_retry_recovery_tools(self) -> None:
        """Validate configured retry recovery tools against static HDS surfaces."""
        for node in self.hds_config.iter_nodes():
            resolved = node._resolved_node_config
            recovery_tool = (
                resolved.config.runtime.retry.recovery_tool if resolved else None
            )
            if recovery_tool is None:
                continue
            tool_name = recovery_tool.tool_name.strip()
            if not tool_name:
                raise ValueError("Retry recovery tool requires a non-empty tool name.")
            hds = node._hds
            static_tools = list(hds.sub_tools if hds is not None else [])
            matching_tool = next(
                (
                    tool
                    for tool in static_tools
                    if tool_name in {tool.name, tool.get_runtime_name()}
                ),
                None,
            )
            node_path = "/".join(node._path)
            if matching_tool is None:
                raise ValueError(
                    f"Retry recovery tool '{tool_name}' is not visible in HDS "
                    f"node '{node_path}'."
                )
            if not isinstance(matching_tool, Tool):
                raise ValueError(
                    f"Retry recovery capability '{tool_name}' in HDS node "
                    f"'{node_path}' must be a regular Tool."
                )
            required_arguments = self._required_model_arguments(matching_tool)
            if required_arguments:
                joined = ", ".join(required_arguments)
                raise ValueError(
                    f"Retry recovery tool '{tool_name}' in HDS node "
                    f"'{node_path}' requires model arguments: {joined}."
                )

    @staticmethod
    def _required_model_arguments(tool: Tool) -> list[str]:
        """Return required handler parameters that cannot be runtime-injected."""
        signature = inspect.signature(tool.handler)
        required: list[str] = []
        for name, parameter in signature.parameters.items():
            if name in INJECTED_TOOL_ARGUMENTS:
                continue
            if parameter.kind in {
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            }:
                continue
            if parameter.default is inspect.Parameter.empty:
                required.append(name)
        return required
