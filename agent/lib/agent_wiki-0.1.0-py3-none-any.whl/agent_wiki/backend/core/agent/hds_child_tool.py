from __future__ import annotations

from typing import TYPE_CHECKING

from .deep_agent_state import _LevelContext
from ..capabilities.tool import Tool

if TYPE_CHECKING:
    from .deep_agent import DeepAgent


HDS_CHILD_TOOL_NAME = "call_sub_agent"


def build_hds_child_tool(
    *, agent: DeepAgent, child_descriptions: list[tuple[str, str]]
) -> Tool:
    """Build the synthetic tool that delegates a message to a direct child HDS."""
    available_children = "\n".join(
        f"- {child_name}: {description}"
        for child_name, description in child_descriptions
    )
    description = (
        "Send input to one direct child graph node and wait for its result. Use "
        "'message' for an HDS or sequential pipeline. Use the non-empty "
        "'messages' text list and optional 'static_text' only for a for-pipeline."
        f"\n\nAvailable children:\n{available_children}"
    )

    def call_sub_agent(
        sub_agent: str,
        text: str | None = None,
        messages: list[str] | None = None,
        static_text: str | None = None,
        hds_context: _LevelContext | None = None,
    ) -> str:
        """Send scalar or for-loop input to a child and return its response."""
        if hds_context is None:
            return "Error: HDS runtime context is not available."
        return agent._run_hds_child_message(
            child_name=sub_agent,
            message=text,
            messages=messages,
            static_text=static_text,
            parent_context=hds_context,
        )

    return Tool(
        name=HDS_CHILD_TOOL_NAME,
        description=description,
        handler=call_sub_agent,
    )
