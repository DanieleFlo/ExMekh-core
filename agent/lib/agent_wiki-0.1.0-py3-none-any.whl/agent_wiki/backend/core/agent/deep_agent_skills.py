from __future__ import annotations

import copy
import logging
from pathlib import Path
from typing import Any, Mapping

from ..capabilities.agent_capabilities import AgentCapabilities
from ..conversation.chat_agent import ChatAgent
from .deep_agent_state import LevelOutcome, _ActiveLevel, _LevelContext
from ..capabilities.deep_skill import DeepSkill
from ..observability.events import LevelEventData
from ..capabilities.exit_skill import ExitSkill
from .hds_child_tool import build_hds_child_tool
from .deep_agent_loop import AgentRunCancelled
from ..config.hds_config import HDSStructureNode
from ..capabilities.hierarchical_deep_skill import HierarchicalDeepSkill
from ..conversation.message import ChatMessage
from ..outputs.tool_result_renderer import ExitSkillResult, resolve_exit_skill_result
from agent_wiki.configs.text_catalog import get_runtime_text
from ..capabilities.deep_skill_middleware import (
    snapshot_history,
    validate_after_result,
    validate_before_result,
)
from agent_wiki.backend.interface.deep_skill_middleware import DeepSkillAfterResult
from agent_wiki.backend.interface.envelope import EnvelopeMetadata
from .runtime_error_log import write_runtime_error_log

logger = logging.getLogger(__name__)


def _diagnostic_messages(
    chat_agent: ChatAgent, *, limit: int = 12
) -> list[dict[str, Any]]:
    """Return compact recent messages for runtime error diagnostics."""
    records: list[dict[str, Any]] = []
    for message in chat_agent.chat_history[-limit:]:
        payload = message.to_dict()
        content = str(payload.get("content") or "")
        payload["content"] = content[:4000]
        if len(content) > 4000:
            payload["content_truncated"] = True
        records.append(payload)
    return records


def _relative_diagnostic_path(*, path: Any, workroot: Any) -> str:
    """Return a model-facing diagnostic path without leaking host directories."""
    if path is None or workroot is None:
        return ".agent-wiki/runtime-errors/errors.jsonl"
    try:
        return Path(path).resolve().relative_to(Path(workroot).resolve()).as_posix()
    except (OSError, ValueError, TypeError):
        return ".agent-wiki/runtime-errors/errors.jsonl"


class DeepAgentSkillsMixin:
    """Manages child level creation, skill result promotion, and exits."""

    def _hds_capabilities(
        self,
        *,
        hds: HierarchicalDeepSkill,
        node_path: tuple[str, ...],
    ) -> AgentCapabilities:
        """Build the capability surface for one configured HDS node."""
        if hds.exit_skill is None:
            raise ValueError(get_runtime_text("agent.errors.exit_skill_required"))
        skills = list(hds.sub_skills or [])
        node = self.hds_config.get_node_by_path(node_path)
        resolved_node = node._resolved_node_config if node is not None else None
        resolver = (
            resolved_node.dynamic_sub_skill_resolver
            if resolved_node is not None
            else None
        )
        if resolver is not None:
            dynamic_skills = resolver.resolve(
                config=resolved_node.config,
                workroot=resolved_node.workroot,
            )
            seen_names = {skill.get_runtime_name() for skill in skills}
            for skill in dynamic_skills:
                runtime_name = skill.get_runtime_name()
                if runtime_name in seen_names:
                    continue
                skills.append(skill)
                seen_names.add(runtime_name)
        capabilities = AgentCapabilities(
            exit=hds.exit_skill,
            tools=hds.sub_tools,
            skills=skills,
            level_path=node_path,
            canonical_prefix=node_path[1:],
        )
        child_descriptions = self.hds_config.get_child_descriptions(node_path)
        if child_descriptions:
            capabilities.add_tools(
                [
                    build_hds_child_tool(
                        agent=self,
                        child_descriptions=child_descriptions,
                    )
                ]
            )
        return capabilities

    def _build_agentic_tool_registry(self) -> list[dict[str, Any]] | None:
        """Build one immutable tool registry for the complete configured HDS graph."""
        agentic_client = next(
            (
                node._resolved_node_config.client
                for node in self.hds_config.iter_nodes()
                if node._resolved_node_config is not None
                and bool(
                    getattr(
                        getattr(node._resolved_node_config.client, "provider", None),
                        "supports_agentic_capabilities",
                        False,
                    )
                )
            ),
            None,
        )
        if agentic_client is None:
            return None

        registry: dict[str, dict[str, Any]] = {}
        root_path = self.hds_config.get_main_node()._path
        for node in self.hds_config.iter_nodes():
            if node._hds is None:
                continue
            capabilities = self._hds_capabilities(
                hds=node._hds,
                node_path=node._path,
            )
            schemas = capabilities.get_tools_for_llm(
                client=agentic_client,
                is_agentic=True,
            ) or []
            for schema in schemas:
                candidate = dict(schema)
                if node._path != root_path:
                    candidate["description"] = ""
                name = str(candidate["name"])
                existing = registry.get(name)
                if existing is not None and existing != candidate:
                    raise ValueError(
                        f"Agentic capability registry collision for '{name}'."
                    )
                registry.setdefault(name, candidate)
        return list(registry.values())

    def _run_hds_child_message(
        self,
        *,
        child_name: str,
        message: str | None = None,
        messages: list[str] | None = None,
        static_text: str | None = None,
        parent_context: _LevelContext,
        complete_on_assistant_text: bool = True,
        fail_fast: bool = False,
    ) -> str:
        """Send validated scalar or loop input to one direct child graph node."""
        if parent_context.hds_node_path is None:
            return "Error: the current level is not attached to an HDS node."
        child_node = self.hds_config.get_child_node(
            parent_context.hds_node_path,
            child_name,
        )
        if child_node is None:
            available_children = ", ".join(
                self.hds_config.get_child_names(parent_context.hds_node_path)
            )
            logger.warning(
                "Requested HDS child is unavailable",
                extra={
                    "child_name": child_name,
                    "parent_hds_node_path": list(parent_context.hds_node_path),
                },
            )
            return (
                f"Error: '{child_name}' is not a direct child HDS. "
                f"Available children: {available_children or 'none'}."
            )
        if child_node.pipeline_steps is not None:
            if child_node.pipeline_for_each:
                return self._run_for_pipeline_message(
                    pipeline_node=child_node,
                    message=message,
                    messages=messages,
                    static_text=static_text,
                    parent_context=parent_context,
                )
            if message is None or messages is not None or static_text is not None:
                return "Error: sequential pipeline children require only 'message'."
            return self._run_pipeline_message(
                pipeline_node=child_node,
                message=message,
                parent_context=parent_context,
            )
        if message is None or messages is not None or static_text is not None:
            return "Error: HDS children require only 'message'."
        if child_node._hds is None:
            return f"Error: child HDS '{child_name}' is not loaded."

        if child_node._resolved_node_config is None:
            return f"Error: child HDS '{child_name}' configuration is not resolved."
        child_node_config = child_node._resolved_node_config
        logger.info(
            "Sending message to child HDS",
            extra={
                "child_name": child_name,
                "parent_skill": parent_context.current_skill,
                "parent_hds_node_path": list(parent_context.hds_node_path),
                "child_hds_node_path": list(child_node._path),
            },
        )
        chat_child = self._hds_child_chat(
            child_node=child_node,
            history_graph=self._active_levels[-1].chat_agent.history_graph
            if self._active_levels
            else None,
        )
        history_was_reset = False
        if not child_node_config.preserve_history and len(chat_child.chat_history) > 1:
            chat_child.reset_history()
            history_was_reset = True
            self._pending_hds_child_merge_step_id = None
            logger.info(
                "Reset child HDS history",
                extra={"hds_node_path": list(child_node._path)},
            )
        chat_child.add_user_message(message=message)
        child_workroot = child_node._resolved_workroot or parent_context.workroot
        try:
            local_tools = self._hds_capabilities(
                hds=child_node._hds,
                node_path=child_node._path,
            )
        except (OSError, TypeError, ValueError) as error:
            return (
                f"Error: failed to resolve capabilities for child HDS "
                f"'{child_name}': {error}"
            )
        child_context = _LevelContext(
            current_skill=child_node.name,
            execution_id=self._next_level_execution_id(child_node.name),
            memory_hds_id=parent_context.memory_hds_id,
            agent_context_namespace=parent_context.agent_context_namespace,
            depth=parent_context.depth + 1,
            level_path=child_node._path,
            local_tools=local_tools,
            level_start_index=len(chat_child.chat_history),
            parallel_tool_calls=(
                child_node._hds.parallel_tool_calls
                if child_node._hds.parallel_tool_calls is not None
                else child_node_config.parallel_tool_calls
            ),
            workroot=child_workroot,
            client=child_node_config.client,
            config=child_node_config.config,
            tool_choice=child_node_config.tool_choice,
            hds_node_path=child_node._path,
            excluded_tool_names=tuple(child_node._resolved_excluded_tool_names),
            parent_span_id=self._active_tool_span_id,
            complete_on_assistant_text=complete_on_assistant_text,
            loop_detector=child_node_config.loop_detector,
            agentic_tool_registry=self._agentic_tool_registry,
        )
        child_context.sync_capability_summary(chat_agent=chat_child)
        self._emit_level_event(
            chat_agent=chat_child,
            context=child_context,
            event_data=LevelEventData(
                event_type="parent_message",
                content=message,
                payload={
                    "kind": "hds-parent-message",
                    "parent_hds": parent_context.hds_node_path[-1],
                    "history_reset": history_was_reset,
                },
            ),
        )
        self._active_levels.append(
            _ActiveLevel(
                chat_agent=chat_child,
                context=child_context,
                frame_kind="child_hds",
                parent_hds_node_path=parent_context.hds_node_path,
                delegating_tool_call_id=self._active_hds_child_tool_call_id,
                delegating_child_name=child_name,
                opening_skill_name=child_node._hds.name,
                opening_tool_call_id=self._active_hds_child_tool_call_id,
            )
        )
        try:
            outcome = self._run_level(
                chat_agent=chat_child,
                context=child_context,
            )
        except AgentRunCancelled:
            raise
        except Exception as error:
            logger.exception(
                "HDS child message failed",
                extra={
                    "child_name": child_name,
                    "parent_skill": parent_context.current_skill,
                    "child_skill": child_context.current_skill,
                    "depth": child_context.depth,
                },
            )
            log_path = write_runtime_error_log(
                workroot=child_context.workroot,
                event="hds_child_message_failed",
                error=error,
                context={
                    "child_name": child_name,
                    "parent_skill": parent_context.current_skill,
                    "child_skill": child_context.current_skill,
                    "depth": child_context.depth,
                    "execution_id": child_context.execution_id,
                    "memory_hds_id": child_context.memory_hds_id,
                    "hds_node_path": list(child_context.hds_node_path or ()),
                    "active_exit_tool": child_context.snapshot().exit_tool,
                    "visible_tools": child_context.snapshot().tools,
                    "visible_skills": child_context.snapshot().skills,
                },
                messages=_diagnostic_messages(chat_child),
            )
            diagnostic_path = _relative_diagnostic_path(
                path=log_path,
                workroot=child_context.workroot,
            )
            if fail_fast:
                raise
            return (
                f"Error: child HDS '{child_name}' failed unexpectedly. "
                f"Diagnostics saved to {diagnostic_path}."
            )
        finally:
            self._discard_dynamic_pipelines(
                owner_execution_id=child_context.execution_id
            )
            if self._active_levels and self._active_levels[-1].context is child_context:
                self._active_levels.pop()
        self._pending_hds_child_merge_step_id = chat_child.last_step_id
        logger.info(
            "Child HDS message completed",
            extra={
                "child_name": child_name,
                "parent_skill": parent_context.current_skill,
                "child_skill": child_context.current_skill,
                "depth": child_context.depth,
            },
        )
        return outcome.response

    def _hds_child_chat(
        self,
        *,
        child_node: HDSStructureNode,
        history_graph: Any | None = None,
    ) -> ChatAgent:
        """Return an existing child HDS chat or initialize it on first use."""
        existing_chat = self._hds_child_chats.get(child_node._path)
        if existing_chat is not None:
            logger.debug(
                "Reusing child HDS chat",
                extra={
                    "child_name": child_node.name,
                    "hds_node_path": list(child_node._path),
                },
            )
            return existing_chat
        if child_node._hds is None:
            raise ValueError(f"Child HDS is not loaded: {child_node.name}")
        chat_child = ChatAgent(
            client=child_node._resolved_node_config.client
            if child_node._resolved_node_config is not None
            else self.client,
            system_prompt=self._render_hds_prompt(node=child_node),
            history_graph=history_graph,
        )
        # Automatic developer-message injection is intentionally suspended.
        # if developer_message := child_node._hds.developer_message:
        #     chat_child.add_developer_message(message=developer_message)
        self._hds_child_chats[child_node._path] = chat_child
        logger.debug(
            "Initialized child HDS chat",
            extra={
                "child_name": child_node.name,
                "hds_node_path": list(child_node._path),
            },
        )
        return chat_child

    def _run_deep_skill(
        self,
        *,
        deep_skill: DeepSkill,
        tool_call_id: str,
        chat_history: list[ChatMessage] | None,
        parent_chat_agent: ChatAgent | None = None,
        parent_context: _LevelContext,
    ) -> LevelOutcome:
        """Open a child level for a deep skill and return its promoted result."""
        logger.debug(
            "Entering deep skill",
            extra={
                "deep_skill": deep_skill.name,
                "parent_skill": parent_context.current_skill,
                "depth": parent_context.depth + 1,
            },
        )
        self._run_deep_skill_before_middleware(
            deep_skill=deep_skill,
            parent_chat_agent=parent_chat_agent,
            chat_history=chat_history,
        )
        chat_skill = ChatAgent(
            client=parent_context.client,
            system_prompt=(
                parent_chat_agent.get_visible_system_prompt()
                if parent_chat_agent is not None
                else None
            ),
            history_graph=(
                parent_chat_agent.history_graph
                if parent_chat_agent is not None
                else None
            ),
        )
        if chat_history is not None:
            chat_skill.extend_messages(messages=copy.deepcopy(chat_history))
        if parent_chat_agent is not None:
            chat_skill.last_step_id = parent_chat_agent.last_step_id

        # Automatic developer-message injection is intentionally suspended.
        # chat_skill.add_developer_message(message=deep_skill.developer_message)
        original_content = deep_skill.get_content()
        child_level_path = parent_context.level_path + (deep_skill.name,)
        opening_message = chat_skill.add_tool_result(
            content=original_content,
            tool_call_id=tool_call_id,
            name=deep_skill.name,
            depth=parent_context.depth + 1,
            level_path=child_level_path,
        )
        opening_message_id = chat_skill.get_message_ids()[-1]
        after_result = self._run_deep_skill_after_middleware(
            deep_skill=deep_skill,
            chat_skill=chat_skill,
            metadata=EnvelopeMetadata(values={"level_path": child_level_path}),
        )
        patch = after_result.patch if after_result is not None else None
        content, sub_tools, sub_skills = deep_skill.apply_patch(patch=patch)
        rendered_content = self._render_prompt_body(
            body=content,
            source=str(deep_skill.source_path or f"regular skill '{deep_skill.name}'"),
            skill_name=deep_skill.name,
            level_path=child_level_path,
            hds_node_path=parent_context.hds_node_path or parent_context.level_path[:1],
            workroot=parent_context.workroot,
        )
        chat_skill.replace_tool_result_content(
            message_id=opening_message_id,
            content=rendered_content,
        )
        if after_result is not None and after_result.metadata is not None:
            chat_skill.replace_tool_result_metadata(
                message_id=opening_message_id,
                metadata=after_result.metadata,
                depth=parent_context.depth + 1,
                level_path=child_level_path,
            )
        logger.debug(
            "Prepared deep skill chat state",
            extra={
                "deep_skill": deep_skill.name,
                "message_count": len(chat_skill.chat_history),
            },
        )
        if deep_skill.exit_skill is None:
            raise ValueError(
                get_runtime_text(
                    "agent.errors.deep_skill_exit_skill_required",
                    skill_name=deep_skill.name,
                )
            )

        local_tools = parent_context.local_tools.child(
            exit_skill=deep_skill.exit_skill,
            tools=sub_tools,
            skills=sub_skills,
            inherit_parent_tools=deep_skill.inherits_parent_tools,
            level_path=child_level_path,
        )
        child_context = parent_context.child(
            current_skill=deep_skill.name,
            execution_id=self._next_level_execution_id(deep_skill.name),
            local_tools=local_tools,
            level_start_index=len(chat_skill.chat_history),
        )
        child_context.parent_span_id = f"{self._current_turn_id}:skill:{tool_call_id}"
        child_context.parallel_tool_calls = (
            deep_skill.parallel_tool_calls
            if deep_skill.parallel_tool_calls is not None
            else parent_context.parallel_tool_calls
        )
        child_context.sync_capability_summary(chat_agent=chat_skill)
        synced_opening_message_id = child_context._find_body_message_id(
            chat_agent=chat_skill
        )
        opening_message = chat_skill.history_graph.get_message(
            synced_opening_message_id or opening_message_id
        )
        previous_step_id = chat_skill.last_step_id
        visible_message_ids = chat_skill.get_message_ids()
        skill_enter_step = chat_skill.history_graph.add_step(
            depth=child_context.depth,
            current_skill=child_context.current_skill,
            input_message_ids=[
                message_id
                for message_id in visible_message_ids
                if message_id != opening_message.id
            ],
            output_message_ids=[opening_message.id],
            previous_step_ids=[previous_step_id] if previous_step_id else [],
            response_text=opening_message.content,
            tool_names=[deep_skill.name],
            event_type="skill_enter",
            metadata={
                "tool_call_id": tool_call_id,
                "tool_name": deep_skill.name,
                "kind": "deep-skill-context",
            },
        )
        chat_skill.last_step_id = skill_enter_step.id
        self._emit_level_event(
            chat_agent=chat_skill,
            context=child_context,
            event_data=LevelEventData(
                event_type="skill_enter",
                content=opening_message.content,
                tool_name=deep_skill.name,
                tool_call_id=tool_call_id,
            ),
        )
        self._active_levels.append(
            _ActiveLevel(
                chat_agent=chat_skill,
                context=child_context,
                frame_kind="deep_skill",
                opening_skill_name=deep_skill.name,
                opening_tool_call_id=tool_call_id,
            )
        )
        try:
            outcome = self._run_level(
                chat_agent=chat_skill,
                context=child_context,
            )
        finally:
            self._discard_dynamic_pipelines(
                owner_execution_id=child_context.execution_id
            )
            if self._active_levels and self._active_levels[-1].context is child_context:
                self._active_levels.pop()
        self._pending_child_merge_step_ids[tool_call_id] = chat_skill.last_step_id
        logger.info(
            "Deep skill completed",
            extra={
                "deep_skill": deep_skill.name,
                "tool_call_id": tool_call_id,
                "parent_skill": parent_context.current_skill,
                "depth": child_context.depth,
            },
        )
        return outcome

    @staticmethod
    def _run_deep_skill_before_middleware(
        *,
        deep_skill: DeepSkill,
        parent_chat_agent: ChatAgent | None,
        chat_history: list[ChatMessage] | None,
    ) -> None:
        """Run a deep skill's pre-descent hook and append its optional message."""
        middleware = deep_skill.middleware
        if middleware is None or middleware.before is None:
            return
        source_history = (
            parent_chat_agent.chat_history
            if parent_chat_agent is not None
            else chat_history or []
        )
        try:
            result = validate_before_result(
                middleware.before(snapshot_history(source_history))
            )
        except Exception:
            logger.exception(
                "Deep-skill before middleware failed",
                extra={"deep_skill": deep_skill.name},
            )
            raise
        if result is None or result.message is None:
            return
        logger.debug(
            "Deep-skill before middleware returned a message",
            extra={"deep_skill": deep_skill.name},
        )
        if parent_chat_agent is not None:
            parent_chat_agent.add_message(message=result.message)
            return
        if chat_history is None:
            raise ValueError(
                "Deep-skill before middleware returned a message without parent history."
            )
        chat_history.append(result.message)

    @staticmethod
    def _run_deep_skill_after_middleware(
        *,
        deep_skill: DeepSkill,
        chat_skill: ChatAgent,
        metadata: EnvelopeMetadata,
    ) -> DeepSkillAfterResult | None:
        """Run a deep skill's post-injection hook and validate its optional patch."""
        middleware = deep_skill.middleware
        if middleware is None or middleware.after is None:
            return None
        try:
            return validate_after_result(
                middleware.after(snapshot_history(chat_skill.chat_history), metadata)
            )
        except Exception:
            logger.exception(
                "Deep-skill after middleware failed",
                extra={"deep_skill": deep_skill.name},
            )
            raise

    def _record_skill_result(
        self,
        *,
        chat_agent: ChatAgent,
        context: _LevelContext,
        tool_call_id: str,
        tool_name: str,
        content: str,
        metadata: EnvelopeMetadata | None = None,
    ) -> None:
        """Record a promoted deep-skill result in the parent level."""
        context.pending_return_skill_call_id = tool_call_id
        previous_parent_step_id = chat_agent.last_step_id
        visible_tool_call_id = self._tool_output_memory.visible_id_for(tool_call_id)
        skill_message = chat_agent.add_tool_result(
            content=content,
            tool_call_id=tool_call_id,
            name=tool_name,
            visible_tool_call_id=visible_tool_call_id,
            metadata=metadata,
            depth=context.depth,
            level_path=context.level_path,
        )
        self._remember_callable_output(
            context=context,
            tool_call_id=tool_call_id,
            capability_name=tool_name,
            content=skill_message.content,
            visible_tool_call_id=visible_tool_call_id,
        )
        self._emit_level_event(
            chat_agent=chat_agent,
            context=context,
            event_data=LevelEventData(
                event_type="tool_result",
                content=skill_message.content,
                tool_name=tool_name,
                tool_call_id=tool_call_id,
                payload={"kind": "deep-skill"},
            ),
        )
        logger.info(
            "Recorded deep skill result",
            extra={
                "tool_name": tool_name,
                "tool_call_id": tool_call_id,
                "current_skill": context.current_skill,
                "depth": context.depth,
            },
        )
        previous_step_ids = [
            step_id
            for step_id in (
                previous_parent_step_id,
                self._pop_pending_child_merge_step_id(tool_call_id=tool_call_id),
            )
            if step_id
        ]
        merge_step = chat_agent.history_graph.add_step(
            depth=context.depth,
            current_skill=context.current_skill,
            input_message_ids=chat_agent.get_message_ids()[:-1],
            output_message_ids=[chat_agent.get_message_ids()[-1]],
            previous_step_ids=previous_step_ids,
            response_text=content,
            tool_names=[tool_name],
            event_type="skill_merge",
            metadata={
                "tool_call_id": tool_call_id,
                "tool_name": tool_name,
                "kind": "deep-skill",
            },
        )
        chat_agent.last_step_id = merge_step.id
        self._emit_level_event(
            chat_agent=chat_agent,
            context=context,
            event_data=LevelEventData(
                event_type="skill_exit",
                content=skill_message.content,
                tool_name=tool_name,
                tool_call_id=tool_call_id,
                payload={"kind": "deep-skill"},
            ),
        )

    def _pop_pending_child_merge_step_id(self, *, tool_call_id: str) -> str | None:
        """Return and clear the child step id waiting to be merged into a parent."""
        return self._pending_child_merge_step_ids.pop(tool_call_id, None)

    def _resolve_exit_skill_result(
        self,
        *,
        exit_skill: ExitSkill,
        tool_result: str,
        chat_agent: ChatAgent,
        context: _LevelContext | None = None,
        local_tools: AgentCapabilities | None = None,
        level_start_index: int | None = None,
        runtime_tool_call_id: str | None = None,
    ) -> ExitSkillResult:
        """Validate and render the payload returned by an exit skill."""
        if context is not None:
            local_tools = context.local_tools
            level_start_index = context.level_start_index

        if local_tools is None or level_start_index is None:
            raise ValueError(get_runtime_text("agent.errors.exit_context_required"))

        reusable_output_payload = (
            self._tool_output_memory.build_awareness_payload(
                hds_node_path=tuple(context.hds_node_path)
            )
            if context is not None and context.hds_node_path is not None
            else {"entries": []}
        )
        raw_reusable_outputs = reusable_output_payload.get("entries", [])
        reusable_tool_outputs = (
            [
                output
                for output in raw_reusable_outputs
                if isinstance(output, Mapping)
            ]
            if isinstance(raw_reusable_outputs, list)
            else []
        )
        tool_output_id_aliases = {
            output["real_tool_call_id"]: output["tool_call_id"]
            for output in reusable_tool_outputs
            if isinstance(output.get("real_tool_call_id"), str)
            and isinstance(output.get("tool_call_id"), str)
        }
        return resolve_exit_skill_result(
            tool=exit_skill.tool,
            tool_result=tool_result,
            chat_agent=chat_agent,
            local_tools=local_tools,
            level_start_index=level_start_index,
            error_suggestion_generator=exit_skill.error_suggestion_generator,
            excluded_tool_names=(
                context.excluded_tool_names if context is not None else None
            ),
            runtime_tool_call_id=runtime_tool_call_id,
            metadata_preview_char_limit=(
                self._resolve_metadata_preview_char_limit(context=context)
                if context is not None
                else 20
            ),
            reference_similarity_mode=(
                context.config.runtime.tool_output.reference_similarity_mode
                if context is not None
                else "characters"
            ),
            tool_output_id_aliases=tool_output_id_aliases,
            reusable_tool_outputs=reusable_tool_outputs,
        )

    @staticmethod
    def _replace_last_assistant_content(*, chat_agent: ChatAgent, content: str) -> None:
        """Overwrite the latest assistant message when a rendered version is needed."""
        chat_agent.history_cursor.replace_last_assistant_content(content)
