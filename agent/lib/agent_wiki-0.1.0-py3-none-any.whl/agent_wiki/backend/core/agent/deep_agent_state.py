from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from ..capabilities.agent_capabilities import (
    CAPABILITY_SUMMARY_START,
    AgentCapabilities,
)
from ..client import Client
from ..conversation.chat_agent import ChatAgent
from ..conversation.message import ChatMessage
from ..conversation.types import ModelResponse
from ..observability.runtime_events import CapabilitySnapshot
from ...interface.structured_output import StructuredModelT
from ...interface.envelope import EnvelopeMetadata, format_level_path
from ...interface.loop_detection import LoopDetectorInterface


@dataclass(slots=True)
class _LevelContext:
    """Carries the state that stays constant within a runtime level."""

    current_skill: str | None
    execution_id: str
    memory_hds_id: str
    agent_context_namespace: str
    depth: int
    level_path: tuple[str, ...]
    local_tools: AgentCapabilities
    level_start_index: int
    parallel_tool_calls: bool
    workroot: Path
    client: Client
    config: Any
    tool_choice: Any = "auto"
    hds_node_path: tuple[str, ...] | None = None
    parent_span_id: str | None = None
    excluded_tool_names: tuple[str, ...] = ()
    suppress_events: bool = False
    suppress_checkpoints: bool = False
    complete_on_assistant_text: bool = False
    body_kind: str = "hds"
    parent_tools: AgentCapabilities | None = None
    promoted_metadata: EnvelopeMetadata | None = None
    loop_detector: LoopDetectorInterface | None = None
    pending_return_skill_call_id: str | None = None
    agentic_tool_registry: list[dict[str, Any]] | None = None

    def snapshot(self) -> CapabilitySnapshot:
        """Build a capability snapshot for tracing and frontend events."""
        return self.local_tools.snapshot(current_skill=self.current_skill)

    def call(
        self,
        *,
        chat_agent: ChatAgent,
        on_thinking_delta: Callable[[str], None] | None = None,
    ) -> ModelResponse:
        """Send this level's current provider request and return the response."""
        self.sync_capability_summary(chat_agent=chat_agent)

        is_agentic = self._supports_agentic_capabilities()

        agentic: dict[str, Any] | None = None
        if is_agentic:
            allowed_tools = self.local_tools.get_allowed_tools(is_agentic=True)
            allowed_skills = self.local_tools.get_allowed_skills()
            self.local_tools.validate_agentic_scope(
                allowed_tools=allowed_tools,
                allowed_skills=allowed_skills,
            )
            agentic = {
                "agent_context_id": (
                    f"{self.agent_context_namespace}:"
                    f"{'/'.join(self.hds_node_path or self.level_path)}"
                ),
                "allowed_tools": allowed_tools,
                "allowed_skills": allowed_skills,
            }
            if self.pending_return_skill_call_id is not None:
                agentic["operation"] = "return"
                agentic["skill_call_id"] = self.pending_return_skill_call_id

        tools = (
            self.agentic_tool_registry
            if is_agentic and self.agentic_tool_registry is not None
            else self.local_tools.get_tools_for_llm(
                client=self.client,
                is_agentic=is_agentic,
            )
        )
        if is_agentic:
            registered_names = {str(tool["name"]) for tool in tools or []}
            missing = set((*allowed_tools, *allowed_skills)) - registered_names
            if missing:
                raise ValueError(
                    f"Agentic allowed capabilities are absent from the graph registry: {sorted(missing)}"
                )

        response = self.client.create(
            messages=chat_agent.get_messages(),
            tools=tools,
            tool_choice=self.tool_choice,
            parallel_tool_calls=self.parallel_tool_calls,
            config=self.config,
            on_thinking_delta=on_thinking_delta,
            agentic=agentic,
        )
        if agentic is not None and agentic.get("operation") == "return":
            self.pending_return_skill_call_id = None
        return response

    def sync_capability_summary(self, *, chat_agent: ChatAgent) -> None:
        """Append the level's capability summary once and then keep it static."""
        message_id = self._find_body_message_id(chat_agent=chat_agent)
        if message_id is None:
            raise ValueError("The active level body is missing from model history.")
        current = chat_agent.history_graph.get_message(message_id).content
        if not self.config.inject_capability_summaries:
            return
        if CAPABILITY_SUMMARY_START in current:
            return
        is_agentic = self._supports_agentic_capabilities()
        rendered = self.local_tools.render_markdown_summary(
            level_name=self.current_skill or "root",
            body_kind=self.body_kind,
            level_path=format_level_path(level_path=self.level_path),
            parent=self.parent_tools,
            include_unavailable_parent=self.body_kind == "deep_skill",
            is_agentic=is_agentic,
        )
        content = f"{current.rstrip()}\n\n{rendered}"
        chat_agent.replace_message_content_versioned(
            message_id=message_id,
            content=content,
        )

    def _supports_agentic_capabilities(self) -> bool:
        """Return whether this level's client implements the agentic extension."""
        provider = getattr(self.client, "provider", None)
        return bool(getattr(provider, "supports_agentic_capabilities", False))

    def _find_body_message_id(self, *, chat_agent: ChatAgent) -> str | None:
        """Locate the canonical HDS prompt or regular deep-skill opening body."""
        if self.body_kind == "hds":
            return next(
                (
                    message_id
                    for message_id in chat_agent.get_message_ids()
                    if chat_agent.history_graph.get_message(message_id).role == "system"
                ),
                None,
            )
        return next(
            (
                message_id
                for message_id in reversed(chat_agent.get_message_ids())
                if chat_agent.history_graph.get_message(message_id).role == "tool"
                and chat_agent.history_graph.get_message(message_id).name
                == self.current_skill
            ),
            None,
        )

    def call_structured(
        self,
        *,
        chat_agent: ChatAgent,
        output_model: type[StructuredModelT],
        schema_name: str | None = None,
        strict: bool = True,
        on_thinking_delta: Callable[[str], None] | None = None,
    ) -> StructuredModelT:
        """Send a no-tool structured-output request for this level."""
        self.sync_capability_summary(chat_agent=chat_agent)
        return self.client.create_structured(
            messages=chat_agent.get_messages(),
            config=self.config,
            output_model=output_model,
            schema_name=schema_name,
            strict=strict,
            on_thinking_delta=on_thinking_delta,
        )

    def child(
        self,
        *,
        current_skill: str | None,
        execution_id: str,
        local_tools: AgentCapabilities,
        level_start_index: int,
    ) -> _LevelContext:
        """Create a deep-skill context that requires an explicit exit tool."""
        return _LevelContext(
            current_skill=current_skill,
            execution_id=execution_id,
            memory_hds_id=self.memory_hds_id,
            agent_context_namespace=self.agent_context_namespace,
            depth=self.depth + 1,
            level_path=self.level_path + ((current_skill or "child-level"),),
            local_tools=local_tools,
            level_start_index=level_start_index,
            parallel_tool_calls=self.parallel_tool_calls,
            workroot=self.workroot,
            client=self.client,
            config=self.config,
            tool_choice=self.tool_choice,
            hds_node_path=self.hds_node_path,
            parent_span_id=self.parent_span_id,
            excluded_tool_names=self.excluded_tool_names,
            suppress_events=self.suppress_events,
            suppress_checkpoints=self.suppress_checkpoints,
            complete_on_assistant_text=False,
            body_kind="deep_skill",
            parent_tools=self.local_tools,
            loop_detector=self.loop_detector,
            agentic_tool_registry=self.agentic_tool_registry,
        )


@dataclass(slots=True)
class LevelOutcome:
    """Represents the final response and history produced by one level."""

    response: str
    chat_history: list[ChatMessage]
    metadata: EnvelopeMetadata | None = None


@dataclass(slots=True)
class _ActiveLevel:
    """Tracks one active level for checkpoint persistence and resume."""

    chat_agent: ChatAgent
    context: _LevelContext
    frame_kind: str = "deep_skill"
    parent_hds_node_path: tuple[str, ...] | None = None
    delegating_tool_call_id: str | None = None
    delegating_child_name: str | None = None
    opening_skill_name: str | None = None
    opening_tool_call_id: str | None = None
    pending_tool_call: dict[str, Any] | None = None
