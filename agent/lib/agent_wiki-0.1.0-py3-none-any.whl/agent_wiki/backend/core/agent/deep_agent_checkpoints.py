from __future__ import annotations

import copy
import logging
from pathlib import Path
from typing import Any, Mapping

from ..capabilities.agent_capabilities import AgentCapabilities
from ..conversation.chat_agent import ChatAgent
from ..checkpoints.checkpoint import (
    CheckpointFrame,
    CheckpointHDSChat,
    CheckpointPipelineState,
    CheckpointRecord,
    build_checkpoint_record,
)
from ..conversation.history_graph import HistoryGraph, LevelHistoryCursor
from .deep_agent_state import LevelOutcome, _ActiveLevel, _LevelContext
from ..capabilities.deep_skill import DeepSkill
from ..capabilities.exit_skill import ExitSkill
from ..conversation.result import AgentResult
from ..conversation.types import TokenUsageSummary
from ..observability.events import LevelEventData
from agent_wiki.configs.text_catalog import get_runtime_text
from agent_wiki.backend.interface.interaction import (
    InteractionRequest,
    InteractionResponse,
)
from .hds_child_tool import HDS_CHILD_TOOL_NAME


logger = logging.getLogger(__name__)


class DeepAgentCheckpointMixin:
    """Persists and restores active DeepAgent runtime stacks."""

    def run_from_checkpoint(self, checkpoint_path: Path | str) -> AgentResult:
        """Resume execution from a persisted runtime checkpoint."""
        logger.info("Loading checkpoint", extra={"checkpoint_path": str(checkpoint_path)})
        record = self._checkpoint_store.load(checkpoint_path)
        if not record.frames:
            raise ValueError("Checkpoint must contain at least one active level frame.")

        self._current_turn_thinking_history.clear()
        self._last_model_thinking_by_level.clear()
        self._current_turn_token_usage_requests.clear()
        self._level_execution_sequence = max(
            self._level_execution_sequence,
            record.level_execution_sequence,
        )
        self._tool_output_memory.import_outputs(record.tool_outputs)
        self._active_pipeline_states = {
            tuple(state.node_path): {
                "next_step": state.next_step,
                "text": state.text,
                "accumulating_outputs": state.accumulating_outputs,
                "pipeline_kind": state.pipeline_kind,
                "iteration_index": state.iteration_index,
                "iteration_total": state.iteration_total,
                "messages": list(state.messages),
                "static_text": state.static_text,
                "outputs": list(state.outputs),
            }
            for state in record.pipeline_states
        }
        self._import_dynamic_pipeline_definitions(
            record.dynamic_pipeline_definitions
        )
        self._active_levels = self._active_levels_from_checkpoint(record)
        self._pending_interaction = (
            InteractionRequest.from_dict(record.pending_interaction)
            if record.pending_interaction is not None
            else None
        )
        self._interaction_response = (
            InteractionResponse.from_dict(record.interaction_response)
            if record.interaction_response is not None
            else None
        )

        outcome = self._resume_active_stack()
        logger.info(
            "Checkpoint resume completed",
            extra={"checkpoint_path": str(checkpoint_path)},
        )
        return AgentResult(
            response=outcome.response,
            chat_history=outcome.chat_history,
            thinking_history=list(self._current_turn_thinking_history),
            token_usage=TokenUsageSummary.from_requests(
                self._current_turn_token_usage_requests
            ),
            token_usage_requests=list(self._current_turn_token_usage_requests),
        )

    def _checkpoint_before_execution(
        self,
        *,
        reason: str,
        pending_tool_call: Mapping[str, Any],
    ) -> None:
        """Save a checkpoint before a tool or deep skill executes."""
        if self._active_levels and self._active_levels[-1].context.suppress_checkpoints:
            return
        if not self._checkpoint_policy.should_save_before_execution():
            return
        self._save_checkpoint(
            reason=reason,
            pending_tool_call=dict(pending_tool_call),
        )

    def _checkpoint_after_skill_close(self) -> None:
        """Save a checkpoint after a child skill result is recorded in the parent."""
        if self._active_levels and self._active_levels[-1].context.suppress_checkpoints:
            return
        if not self._checkpoint_policy.should_save_after_skill_close():
            return
        self._save_checkpoint(reason="after-skill-close")

    def _checkpoint_after_message_threshold(self, *, chat_agent: ChatAgent) -> None:
        """Save a checkpoint when the current history crosses the configured threshold."""
        if self._active_levels and self._active_levels[-1].context.suppress_checkpoints:
            return
        message_count = len(chat_agent.chat_history)
        if not self._checkpoint_policy.should_save_after_message_count(
            message_count=message_count,
            last_checkpoint_message_count=self._last_checkpoint_message_count,
        ):
            return
        self._last_checkpoint_message_count = message_count
        self._save_checkpoint(reason="message-threshold")

    def _save_checkpoint(
        self,
        *,
        reason: str,
        pending_tool_call: dict[str, Any] | None = None,
    ) -> Path | None:
        """Persist the currently active runtime stack as one checkpoint."""
        if not self._active_levels or self._main_hds is None:
            return None

        self._checkpoint_sequence += 1
        memory_hds_id = self._active_levels[0].context.memory_hds_id
        checkpoint_id = f"{self._checkpoint_sequence:04d}-{reason}"
        record = build_checkpoint_record(
            checkpoint_id=checkpoint_id,
            reason=reason,
            workroot=self.workroot,
            hds_name=self.hds_config.get_main_node().name,
            memory_hds_id=memory_hds_id,
            level_execution_sequence=self._level_execution_sequence,
            frames=self._checkpoint_frames(pending_tool_call=pending_tool_call),
            history_graph=self._active_levels[0].chat_agent.history_graph,
            tool_outputs=self._tool_output_memory.export_outputs(),
            checkpoint_node_path=self._checkpoint_node_path(),
            hds_child_chats=self._checkpoint_hds_child_chats(),
            pipeline_states=self._checkpoint_pipeline_states(),
            dynamic_pipeline_definitions=self._export_dynamic_pipeline_definitions(),
            pending_interaction=(
                self._pending_interaction.to_dict()
                if self._pending_interaction is not None
                else None
            ),
            interaction_response=(
                self._interaction_response.to_dict()
                if self._interaction_response is not None
                else None
            ),
        )
        path = self._checkpoint_store.save(record=record)
        logger.info(
            "Saved checkpoint",
            extra={
                "checkpoint_id": checkpoint_id,
                "reason": reason,
                "path": str(path) if path is not None else None,
                "hds_node_path": list(record.checkpoint_node_path),
            },
        )
        return path

    def _checkpoint_node_path(self) -> tuple[str, ...]:
        """Return the HDS node path that owns the active checkpoint point."""
        if not self._active_levels:
            return ()
        return self._active_levels[-1].context.hds_node_path or ()

    def _checkpoint_frames(
        self, *, pending_tool_call: dict[str, Any] | None = None
    ) -> list[CheckpointFrame]:
        """Serialize all active levels for checkpoint persistence."""
        frames: list[CheckpointFrame] = []
        for index, active_level in enumerate(self._active_levels):
            frame_pending_tool_call = (
                pending_tool_call if index == len(self._active_levels) - 1 else None
            )
            frames.append(
                CheckpointFrame(
                    frame_kind=active_level.frame_kind,
                    current_skill=active_level.context.current_skill,
                    execution_id=active_level.context.execution_id,
                    memory_hds_id=active_level.context.memory_hds_id,
                    depth=active_level.context.depth,
                    level_start_index=active_level.context.level_start_index,
                    parallel_tool_calls=active_level.context.parallel_tool_calls,
                    history_cursor=active_level.chat_agent.history_cursor.to_dict(),
                    hds_node_path=list(active_level.context.hds_node_path or ()),
                    parent_hds_node_path=(
                        list(active_level.parent_hds_node_path)
                        if active_level.parent_hds_node_path is not None
                        else None
                    ),
                    delegating_tool_call_id=active_level.delegating_tool_call_id,
                    delegating_child_name=active_level.delegating_child_name,
                    opening_skill_name=active_level.opening_skill_name,
                    opening_tool_call_id=active_level.opening_tool_call_id,
                    pending_return_skill_call_id=(
                        active_level.context.pending_return_skill_call_id
                    ),
                    pending_tool_call=frame_pending_tool_call,
                )
            )
        return frames

    def _checkpoint_hds_child_chats(self) -> list[CheckpointHDSChat]:
        """Serialize persistent configured HDS child chats for checkpoint resume."""
        return [
            CheckpointHDSChat(
                hds_node_path=list(node_path),
                history_cursor=chat_agent.history_cursor.to_dict(),
            )
            for node_path, chat_agent in sorted(self._hds_child_chats.items())
        ]

    def _checkpoint_pipeline_states(self) -> list[CheckpointPipelineState]:
        """Serialize progress for every pipeline currently awaiting completion."""
        return [
            CheckpointPipelineState(
                node_path=list(node_path),
                next_step=int(state["next_step"]),
                text=str(state["text"]),
                accumulating_outputs=bool(
                    state.get("accumulating_outputs", False)
                ),
                pipeline_kind=str(state.get("pipeline_kind", "sequential")),
                iteration_index=int(state.get("iteration_index", 0)),
                iteration_total=int(state.get("iteration_total", 0)),
                messages=[str(item) for item in state.get("messages", [])],
                static_text=(
                    str(state["static_text"])
                    if state.get("static_text") is not None
                    else None
                ),
                outputs=[str(item) for item in state.get("outputs", [])],
            )
            for node_path, state in sorted(self._active_pipeline_states.items())
        ]

    def _active_levels_from_checkpoint(
        self, record: CheckpointRecord
    ) -> list[_ActiveLevel]:
        """Rebuild active runtime levels from a checkpoint record."""
        active_levels: list[_ActiveLevel] = []
        parent_context: _LevelContext | None = None
        history_graph = HistoryGraph.from_dict(record.history_graph)
        self._hds_child_chats = self._hds_child_chats_from_checkpoint(
            record=record,
            history_graph=history_graph,
        )

        for index, frame in enumerate(record.frames):
            active_client = self.client
            active_config = self._config
            active_tool_choice = self.tool_choice

            chat_agent = ChatAgent(
                client=active_client,
                history_graph=history_graph,
                history_cursor=LevelHistoryCursor.from_dict(
                    graph=history_graph,
                    payload=frame.history_cursor,
                ),
            )
            if frame.frame_kind == "root_hds":
                local_tools = self._root_capabilities()
                root_node = self.hds_config.get_main_node()
                chat_agent.system_prompt = self._render_hds_prompt(node=root_node)
                if root_node._resolved_node_config is not None:
                    active_client = root_node._resolved_node_config.client
                    active_config = root_node._resolved_node_config.config
                    active_tool_choice = root_node._resolved_node_config.tool_choice
                    chat_agent.client = active_client
                workroot = root_node._resolved_workroot or self.workroot
                hds_node_path = root_node._path
                level_path = root_node._path
                excluded_tool_names = tuple(root_node._resolved_excluded_tool_names)
                self._root_chat_agent = chat_agent
            elif frame.frame_kind == "child_hds":
                node_path = tuple(frame.hds_node_path)
                node = self.hds_config.get_node_by_path(node_path)
                if node is None or node._hds is None:
                    raise ValueError(
                        f"Checkpoint HDS node is not visible: {'/'.join(node_path)}"
                    )
                if node._resolved_node_config is None:
                    raise ValueError(
                        f"Checkpoint HDS node is not resolved: {'/'.join(node_path)}"
                    )
                active_client = node._resolved_node_config.client
                active_config = node._resolved_node_config.config
                active_tool_choice = node._resolved_node_config.tool_choice
                chat_agent.client = active_client
                chat_agent.system_prompt = self._render_hds_prompt(node=node)
                local_tools = self._hds_capabilities(hds=node._hds, node_path=node_path)
                workroot = node._resolved_workroot or self.workroot
                hds_node_path = node_path
                level_path = node_path
                excluded_tool_names = tuple(node._resolved_excluded_tool_names)
                self._hds_child_chats[node_path] = chat_agent
            elif frame.frame_kind == "deep_skill":
                if parent_context is None:
                    raise ValueError("Child checkpoint frame is missing its parent.")
                active_client = parent_context.client
                active_config = parent_context.config
                active_tool_choice = parent_context.tool_choice
                chat_agent.client = active_client
                local_tools = self._child_capabilities_from_frame(
                    frame=frame,
                    parent_context=parent_context,
                )
                workroot = parent_context.workroot
                hds_node_path = parent_context.hds_node_path
                level_path = parent_context.level_path + (
                    frame.current_skill or "child-level",
                )
                excluded_tool_names = parent_context.excluded_tool_names
            else:
                raise ValueError(
                    f"Unsupported checkpoint frame kind: {frame.frame_kind}"
                )

            if self._frame_has_active_exit_tool(
                frame=frame,
                exit_skill=local_tools.exit,
                history_graph=history_graph,
            ):
                local_tools.activate_exit_tool()

            active_node = self.hds_config.get_node_by_path(hds_node_path)
            loop_detector = (
                active_node._resolved_node_config.loop_detector
                if active_node is not None
                and active_node._resolved_node_config is not None
                else None
            )

            context = _LevelContext(
                current_skill=frame.current_skill,
                execution_id=frame.execution_id,
                memory_hds_id=frame.memory_hds_id,
                agent_context_namespace=self._agent_context_namespace,
                depth=frame.depth,
                level_path=level_path,
                local_tools=local_tools,
                level_start_index=frame.level_start_index,
                parallel_tool_calls=frame.parallel_tool_calls,
                workroot=workroot,
                client=active_client,
                config=active_config,
                tool_choice=active_tool_choice,
                hds_node_path=hds_node_path,
                excluded_tool_names=excluded_tool_names,
                complete_on_assistant_text=frame.frame_kind == "child_hds",
                body_kind=(
                    "deep_skill" if frame.frame_kind == "deep_skill" else "hds"
                ),
                parent_tools=(
                    parent_context.local_tools
                    if frame.frame_kind == "deep_skill" and parent_context is not None
                    else None
                ),
                loop_detector=loop_detector,
                pending_return_skill_call_id=frame.pending_return_skill_call_id,
                agentic_tool_registry=self._agentic_tool_registry,
            )
            active_level = _ActiveLevel(
                chat_agent=chat_agent,
                context=context,
                frame_kind=frame.frame_kind,
                parent_hds_node_path=(
                    tuple(frame.parent_hds_node_path)
                    if frame.parent_hds_node_path is not None
                    else None
                ),
                delegating_tool_call_id=frame.delegating_tool_call_id,
                delegating_child_name=frame.delegating_child_name,
                opening_skill_name=frame.opening_skill_name,
                opening_tool_call_id=frame.opening_tool_call_id,
                pending_tool_call=frame.pending_tool_call,
            )
            active_levels.append(active_level)
            parent_context = context

        return active_levels

    def _hds_child_chats_from_checkpoint(
        self,
        *,
        record: CheckpointRecord,
        history_graph: HistoryGraph,
    ) -> dict[tuple[str, ...], ChatAgent]:
        """Rebuild persistent HDS child chats from a checkpoint record."""
        chats: dict[tuple[str, ...], ChatAgent] = {}
        for stored_chat in record.hds_child_chats:
            node_path = tuple(stored_chat.hds_node_path)
            node = self.hds_config.get_node_by_path(node_path)
            if node is None:
                continue
            client = (
                node._resolved_node_config.client
                if node._resolved_node_config is not None
                else self.client
            )
            chats[node_path] = ChatAgent(
                client=client,
                system_prompt=(
                    self._render_hds_prompt(node=node)
                    if node._hds is not None
                    else None
                ),
                history_graph=history_graph,
                history_cursor=LevelHistoryCursor.from_dict(
                    graph=history_graph,
                    payload=stored_chat.history_cursor,
                ),
            )
        return chats

    def _root_capabilities(self) -> AgentCapabilities:
        """Build the root capability surface from the loaded main HDS."""
        if self._main_hds is None or self._main_hds.exit_skill is None:
            raise ValueError(get_runtime_text("agent.errors.exit_skill_required"))
        return self._hds_capabilities(
            hds=self._main_hds,
            node_path=self.hds_config.get_main_node()._path,
        )

    def _child_capabilities_from_frame(
        self,
        *,
        frame: CheckpointFrame,
        parent_context: _LevelContext,
    ) -> AgentCapabilities:
        """Rebuild one child capability surface from its saved skill name."""
        skill_name = frame.opening_skill_name or frame.current_skill
        if skill_name is None:
            raise ValueError("Child checkpoint frame is missing its skill name.")
        capability = parent_context.local_tools.get_tool_by_name(skill_name)
        if not isinstance(capability, DeepSkill):
            raise ValueError(f"Checkpoint skill is not visible: {skill_name}")
        if capability.exit_skill is None:
            raise ValueError(
                get_runtime_text(
                    "agent.errors.deep_skill_exit_skill_required",
                    skill_name=capability.name,
                )
            )
        child_level_path = parent_context.level_path + (capability.name,)
        return parent_context.local_tools.child(
            exit_skill=capability.exit_skill,
            tools=capability.sub_tools,
            skills=capability.sub_skills,
            inherit_parent_tools=capability.inherits_parent_tools,
            level_path=child_level_path,
        )

    @staticmethod
    def _frame_has_active_exit_tool(
        *,
        frame: CheckpointFrame,
        exit_skill: ExitSkill,
        history_graph: HistoryGraph,
    ) -> bool:
        """Return whether a checkpoint frame already activated its exit tool."""
        exit_skill_name = exit_skill.get_runtime_name()
        exit_tool_name = exit_skill.get_exit_tool_name()
        message_ids = frame.history_cursor.get("message_ids", [])
        for message_id in message_ids if isinstance(message_ids, list) else []:
            if (
                not isinstance(message_id, str)
                or message_id not in history_graph.messages
            ):
                continue
            message = history_graph.message_to_dict(message_id)
            if message.get("role") == "tool" and message.get("name") in {
                exit_skill_name,
                exit_tool_name,
            }:
                return True

        pending_tool_call = frame.pending_tool_call
        if not isinstance(pending_tool_call, Mapping):
            return False
        function_payload = pending_tool_call.get("function")
        if not isinstance(function_payload, Mapping):
            return False
        return function_payload.get("name") == exit_tool_name

    def _resume_active_stack(self) -> LevelOutcome:
        """Resume the deepest active level and promote results back to the root."""
        if not self._active_levels:
            raise ValueError("No active levels are available for checkpoint resume.")

        outcome = self._resume_level(self._active_levels[-1])
        for index in range(len(self._active_levels) - 2, -1, -1):
            child_level = self._active_levels[index + 1]
            parent_level = self._active_levels[index]
            if child_level.opening_skill_name is None or (
                child_level.frame_kind == "deep_skill"
                and child_level.opening_tool_call_id is None
            ):
                raise ValueError("Checkpoint child frame is missing opening metadata.")
            if child_level.frame_kind == "child_hds":
                self._record_hds_child_result_from_resume(
                    parent_level=parent_level,
                    child_level=child_level,
                    content=outcome.response,
                )
            else:
                self._record_skill_result(
                    chat_agent=parent_level.chat_agent,
                    context=parent_level.context,
                    tool_call_id=child_level.opening_tool_call_id or "",
                    tool_name=child_level.opening_skill_name,
                    content=outcome.response,
                    metadata=outcome.metadata,
                )
                self._discard_dynamic_pipelines(
                    owner_execution_id=child_level.context.execution_id
                )
            self._active_levels = self._active_levels[: index + 1]
            self._checkpoint_after_skill_close()
            outcome = self._resume_level(parent_level)
        return outcome

    def _record_hds_child_result_from_resume(
        self,
        *,
        parent_level: _ActiveLevel,
        child_level: _ActiveLevel,
        content: str,
    ) -> None:
        """Record a resumed configured HDS child response in its parent level."""
        tool_call_id = (
            child_level.delegating_tool_call_id
            or child_level.opening_tool_call_id
            or ""
        )
        if not tool_call_id:
            raise ValueError("Checkpoint HDS child frame is missing delegation id.")

        chat_agent = parent_level.chat_agent
        context = parent_level.context
        previous_step_id = chat_agent.last_step_id
        visible_tool_call_id = self._tool_output_memory.visible_id_for(tool_call_id)
        tool_message = chat_agent.add_tool_result(
            content=content,
            tool_call_id=tool_call_id,
            name=HDS_CHILD_TOOL_NAME,
            visible_tool_call_id=visible_tool_call_id,
            depth=context.depth,
            level_path=context.level_path,
            include_envelope=not self._is_tool_output_excluded(
                context=context,
                tool_name=HDS_CHILD_TOOL_NAME,
            ),
        )
        self._remember_callable_output(
            context=context,
            tool_call_id=tool_call_id,
            capability_name=HDS_CHILD_TOOL_NAME,
            content=tool_message.content,
            visible_tool_call_id=visible_tool_call_id,
        )
        previous_step_ids = [
            step_id
            for step_id in (previous_step_id, child_level.chat_agent.last_step_id)
            if step_id
        ]
        tool_step = chat_agent.history_graph.add_step(
            depth=context.depth,
            current_skill=context.current_skill,
            input_message_ids=chat_agent.get_message_ids()[:-1],
            output_message_ids=chat_agent.get_message_ids()[-1:],
            previous_step_ids=previous_step_ids,
            response_text=content,
            tool_names=[HDS_CHILD_TOOL_NAME],
            event_type="tool_result",
            metadata={
                "tool_call_id": tool_call_id,
                "tool_name": HDS_CHILD_TOOL_NAME,
                "kind": "hds-child-delegation",
                "child_name": child_level.delegating_child_name,
            },
        )
        chat_agent.last_step_id = tool_step.id
        self._pending_hds_child_merge_step_id = None
        self._emit_level_event(
            chat_agent=chat_agent,
            context=context,
            event_data=LevelEventData(
                event_type="tool_result",
                content=tool_message.content,
                tool_name=HDS_CHILD_TOOL_NAME,
                tool_call_id=tool_call_id,
                payload={"kind": "hds-child-delegation"},
            ),
        )

    def _resume_level(self, active_level: _ActiveLevel) -> LevelOutcome:
        """Resume one active level, first handling any pending tool call."""
        if active_level.pending_tool_call is not None:
            handled_response = self._handle_tool_call(
                tool_call=active_level.pending_tool_call,
                chat_agent=active_level.chat_agent,
                context=active_level.context,
            )
            active_level.pending_tool_call = None
            if handled_response is not None:
                promoted_metadata = active_level.context.promoted_metadata
                active_level.context.promoted_metadata = None
                return LevelOutcome(
                    response=handled_response,
                    chat_history=copy.deepcopy(active_level.chat_agent.chat_history),
                    metadata=promoted_metadata,
                )

        return self._run_level(
            chat_agent=active_level.chat_agent,
            context=active_level.context,
        )
