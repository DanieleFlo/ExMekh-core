from __future__ import annotations

import json
import traceback
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Mapping, Sequence


def write_runtime_error_log(
    *,
    workroot: Path | None,
    event: str,
    error: BaseException,
    context: Mapping[str, Any] | None = None,
    messages: Sequence[Mapping[str, Any]] | None = None,
) -> Path | None:
    """Append one runtime error diagnostic record under the injected workroot."""
    if workroot is None:
        return None
    try:
        log_dir = workroot.resolve() / ".agent-wiki" / "runtime-errors"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "errors.jsonl"
        record = {
            "timestamp": datetime.now(UTC).isoformat(),
            "event": event,
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": "".join(
                traceback.format_exception(type(error), error, error.__traceback__)
            ),
            "context": dict(context or {}),
            "messages": list(messages or ()),
        }
        with log_path.open("a", encoding="utf-8") as file:
            file.write(json.dumps(record, ensure_ascii=False) + "\n")
        return log_path
    except Exception:
        return None
