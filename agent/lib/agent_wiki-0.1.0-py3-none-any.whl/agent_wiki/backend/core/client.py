from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from .conversation.message import ChatMessage, ToolMessage
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.backend.interface.provider import ProviderInterface
from agent_wiki.backend.interface.structured_output import (
    StructuredModelT,
    StructuredOutputSpec,
)
from agent_wiki.backend.providers.ollama import _OllamaChatCompletionsProvider
from agent_wiki.backend.providers.lmstudio import (
    LMSTUDIO_BASE_URL,
    _LMStudioChatCompletionsProvider,
)
from agent_wiki.backend.providers.openai import _OpenAIResponsesProvider
from agent_wiki.backend.providers.openrouter import (
    OPENROUTER_BASE_URL,
    _OpenRouterChatCompletionsProvider,
    build_openrouter_headers,
)
from agent_wiki.backend.providers.agentic_openai import (
    AGENTIC_OPENAI_DEFAULT_BASE_URL,
    _AgenticOpenAIProvider,
)
from .conversation.types import ModelResponse, ModelTokenUsage, ToolChoice

logger = logging.getLogger(__name__)


def _model_request_config(config: Any) -> Any:
    """Return typed or legacy model request settings from a runtime config."""
    runtime = getattr(config, "runtime", None)
    if runtime is not None:
        return runtime.model
    return config.agent


@dataclass(slots=True)
class Client:
    """Provider-agnostic facade used by the runtime to talk to LLM backends."""

    provider: ProviderInterface

    @classmethod
    def ollama(
        cls,
        *,
        model: str,
        base_url: str = "http://localhost:11434/v1",
        api_key: str = "ollama",
        timeout: float | None = None,
        max_retries: int = 2,
    ) -> Client:
        """Build a client backed by the Ollama-compatible provider."""
        logging.info(f"Initializing Ollama client with model '{model}' at '{base_url}'")
        return cls(
            provider=_OllamaChatCompletionsProvider(
                model_name=model,
                base_url=base_url,
                api_key=api_key,
                timeout=timeout,
                max_retries=max_retries,
            )
        )

    @classmethod
    def openai(
        cls,
        *,
        model: str,
        api_key: str,
        base_url: str | None = None,
        timeout: float | None = None,
        max_retries: int = 2,
    ) -> Client:
        """Build a client backed by the OpenAI Responses provider."""
        logging.info(f"Initializing OpenAI client with model '{model}'")
        return cls(
            provider=_OpenAIResponsesProvider(
                model_name=model,
                api_key=api_key,
                base_url=base_url,
                timeout=timeout,
                max_retries=max_retries,
            )
        )

    @classmethod
    def agentic_openai(
        cls,
        *,
        model: str,
        api_key: str,
        base_url: str | None = None,
        timeout: float | None = None,
        max_retries: int = 2,
    ) -> Client:
        """Build a client backed by the agentic OpenAI Responses provider."""
        logging.info(f"Initializing Agentic OpenAI client with model '{model}'")
        return cls(
            provider=_AgenticOpenAIProvider(
                model_name=model,
                api_key=api_key,
                base_url=base_url or AGENTIC_OPENAI_DEFAULT_BASE_URL,
                timeout=timeout,
                max_retries=max_retries,
            )
        )

    @classmethod
    def lmstudio(
        cls,
        *,
        model: str,
        base_url: str = LMSTUDIO_BASE_URL,
        api_key: str = "lm-studio",
        timeout: float | None = None,
        max_retries: int = 2,
    ) -> Client:
        """Build a client backed by LM Studio's OpenAI-compatible API."""
        logging.info(
            f"Initializing LM Studio client with model '{model}' at '{base_url}'"
        )
        return cls(
            provider=_LMStudioChatCompletionsProvider(
                model_name=model,
                base_url=base_url,
                api_key=api_key,
                timeout=timeout,
                max_retries=max_retries,
            )
        )

    @classmethod
    def openrouter(
        cls,
        *,
        model: str,
        api_key: str,
        base_url: str = OPENROUTER_BASE_URL,
        referer: str | None = None,
        title: str | None = None,
        timeout: float | None = None,
        max_retries: int = 2,
    ) -> Client:
        """Build a client backed by the OpenRouter Chat Completions provider."""
        logging.info(
            f"Initializing OpenRouter client with model '{model}' at '{base_url}'"
        )
        return cls(
            provider=_OpenRouterChatCompletionsProvider(
                model_name=model,
                base_url=base_url,
                api_key=api_key,
                timeout=timeout,
                max_retries=max_retries,
                default_headers=build_openrouter_headers(
                    referer=referer,
                    title=title,
                ),
            )
        )

    @property
    def model(self) -> str:
        """Return the model name exposed by the underlying provider."""
        return self.provider.model

    def build_system_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        """Build a system message using the active provider format."""
        return self.provider.build_system_message(
            content=content,
            name=name,
        )

    def build_developer_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        """Build a developer message using the active provider format."""
        return self.provider.build_developer_message(
            content=content,
            name=name,
        )

    def build_user_message(
        self,
        *,
        content: str,
        name: str | None = None,
    ) -> ChatMessage:
        """Build a user message using the active provider format."""
        return self.provider.build_user_message(
            content=content,
            name=name,
        )

    def build_assistant_message(
        self,
        *,
        content: str,
        name: str | None = None,
        tool_calls: Sequence[Mapping[str, Any]] | None = None,
    ) -> ChatMessage:
        """Build an assistant message using the active provider format."""
        return self.provider.build_assistant_message(
            content=content,
            name=name,
            tool_calls=tool_calls,
        )

    def build_tool_message(
        self,
        *,
        content: str,
        tool_call_id: str,
        name: str | None = None,
    ) -> ToolMessage:
        """Build a tool message using the active provider format."""
        return self.provider.build_tool_message(
            content=content,
            tool_call_id=tool_call_id,
            name=name,
        )

    def build_function_tool(
        self,
        *,
        name: str,
        description: str,
        handler: Callable[..., Any],
        strict: bool = True,
    ) -> dict[str, Any]:
        """Build the provider payload for a regular runtime tool."""
        return self.provider.build_function_tool(
            name=name,
            description=description,
            handler=handler,
            strict=strict,
        )

    def build_deep_skill_tool(
        self,
        *,
        name: str,
        description: str,
        strict: bool = True,
    ) -> dict[str, Any]:
        """Build the provider payload for a deep skill capability."""
        return self.provider.build_deep_skill_tool(
            name=name,
            description=description,
            strict=strict,
        )

    def build_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
        agentic: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Assemble a provider request without executing it."""
        kwargs: dict[str, Any] = {
            "messages": messages,
            "tools": tools,
            "tool_choice": tool_choice,
            "parallel_tool_calls": parallel_tool_calls,
            "temperature": temperature,
            "top_p": top_p,
            "max_output_tokens": max_output_tokens,
            "stop": stop,
            "seed": seed,
            "user": user,
            "thinking": thinking,
        }
        if agentic is not None:
            kwargs["agentic"] = agentic
        return self.provider.build_request(**kwargs)

    def build_structured_request(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        output_model: type[StructuredModelT],
        schema_name: str | None = None,
        strict: bool = True,
        temperature: float | None = None,
        top_p: float | None = None,
        max_output_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        seed: int | None = None,
        user: str | None = None,
        thinking: bool = False,
    ) -> dict[str, Any]:
        """Assemble a provider structured-output request without executing it."""
        structured_output = StructuredOutputSpec.from_model(
            output_model,
            name=schema_name,
            strict=strict,
        )
        return self.provider.build_structured_request(
            messages=messages,
            structured_output=structured_output,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=max_output_tokens,
            stop=stop,
            seed=seed,
            user=user,
            thinking=thinking,
        )

    def create(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        config: RuntimePackageConfig,
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: ToolChoice | None = None,
        parallel_tool_calls: bool = False,
        on_thinking_delta: Callable[[str], None] | None = None,
        agentic: Mapping[str, Any] | None = None,
    ) -> ModelResponse:
        """Execute a model request using the runtime configuration values."""
        logging.debug(
            "Creating model request",
            extra={
                "message_count": len(messages),
                "tool_count": len(tools or []),
                "tool_choice": tool_choice,
                "parallel_tool_calls": parallel_tool_calls,
                "model": self.model,
            },
        )
        model_config = _model_request_config(config)
        thinking = bool(getattr(model_config, "thinking", True))
        supports_thinking = bool(getattr(self.provider, "supports_thinking", False))
        supports_thinking_stream = bool(
            getattr(self.provider, "supports_thinking_stream", False)
        )
        if thinking and not supports_thinking:
            logger.warning(
                "Provider does not support model thinking; continuing without thinking output",
                extra={
                    "model": self.model,
                    "provider": type(self.provider).__name__,
                },
            )
        thinking_enabled = thinking and supports_thinking
        kwargs: dict[str, Any] = {
            "messages": messages,
            "tools": tools,
            "tool_choice": tool_choice,
            "parallel_tool_calls": parallel_tool_calls,
            "temperature": model_config.temperature,
            "top_p": model_config.top_p,
            "max_output_tokens": model_config.max_output_tokens,
            "stop": model_config.stop,
            "seed": model_config.seed,
            "user": model_config.user,
            "thinking": thinking_enabled,
            "on_thinking_delta": (
                on_thinking_delta
                if thinking_enabled and supports_thinking_stream
                else None
            ),
        }
        if agentic is not None:
            kwargs["agentic"] = agentic
        return self.provider.create(**kwargs)

    def create_structured(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        config: RuntimePackageConfig,
        output_model: type[StructuredModelT],
        schema_name: str | None = None,
        strict: bool = True,
        on_thinking_delta: Callable[[str], None] | None = None,
        on_usage: Callable[[ModelTokenUsage], None] | None = None,
    ) -> StructuredModelT:
        """Execute structured output and optionally observe provider token usage."""
        structured_output = StructuredOutputSpec.from_model(
            output_model,
            name=schema_name,
            strict=strict,
        )
        if not self.provider.supports_structured_output:
            logger.warning(
                "Provider does not support structured output; falling back to normal text response",
                extra={
                    "model": self.model,
                    "provider": type(self.provider).__name__,
                    "schema_name": structured_output.name,
                },
            )
        model_config = _model_request_config(config)
        thinking = bool(getattr(model_config, "thinking", True))
        supports_thinking = bool(getattr(self.provider, "supports_thinking", False))
        supports_thinking_stream = bool(
            getattr(self.provider, "supports_thinking_stream", False)
        )
        if thinking and not supports_thinking:
            logger.warning(
                "Provider does not support model thinking for structured output; continuing without thinking output",
                extra={
                    "model": self.model,
                    "provider": type(self.provider).__name__,
                    "schema_name": structured_output.name,
                },
            )
        thinking_enabled = thinking and supports_thinking
        response = self.provider.create_structured_response(
            messages=messages,
            structured_output=structured_output,
            temperature=model_config.temperature,
            top_p=model_config.top_p,
            max_output_tokens=model_config.max_output_tokens,
            stop=model_config.stop,
            seed=model_config.seed,
            user=model_config.user,
            thinking=thinking_enabled,
            on_thinking_delta=(
                on_thinking_delta
                if thinking_enabled and supports_thinking_stream
                else None
            ),
        )
        response_usage = ModelResponse.normalized_usage(response)
        if on_usage is not None and response_usage is not None:
            on_usage(response_usage)
        text = self.extract_text(response)
        return structured_output.parse_text(text)

    def create_multimodal_text(
        self,
        *,
        prompt: str,
        image_data_urls: Sequence[str],
        model: str | None = None,
        config: RuntimePackageConfig | None = None,
    ) -> str:
        """Execute one provider-agnostic text response over image inputs."""
        model_config = _model_request_config(config) if config is not None else None
        return self.provider.create_multimodal_text(
            prompt=prompt,
            image_data_urls=image_data_urls,
            model=model,
            temperature=model_config.temperature if model_config is not None else None,
            max_output_tokens=(
                model_config.max_output_tokens if model_config is not None else None
            ),
        )

    def extract_text(
        self,
        response: ModelResponse,
    ) -> str:
        """Extract assistant text from a provider response."""
        return self.provider.extract_text(response)

    def extract_tool_calls(
        self,
        response: ModelResponse,
    ) -> list[dict[str, Any]]:
        """Extract normalized tool calls from a provider response."""
        return self.provider.extract_tool_calls(response)

    def extract_messages(
        self,
        response: ModelResponse,
    ) -> list[ChatMessage]:
        """Extract message objects from a provider response."""
        return self.provider.extract_messages(response)
