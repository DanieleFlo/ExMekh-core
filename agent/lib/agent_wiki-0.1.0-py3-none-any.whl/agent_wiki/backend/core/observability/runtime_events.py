from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, fields, field, is_dataclass
from typing import Any, Literal, Mapping, TypeAlias


RuntimeEventType: TypeAlias = Literal[
    "user_message",
    "parent_message",
    "assistant_response",
    "model_thinking_delta",
    "tool_call",
    "tool_result",
    "skill_enter",
    "skill_exit",
    "pipeline",
]
RuntimeEventPhase: TypeAlias = Literal["start", "update", "end", "instant"]
RuntimeOperation: TypeAlias = Literal[
    "user",
    "model",
    "tool",
    "skill",
    "hds-child",
    "pipeline",
]


@dataclass(slots=True)
class CapabilitySnapshot:
    """Store the capability surface visible at one runtime level."""

    current_skill: str | None
    exit_skill: str | None
    exit_tool: str | None = None
    tools: list[str] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)
    descriptions: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize a capability snapshot into a JSON-friendly dictionary."""
        return {
            "current_skill": self.current_skill,
            "exit_skill": self.exit_skill,
            "exit_tool": self.exit_tool,
            "tools": list(self.tools),
            "skills": list(self.skills),
            "descriptions": dict(self.descriptions),
        }


@dataclass(slots=True)
class RuntimeEvent:
    """Represent one compact, correlated event emitted by DeepAgent."""

    sequence: int
    turn_id: str
    event_type: RuntimeEventType
    phase: RuntimeEventPhase
    operation: RuntimeOperation
    depth: int
    level_path: tuple[str, ...]
    level_id: str
    span_id: str
    parent_span_id: str | None
    current_skill: str | None
    hds_name: str | None
    hds_node_path: tuple[str, ...]
    capabilities: CapabilitySnapshot | None = None
    content: str | None = None
    tool_name: str | None = None
    tool_call_id: str | None = None
    payload: Mapping[str, Any] = field(default_factory=dict)
    step_id: str | None = None
    previous_step_ids: tuple[str, ...] = ()
    added_message_ids: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        """Serialize the runtime event into a JSON-friendly dictionary."""
        return {
            "sequence": self.sequence,
            "turn_id": self.turn_id,
            "event_type": self.event_type,
            "phase": self.phase,
            "operation": self.operation,
            "depth": self.depth,
            "level_path": list(self.level_path),
            "level_id": self.level_id,
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id,
            "current_skill": self.current_skill,
            "hds_name": self.hds_name,
            "hds_node_path": list(self.hds_node_path),
            "capabilities": self.capabilities.to_dict() if self.capabilities else None,
            "content": self.content,
            "tool_name": self.tool_name,
            "tool_call_id": self.tool_call_id,
            "payload": _json_safe(self.payload),
            "step_id": self.step_id,
            "previous_step_ids": list(self.previous_step_ids),
            "added_message_ids": list(self.added_message_ids),
        }


@dataclass(frozen=True, slots=True)
class TransportEvent:
    """Wrap one versioned event for HTTP polling and SSE transport."""

    id: int
    session_id: str
    turn_id: str | None
    type: str
    data: Mapping[str, Any]
    version: int = 1

    def to_dict(self) -> dict[str, Any]:
        """Serialize one transport event."""
        return {
            "id": self.id,
            "version": self.version,
            "session_id": self.session_id,
            "turn_id": self.turn_id,
            "type": self.type,
            "data": _json_safe(self.data),
        }


def _json_safe(value: Any) -> Any:
    """Convert nested runtime event payload values into JSON-safe primitives."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if is_dataclass(value) and not isinstance(value, type):
        return {
            field.name: _json_safe(getattr(value, field.name))
            for field in fields(value)
        }
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (set, frozenset)):
        return [_json_safe(item) for item in value]
    return str(value)
