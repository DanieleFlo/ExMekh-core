from __future__ import annotations

from dataclasses import dataclass, field
import logging
from typing import Any, List, Mapping, Sequence

from ..capabilities.deep_skill import DeepSkill
from ..capabilities.tool import Tool
from ..conversation.chat_agent import ChatAgent
from ..conversation.history_graph import HistoryGraph, HistoryStepNode
from ..client import Client

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..agent.deep_agent import DeepAgent
    from ..capabilities.exit_skill import ExitSkill


logger = logging.getLogger(__name__)


@dataclass(slots=True)
class DebugStep:
    """Stores one traced request-response step produced by DeepAgent."""

    step_index: int
    current_skill: str | None
    request_payload: Payload
    response: Any
    response_text: str
    tool_calls: list[dict[str, Any]]
    local_history: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        """Serialize one recorded step into a JSON-friendly dictionary."""
        return {
            "step_index": self.step_index,
            "current_skill": self.current_skill,
            "request_payload": self.request_payload.to_dict(),
            "response": _serialize_debug_value(self.response),
            "response_text": self.response_text,
            "tool_calls": [dict(tool_call) for tool_call in self.tool_calls],
            "local_history": [dict(message) for message in self.local_history],
        }


@dataclass(slots=True)
class Payload:
    """Captures the outbound request payload relevant for debugging."""

    messages: list[dict[str, Any]]
    tools: List[str] | None
    tool_payloads: list[dict[str, Any]] | None
    tool_choice: str | Mapping[str, Any] | None
    parallel_tool_calls: bool

    def to_dict(self) -> dict[str, Any]:
        """Serialize the debug payload into a JSON-friendly dictionary."""
        return {
            "messages": [dict(message) for message in self.messages],
            "tools": list(self.tools) if self.tools is not None else None,
            "tool_payloads": (
                [dict(tool_payload) for tool_payload in self.tool_payloads]
                if self.tool_payloads is not None
                else None
            ),
            "tool_choice": _serialize_debug_value(self.tool_choice),
            "parallel_tool_calls": self.parallel_tool_calls,
        }


@dataclass(slots=True)
class DebugHistory:
    """Collects structured debug traces for each step of a DeepAgent run."""

    agent: DeepAgent
    client: Client | None = None
    temperature: float | None = None
    top_p: float | None = None
    max_output_tokens: int | None = None
    stop: Sequence[str] | None = None
    seed: int | None = None
    user: str | None = None
    history_graph: HistoryGraph = field(init=False)
    steps: list[HistoryStepNode] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Snapshot the runtime settings that apply to every recorded step."""
        runtime = getattr(self.agent._config, "runtime", None)
        model_config = runtime.model if runtime is not None else self.agent._config.agent
        self.temperature = model_config.temperature
        self.top_p = model_config.top_p
        self.max_output_tokens = model_config.max_output_tokens
        self.stop = model_config.stop
        self.seed = model_config.seed
        self.user = model_config.user
        self.client = self.agent.client
        self.history_graph = HistoryGraph()

    def clear(self) -> None:
        """Discard all recorded debug steps."""
        self.steps.clear()
        self.history_graph = HistoryGraph()

    def add_step(
        self,
        *,
        current_skill: str | None,
        deep_agent: DeepAgent,
        chat_agent: ChatAgent,
        response: Any,
        tools: Sequence[Tool | DeepSkill | ExitSkill] | None = None,
        tool_payloads: Sequence[Mapping[str, Any]] | None = None,
        parallel_tool_calls: bool | None = None,
        client: Client | None = None,
        tool_choice: str | Mapping[str, Any] | None = None,
        depth: int = 0,
        input_message_ids: Sequence[str] | None = None,
        output_message_ids: Sequence[str] | None = None,
        previous_step_ids: Sequence[str] | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> HistoryStepNode:
        """Append a new debug step for the latest model interaction."""
        active_client = client or self.client
        if active_client is None:
            raise ValueError("Client is not available in DebugHistory.")

        rendered_tool_payloads = (
            [dict(tool_payload) for tool_payload in tool_payloads]
            if tool_payloads is not None
            else None
        )
        if rendered_tool_payloads is None:
            rendered_tool_payloads = (
                [tool.to_llm_capability(client=active_client) for tool in tools]
                if tools is not None
                else None
            )

        active_tool_choice = (
            tool_choice if tool_choice is not None else deep_agent.tool_choice
        )
        active_parallel_tool_calls = (
            deep_agent.parallel_tool_calls
            if parallel_tool_calls is None
            else parallel_tool_calls
        )
        self.history_graph = chat_agent.history_graph
        step_metadata = {"response": _serialize_debug_value(response)}
        if metadata is not None:
            step_metadata.update(dict(metadata))
        step = chat_agent.history_graph.add_step(
            depth=depth,
            current_skill=current_skill,
            input_message_ids=input_message_ids or chat_agent.get_message_ids(),
            output_message_ids=output_message_ids or [],
            previous_step_ids=previous_step_ids or (
                [chat_agent.last_step_id] if chat_agent.last_step_id else []
            ),
            response_text=active_client.extract_text(response=response),
            tool_calls=active_client.extract_tool_calls(response=response),
            tool_names=[tool.name for tool in tools] if tools else [],
            tool_payloads=rendered_tool_payloads or [],
            tool_choice=active_tool_choice,
            parallel_tool_calls=active_parallel_tool_calls,
            event_type="model_response",
            metadata=step_metadata,
        )
        chat_agent.last_step_id = step.id
        self.steps.append(step)
        logger.debug(
            "Recorded debug step",
            extra={
                "step_id": step.id,
                "current_skill": current_skill,
                "tool_count": len(step.tool_names),
                "tool_call_count": len(step.tool_calls),
            },
        )
        return step

    def to_dict(self) -> dict[str, Any]:
        """Serialize the full debug history into a JSON-friendly dictionary."""
        return {
            "temperature": self.temperature,
            "top_p": self.top_p,
            "max_output_tokens": self.max_output_tokens,
            "stop": list(self.stop) if self.stop is not None else None,
            "seed": self.seed,
            "user": self.user,
            "steps": [step.to_dict() for step in self.steps],
            "history_graph": self.history_graph.to_dict(),
        }


def _serialize_debug_value(value: Any) -> Any:
    """Best-effort conversion of debug values into JSON-friendly data."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _serialize_debug_value(item) for key, item in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_serialize_debug_value(item) for item in value]
    if hasattr(value, "model_dump"):
        return _serialize_debug_value(value.model_dump())
    if hasattr(value, "to_dict"):
        try:
            return _serialize_debug_value(value.to_dict())
        except Exception:
            logger.debug("Failed to serialize debug value with to_dict", exc_info=True)
    return repr(value)
