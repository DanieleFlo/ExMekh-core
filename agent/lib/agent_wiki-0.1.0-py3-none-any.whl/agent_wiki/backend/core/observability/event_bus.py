from __future__ import annotations

from dataclasses import dataclass, field
from threading import RLock

from agent_wiki.backend.interface.runtime_event_sink import RuntimeEventSink

from .runtime_events import RuntimeEvent


@dataclass(slots=True)
class RuntimeEventBus(RuntimeEventSink):
    """Publish runtime events to independent sinks in registration order."""

    _sinks: list[RuntimeEventSink] = field(default_factory=list)
    _lock: RLock = field(default_factory=RLock, repr=False)

    def add_sink(self, sink: RuntimeEventSink) -> None:
        """Register one sink once."""
        with self._lock:
            if sink not in self._sinks:
                self._sinks.append(sink)

    def remove_sink(self, sink: RuntimeEventSink) -> None:
        """Remove one previously registered sink."""
        with self._lock:
            self._sinks = [registered for registered in self._sinks if registered is not sink]

    def publish(self, event: RuntimeEvent) -> None:
        """Publish an event to a stable snapshot of registered sinks."""
        with self._lock:
            sinks = list(self._sinks)
        for sink in sinks:
            sink.publish(event)
