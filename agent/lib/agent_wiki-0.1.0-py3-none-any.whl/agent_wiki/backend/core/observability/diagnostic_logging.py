from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

from agent_wiki.configs.runtime import DiagnosticLogConfig


LOGGER_NAME = "agent_wiki"
_HANDLER_KEY = "_agent_wiki_diagnostic_log_path"
_DEFAULT_MAX_BYTES = 5 * 1024 * 1024
_DEFAULT_BACKUP_COUNT = 3
_STANDARD_LOG_RECORD_FIELDS = {
    "args",
    "asctime",
    "created",
    "exc_info",
    "exc_text",
    "filename",
    "funcName",
    "levelname",
    "levelno",
    "lineno",
    "message",
    "module",
    "msecs",
    "msg",
    "name",
    "pathname",
    "process",
    "processName",
    "relativeCreated",
    "stack_info",
    "thread",
    "threadName",
}


class DiagnosticLogFormatter(logging.Formatter):
    """Format diagnostic records with compact extra context."""

    def format(self, record: logging.LogRecord) -> str:
        """Return one formatted log record with non-standard fields appended."""
        base_message = super().format(record)
        context = {
            key: value
            for key, value in sorted(record.__dict__.items())
            if key not in _STANDARD_LOG_RECORD_FIELDS and not key.startswith("_")
        }
        if not context:
            return base_message
        return f"{base_message} context={context!r}"


def configure_diagnostic_logging(
    *,
    config: DiagnosticLogConfig,
    workroot: Path,
) -> Path | None:
    """Configure Agent Wiki diagnostic file logging when enabled."""
    if not config.enabled:
        return None

    log_path = _resolve_log_path(config=config, workroot=workroot)
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(_parse_log_level(config.level))
    logger.propagate = True

    if _has_handler(logger=logger, log_path=log_path):
        return log_path

    log_path.parent.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(
        log_path,
        maxBytes=_DEFAULT_MAX_BYTES,
        backupCount=_DEFAULT_BACKUP_COUNT,
        encoding="utf-8",
    )
    handler.setLevel(_parse_log_level(config.level))
    handler.setFormatter(
        DiagnosticLogFormatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    )
    setattr(handler, _HANDLER_KEY, str(log_path))
    logger.addHandler(handler)
    logger.info("Diagnostic logging enabled", extra={"log_path": str(log_path)})
    return log_path


def _has_handler(*, logger: logging.Logger, log_path: Path) -> bool:
    """Return whether the logger already writes to the requested path."""
    expected = str(log_path)
    return any(
        getattr(handler, _HANDLER_KEY, None) == expected
        for handler in logger.handlers
    )


def _resolve_log_path(*, config: DiagnosticLogConfig, workroot: Path) -> Path:
    """Resolve the diagnostic log file path below the active workroot."""
    directory = Path(config.directory).expanduser()
    if not directory.is_absolute():
        directory = workroot / directory
    return directory.resolve() / _safe_file_name(config.file_name)


def _parse_log_level(value: str) -> int:
    """Return a logging level from a configured level name."""
    level = getattr(logging, str(value).strip().upper(), None)
    return level if isinstance(level, int) else logging.DEBUG


def _safe_file_name(value: Any) -> str:
    """Return a safe diagnostic log filename."""
    file_name = str(value or "").strip()
    if not file_name:
        return "runtime.log"
    return Path(file_name).name or "runtime.log"
