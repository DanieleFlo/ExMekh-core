from dataclasses import dataclass
from typing import Any, Optional

from .runtime_events import RuntimeEventPhase, RuntimeOperation


@dataclass(slots=True)
class LevelEventData:
    """Encapsulates payload and context for a runtime level event."""

    event_type: str
    content: Optional[str] = None
    tool_name: Optional[str] = None
    tool_call_id: Optional[str] = None
    payload: Optional[dict[str, Any]] = None
    operation: RuntimeOperation | None = None
    phase: RuntimeEventPhase | None = None
    span_id: str | None = None
    parent_span_id: str | None = None
