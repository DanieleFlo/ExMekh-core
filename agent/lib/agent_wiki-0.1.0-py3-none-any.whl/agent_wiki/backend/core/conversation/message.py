from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, ClassVar, Mapping, Sequence

from .types import MessageKind, MessageRole, parse_message_kind


@dataclass(slots=True, kw_only=True)
class Message:
    """Base runtime message shared by all chat roles."""

    content: str
    name: str | None = None
    kind: MessageKind | None = None

    role: ClassVar[MessageRole]

    def __post_init__(self) -> None:
        """Assign and validate the application-facing semantic message kind."""
        self.kind = parse_message_kind(self.role if self.kind is None else self.kind)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the message into the provider-facing dictionary format."""
        payload: dict[str, Any] = {
            "role": self.role,
            "content": self.content,
        }

        if self.name is not None:
            payload["name"] = self.name

        return payload


@dataclass(slots=True, kw_only=True)
class SystemMessage(Message):
    """Message emitted with the system role."""

    role: ClassVar[MessageRole] = "system"


@dataclass(slots=True, kw_only=True)
class DeveloperMessage(Message):
    """Message emitted with the developer role."""

    role: ClassVar[MessageRole] = "developer"


@dataclass(slots=True, kw_only=True)
class UserMessage(Message):
    """Message emitted with the user role."""

    role: ClassVar[MessageRole] = "user"


@dataclass(slots=True, kw_only=True)
class AssistantMessage(Message):
    """Assistant message that may carry structured tool calls."""

    tool_calls: Sequence[Mapping[str, Any]] = field(default_factory=list)

    role: ClassVar[MessageRole] = "assistant"

    def to_dict(self) -> dict[str, Any]:
        """Serialize assistant text together with any tool calls."""
        payload = super(AssistantMessage, self).to_dict()

        if self.tool_calls:
            payload["tool_calls"] = [dict(tool_call) for tool_call in self.tool_calls]

        return payload


@dataclass(slots=True, kw_only=True)
class ToolMessage(Message):
    """Tool result message tied to a specific tool call identifier."""

    tool_call_id: str

    role: ClassVar[MessageRole] = "tool"

    def to_dict(self) -> dict[str, Any]:
        """Serialize a tool result including its tool-call identifier."""
        payload = super(ToolMessage, self).to_dict()
        payload["tool_call_id"] = self.tool_call_id
        return payload


ChatMessage = (
    SystemMessage | DeveloperMessage | UserMessage | AssistantMessage | ToolMessage
)
