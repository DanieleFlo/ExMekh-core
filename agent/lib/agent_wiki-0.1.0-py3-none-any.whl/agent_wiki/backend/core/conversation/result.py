from __future__ import annotations

from dataclasses import dataclass, field

from .message import ChatMessage
from .types import ModelRequestUsage, ModelThinking, TokenUsageSummary


@dataclass(slots=True)
class AgentResult:
    """Return value exposed by DeepAgent after a completed run."""

    response: str
    chat_history: list[ChatMessage]
    thinking_history: list[ModelThinking] = field(default_factory=list)
    token_usage: TokenUsageSummary = field(default_factory=TokenUsageSummary)
    token_usage_requests: list[ModelRequestUsage] = field(default_factory=list)
