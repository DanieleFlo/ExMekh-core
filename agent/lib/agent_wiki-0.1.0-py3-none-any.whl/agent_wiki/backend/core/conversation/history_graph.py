from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from .message import (
    AssistantMessage,
    ChatMessage,
    ToolMessage,
)
from .types import MessageKind, MessageRole, parse_message_kind, parse_message_role


@dataclass(slots=True)
class HistoryMessageNode:
    """Store one immutable-position chat message inside the runtime history graph."""

    id: str
    role: MessageRole
    kind: MessageKind
    content: str
    name: str | None = None
    tool_call_id: str | None = None
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    provider_metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Reject unsupported roles when constructing a history message node."""
        self.role = parse_message_role(self.role)
        self.kind = parse_message_kind(self.kind)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the message node into a JSON-friendly payload."""
        payload: dict[str, Any] = {
            "id": self.id,
            "role": self.role,
            "kind": self.kind,
            "content": self.content,
            "name": self.name,
            "tool_call_id": self.tool_call_id,
            "tool_calls": [dict(tool_call) for tool_call in self.tool_calls],
            "provider_metadata": dict(self.provider_metadata),
        }
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> HistoryMessageNode:
        """Rebuild a message node from a serialized payload."""
        raw_tool_calls = payload.get("tool_calls")
        tool_calls = (
            [
                dict(tool_call)
                for tool_call in raw_tool_calls
                if isinstance(tool_call, Mapping)
            ]
            if isinstance(raw_tool_calls, list)
            else []
        )
        raw_metadata = payload.get("provider_metadata")
        return cls(
            id=_required_string(payload, "id"),
            role=parse_message_role(payload.get("role")),
            kind=parse_message_kind(payload.get("kind")),
            content=_string_or_empty(payload.get("content")),
            name=_optional_string(payload.get("name")),
            tool_call_id=_optional_string(payload.get("tool_call_id")),
            tool_calls=tool_calls,
            provider_metadata=dict(raw_metadata)
            if isinstance(raw_metadata, Mapping)
            else {},
        )


@dataclass(slots=True)
class HistoryStepNode:
    """Store one model/debug step and its graph predecessors."""

    id: str
    depth: int
    current_skill: str | None
    input_message_ids: list[str] = field(default_factory=list)
    output_message_ids: list[str] = field(default_factory=list)
    previous_step_ids: list[str] = field(default_factory=list)
    response_text: str = ""
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    tool_names: list[str] = field(default_factory=list)
    tool_payloads: list[dict[str, Any]] = field(default_factory=list)
    tool_choice: str | Mapping[str, Any] | None = None
    parallel_tool_calls: bool = False
    event_type: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the step node into a JSON-friendly payload."""
        return {
            "id": self.id,
            "depth": self.depth,
            "current_skill": self.current_skill,
            "input_message_ids": list(self.input_message_ids),
            "output_message_ids": list(self.output_message_ids),
            "previous_step_ids": list(self.previous_step_ids),
            "response_text": self.response_text,
            "tool_calls": [dict(tool_call) for tool_call in self.tool_calls],
            "tool_names": list(self.tool_names),
            "tool_payloads": [
                dict(tool_payload) for tool_payload in self.tool_payloads
            ],
            "tool_choice": _serialize_value(self.tool_choice),
            "parallel_tool_calls": self.parallel_tool_calls,
            "event_type": self.event_type,
            "metadata": _serialize_value(self.metadata),
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> HistoryStepNode:
        """Rebuild a step node from a serialized payload."""
        return cls(
            id=_required_string(payload, "id"),
            depth=_int_or_zero(payload.get("depth")),
            current_skill=_optional_string(payload.get("current_skill")),
            input_message_ids=_string_list(payload.get("input_message_ids")),
            output_message_ids=_string_list(payload.get("output_message_ids")),
            previous_step_ids=_string_list(payload.get("previous_step_ids")),
            response_text=_string_or_empty(payload.get("response_text")),
            tool_calls=_mapping_list(payload.get("tool_calls")),
            tool_names=_string_list(payload.get("tool_names")),
            tool_payloads=_mapping_list(payload.get("tool_payloads")),
            tool_choice=payload.get("tool_choice"),
            parallel_tool_calls=bool(payload.get("parallel_tool_calls")),
            event_type=_optional_string(payload.get("event_type")),
            metadata=(
                dict(payload.get("metadata"))
                if isinstance(payload.get("metadata"), Mapping)
                else {}
            ),
        )


@dataclass(slots=True)
class LevelHistoryCursor:
    """Represent one level's ordered view over a shared history graph."""

    graph: HistoryGraph
    message_ids: list[str] = field(default_factory=list)
    last_step_id: str | None = None

    def append_message(self, message: ChatMessage) -> HistoryMessageNode:
        """Append a runtime message to this cursor and return its node."""
        node = self.graph.add_message(message)
        self.message_ids.append(node.id)
        return node

    def extend_messages(
        self, messages: Sequence[ChatMessage]
    ) -> list[HistoryMessageNode]:
        """Append multiple runtime messages to this cursor."""
        return [self.append_message(message) for message in messages]

    def get_messages(self) -> list[dict[str, Any]]:
        """Return this cursor's messages as provider-facing dictionaries."""
        return self.graph.messages_to_dicts(self.message_ids)

    def get_chat_messages(self, *, client: Any) -> list[ChatMessage]:
        """Return this cursor's messages rebuilt as provider chat objects."""
        return [
            self.graph.message_to_chat_message(client=client, node_id=node_id)
            for node_id in self.message_ids
        ]

    def replace_last_assistant_content(self, content: str) -> bool:
        """Replace the latest assistant message content when present."""
        for node_id in reversed(self.message_ids):
            node = self.graph.get_message(node_id)
            if node.role == "assistant":
                node.content = content
                return True
            return False
        return False

    def pop_last_empty_assistant(self) -> bool:
        """Remove a trailing empty assistant message from this cursor."""
        if not self.message_ids:
            return False
        node = self.graph.get_message(self.message_ids[-1])
        if (
            node.role == "assistant"
            and not node.content.strip()
            and not node.tool_calls
        ):
            self.message_ids.pop()
            self.graph.remove_message_if_unreferenced(node.id, cursors=[self])
            return True
        return False

    def to_dict(self) -> dict[str, Any]:
        """Serialize the cursor position into a checkpoint-friendly payload."""
        return {
            "message_ids": list(self.message_ids),
            "last_step_id": self.last_step_id,
        }

    @classmethod
    def from_dict(
        cls, *, graph: HistoryGraph, payload: Mapping[str, Any]
    ) -> LevelHistoryCursor:
        """Rebuild a cursor from serialized checkpoint data."""
        return cls(
            graph=graph,
            message_ids=_string_list(payload.get("message_ids")),
            last_step_id=_optional_string(payload.get("last_step_id")),
        )


@dataclass(slots=True)
class HistoryGraph:
    """Store runtime messages and model steps as an append-oriented graph."""

    messages: dict[str, HistoryMessageNode] = field(default_factory=dict)
    message_order: list[str] = field(default_factory=list)
    steps: dict[str, HistoryStepNode] = field(default_factory=dict)
    step_order: list[str] = field(default_factory=list)
    _message_sequence: int = 0
    _step_sequence: int = 0

    def new_cursor(
        self, message_ids: Sequence[str] | None = None
    ) -> LevelHistoryCursor:
        """Create a new level cursor over this graph."""
        return LevelHistoryCursor(graph=self, message_ids=list(message_ids or []))

    def add_message(self, message: ChatMessage) -> HistoryMessageNode:
        """Append one chat message node to the graph."""
        self._message_sequence += 1
        node = self._node_from_chat_message(
            node_id=f"msg-{self._message_sequence:06d}",
            message=message,
        )
        self.messages[node.id] = node
        self.message_order.append(node.id)
        return node

    def clone_message_with_content(
        self, *, node_id: str, content: str
    ) -> HistoryMessageNode:
        """Append an immutable-position copy of one message with new content."""
        source = self.get_message(node_id)
        self._message_sequence += 1
        clone = HistoryMessageNode(
            id=f"msg-{self._message_sequence:06d}",
            role=source.role,
            kind=source.kind,
            content=content,
            name=source.name,
            tool_call_id=source.tool_call_id,
            tool_calls=[dict(tool_call) for tool_call in source.tool_calls],
            provider_metadata=dict(source.provider_metadata),
        )
        self.messages[clone.id] = clone
        self.message_order.append(clone.id)
        return clone

    def add_step(
        self,
        *,
        depth: int,
        current_skill: str | None,
        input_message_ids: Sequence[str],
        output_message_ids: Sequence[str],
        previous_step_ids: Sequence[str] | None = None,
        response_text: str = "",
        tool_calls: Sequence[Mapping[str, Any]] | None = None,
        tool_names: Sequence[str] | None = None,
        tool_payloads: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: str | Mapping[str, Any] | None = None,
        parallel_tool_calls: bool = False,
        event_type: str | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> HistoryStepNode:
        """Append one model/debug step node to the graph."""
        self._step_sequence += 1
        step = HistoryStepNode(
            id=f"step-{self._step_sequence:06d}",
            depth=depth,
            current_skill=current_skill,
            input_message_ids=list(input_message_ids),
            output_message_ids=list(output_message_ids),
            previous_step_ids=list(previous_step_ids or []),
            response_text=response_text,
            tool_calls=[dict(tool_call) for tool_call in (tool_calls or [])],
            tool_names=list(tool_names or []),
            tool_payloads=[
                dict(tool_payload) for tool_payload in (tool_payloads or [])
            ],
            tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            event_type=event_type,
            metadata=dict(metadata or {}),
        )
        self.steps[step.id] = step
        self.step_order.append(step.id)
        return step

    def get_message(self, node_id: str) -> HistoryMessageNode:
        """Return one message node by id."""
        return self.messages[node_id]

    def get_step(self, step_id: str) -> HistoryStepNode:
        """Return one step node by id."""
        return self.steps[step_id]

    def messages_to_dicts(self, message_ids: Sequence[str]) -> list[dict[str, Any]]:
        """Return provider-facing dictionaries for the selected message ids."""
        return [self.message_to_dict(node_id) for node_id in message_ids]

    def message_to_dict(self, node_id: str) -> dict[str, Any]:
        """Serialize one message node into the provider-facing message shape."""
        node = self.get_message(node_id)
        payload: dict[str, Any] = {
            "role": node.role,
            "content": node.content,
        }
        if node.name is not None:
            payload["name"] = node.name
        if node.role == "assistant" and node.tool_calls:
            payload["tool_calls"] = [dict(tool_call) for tool_call in node.tool_calls]
        if node.role == "tool" and node.tool_call_id is not None:
            payload["tool_call_id"] = node.tool_call_id
        return payload

    def message_to_chat_message(self, *, client: Any, node_id: str) -> ChatMessage:
        """Rebuild a provider chat message object from one message node."""
        node = self.get_message(node_id)
        if node.role == "system":
            message = client.build_system_message(content=node.content, name=node.name)
            return _with_message_kind(message=message, kind=node.kind)
        if node.role == "developer":
            message = client.build_developer_message(
                content=node.content, name=node.name
            )
            return _with_message_kind(message=message, kind=node.kind)
        if node.role == "user":
            message = client.build_user_message(content=node.content, name=node.name)
            return _with_message_kind(message=message, kind=node.kind)
        if node.role == "assistant":
            message = client.build_assistant_message(
                content=node.content,
                name=node.name,
                tool_calls=node.tool_calls,
            )
            return _with_message_kind(message=message, kind=node.kind)
        if node.role == "tool":
            message = client.build_tool_message(
                content=node.content,
                tool_call_id=node.tool_call_id or "",
                name=node.name,
            )
            return _with_message_kind(message=message, kind=node.kind)
        raise ValueError(f"Unsupported history message role: {node.role}")

    def remove_message_if_unreferenced(
        self, node_id: str, *, cursors: Sequence[LevelHistoryCursor]
    ) -> None:
        """Remove a message node when no supplied cursor still references it."""
        if any(node_id in cursor.message_ids for cursor in cursors):
            return
        self.messages.pop(node_id, None)
        self.message_order = [
            existing_id for existing_id in self.message_order if existing_id != node_id
        ]

    def to_dict(self) -> dict[str, Any]:
        """Serialize the graph into a JSON-friendly payload."""
        return {
            "messages": [
                self.messages[node_id].to_dict() for node_id in self.message_order
            ],
            "steps": [self.steps[step_id].to_dict() for step_id in self.step_order],
            "message_sequence": self._message_sequence,
            "step_sequence": self._step_sequence,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> HistoryGraph:
        """Rebuild a graph from a serialized payload."""
        graph = cls()
        raw_messages = payload.get("messages")
        if isinstance(raw_messages, list):
            for raw_message in raw_messages:
                if isinstance(raw_message, Mapping):
                    node = HistoryMessageNode.from_dict(raw_message)
                    graph.messages[node.id] = node
                    graph.message_order.append(node.id)
        raw_steps = payload.get("steps")
        if isinstance(raw_steps, list):
            for raw_step in raw_steps:
                if isinstance(raw_step, Mapping):
                    step = HistoryStepNode.from_dict(raw_step)
                    graph.steps[step.id] = step
                    graph.step_order.append(step.id)
        graph._message_sequence = _int_or_zero(payload.get("message_sequence"))
        graph._step_sequence = _int_or_zero(payload.get("step_sequence"))
        graph._message_sequence = max(
            graph._message_sequence, _max_suffix(graph.message_order)
        )
        graph._step_sequence = max(graph._step_sequence, _max_suffix(graph.step_order))
        return graph

    @staticmethod
    def _node_from_chat_message(
        *, node_id: str, message: ChatMessage
    ) -> HistoryMessageNode:
        """Convert a provider chat message into a graph message node."""
        tool_calls = (
            [dict(tool_call) for tool_call in getattr(message, "tool_calls", [])]
            if isinstance(message, AssistantMessage)
            else []
        )
        tool_call_id = (
            getattr(message, "tool_call_id", None)
            if isinstance(message, ToolMessage)
            else None
        )
        return HistoryMessageNode(
            id=node_id,
            role=message.role,
            kind=parse_message_kind(message.kind),
            content=str(getattr(message, "content", "")),
            name=getattr(message, "name", None),
            tool_call_id=tool_call_id,
            tool_calls=tool_calls,
            provider_metadata={"message_type": type(message).__name__},
        )


def chat_message_from_payload(
    *, client: Any, payload: Mapping[str, Any]
) -> ChatMessage:
    """Rebuild a provider chat message from a serialized provider-style payload."""
    role = parse_message_role(payload.get("role"))
    content = _string_or_empty(payload.get("content"))
    name = _optional_string(payload.get("name"))
    if role == "system":
        return client.build_system_message(content=content, name=name)
    if role == "developer":
        return client.build_developer_message(content=content, name=name)
    if role == "user":
        return client.build_user_message(content=content, name=name)
    if role == "assistant":
        return client.build_assistant_message(
            content=content,
            name=name,
            tool_calls=_mapping_list(payload.get("tool_calls")),
        )
    if role == "tool":
        return client.build_tool_message(
            content=content,
            tool_call_id=_string_or_empty(payload.get("tool_call_id")),
            name=name,
        )
    raise AssertionError(f"Unhandled validated message role: {role}")


def _with_message_kind(*, message: ChatMessage, kind: MessageKind) -> ChatMessage:
    """Restore semantic kind without adding it to provider-facing payloads."""
    message.kind = kind
    return message


def _required_string(payload: Mapping[str, Any], key: str) -> str:
    """Read a required string from a mapping."""
    value = payload.get(key)
    if not isinstance(value, str):
        raise ValueError(f"History graph field '{key}' must be a string.")
    return value


def _optional_string(value: Any) -> str | None:
    """Return a string only when the raw value is a string."""
    return value if isinstance(value, str) else None


def _string_or_empty(value: Any) -> str:
    """Return a string value or an empty fallback."""
    return value if isinstance(value, str) else ""


def _string_list(value: Any) -> list[str]:
    """Return only string values from a raw list."""
    return (
        [item for item in value if isinstance(item, str)]
        if isinstance(value, list)
        else []
    )


def _mapping_list(value: Any) -> list[dict[str, Any]]:
    """Return only mapping values from a raw list."""
    return (
        [dict(item) for item in value if isinstance(item, Mapping)]
        if isinstance(value, list)
        else []
    )


def _int_or_zero(value: Any) -> int:
    """Return an integer value or zero."""
    return value if isinstance(value, int) else 0


def _max_suffix(values: Sequence[str]) -> int:
    """Return the maximum numeric suffix from ids like 'msg-000001'."""
    maximum = 0
    for value in values:
        try:
            maximum = max(maximum, int(value.rsplit("-", 1)[-1]))
        except ValueError:
            continue
    return maximum


def _serialize_value(value: Any) -> Any:
    """Best-effort conversion of arbitrary metadata into JSON-friendly data."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _serialize_value(item) for key, item in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_serialize_value(item) for item in value]
    if hasattr(value, "model_dump"):
        return _serialize_value(value.model_dump())
    if hasattr(value, "to_dict"):
        return _serialize_value(value.to_dict())
    return repr(value)
