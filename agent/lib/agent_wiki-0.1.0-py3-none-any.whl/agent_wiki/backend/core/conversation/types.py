from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Literal, Mapping, Sequence, cast, get_args

MessageRole = Literal["system", "developer", "user", "assistant", "tool"]
MessageKind = Literal[
    "system", "developer", "user", "assistant", "tool", "feedback", "error"
]
MESSAGE_ROLES = cast(
    tuple[MessageRole, ...],
    get_args(MessageRole),
)
MESSAGE_KINDS = cast(
    tuple[MessageKind, ...],
    get_args(MessageKind),
)
ToolChoice = Literal["none", "auto", "required"] | Mapping[str, Any]


def parse_message_role(value: Any) -> MessageRole:
    """Validate and return one supported conversation message role."""
    if not isinstance(value, str) or value not in MESSAGE_ROLES:
        supported = ", ".join(MESSAGE_ROLES)
        raise ValueError(
            f"History message role must be one of: {supported}. Received: {value!r}."
        )
    return cast(MessageRole, value)


def parse_message_kind(value: Any) -> MessageKind:
    """Validate and return one supported semantic message kind."""
    if not isinstance(value, str) or value not in MESSAGE_KINDS:
        supported = ", ".join(MESSAGE_KINDS)
        raise ValueError(
            f"History message kind must be one of: {supported}. Received: {value!r}."
        )
    return cast(MessageKind, value)


@dataclass(slots=True)
class ModelThinking:
    """Represent provider-visible thinking text for one model response."""

    content: str

    @classmethod
    def from_value(cls, value: Any) -> ModelThinking | None:
        """Normalize supported thinking payload shapes into a ModelThinking."""
        if value is None:
            return None
        if isinstance(value, cls):
            return value if value.content.strip() else None
        if isinstance(value, str):
            return cls(content=value) if value.strip() else None
        if isinstance(value, Mapping):
            content = value.get("content")
            if content is None:
                content = value.get("text")
            return cls.from_value(content)
        content = getattr(value, "content", None)
        return cls.from_value(content)


@dataclass(slots=True)
class ModelTokenUsage:
    """Provider-reported token usage for one model response."""

    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None
    reasoning_tokens: int | None = None
    cache_read_tokens: int | None = None
    cache_write_tokens: int | None = None
    raw_details: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_value(cls, value: Any) -> ModelTokenUsage | None:
        """Normalize known provider usage payload shapes."""
        if value is None:
            return None
        if isinstance(value, cls):
            return value if value.has_values() else None
        input_details = _usage_nested(value, "input_tokens_details")
        if not input_details:
            input_details = _usage_nested(value, "prompt_tokens_details")
        output_details = _usage_nested(value, "output_tokens_details")
        if not output_details:
            output_details = _usage_nested(value, "completion_tokens_details")
        usage = cls(
            input_tokens=_usage_int(value, "input_tokens", "prompt_tokens"),
            output_tokens=_usage_int(value, "output_tokens", "completion_tokens"),
            total_tokens=_usage_int(value, "total_tokens"),
            reasoning_tokens=_first_int(
                _usage_int(output_details, "reasoning_tokens"),
                _usage_int(value, "reasoning_tokens"),
            ),
            cache_read_tokens=_first_int(
                _usage_int(input_details, "cached_tokens"),
                _usage_int(value, "cache_read_tokens", "cached_tokens"),
            ),
            cache_write_tokens=_first_int(
                _usage_int(input_details, "cache_write_tokens", "cache_creation_tokens"),
                _usage_int(value, "cache_write_tokens", "cache_creation_tokens"),
            ),
            raw_details=_usage_raw_details(value),
        )
        return usage if usage.has_values() else None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> ModelTokenUsage:
        """Rebuild token usage from serialized runtime metadata."""
        raw_details = payload.get("raw_details")
        return cls(
            input_tokens=_positive_or_zero_int(payload.get("input_tokens")),
            output_tokens=_positive_or_zero_int(payload.get("output_tokens")),
            total_tokens=_positive_or_zero_int(payload.get("total_tokens")),
            reasoning_tokens=_positive_or_zero_int(payload.get("reasoning_tokens")),
            cache_read_tokens=_positive_or_zero_int(payload.get("cache_read_tokens")),
            cache_write_tokens=_positive_or_zero_int(
                payload.get("cache_write_tokens")
            ),
            raw_details=dict(raw_details) if isinstance(raw_details, Mapping) else {},
        )

    def has_values(self) -> bool:
        """Return whether at least one numeric usage field is available."""
        return any(
            value is not None
            for value in (
                self.input_tokens,
                self.output_tokens,
                self.total_tokens,
                self.reasoning_tokens,
                self.cache_read_tokens,
                self.cache_write_tokens,
            )
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize token usage, omitting unknown numeric fields."""
        payload: dict[str, Any] = {}
        for key in (
            "input_tokens",
            "output_tokens",
            "total_tokens",
            "reasoning_tokens",
            "cache_read_tokens",
            "cache_write_tokens",
        ):
            value = getattr(self, key)
            if value is not None:
                payload[key] = value
        if self.raw_details:
            payload["raw_details"] = dict(self.raw_details)
        return payload


@dataclass(slots=True)
class ModelRequestUsage:
    """Token usage for one runtime model request."""

    model_request_id: str
    model: str
    level_path: tuple[str, ...]
    hds_node_path: tuple[str, ...]
    current_skill: str | None
    usage: ModelTokenUsage

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> ModelRequestUsage | None:
        """Rebuild one request-usage record from serialized metadata."""
        raw_usage = payload.get("usage")
        if not isinstance(raw_usage, Mapping):
            return None
        usage = ModelTokenUsage.from_dict(raw_usage)
        if not usage.has_values():
            return None
        return cls(
            model_request_id=str(payload.get("model_request_id") or ""),
            model=str(payload.get("model") or ""),
            level_path=tuple(_string_items(payload.get("level_path"))),
            hds_node_path=tuple(_string_items(payload.get("hds_node_path"))),
            current_skill=(
                str(payload["current_skill"])
                if isinstance(payload.get("current_skill"), str)
                else None
            ),
            usage=usage,
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize one request-usage record for clients and checkpoints."""
        return {
            "model_request_id": self.model_request_id,
            "model": self.model,
            "level_path": list(self.level_path),
            "hds_node_path": list(self.hds_node_path),
            "current_skill": self.current_skill,
            "usage": self.usage.to_dict(),
        }


@dataclass(slots=True)
class TokenUsageSummary:
    """Aggregate token usage across model requests."""

    request_count: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    reasoning_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0

    @classmethod
    def from_requests(
        cls, requests: Sequence[ModelRequestUsage]
    ) -> TokenUsageSummary:
        """Aggregate provider-reported usage records."""
        summary = cls()
        for request in requests:
            summary.add(request.usage)
        return summary

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> TokenUsageSummary:
        """Rebuild a summary from serialized runtime metadata."""
        return cls(
            request_count=_int_or_zero(payload.get("request_count")),
            input_tokens=_int_or_zero(payload.get("input_tokens")),
            output_tokens=_int_or_zero(payload.get("output_tokens")),
            total_tokens=_int_or_zero(payload.get("total_tokens")),
            reasoning_tokens=_int_or_zero(payload.get("reasoning_tokens")),
            cache_read_tokens=_int_or_zero(payload.get("cache_read_tokens")),
            cache_write_tokens=_int_or_zero(payload.get("cache_write_tokens")),
        )

    def add(self, usage: ModelTokenUsage) -> None:
        """Add one provider usage record to the summary."""
        self.request_count += 1
        self.input_tokens += usage.input_tokens or 0
        self.output_tokens += usage.output_tokens or 0
        if usage.total_tokens is not None:
            self.total_tokens += usage.total_tokens
        else:
            self.total_tokens += (usage.input_tokens or 0) + (
                usage.output_tokens or 0
            )
        self.reasoning_tokens += usage.reasoning_tokens or 0
        self.cache_read_tokens += usage.cache_read_tokens or 0
        self.cache_write_tokens += usage.cache_write_tokens or 0

    def to_dict(self) -> dict[str, int]:
        """Serialize aggregate token usage."""
        return {
            "request_count": self.request_count,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "reasoning_tokens": self.reasoning_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "cache_write_tokens": self.cache_write_tokens,
        }


@dataclass(slots=True)
class ModelResponse:
    """Wraps the raw provider response handled by the runtime."""

    response: Dict[str, Any] | None
    thinking: ModelThinking | None = None
    usage: ModelTokenUsage | None = None

    @staticmethod
    def normalized_thinking(response: object) -> ModelThinking | None:
        """Return normalized thinking from model or scripted test responses."""
        thinking = getattr(response, "thinking", None)
        if thinking is None and isinstance(response, Mapping):
            thinking = response.get("thinking")
        return ModelThinking.from_value(thinking)

    @staticmethod
    def normalized_usage(response: object) -> ModelTokenUsage | None:
        """Return normalized token usage from model or scripted test responses."""
        usage = getattr(response, "usage", None)
        if usage is None and isinstance(response, Mapping):
            usage = response.get("usage")
        if usage is None:
            raw_response = getattr(response, "response", None)
            usage = _usage_value(raw_response)
        return ModelTokenUsage.from_value(usage)


def _usage_value(value: Any) -> Any:
    """Read a raw usage field from mapping-like or SDK-object values."""
    if isinstance(value, Mapping):
        return value.get("usage")
    return getattr(value, "usage", None)


def _usage_nested(value: Any, key: str) -> Any:
    """Read one nested usage-details field."""
    if value is None:
        return None
    if isinstance(value, Mapping):
        return value.get(key)
    return getattr(value, key, None)


def _usage_int(value: Any, *keys: str) -> int | None:
    """Read the first integer usage field available under any key."""
    for key in keys:
        raw = _usage_nested(value, key)
        parsed = _positive_or_zero_int(raw)
        if parsed is not None:
            return parsed
    return None


def _positive_or_zero_int(value: Any) -> int | None:
    """Return a non-negative integer value when possible."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int) and value >= 0:
        return value
    return None


def _int_or_zero(value: Any) -> int:
    """Return a non-negative integer or zero."""
    parsed = _positive_or_zero_int(value)
    return parsed if parsed is not None else 0


def _first_int(*values: int | None) -> int | None:
    """Return the first available integer value."""
    for value in values:
        if value is not None:
            return value
    return None


def _usage_raw_details(value: Any) -> dict[str, Any]:
    """Keep provider usage details that are useful but not standardized."""
    details: dict[str, Any] = {}
    for key in ("input_tokens_details", "prompt_tokens_details"):
        nested = _usage_nested(value, key)
        if nested is not None:
            details[key] = _json_safe_usage_value(nested)
    for key in ("output_tokens_details", "completion_tokens_details"):
        nested = _usage_nested(value, key)
        if nested is not None:
            details[key] = _json_safe_usage_value(nested)
    return details


def _json_safe_usage_value(value: Any) -> Any:
    """Convert usage detail SDK objects into JSON-friendly mappings."""
    if isinstance(value, Mapping):
        return {
            str(key): _json_safe_usage_value(item)
            for key, item in value.items()
            if isinstance(key, str)
        }
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if hasattr(value, "model_dump"):
        dumped = value.model_dump()
        if isinstance(dumped, Mapping):
            return _json_safe_usage_value(dumped)
    if hasattr(value, "__dict__"):
        return _json_safe_usage_value(vars(value))
    return str(value)


def _string_items(value: Any) -> list[str]:
    """Return only string items from a serialized list."""
    return [item for item in value if isinstance(item, str)] if isinstance(value, list) else []
