from __future__ import annotations

import logging

from collections.abc import Mapping

import yaml

from agent_wiki.backend.interface.envelope import (
    compact_metadata_value,
    ensure_envelope_metadata,
    EnvelopeMetadata,
    render_envelope_metadata,
)
from ..client import Client
from .message import ChatMessage, ToolMessage, SystemMessage
from .history_graph import HistoryGraph, LevelHistoryCursor

from .types import MessageKind, ModelResponse
from typing import Any, Iterator, Sequence

logger = logging.getLogger(__name__)


class ChatAgent:
    """Stores and mutates the message history for a single runtime level."""

    def __init__(
        self,
        *,
        client: Client,
        system_prompt: str | None = None,
        history_graph: HistoryGraph | None = None,
        history_cursor: LevelHistoryCursor | None = None,
    ):
        """Initialize a chat level, optionally seeding it with a system prompt."""
        self.client = client
        self.system_prompt = system_prompt
        self.history_graph = history_graph or HistoryGraph()
        self.history_cursor = history_cursor or self.history_graph.new_cursor()
        self._chat_history_proxy = _ChatHistoryProxy(agent=self)
        if self.system_prompt and not self.history_cursor.message_ids:
            self.history_cursor.append_message(
                self.client.build_system_message(content=self.system_prompt)
            )

    @property
    def chat_history(self) -> _ChatHistoryProxy:
        """Expose a list-like view of this level's graph-backed messages."""
        return self._chat_history_proxy

    @chat_history.setter
    def chat_history(self, messages: Sequence[ChatMessage]) -> None:
        """Replace this cursor with a graph-backed sequence of messages."""
        self.history_cursor = self.history_graph.new_cursor()
        self.history_cursor.extend_messages(messages)
        self._chat_history_proxy = _ChatHistoryProxy(agent=self)

    @property
    def last_step_id(self) -> str | None:
        """Return the latest model/debug step associated with this level."""
        return self.history_cursor.last_step_id

    @last_step_id.setter
    def last_step_id(self, step_id: str | None) -> None:
        """Set the latest model/debug step associated with this level."""
        self.history_cursor.last_step_id = step_id

    def get_message_ids(self) -> list[str]:
        """Return the graph message ids visible to this level."""
        return list(self.history_cursor.message_ids)

    def get_visible_system_prompt(self) -> str | None:
        """Return the system prompt currently visible in this level's cursor."""
        for message_id in self.history_cursor.message_ids:
            message = self.history_graph.get_message(message_id)
            if message.role == "system":
                return message.content
        return None

    def replace_message_content_versioned(
        self, *, message_id: str, content: str
    ) -> str:
        """Replace one cursor message with a new graph node and return its id."""
        if message_id not in self.history_cursor.message_ids:
            raise ValueError(f"Message '{message_id}' is not visible in this level.")
        source = self.history_graph.get_message(message_id)
        if source.content == content:
            return message_id
        replacement = self.history_graph.clone_message_with_content(
            node_id=message_id,
            content=content,
        )
        source.provider_metadata["superseded_by_message_id"] = replacement.id
        replacement.provider_metadata["supersedes_message_id"] = source.id
        index = self.history_cursor.message_ids.index(message_id)
        self.history_cursor.message_ids[index] = replacement.id
        return replacement.id

    def reset_history(self) -> None:
        """Start a disconnected history cursor while retaining the shared graph."""
        self.history_cursor = self.history_graph.new_cursor()
        self._chat_history_proxy = _ChatHistoryProxy(agent=self)
        if self.system_prompt:
            self.history_cursor.append_message(
                self.client.build_system_message(content=self.system_prompt)
            )

    def get_messages(
        self,
    ) -> list[dict[str, Any]]:
        """Return the current chat history serialized for the provider."""
        messages = self.history_cursor.get_messages()
        logger.debug("Serialized chat history", extra={"message_count": len(messages)})
        return messages

    def extend_messages(self, messages: Sequence[ChatMessage] | None) -> None:
        """Extend the history while preventing duplicated system prompts."""
        if messages is not None:
            self.history_cursor.extend_messages(
                [
                    message
                    for message in messages
                    if not isinstance(message, SystemMessage)
                ]
            )
            logger.debug(
                "Extended chat history",
                extra={
                    "added_messages": len(messages),
                    "message_count": len(self.chat_history),
                },
            )

    @staticmethod
    def _messages_to_dicts(
        messages: Sequence[ChatMessage],
    ) -> list[dict[str, Any]]:
        """Convert message objects into provider-ready dictionaries."""
        for message in messages:
            try:
                message.to_dict()
            except Exception:
                logger.exception(
                    "Failed to convert message to dict",
                    extra={
                        "message_type": type(message).__name__,
                        "message_content": message.content,
                    },
                )
        return [message.to_dict() for message in messages]

    def add_user_message(
        self,
        *,
        message: str,
        kind: MessageKind = "user",
    ) -> None:
        """Append a user message to the current history."""
        user_message = self.client.build_user_message(content=message)
        user_message.kind = kind
        self.history_cursor.append_message(user_message)
        logger.debug(
            "Added user message", extra={"message_count": len(self.chat_history)}
        )

    def add_assistant_message(
        self,
        *,
        text: str,
    ) -> None:
        """Append an assistant text message to the current history."""
        self.history_cursor.append_message(
            self.client.build_assistant_message(content=text)
        )
        logger.debug(
            "Added assistant message", extra={"message_count": len(self.chat_history)}
        )

    def add_message(self, *, message: ChatMessage) -> None:
        """Append one already constructed runtime message to this level."""
        self.history_cursor.append_message(message)
        logger.debug(
            "Added runtime message",
            extra={
                "role": message.role,
                "message_count": len(self.chat_history),
            },
        )

    def add_developer_message(
        self,
        *,
        message: str | None,
    ) -> None:
        """Append a developer message when one is provided."""
        if message is not None:
            self.history_cursor.append_message(
                self.client.build_developer_message(content=message)
            )
            logger.debug(
                "Added developer message",
                extra={"message_count": len(self.chat_history)},
            )

    def add_tool_result(
        self,
        *,
        content: str,
        tool_call_id: str,
        name: str | None = None,
        kind: MessageKind = "tool",
        visible_tool_call_id: str | None = None,
        metadata: EnvelopeMetadata | Mapping[str, Any] | None = None,
        call_arguments: Mapping[str, Any] | None = None,
        metadata_preview_char_limit: int = 20,
        depth: int = 0,
        level_path: tuple[str, ...] = (),
        include_envelope: bool = True,
    ) -> ToolMessage:
        """Append a tool result message with its semantic kind and runtime envelope."""
        message_content = str(content)
        if include_envelope:
            message_content = self._format_tool_result_content(
                content=str(content),
                tool_call_id=tool_call_id,
                name=name,
                visible_tool_call_id=visible_tool_call_id,
                metadata=metadata,
                call_arguments=call_arguments,
                metadata_preview_char_limit=metadata_preview_char_limit,
                depth=depth,
                level_path=level_path,
            )
        message = self.client.build_tool_message(
            content=message_content,
            tool_call_id=tool_call_id,
            name=name,
        )
        message.kind = kind
        self.history_cursor.append_message(message)
        logger.debug(
            "Added tool result",
            extra={
                "tool_call_id": tool_call_id,
                "tool_name": name,
                "message_count": len(self.chat_history),
            },
        )
        return message

    def replace_tool_result_content(
        self,
        *,
        message_id: str,
        content: str,
    ) -> None:
        """Replace a tool result body while preserving its existing YAML envelope."""
        node = self.history_graph.get_message(message_id)
        if node.role != "tool":
            raise ValueError(f"Message '{message_id}' is not a tool result.")
        envelope_end = node.content.find("\n----\n", len("----"))
        if not node.content.startswith("----\n") or envelope_end < 0:
            node.content = content
            return
        header_end = envelope_end + len("\n----\n")
        node.content = f"{node.content[:header_end]}{content}"

    def replace_tool_result_metadata(
        self,
        *,
        message_id: str,
        metadata: EnvelopeMetadata | Mapping[str, Any] | None,
        depth: int,
        level_path: tuple[str, ...],
        metadata_preview_char_limit: int = 20,
    ) -> None:
        """Replace a tool result metadata envelope while preserving its body."""
        node = self.history_graph.get_message(message_id)
        if node.role != "tool":
            raise ValueError(f"Message '{message_id}' is not a tool result.")
        parsed = self._split_tool_result_envelope(content=node.content)
        if parsed is None:
            return
        header, body = parsed
        node.content = self._format_tool_result_content(
            content=body,
            tool_call_id=str(header.get("tool_call_id") or ""),
            name=str(header.get("tool_name") or ""),
            metadata=metadata,
            metadata_preview_char_limit=metadata_preview_char_limit,
            depth=depth,
            level_path=level_path,
        )

    @staticmethod
    def _format_tool_result_content(
        *,
        content: str,
        tool_call_id: str,
        name: str | None,
        visible_tool_call_id: str | None = None,
        metadata: EnvelopeMetadata | Mapping[str, Any] | None = None,
        call_arguments: Mapping[str, Any] | None = None,
        metadata_preview_char_limit: int = 20,
        depth: int = 0,
        level_path: tuple[str, ...] = (),
    ) -> str:
        """Wrap tool output with a small YAML-like metadata header."""

        def yaml_quote(value: str) -> str:
            return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'

        header_lines = ["----"]
        output_id = visible_tool_call_id or tool_call_id
        if output_id:
            header_lines.append(f"tool_call_id: {yaml_quote(output_id)}")
        if name:
            header_lines.append(f"tool_name: {yaml_quote(name)}")
        metadata = ChatAgent._metadata_with_call_arguments(
            metadata=metadata,
            call_arguments=call_arguments,
            metadata_preview_char_limit=metadata_preview_char_limit,
        )
        envelope_metadata = render_envelope_metadata(
            metadata=metadata,
            level_path=level_path,
        )
        if envelope_metadata:
            header_lines.append("metadata:")
            header_lines.extend(f"  {line}" for line in envelope_metadata.splitlines())
        header_lines.append("----")
        header = "\n".join(header_lines)
        return f"{header}\n{content}"

    @staticmethod
    def _metadata_with_call_arguments(
        *,
        metadata: EnvelopeMetadata | Mapping[str, Any] | None,
        call_arguments: Mapping[str, Any] | None,
        metadata_preview_char_limit: int,
    ) -> EnvelopeMetadata | Mapping[str, Any] | None:
        """Return envelope metadata enriched with compact public call arguments."""
        if call_arguments is None:
            return metadata
        normalized = ensure_envelope_metadata(metadata)
        values = dict(normalized.values) if normalized is not None else {}
        values["args"] = compact_metadata_value(
            dict(call_arguments),
            edge_length=metadata_preview_char_limit,
        )
        return EnvelopeMetadata.from_values(values)

    @staticmethod
    def _split_tool_result_envelope(
        *, content: str
    ) -> tuple[Mapping[str, Any], str] | None:
        """Return a parsed envelope header and stripped body when present."""
        envelope_end = content.find("\n----\n", len("----"))
        if not content.startswith("----\n") or envelope_end < 0:
            return None
        raw_header = content[len("----\n") : envelope_end]
        parsed_header = yaml.safe_load(raw_header) or {}
        if not isinstance(parsed_header, Mapping):
            return None
        header_end = envelope_end + len("\n----\n")
        return parsed_header, content[header_end:]

    def add_response(
        self,
        *,
        response: ModelResponse,
    ) -> list[str]:
        """Append all assistant-side messages extracted from a model response."""
        extracted_messages = self.client.extract_messages(response)
        nodes = self.history_cursor.extend_messages(extracted_messages)
        logger.debug(
            "Added assistant response messages",
            extra={
                "added_messages": len(extracted_messages),
                "message_count": len(self.chat_history),
            },
        )
        return [node.id for node in nodes]


class _ChatHistoryProxy:
    """List-like compatibility facade over a graph-backed level cursor."""

    def __init__(self, *, agent: ChatAgent) -> None:
        """Bind the proxy to one chat agent."""
        self._agent = agent

    def __iter__(self) -> Iterator[ChatMessage]:
        """Iterate over rebuilt chat messages in cursor order."""
        return iter(self._messages())

    def __len__(self) -> int:
        """Return the number of messages visible to the cursor."""
        return len(self._agent.history_cursor.message_ids)

    def __getitem__(self, index: int | slice) -> ChatMessage | list[ChatMessage]:
        """Return one message or a list slice from the cursor."""
        return self._messages()[index]

    def __bool__(self) -> bool:
        """Return whether the cursor contains any messages."""
        return bool(self._agent.history_cursor.message_ids)

    def __deepcopy__(self, memo: dict[int, Any]) -> list[ChatMessage]:
        """Return a deep-copy compatible list of rebuilt messages."""
        import copy

        return copy.deepcopy(self._messages(), memo)

    def append(self, message: ChatMessage) -> None:
        """Append a message to the underlying graph cursor."""
        self._agent.history_cursor.append_message(message)

    def extend(self, messages: Sequence[ChatMessage]) -> None:
        """Append multiple messages to the underlying graph cursor."""
        self._agent.history_cursor.extend_messages(messages)

    def pop(self, index: int = -1) -> ChatMessage:
        """Remove and return a message from the cursor."""
        messages = self._messages()
        message = messages[index]
        node_id = self._agent.history_cursor.message_ids.pop(index)
        self._agent.history_graph.remove_message_if_unreferenced(
            node_id,
            cursors=[self._agent.history_cursor],
        )
        return message

    def clear(self) -> None:
        """Remove all message ids from this cursor."""
        self._agent.history_cursor.message_ids.clear()

    def to_list(self) -> list[ChatMessage]:
        """Return the cursor messages as a plain list."""
        return self._messages()

    def _messages(self) -> list[ChatMessage]:
        """Rebuild cursor messages as provider chat objects."""
        return self._agent.history_cursor.get_chat_messages(client=self._agent.client)
