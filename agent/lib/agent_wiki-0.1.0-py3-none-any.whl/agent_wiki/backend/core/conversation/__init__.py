"""Conversation message and response primitives."""
