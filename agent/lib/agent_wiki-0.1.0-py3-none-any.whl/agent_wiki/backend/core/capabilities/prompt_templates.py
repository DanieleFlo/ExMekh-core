"""Validate and render runtime placeholders in capability Markdown bodies."""

from __future__ import annotations

from dataclasses import dataclass
from difflib import get_close_matches
from pathlib import Path
import re
from typing import Any, Iterable, Mapping

from jinja2 import Environment, StrictUndefined, TemplateError

from agent_wiki.configs.text_catalog import get_runtime_text


BUILTIN_PROMPT_VARIABLES = frozenset(
    {
        "skill-name",
        "hds-name",
        "hds-capability-name",
        "level-path",
        "parent-level-path",
        "root-level-path",
        "parent-name",
        "root-name",
        "depth",
        "workroot",
    }
)
_NAME_PATTERN = r"[A-Za-z0-9][A-Za-z0-9._-]*"
_TOKEN_PATTERN = re.compile(
    rf"(?P<escaped>\\)?\{{\{{(?P<reference>!)?(?P<name>{_NAME_PATTERN})\}}\}}"
)
_JINJA_ENVIRONMENT = Environment(autoescape=False, undefined=StrictUndefined)


@dataclass(frozen=True, slots=True)
class PromptTemplateContext:
    """Store the resolved values available to one capability body."""

    skill_name: str
    hds_name: str
    hds_capability_name: str
    level_path: tuple[str, ...]
    workroot: Path
    custom_variables: Mapping[str, str]

    def variables(self) -> dict[str, str]:
        """Return built-in and custom variables for one rendering pass."""
        parent_path = self.level_path[:-1]
        values = dict(self.custom_variables)
        values.update(
            {
                "skill-name": self.skill_name,
                "hds-name": self.hds_name,
                "hds-capability-name": self.hds_capability_name,
                "level-path": _format_path(self.level_path),
                "parent-level-path": _format_path(parent_path),
                "root-level-path": _format_path(self.level_path[:1]),
                "parent-name": parent_path[-1] if parent_path else "",
                "root-name": self.level_path[0] if self.level_path else "",
                "depth": str(max(0, len(self.level_path) - 1)),
                "workroot": str(self.workroot),
            }
        )
        return values


@dataclass(frozen=True, slots=True)
class PromptTemplateInspection:
    """Describe placeholders found in one capability body."""

    source: str
    variables: tuple[str, ...]
    capability_references: tuple[str, ...]


def validate_custom_prompt_variables(
    variables: Mapping[str, str], *, owner: str
) -> None:
    """Reject invalid, non-string, or reserved custom prompt variables."""
    if not isinstance(variables, Mapping):
        raise TypeError(f"Prompt variables for {owner} must be a mapping.")
    for name, value in variables.items():
        if not isinstance(name, str) or re.fullmatch(_NAME_PATTERN, name) is None:
            raise ValueError(f"Prompt variable name {name!r} for {owner} is invalid.")
        if name in BUILTIN_PROMPT_VARIABLES:
            raise ValueError(f"Prompt variable '{name}' for {owner} is reserved.")
        if not isinstance(value, str):
            raise TypeError(f"Prompt variable '{name}' for {owner} must be a string.")


def inspect_prompt_template(*, body: str, source: str) -> PromptTemplateInspection:
    """Return the unescaped variables and references used by one body."""
    variables: list[str] = []
    references: list[str] = []
    for match in _TOKEN_PATTERN.finditer(body):
        if match.group("escaped"):
            continue
        target = references if match.group("reference") else variables
        name = match.group("name")
        if name not in target:
            target.append(name)
    return PromptTemplateInspection(source, tuple(variables), tuple(references))


def validate_prompt_template(
    *,
    body: str,
    source: str,
    variable_names: Iterable[str],
    capability_catalog: Mapping[str, Iterable[str]],
) -> PromptTemplateInspection:
    """Validate every unescaped placeholder in a capability body."""
    inspection = inspect_prompt_template(body=body, source=source)
    for name in inspection.capability_references:
        categories = sorted(
            category
            for category, names in capability_catalog.items()
            if name in set(names)
        )
        if not categories:
            all_names = {item for names in capability_catalog.values() for item in names}
            raise ValueError(
                get_runtime_text(
                    "prompt_templates.errors.unknown_capability",
                    source=source,
                    placeholder=f"{{{{!{name}}}}}",
                    suggestions=_suggest(name, all_names),
                )
            )
        if len(categories) > 1:
            raise ValueError(
                get_runtime_text(
                    "prompt_templates.errors.ambiguous_capability",
                    source=source,
                    placeholder=f"{{{{!{name}}}}}",
                    categories=", ".join(categories),
                )
            )
    return inspection


def render_prompt_template(
    *,
    body: str,
    source: str,
    context: PromptTemplateContext,
    capability_catalog: Mapping[str, Iterable[str]],
) -> str:
    """Validate and render a capability body in exactly one substitution pass."""
    variables = context.variables()
    validate_prompt_template(
        body=body,
        source=source,
        variable_names=variables,
        capability_catalog=capability_catalog,
    )

    aliases: dict[str, str] = {}

    def replace(match: re.Match[str]) -> str:
        """Map each token to a safe Jinja identifier for one render pass."""
        name = match.group("name")
        if match.group("escaped"):
            value = match.group(0)[1:]
        elif match.group("reference"):
            value = name
        elif name in variables:
            value = variables[name]
        else:
            value = match.group(0)
        alias = f"__agent_wiki_prompt_{len(aliases)}"
        aliases[alias] = value
        return "{{ " + alias + " }}"

    prepared = _TOKEN_PATTERN.sub(replace, body)
    try:
        return _JINJA_ENVIRONMENT.from_string(prepared).render(**aliases)
    except TemplateError as error:
        raise ValueError(
            get_runtime_text(
                "prompt_templates.errors.render",
                source=source,
                details=error,
            )
        ) from error


def build_capability_catalog(hds_config: Any) -> dict[str, set[str]]:
    """Build the graph-wide capability-name catalog with root precedence applied."""
    from .capability_roots import iter_existing_capability_dirs, resolve_capability_roots

    catalog: dict[str, set[str]] = {
        "tool": set(),
        "skill": set(),
        "exit-skill": set(),
        "exit-tool": set(),
        "hds": set(hds_config.get_node_names()),
    }
    for node in hds_config.iter_nodes():
        resolved = node._resolved_node_config
        if resolved is None:
            continue
        roots = resolve_capability_roots(
            config=resolved.config, workroot=resolved.workroot
        )
        catalog["tool"].update(
            path.name for path in iter_existing_capability_dirs(roots=roots.tool_roots)
        )
        catalog["skill"].update(
            path.name for path in iter_existing_capability_dirs(roots=roots.skill_roots)
        )
        exit_names = {
            path.name
            for path in iter_existing_capability_dirs(roots=roots.exit_skill_roots)
        }
        catalog["exit-skill"].update(exit_names)
        catalog["exit-tool"].update(f"{name}-tool" for name in exit_names)
    return catalog


def validate_loaded_prompt_templates(hds_config: Any) -> list[PromptTemplateInspection]:
    """Validate every static body in an already loaded HDS graph."""
    catalog = build_capability_catalog(hds_config)
    reports: list[PromptTemplateInspection] = []
    for node in hds_config.iter_nodes():
        hds = node._hds
        resolved = node._resolved_node_config
        if hds is None or resolved is None:
            continue
        variable_names = BUILTIN_PROMPT_VARIABLES | set(resolved.prompt_variables)
        reports.append(
            validate_prompt_template(
                body=hds.system_prompt,
                source=str(hds.source_path or f"HDS '{node.hds_name}'"),
                variable_names=variable_names,
                capability_catalog=catalog,
            )
        )
        _validate_skill_tree(
            skills=hds.sub_skills or [],
            source_prefix=f"HDS '{node.hds_name}'",
            variable_names=variable_names,
            capability_catalog=catalog,
            reports=reports,
        )
    return reports


def validate_prompt_templates(node_config: Any) -> list[PromptTemplateInspection]:
    """Load and validate prompt templates without constructing a DeepAgent."""
    from ..config.hds_config import HDSConfig

    return validate_loaded_prompt_templates(HDSConfig(node_config=node_config))


def inspect_prompt_templates(node_config: Any) -> list[PromptTemplateInspection]:
    """Return a read-only diagnostic inventory after validating the graph."""
    return validate_prompt_templates(node_config)


def _validate_skill_tree(
    *,
    skills: Iterable[Any],
    source_prefix: str,
    variable_names: set[str] | frozenset[str],
    capability_catalog: Mapping[str, Iterable[str]],
    reports: list[PromptTemplateInspection],
) -> None:
    """Validate regular-skill bodies recursively without touching exit templates."""
    for skill in skills:
        source = str(skill.source_path or f"{source_prefix} regular skill '{skill.name}'")
        reports.append(
            validate_prompt_template(
                body=skill.context,
                source=source,
                variable_names=variable_names,
                capability_catalog=capability_catalog,
            )
        )
        _validate_skill_tree(
            skills=skill.sub_skills or [],
            source_prefix=source,
            variable_names=variable_names,
            capability_catalog=capability_catalog,
            reports=reports,
        )


def _format_path(parts: tuple[str, ...]) -> str:
    """Format one model-facing level path."""
    return "/" + "/".join(parts) if parts else "/"


def _suggest(name: str, candidates: Iterable[str]) -> str:
    """Return deterministic close-name suggestions for validation feedback."""
    matches = get_close_matches(name, sorted(set(candidates)), n=5, cutoff=0.45)
    return ", ".join(matches) if matches else "none"
