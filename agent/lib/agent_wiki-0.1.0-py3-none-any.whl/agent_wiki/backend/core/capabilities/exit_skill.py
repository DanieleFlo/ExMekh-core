from __future__ import annotations

from dataclasses import dataclass
import hashlib
import importlib.util
import logging
from pathlib import Path
import sys
from typing import Any, Sequence, cast

from ..client import Client
from .capability_descriptions import (
    format_exit_tool_description,
    format_skill_description,
)
from .tool import Tool, ToolOutput
from ..outputs.exit_validation import ExitErrorSuggestionGenerator
from ..utils import parse_frontmatter_lines, require_string
from agent_wiki.backend.utils.handler_files_dirs import check_file, read_optional_file

from .capability_middleware import CapabilityMiddlewareRegistry
from .capability_roots import (
    find_named_capability_dir,
    iter_existing_capability_dirs,
)


logger = logging.getLogger(__name__)


@dataclass(slots=True, kw_only=True)
class ExitSkill:
    """Represents the non-descending skill that exposes a level-closing tool."""

    name: str
    description: str
    context: str
    tool: Tool
    error_suggestion_generator: ExitErrorSuggestionGenerator | None = None

    def get_runtime_name(self) -> str:
        """Return the provider-visible activation identifier."""
        return self.name

    def get_exit_tool_name(self) -> str:
        """Return the provider-visible name for the owned closing tool."""
        return f"{self.name}-tool"

    def to_llm_capability(
        self,
        *,
        client: Client,
        override_name: str | None = None,
        include_description: bool = True,
    ) -> dict[str, Any]:
        """Serialize the activation callable that injects the exit-skill context."""
        return client.build_function_tool(
            name=override_name or self.get_runtime_name(),
            description=(
                format_skill_description(self.description)
                if include_description
                else ""
            ),
            handler=_activate_exit_skill,
            strict=True,
        )

    def to_llm_exit_tool_capability(
        self,
        *,
        client: Client,
        override_name: str | None = None,
        include_description: bool = True,
    ) -> dict[str, Any]:
        """Serialize the owned closing tool exposed after activation."""
        return client.build_function_tool(
            name=override_name or self.get_exit_tool_name(),
            description=(
                format_exit_tool_description(self.tool.description)
                if include_description
                else ""
            ),
            handler=self.tool.handler,
            strict=self.tool.strict,
        )

    def execute(
        self, *, arguments: Any, injected_arguments: dict[str, Any] | None = None
    ) -> ToolOutput:
        """Execute the owned closing tool without opening a child level."""
        return self.tool.execute(
            arguments=arguments,
            injected_arguments=injected_arguments or {},
        )

    def render_skill_context(self) -> str:
        """Render the markdown context injected after activation."""
        return self.context.strip()

    @classmethod
    def load_exit_skills(
        cls, *, paths: Sequence[Path], prompt_file: str
    ) -> list[ExitSkill]:
        """Load every exit skill declared under the configured roots."""
        exit_skills: list[ExitSkill] = []
        seen_names: set[str] = set()
        for exit_skill_dir in iter_existing_capability_dirs(roots=paths):
            exit_skill = cls.load_exit_skill(
                paths=paths,
                name=exit_skill_dir.name,
                prompt_file=prompt_file,
            )
            runtime_name = exit_skill.get_runtime_name()
            if exit_skill.name in seen_names or runtime_name in seen_names:
                continue
            seen_names.add(exit_skill.name)
            seen_names.add(runtime_name)
            exit_skills.append(exit_skill)
            logger.debug(
                "Loaded exit skill capability",
                extra={
                    "exit_skill": exit_skill.name,
                    "runtime_name": runtime_name,
                    "exit_skill_dir": str(exit_skill_dir),
                },
            )
        return exit_skills

    @classmethod
    def load_exit_skill(
        cls, *, paths: Sequence[Path], name: str, prompt_file: str
    ) -> ExitSkill:
        """Load one exit skill and its owned tool from the filesystem."""
        exit_skill_dir = find_named_capability_dir(roots=paths, name=name)
        metadata = cls._metadata_from_prompt(
            prompt_path=exit_skill_dir / prompt_file,
            name=name,
        )
        tool = Tool.load_tool(path=exit_skill_dir)
        tool.name = f"{name}-tool"
        error_suggestion_generator = _load_error_suggestion_generator(
            exit_skill_dir=exit_skill_dir
        )
        exit_skill = CapabilityMiddlewareRegistry.apply_exit_skill_loaded(
            exit_skill=cls(
                name=name,
                description=metadata["description"],
                context=metadata["context"],
                tool=tool,
                error_suggestion_generator=error_suggestion_generator,
            )
        )
        logger.debug(
            "Loaded exit skill capability",
            extra={"exit_skill": exit_skill.name, "exit_skill_dir": str(exit_skill_dir)},
        )
        return exit_skill

    @staticmethod
    def _metadata_from_prompt(*, prompt_path: Path, name: str) -> dict[str, str]:
        """Parse an exit-skill markdown file into metadata and context."""
        check_file(prompt_path)
        raw_content = read_optional_file(prompt_path)
        if not raw_content:
            raise ValueError(f"Exit skill prompt for '{name}' is empty.")

        lines = raw_content.splitlines()
        if not lines or lines[0].strip() != "---":
            raise ValueError(
                "Exit skill markdown must start with a frontmatter block delimited by '---'"
            )

        closing_index = None
        for index in range(1, len(lines)):
            if lines[index].strip() == "---":
                closing_index = index
                break
        if closing_index is None:
            raise ValueError(
                "Exit skill markdown has an unterminated frontmatter block"
            )

        frontmatter = parse_frontmatter_lines(lines=lines[1:closing_index])
        return {
            "description": require_string(
                metadata=frontmatter,
                key="description",
            ),
            "context": "\n".join(lines[closing_index + 1 :]).strip(),
        }


def _activate_exit_skill() -> dict[str, object]:
    """Return an empty activation payload; DeepAgent injects the context."""
    return {}


def _load_error_suggestion_generator(
    *, exit_skill_dir: Path
) -> ExitErrorSuggestionGenerator | None:
    """Load an optional error-suggestion generator from one exit-skill directory."""
    module_path = exit_skill_dir / "error_suggestions.py"
    if not module_path.exists():
        return None

    path_digest = hashlib.sha256(str(module_path.resolve()).encode()).hexdigest()[:16]
    module_name = f"_agent_wiki_exit_error_suggestions_{path_digest}"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load exit suggestion module: {module_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        sys.modules.pop(module_name, None)

    generator = getattr(module, "generate_error_suggestions", None)
    if generator is None:
        raise ValueError(
            f"Exit suggestion module must expose generate_error_suggestions: {module_path}"
        )
    if not callable(generator):
        raise TypeError(
            f"generate_error_suggestions must be callable: {module_path}"
        )
    return cast(ExitErrorSuggestionGenerator, generator)
