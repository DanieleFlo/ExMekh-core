from __future__ import annotations

import json
import logging
from dataclasses import dataclass
import inspect
from functools import wraps
from pathlib import Path
from string import Template
from types import UnionType
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Mapping,
    Sequence,
    Union,
    cast,
    get_args,
    get_origin,
    get_type_hints,
)
from omegaconf import DictConfig, OmegaConf
from agent_wiki.backend.interface.envelope import (
    EnvelopeMetadata,
    ensure_envelope_metadata,
)
from agent_wiki.backend.interface.tool_hitl import ToolHITLResolverInterface
from agent_wiki.backend.utils.handler_files_dirs import check_dir

from .capability_middleware import (
    CapabilityMiddlewareAbort,
    CapabilityMiddlewareRegistry,
)
from .capability_descriptions import format_tool_description
from .dynamic_modules import load_directory_modules

from typing import TYPE_CHECKING
from pydantic import BaseModel

if TYPE_CHECKING:
    from ..client import Client
    from agent_wiki.backend.interface.interaction import (
        InteractionRequest,
        InteractionResponse,
    )


ToolBeforeMiddleware = Callable[..., "ToolBeforeResult | None"]
ToolAfterMiddleware = Callable[..., "ToolAfterResult | None"]

ERROR_MESSAGES_FILE = "msg_error.yaml"
_LOGGER = logging.getLogger(__name__)
_DEFAULT_ERROR_MESSAGES = {
    "invalid_arguments": "Error: invalid arguments for $tool_name: $error",
    "invalid_arguments_object": "Error: arguments for $tool_name must be a JSON object.",
    "before_middleware": "Error: failed before executing $tool_name.",
    "type_error": "Error while executing $tool_name: $error",
    "unexpected": "Error: $tool_name failed unexpectedly. Check logs for details.",
    "after_middleware": "Error: failed after executing $tool_name.",
    "serialization": "Error: $tool_name returned a value that could not be serialized.",
}


INJECTED_TOOL_ARGUMENTS = {
    "chat_history",
    "model_name",
    "client",
    "config",
    "available_tools",
    "current_skill",
    "current_hds",
    "parent_hds",
    "child_hds_nodes",
    "hds_node_path",
    "workroot",
    "tool_output_awareness",
    "tool_output_awareness_default_page_size",
    "tool_output_awareness_max_page_size",
    "tool_output_description_token_limit",
    "tool_output_content_token_limit",
    "tool_output_ignored_tools",
    "hds_context",
    "runtime_chat_history",
    "dynamic_pipeline_runtime",
    "runtime_tool_call_id",
    "user_question_runtime",
}


class ToolOutput(str):
    """Represent a tool result plus optional YAML metadata for the runtime envelope."""

    result: str | None
    metadata: EnvelopeMetadata | None
    error_kind: str | None

    def __new__(
        cls,
        *,
        result: str | None = None,
        metadata: EnvelopeMetadata | Mapping[str, Any] | None = None,
        error_kind: str | None = None,
    ) -> "ToolOutput":
        """Build a string-compatible output carrying separate result metadata."""
        text_result = result if result is not None else ""
        instance = super().__new__(cls, text_result)
        instance.result = result
        instance.metadata = ensure_envelope_metadata(metadata)
        instance.error_kind = error_kind
        return instance


def format_tool_metadata(values: Mapping[str, Any]) -> EnvelopeMetadata | None:
    """Render compact YAML metadata from scalar tool values."""
    return EnvelopeMetadata.from_values(values)


def normalize_tool_output(value: Any) -> ToolOutput:
    """Normalize legacy handler returns into the unified tool-output type."""
    if isinstance(value, ToolOutput):
        return value

    if isinstance(value, str):
        return ToolOutput(result=value)

    try:
        return ToolOutput(result=json.dumps(value, ensure_ascii=False))
    except Exception as exc:
        raise TypeError("Tool result could not be serialized.") from exc


@dataclass(slots=True, kw_only=True)
class _ToolMetadata:
    """Stores the common metadata shared by runtime tools and loaded definitions."""

    name: str
    description: str
    parameters: Dict[str, Any] | None = None
    error_messages: Dict[str, str] | None = None


@dataclass(frozen=True, slots=True, kw_only=True)
class ToolBeforeResult:
    """Describe tool arguments after before-middleware execution."""

    arguments: dict[str, Any]


@dataclass(frozen=True, slots=True, kw_only=True)
class ToolAfterResult:
    """Describe tool result changes after handler execution."""

    result: Any
    metadata: EnvelopeMetadata | Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True, kw_only=True)
class ToolMiddleware:
    """Stores optional per-tool execution middleware callbacks."""

    before: ToolBeforeMiddleware | None = None
    after: ToolAfterMiddleware | None = None


@dataclass(frozen=True, slots=True, kw_only=True)
class ToolHITL:
    """Configure human approval behavior for one regular tool."""

    resolver: ToolHITLResolverInterface
    denial_message: str
    allow_argument_modification: bool = False
    allow_denial_override: bool = False
    title: str | None = None


@dataclass(frozen=True, slots=True, kw_only=True)
class ToolHITLContext:
    """Provide a tool-specific resolver with one external HITL decision."""

    request: InteractionRequest
    response: InteractionResponse
    original_arguments: Mapping[str, Any]
    policy: ToolHITL


@dataclass(frozen=True, slots=True, kw_only=True)
class ToolHITLResolution:
    """Tell the runtime whether to execute a tool or return a denial result."""

    execute: bool
    arguments: Mapping[str, Any] | None = None
    denial_message: str | None = None

    def __post_init__(self) -> None:
        """Ensure execution and denial fields form an unambiguous result."""
        if self.execute and self.denial_message is not None:
            raise ValueError("An executable HITL resolution cannot deny the tool.")
        if not self.execute and not str(self.denial_message or "").strip():
            raise ValueError("A denied HITL resolution requires a denial message.")


class StandardToolHITLResolver(ToolHITLResolverInterface):
    """Resolve the standard approve, deny, and argument-modification actions."""

    def resolve(self, context: ToolHITLContext) -> ToolHITLResolution:
        """Convert one standard interaction response into a tool resolution."""
        response = context.response
        policy = context.policy
        if response.action == "approve":
            return ToolHITLResolution(
                execute=True,
                arguments=dict(context.original_arguments),
            )
        if response.action == "modify":
            if not policy.allow_argument_modification:
                raise ValueError(
                    "This HITL policy does not allow argument modification."
                )
            arguments = response.payload.get("arguments")
            if not isinstance(arguments, Mapping):
                raise ValueError("A modify response requires object arguments.")
            return ToolHITLResolution(execute=True, arguments=dict(arguments))
        if response.action == "deny":
            denial_message = policy.denial_message
            if policy.allow_denial_override and response.content is not None:
                if not response.content.strip():
                    raise ValueError("A HITL denial override cannot be blank.")
                denial_message = response.content
            return ToolHITLResolution(
                execute=False,
                denial_message=denial_message,
            )
        raise ValueError(f"Unsupported HITL response action: {response.action}")


@dataclass(slots=True, kw_only=True)
class Tool(_ToolMetadata):
    """Represents an executable capability exposed to the model as a function tool."""

    handler: Callable[..., Any]
    strict: bool = True
    middleware: ToolMiddleware | None = None
    hitl: ToolHITL | None = None
    reusable_input_fields: tuple[str, ...] = ()

    def get_runtime_name(self) -> str:
        """Return the provider-visible capability identifier."""
        return self.name

    def get_model_description(self) -> str:
        """Return the description plus reusable-input guidance when applicable."""
        description = format_tool_description(self.description)
        if not self.reusable_input_fields:
            return description
        from agent_wiki.configs.text_catalog import get_capability_text

        guidance = get_capability_text(
            "descriptions.tool_output_references",
            fields=", ".join(self.reusable_input_fields),
        )
        return f"{description} {guidance}"

    def to_llm_capability(
        self,
        *,
        client: Client,
    ) -> Dict[str, Any]:
        """Serialize the tool into the provider-specific capability payload."""
        capability = client.build_function_tool(
            name=self.get_runtime_name(),
            description=self.get_model_description(),
            handler=self.handler,
            strict=self.strict,
        )
        if self.reusable_input_fields:
            from ..outputs.tool_input_references import (
                build_tool_output_references_schema,
            )

            function = capability.get("function", capability)
            parameters = function.setdefault(
                "parameters", build_handler_parameters_schema(self.handler)
            )
            properties = parameters.setdefault("properties", {})
            properties["tool_output_references"] = build_tool_output_references_schema(
                self.reusable_input_fields
            )
            required = parameters.get("required")
            if isinstance(required, list):
                parameters["required"] = [
                    field
                    for field in required
                    if field not in self.reusable_input_fields
                ]
                if not parameters["required"]:
                    parameters.pop("required")
        return capability

    def execute(
        self,
        *,
        arguments: Mapping[str, Any] | str | None,
        injected_arguments: Mapping[str, Any] | None = None,
    ) -> ToolOutput:
        """Execute the handler and normalize the return value into a ToolOutput."""
        try:
            parsed_arguments = self.parse_arguments(arguments)
            if self.reusable_input_fields:
                from ..outputs.tool_input_references import (
                    resolve_tool_input_references,
                )

                injected = injected_arguments or {}
                parsed_arguments = resolve_tool_input_references(
                    arguments=parsed_arguments,
                    reusable_input_fields=self.reusable_input_fields,
                    chat_history=injected.get("chat_history"),
                    tool_output_awareness=injected.get("tool_output_awareness"),
                    description_token_limit=int(
                        injected.get("tool_output_description_token_limit", 10)
                    ),
                    ignored_tools=injected.get("tool_output_ignored_tools"),
                )
        except json.JSONDecodeError as exc:
            return ToolOutput(
                result=self.format_error("invalid_arguments", error=exc),
                error_kind="invalid_tool_call",
            )
        except ValueError as exc:
            from ..outputs.tool_input_references import ToolInputReferenceError

            if isinstance(exc, ToolInputReferenceError):
                return ToolOutput(
                    result=self.format_error("invalid_arguments", error=exc),
                    error_kind="invalid_tool_call",
                )
            return ToolOutput(
                result=self.format_error("invalid_arguments_object", error=exc),
                error_kind="invalid_tool_call",
            )
        except Exception as exc:
            _LOGGER.exception("Failed to parse tool arguments for %s", self.name)
            return ToolOutput(
                result=self.format_error("invalid_arguments", error=exc),
                error_kind="invalid_tool_call",
            )

        try:
            if injected_arguments:
                parsed_arguments = self._merge_injected_arguments(
                    parsed_arguments=parsed_arguments,
                    injected_arguments=injected_arguments,
                )
        except Exception as exc:
            _LOGGER.exception("Failed to merge injected arguments for %s", self.name)
            return ToolOutput(
                result=self.format_error("invalid_arguments", error=exc),
                error_kind="invalid_tool_call",
            )

        try:
            parsed_arguments = self._apply_before_middleware(
                arguments=parsed_arguments,
                injected_arguments=injected_arguments or {},
            )
        except CapabilityMiddlewareAbort as abort:
            return ToolOutput(result=abort.message)
        except Exception as exc:
            _LOGGER.exception("Before middleware failed for %s", self.name)
            return ToolOutput(
                result=self.format_error("before_middleware", error=exc),
                error_kind="tool_execution",
            )

        try:
            result = self.handler(**parsed_arguments)
        except TypeError as exc:
            return ToolOutput(
                result=self.format_error("type_error", error=exc),
                error_kind="invalid_tool_call",
            )
        except Exception as exc:
            _LOGGER.exception("Tool handler failed unexpectedly for %s", self.name)
            return ToolOutput(
                result=self.format_error("unexpected", error=exc),
                error_kind="tool_execution",
            )

        try:
            after_result = self._apply_after_middleware(
                result=result,
                arguments=parsed_arguments,
                injected_arguments=injected_arguments or {},
            )
        except Exception as exc:
            _LOGGER.exception("After middleware failed for %s", self.name)
            return ToolOutput(
                result=self.format_error("after_middleware", error=exc),
                error_kind="tool_execution",
            )

        try:
            tool_output = normalize_tool_output(after_result.result)
            if after_result.metadata is not None:
                tool_output = ToolOutput(
                    result=tool_output.result,
                    metadata=after_result.metadata,
                    error_kind=tool_output.error_kind,
                )
            return tool_output
        except Exception as exc:
            _LOGGER.exception("Failed to serialize result for %s", self.name)
            return ToolOutput(
                result=self.format_error("serialization", error=exc),
                error_kind="tool_execution",
            )

    def validate_call_arguments(
        self,
        *,
        arguments: Mapping[str, Any] | str | None,
        injected_arguments: Mapping[str, Any] | None = None,
    ) -> tuple[dict[str, Any] | None, ToolOutput | None]:
        """Validate one call without running middleware or the tool handler."""
        try:
            parsed_arguments = self.parse_arguments(arguments)
            if self.reusable_input_fields:
                from ..outputs.tool_input_references import (
                    resolve_tool_input_references,
                )

                injected = injected_arguments or {}
                parsed_arguments = resolve_tool_input_references(
                    arguments=parsed_arguments,
                    reusable_input_fields=self.reusable_input_fields,
                    chat_history=injected.get("chat_history"),
                    tool_output_awareness=injected.get("tool_output_awareness"),
                    description_token_limit=int(
                        injected.get("tool_output_description_token_limit", 10)
                    ),
                    ignored_tools=injected.get("tool_output_ignored_tools"),
                )
            merged_arguments = self._merge_injected_arguments(
                parsed_arguments=parsed_arguments,
                injected_arguments=injected_arguments or {},
            )
            inspect.signature(self.handler).bind(**merged_arguments)
        except json.JSONDecodeError as exc:
            return None, ToolOutput(
                result=self.format_error("invalid_arguments", error=exc),
                error_kind="invalid_tool_call",
            )
        except (TypeError, ValueError) as exc:
            return None, ToolOutput(
                result=self.format_error("invalid_arguments", error=exc),
                error_kind="invalid_tool_call",
            )
        except Exception as exc:
            _LOGGER.exception("Failed to validate tool arguments for %s", self.name)
            return None, ToolOutput(
                result=self.format_error("invalid_arguments", error=exc),
                error_kind="invalid_tool_call",
            )
        return parsed_arguments, None

    def format_error(self, key: str, **values: object) -> str:
        """Return one local model-facing error message."""
        messages = self.error_messages or {}
        template = messages.get(key) or _DEFAULT_ERROR_MESSAGES.get(key)
        if template is None:
            template = _DEFAULT_ERROR_MESSAGES["unexpected"]
        substitutions = {"tool_name": self.name, **values}
        string_values = {name: str(value) for name, value in substitutions.items()}
        return Template(template).safe_substitute(string_values)

    def _apply_before_middleware(
        self,
        *,
        arguments: dict[str, Any],
        injected_arguments: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Run this tool's before middleware when one is attached."""
        if self.middleware is None or self.middleware.before is None:
            return dict(arguments)
        result = self.middleware.before(
            tool=self,
            arguments=dict(arguments),
            injected_arguments=injected_arguments,
        )
        if result is None:
            return dict(arguments)
        if not isinstance(result, ToolBeforeResult):
            raise TypeError(
                "Tool before middleware must return ToolBeforeResult or None, "
                f"got {type(result).__name__}."
            )
        return dict(result.arguments)

    def _apply_after_middleware(
        self,
        *,
        result: Any,
        arguments: dict[str, Any],
        injected_arguments: Mapping[str, Any],
    ) -> ToolAfterResult:
        """Run this tool's after middleware when one is attached."""
        if self.middleware is None or self.middleware.after is None:
            return ToolAfterResult(result=result)
        middleware_result = self.middleware.after(
            tool=self,
            result=result,
            arguments=dict(arguments),
            injected_arguments=injected_arguments,
        )
        if middleware_result is None:
            return ToolAfterResult(result=result)
        if not isinstance(middleware_result, ToolAfterResult):
            raise TypeError(
                "Tool after middleware must return ToolAfterResult or None, "
                f"got {type(middleware_result).__name__}."
            )
        return ToolAfterResult(
            result=middleware_result.result,
            metadata=ensure_envelope_metadata(middleware_result.metadata),
        )

    @staticmethod
    def parse_arguments(arguments: Mapping[str, Any] | str | None) -> dict[str, Any]:
        """Parse tool call arguments coming from the provider payload."""
        if arguments is None:
            return {}

        if isinstance(arguments, Mapping):
            return dict(arguments)

        raw_arguments = arguments.strip()
        if not raw_arguments:
            return {}

        loaded = json.loads(raw_arguments)

        if not isinstance(loaded, dict):
            raise ValueError("Tool arguments must be a JSON object")

        return loaded

    def _merge_injected_arguments(
        self,
        *,
        parsed_arguments: dict[str, Any],
        injected_arguments: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Inject runtime values only when the handler signature accepts them."""
        signature = inspect.signature(self.handler)
        accepts_var_keyword = any(
            parameter.kind == inspect.Parameter.VAR_KEYWORD
            for parameter in signature.parameters.values()
        )

        merged_arguments = dict(parsed_arguments)
        for name, value in injected_arguments.items():
            if name in merged_arguments:
                continue
            if accepts_var_keyword or name in signature.parameters:
                merged_arguments[name] = value

        return merged_arguments

    @staticmethod
    def load_tools(
        *, path: Path | None = None, paths: Sequence[Path] | None = None
    ) -> List[Tool]:
        """Load every tool definition found in a capability directory."""
        tools: list[Tool] = []
        seen_names: set[str] = set()
        for tool_root in Tool._normalize_loader_paths(path=path, paths=paths):
            if not tool_root.exists():
                continue
            check_dir(path=tool_root)
            for tool_dir in sorted(
                child for child in tool_root.iterdir() if child.is_dir()
            ):
                tool_definition = ToolDefinition.load_from_directory(tool_dir)
                if tool_definition is None:
                    continue

                built_tool = tool_definition.build_tool()
                runtime_name = built_tool.get_runtime_name()
                if built_tool.name in seen_names or runtime_name in seen_names:
                    continue
                seen_names.add(built_tool.name)
                seen_names.add(runtime_name)
                tools.append(built_tool)
                _LOGGER.debug(
                    "Loaded tool capability",
                    extra={
                        "tool_name": built_tool.name,
                        "runtime_name": runtime_name,
                        "tool_dir": str(tool_dir),
                    },
                )

        return tools

    @staticmethod
    def load_tool(
        *,
        path: Path | None = None,
        paths: Sequence[Path] | None = None,
        name: str | None = None,
    ) -> Tool:
        """Load a single tool from its directory."""
        if name is not None:
            for tool_root in Tool._normalize_loader_paths(path=path, paths=paths):
                tool_path = tool_root / name
                if not tool_path.exists():
                    continue
                check_dir(path=tool_path)
                tool_definition = ToolDefinition.load_from_directory(tool_path)
                if tool_definition is None:
                    continue
                tool = tool_definition.build_tool()
                _LOGGER.debug(
                    "Loaded named tool capability",
                    extra={"tool_name": tool.name, "tool_dir": str(tool_path)},
                )
                return tool
            raise ValueError(f"No tool found with name: {name}")

        if path is None:
            raise ValueError(
                "Either 'path' or 'name' must be provided when loading one tool."
            )

        check_dir(path=path)
        tool_definition = ToolDefinition.load_from_directory(path)
        if tool_definition is None:
            raise ValueError(f"No tool found in directory: {path}")

        tool = tool_definition.build_tool()
        _LOGGER.debug(
            "Loaded tool capability",
            extra={"tool_name": tool.name, "tool_dir": str(path)},
        )
        return tool

    @staticmethod
    def _normalize_loader_paths(
        *, path: Path | None, paths: Sequence[Path] | None
    ) -> list[Path]:
        """Normalize one or many capability roots into a concrete ordered list."""
        if paths is not None:
            normalized = [item.resolve() for item in paths]
            if not normalized:
                raise ValueError("At least one tool loader path is required.")
            return normalized
        if path is None:
            raise ValueError("A tool loader path is required.")
        return [path.resolve()]


@dataclass(slots=True, kw_only=True)
class ToolDefinition(_ToolMetadata):
    """Represents the filesystem-loaded description of a tool before instantiation."""

    handler: Callable[..., Any]
    tool_dir: Path | None = None
    middleware: ToolMiddleware | None = None
    hitl: ToolHITL | None = None
    reusable_input_fields: tuple[str, ...] = ()

    def build_tool(self) -> Tool:
        """Instantiate the runtime tool."""
        return CapabilityMiddlewareRegistry.apply_tool_loaded(
            tool=Tool(
                name=self.name,
                description=self.description,
                parameters=self.parameters,
                error_messages=self.error_messages,
                handler=self.handler,
                middleware=self.middleware,
                hitl=self.hitl,
                reusable_input_fields=self.reusable_input_fields,
            )
        )

    @classmethod
    def load_from_directory(cls, tool_dir: Path) -> ToolDefinition | None:
        """Load the decorated tool definition exposed by a tool directory."""
        main_file = tool_dir / "main.py"
        error_messages_file = tool_dir / ERROR_MESSAGES_FILE

        if not main_file.exists():
            return None

        if not error_messages_file.exists():
            raise FileNotFoundError(
                f"Missing required {ERROR_MESSAGES_FILE} for tool directory: {tool_dir}"
            )

        discovered_tools: list[ToolDefinition] = []
        with load_directory_modules(directory=tool_dir, files=[main_file]) as modules:
            module = modules[0]
            for value in vars(module).values():
                tool_definition = getattr(value, "__tool__", None)
                if isinstance(tool_definition, cls):
                    discovered_tools.append(tool_definition)

        if not discovered_tools:
            return None

        if len(discovered_tools) > 1:
            names = ", ".join(tool.name for tool in discovered_tools)
            raise ValueError(
                f"Expected exactly one @sign_tool in '{tool_dir}', found {len(discovered_tools)}: {names}"
            )

        discovered_tool = discovered_tools[0]
        discovered_tool.error_messages = load_tool_error_messages(error_messages_file)
        return discovered_tool


def build_handler_parameters_schema(handler: Callable[..., Any]) -> Dict[str, Any]:
    """Infer a JSON schema for the public arguments of a tool handler."""
    signature = inspect.signature(handler)
    type_hints = get_type_hints(handler)
    properties: Dict[str, Any] = {}
    required: list[str] = []

    for parameter in signature.parameters.values():
        if parameter.kind not in (
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ):
            continue

        if parameter.name == "self":
            continue

        if parameter.name in INJECTED_TOOL_ARGUMENTS:
            continue

        resolved_annotation = type_hints.get(parameter.name, parameter.annotation)
        schema = _annotation_to_schema(resolved_annotation)
        properties[parameter.name] = schema

        if parameter.default is inspect.Signature.empty:
            required.append(parameter.name)

    payload: Dict[str, Any] = {
        "type": "object",
        "properties": properties,
        "additionalProperties": False,
    }

    if required:
        payload["required"] = required

    return payload


def load_tool_error_messages(path: Path) -> Dict[str, str]:
    """Load and flatten one tool-local error message catalog."""
    loaded = OmegaConf.load(path)
    if not isinstance(loaded, DictConfig):
        raise TypeError(f"Tool error catalog must be a mapping: {path}")
    flattened: dict[str, str] = {}
    _flatten_error_messages(node=loaded, prefix="", output=flattened)
    return flattened


def get_local_tool_error_text(file_path: str | Path, key: str, **values: object) -> str:
    """Resolve one message from the caller tool's local error catalog."""
    catalog_path = Path(file_path).resolve().parent / ERROR_MESSAGES_FILE
    messages = load_tool_error_messages(catalog_path)
    template = messages.get(key)
    if template is None:
        raise KeyError(f"Unknown tool error key '{key}' in {catalog_path}")
    substitutions = {name: str(value) for name, value in values.items()}
    return Template(template).safe_substitute(substitutions)


def _flatten_error_messages(
    *, node: object, prefix: str, output: dict[str, str]
) -> None:
    """Flatten nested YAML mappings into dotted message keys."""
    if isinstance(node, DictConfig):
        for key, value in node.items():
            next_prefix = f"{prefix}.{key}" if prefix else str(key)
            _flatten_error_messages(node=value, prefix=next_prefix, output=output)
        return

    if not isinstance(node, str):
        raise TypeError(f"Tool error message '{prefix}' must be a string.")

    output[prefix] = node


def _annotation_to_schema(annotation: Any) -> Dict[str, Any]:
    """Map a Python type annotation to the subset of JSON Schema used by providers."""
    if annotation is inspect.Signature.empty:
        return {"type": "string"}

    origin = get_origin(annotation)
    args = get_args(annotation)

    if origin in (Union, UnionType):
        return _union_annotation_to_schema(args)

    if annotation is type(None):
        return {"type": "null"}
    if annotation is str:
        return {"type": "string"}
    if annotation is int:
        return {"type": "integer"}
    if annotation is float:
        return {"type": "number"}
    if annotation is bool:
        return {"type": "boolean"}
    if inspect.isclass(annotation) and issubclass(annotation, BaseModel):
        return _inline_pydantic_schema(annotation.model_json_schema())
    if annotation is dict or origin in (dict, Dict, Mapping):
        return {"type": "object", "additionalProperties": True}
    if annotation is list or origin in (list, List, Sequence):
        item_annotation = args[0] if args else Any
        return {
            "type": "array",
            "items": _annotation_to_schema(item_annotation),
        }

    return {"type": "string"}


def _inline_pydantic_schema(schema: Mapping[str, Any]) -> Dict[str, Any]:
    """Inline local Pydantic definitions so nested tool schemas remain portable."""
    definitions = schema.get("$defs", {})

    def resolve(value: Any) -> Any:
        """Resolve one schema node recursively against the root definitions."""
        if isinstance(value, Mapping):
            reference = value.get("$ref")
            if isinstance(reference, str) and reference.startswith("#/$defs/"):
                name = reference.rsplit("/", 1)[-1]
                target = definitions.get(name)
                if isinstance(target, Mapping):
                    return resolve(target)
            return {
                str(key): resolve(item) for key, item in value.items() if key != "$defs"
            }
        if isinstance(value, list):
            return [resolve(item) for item in value]
        return value

    return cast(Dict[str, Any], resolve(schema))


def _union_annotation_to_schema(args: tuple[Any, ...]) -> Dict[str, Any]:
    """Return an anyOf schema that preserves every distinct union member."""
    variants: list[Dict[str, Any]] = []
    for argument in args:
        schema = _annotation_to_schema(argument)
        if schema not in variants:
            variants.append(schema)
    if not variants:
        return {"type": "string"}
    if len(variants) == 1:
        return variants[0]
    return {"anyOf": variants}


def sign_tool(
    *,
    name: str | None = None,
    short_description: str | None = None,
    path_short_description: Path | None = None,
    reusable_input_fields: Sequence[str] = (),
):
    """Decorate a Python callable so it can be discovered as a filesystem tool."""

    def decorator(func: Callable):
        """Attach a ToolDefinition to the decorated callable."""
        # ----------------------------
        # description
        # ----------------------------
        if path_short_description:
            if not path_short_description.exists():
                raise FileNotFoundError(path_short_description)
            desc = path_short_description.read_text(encoding="utf-8").strip()
        elif short_description:
            desc = short_description.strip()
        elif func.__doc__:
            desc = func.__doc__.strip()
        else:
            desc = ""

        # ----------------------------
        # name
        # ----------------------------
        if name:
            tool_name = name.strip()
        else:
            if func.__name__ == "main":
                tool_name = Path(func.__code__.co_filename).parent.name
            else:
                tool_name = func.__name__

        tool_def = ToolDefinition(
            name=tool_name,
            description=desc,
            handler=func,
            tool_dir=Path(func.__code__.co_filename).parent,
            middleware=getattr(func, "__tool_middleware__", None),
            hitl=getattr(func, "__tool_hitl__", None),
            reusable_input_fields=tuple(dict.fromkeys(reusable_input_fields)),
        )

        # attach metadata
        setattr(cast(Any, func), "__tool__", tool_def)

        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        return wrapper

    return decorator


def sign_hitl(
    *,
    resolver: ToolHITLResolverInterface,
    denial_message: str,
    allow_argument_modification: bool = False,
    allow_denial_override: bool = False,
    title: str | None = None,
):
    """Require an external decision before executing a decorated regular tool."""
    if not isinstance(resolver, ToolHITLResolverInterface):
        raise TypeError(
            "HITL resolver must implement ToolHITLResolverInterface.resolve()."
        )
    if not denial_message.strip():
        raise ValueError("HITL denial_message must contain non-space text.")

    def decorator(func: Callable):
        """Attach immutable HITL policy metadata before @sign_tool runs."""
        if hasattr(func, "__tool__"):
            raise ValueError("@sign_hitl must be placed below @sign_tool.")
        setattr(
            func,
            "__tool_hitl__",
            ToolHITL(
                resolver=resolver,
                denial_message=denial_message,
                allow_argument_modification=allow_argument_modification,
                allow_denial_override=allow_denial_override,
                title=title,
            ),
        )
        return func

    return decorator


def with_middleware(
    *,
    before: ToolBeforeMiddleware | None = None,
    after: ToolAfterMiddleware | None = None,
):
    """Attach per-tool execution middleware to a decorated handler."""

    def decorator(func: Callable):
        """Store middleware metadata without wrapping the function signature."""
        setattr(func, "__tool_middleware__", ToolMiddleware(before=before, after=after))
        return func

    return decorator
