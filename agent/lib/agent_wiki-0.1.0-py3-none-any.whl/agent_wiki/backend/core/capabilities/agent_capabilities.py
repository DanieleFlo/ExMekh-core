from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Sequence, Union

from .capability_descriptions import (
    format_exit_tool_description,
    format_skill_description,
)
from .deep_skill import DeepSkill
from .exit_skill import ExitSkill
from agent_wiki.backend.core.observability.runtime_events import CapabilitySnapshot
from .tool import Tool
from ..client import Client


CAPABILITY_SUMMARY_START = "<!-- agent-wiki:capabilities:start -->"
CAPABILITY_SUMMARY_END = "<!-- agent-wiki:capabilities:end -->"


@dataclass(slots=True)
class AgentCapabilities:
    """Groups the tools and deep skills visible inside one runtime level."""

    exit: ExitSkill
    tools: List[Tool] | None = None
    skills: List[DeepSkill] | None = None
    inherited_tools: List[Tool] | None = None
    level_path: tuple[str, ...] = ()
    canonical_prefix: tuple[str, ...] = ()
    _exit_tool_enabled: bool = field(default=False, init=False)
    _capabilities: List[Tool | DeepSkill | ExitSkill] = field(default_factory=list)
    _parent: AgentCapabilities | None = field(default=None, init=False, repr=False)
    _canonical_names_by_capability: dict[int, str] = field(
        default_factory=dict, init=False, repr=False
    )

    def __post_init__(self):
        """Merge local, inherited, and exit-skill capabilities into one ordered surface."""
        exit_tools = [self.exit.tool] if self._exit_tool_enabled else []
        self._capabilities = self._merge_capabilities(
            [self.exit],
            exit_tools,
            self.tools or [],
            self.inherited_tools or [],
            self.skills or [],
        )
        self._sync_canonical_names()

    def _get_root(self) -> AgentCapabilities:
        root = self
        while root._parent is not None:
            root = root._parent
        return root

    def _sync_canonical_names(self) -> None:
        """Synchronize canonical path names for all capabilities in this level."""
        self._canonical_names_by_capability.clear()
        inherited_set = set(id(t) for t in (self.inherited_tools or []))
        root = self._get_root()
        rel_path = self.level_path[len(root.level_path) :]
        canonical_path = (*root.canonical_prefix, *rel_path)
        for cap in self._capabilities:
            if id(cap) in inherited_set and self._parent is not None:
                self._canonical_names_by_capability[id(cap)] = (
                    self._parent.get_canonical_name(cap)
                )
            elif canonical_path:
                prefix = "/".join(canonical_path)
                self._canonical_names_by_capability[id(cap)] = f"{prefix}/{cap.name}"
            else:
                self._canonical_names_by_capability[id(cap)] = cap.get_runtime_name()

    def get_canonical_name(self, capability: Tool | DeepSkill | ExitSkill) -> str:
        """Return the canonical path name for a capability in this level."""
        if id(capability) in self._canonical_names_by_capability:
            return self._canonical_names_by_capability[id(capability)]
        if self._parent is not None:
            parent_canonical = self._parent.get_canonical_name(capability)
            if parent_canonical != capability.name:
                return parent_canonical
        root = self._get_root()
        rel_path = self.level_path[len(root.level_path) :]
        canonical_path = (*root.canonical_prefix, *rel_path)
        if canonical_path:
            return f"{'/'.join(canonical_path)}/{capability.name}"
        return capability.get_runtime_name()

    def get_allowed_tools(self, *, is_agentic: bool = False) -> list[str]:
        """Return canonical names of ordinary tools currently callable at this level."""
        allowed: list[str] = []
        if is_agentic:
            allowed.extend(
                (
                    self.get_canonical_name(self.exit),
                    self.get_canonical_name(self.exit.tool),
                )
            )
        for cap in self._capabilities:
            if isinstance(cap, Tool):
                allowed.append(self.get_canonical_name(cap))
        return list(dict.fromkeys(allowed))

    def get_allowed_skills(self) -> list[str]:
        """Return canonical names of deep skills openable at this level."""
        allowed: list[str] = []
        for cap in self._capabilities:
            if isinstance(cap, DeepSkill):
                allowed.append(self.get_canonical_name(cap))
        return list(dict.fromkeys(allowed))

    def get_all_registered_capabilities(
        self,
    ) -> list[tuple[Tool | DeepSkill | ExitSkill, str]]:
        """Collect all capabilities across the workspace/hierarchy with canonical names."""
        return [
            (capability, name)
            for _, capability, name, _ in self._registered_capabilities()
        ]

    def _registered_capabilities(
        self,
    ) -> list[tuple[AgentCapabilities, Tool | DeepSkill | ExitSkill, str, bool]]:
        """Return the static registry and whether each entry keeps a description."""
        registered: dict[
            str, tuple[AgentCapabilities, Tool | DeepSkill | ExitSkill, str, bool]
        ] = {}
        root = self._get_root()
        described_at_root = {id(capability) for capability in root._capabilities} | {
            id(root.exit.tool)
        }
        expanded_skills: set[int] = set()

        def _traverse(caps: AgentCapabilities) -> None:
            capabilities = self._merge_capabilities(
                [caps.exit, caps.exit.tool],
                caps._capabilities,
            )
            for cap in capabilities:
                c_name = caps.get_canonical_name(cap)
                if c_name not in registered:
                    registered[c_name] = (
                        caps,
                        cap,
                        c_name,
                        id(cap) in described_at_root,
                    )
            for skill in caps.skills or []:
                if id(skill) in expanded_skills:
                    continue
                expanded_skills.add(id(skill))
                child_exit = skill.exit_skill
                if child_exit is not None:
                    child_path = caps.level_path + (skill.name,)
                    child_caps = caps.child(
                        exit_skill=child_exit,
                        tools=skill.sub_tools,
                        skills=skill.sub_skills,
                        inherit_parent_tools=skill.inherits_parent_tools,
                        level_path=child_path,
                    )
                    _traverse(child_caps)

        _traverse(root)
        return list(registered.values())

    def validate_agentic_scope(
        self, *, allowed_tools: Sequence[str], allowed_skills: Sequence[str]
    ) -> None:
        """Validate allowed names and kinds against the static capability registry."""
        overlap = set(allowed_tools).intersection(allowed_skills)
        if overlap:
            raise ValueError(
                f"Agentic capability sets overlap: {sorted(overlap)}."
            )
        registry = {
            name: capability
            for _, capability, name, _ in self._registered_capabilities()
        }
        for name in allowed_tools:
            capability = registry.get(name)
            if capability is None:
                raise ValueError(f"Allowed tool is absent from the registry: {name}")
            if not isinstance(capability, (Tool, ExitSkill)):
                raise ValueError(f"Allowed tool is not an immediate capability: {name}")
        for name in allowed_skills:
            capability = registry.get(name)
            if capability is None:
                raise ValueError(f"Allowed skill is absent from the registry: {name}")
            if not isinstance(capability, DeepSkill):
                raise ValueError(f"Allowed skill is not a regular deep skill: {name}")

    def add_tools(self, local_tools: List[Tool | DeepSkill]) -> None:
        """Append additional capabilities while preserving unique public names."""
        self._capabilities = self._merge_capabilities(self._capabilities, local_tools)
        self._sync_canonical_names()

    def child(
        self,
        *,
        exit_skill: ExitSkill,
        tools: Sequence[Tool] | None = None,
        skills: Sequence[DeepSkill] | None = None,
        inherit_parent_tools: bool = True,
        level_path: tuple[str, ...] = (),
    ) -> AgentCapabilities:
        """Create the capability surface for a child level."""
        inherited_tools = (
            self.get_tools(include_exit=False) if inherit_parent_tools else []
        )
        child_caps = AgentCapabilities(
            exit=exit_skill,
            tools=list(tools) if tools is not None else None,
            skills=list(skills) if skills is not None else None,
            inherited_tools=inherited_tools,
            level_path=level_path,
            canonical_prefix=self._get_root().canonical_prefix,
        )
        child_caps._parent = self
        child_caps._sync_canonical_names()
        return child_caps

    def activate_exit_tool(self) -> None:
        """Expose the active exit skill's owned closing tool in this level."""
        if self._exit_tool_enabled:
            return
        self._exit_tool_enabled = True
        self._capabilities = self._merge_capabilities(
            [self.exit],
            [self.exit.tool],
            self.tools or [],
            self.inherited_tools or [],
            self.skills or [],
        )
        self._sync_canonical_names()

    def get_tools_for_llm(
        self,
        *,
        client: Client,
        is_agentic: bool = False,
    ) -> List[Dict[str, Any]] | None:
        """Serialize visible capabilities for LLM provider or static registry for agentic provider."""
        provider = getattr(client, "provider", None)
        is_agentic_provider = is_agentic or bool(
            getattr(provider, "supports_agentic_capabilities", False)
        )
        if not is_agentic_provider:
            return [
                self._to_llm_capability(capability=capability, client=client)
                for capability in self._capabilities
            ]

        llm_tools: list[dict[str, Any]] = []
        for (
            owner,
            capability,
            canonical_name,
            include_description,
        ) in self._registered_capabilities():
            schema = owner._to_llm_capability(
                capability=capability,
                client=client,
                override_name=canonical_name,
                include_description=include_description,
            )
            llm_tools.append(schema)

        return llm_tools

    def get_tool_names(self) -> List[str]:
        """Return the public names of all visible capabilities."""
        return [tool.get_runtime_name() for tool in self._capabilities]

    def get_skill_names(self) -> List[str]:
        """Return the public names of only visible deep skills."""
        return [
            tool.get_runtime_name()
            for tool in self._capabilities
            if isinstance(tool, DeepSkill)
        ]

    def get_tools(self, *, include_exit: bool = True) -> List[Tool]:
        """Return the visible runtime tools."""
        tools = [tool for tool in self._capabilities if isinstance(tool, Tool)]
        if include_exit:
            return tools
        return [tool for tool in tools if not self.is_exit_tool(tool.name)]

    def get_exit_skill_name(self) -> str:
        """Return the public name of the active exit skill."""
        return self.exit.get_runtime_name()

    def is_exit_skill(self, name: str) -> bool:
        """Return whether a capability name refers to the exit skill."""
        return name in {
            self.exit.name,
            self.get_exit_skill_name(),
            self.get_canonical_name(self.exit),
        }

    def get_exit_tool_name(self) -> str:
        """Return the public name of the active exit tool."""
        return self.exit.get_exit_tool_name()

    def is_exit_tool(self, name: str) -> bool:
        """Return whether a capability name refers to the active exit tool."""
        return name in {
            self.exit.tool.name,
            self.get_exit_tool_name(),
            self.get_canonical_name(self.exit.tool),
        }

    def get_exit_capability_names(self) -> set[str]:
        """Return every name reserved by the active exit-skill workflow."""
        return {
            self.exit.name,
            self.get_exit_skill_name(),
            self.exit.tool.name,
            self.get_exit_tool_name(),
            self.get_canonical_name(self.exit),
            self.get_canonical_name(self.exit.tool),
        }

    def get_tool_by_name(self, name: str) -> Union[Tool, DeepSkill, ExitSkill, None]:
        """Look up a visible capability by its public name or canonical name."""
        for tool in self._capabilities:
            c_name = self.get_canonical_name(tool)
            if name in {tool.name, tool.get_runtime_name(), c_name}:
                return tool
        return None

    def get_agentic_capability_by_name(
        self, name: str
    ) -> Union[Tool, DeepSkill, ExitSkill, None]:
        """Resolve a capability, including the always-callable active exit tool."""
        capability = self.get_tool_by_name(name)
        if capability is not None:
            return capability
        if name in {
            self.exit.tool.name,
            self.get_exit_tool_name(),
            self.get_canonical_name(self.exit.tool),
        }:
            return self.exit.tool
        return None

    def snapshot(
        self,
        *,
        current_skill: str | None = None,
        is_agentic: bool = False,
    ) -> CapabilitySnapshot:
        """Create the trace-friendly snapshot emitted in runtime events."""

        def _name(cap: Tool | DeepSkill | ExitSkill) -> str:
            return self.get_canonical_name(cap) if is_agentic else cap.name

        def _desc_name(cap: Tool | DeepSkill | ExitSkill) -> str:
            return (
                self.get_canonical_name(cap) if is_agentic else cap.get_runtime_name()
            )

        return CapabilitySnapshot(
            current_skill=current_skill,
            exit_skill=_name(self.exit),
            exit_tool=(
                _name(self.exit.tool) if self._exit_tool_enabled or is_agentic else None
            ),
            tools=[
                _name(tool) for tool in self._capabilities if isinstance(tool, Tool)
            ],
            skills=[
                _name(tool)
                for tool in self._capabilities
                if isinstance(tool, DeepSkill)
            ],
            descriptions={
                _desc_name(capability): self._format_snapshot_description(capability)
                for capability in self._capabilities
            },
        )

    def render_markdown_summary(
        self,
        *,
        level_name: str,
        body_kind: str,
        level_path: str,
        parent: AgentCapabilities | None = None,
        include_unavailable_parent: bool = False,
        is_agentic: bool = False,
    ) -> str:
        """Render the model-facing Markdown inventory for one runtime level."""
        current = self.snapshot(is_agentic=is_agentic)
        body_label = "HDS" if body_kind == "hds" else "deep skill"
        lines = [
            "## Level capabilities",
            "",
            f"- **Owner:** `{level_name}`",
            f"- **Body type:** {body_label}",
            f"- **Level path:** `{level_path}`",
            "",
            (
                "This static inventory belongs to the body identified above. "
                "It describes the capabilities available when that body was "
                "opened, not necessarily those of the currently active level."
            ),
            "",
            "### Available tools",
            "",
            *self._render_snapshot_entries(current, kind="tools"),
            "",
            "### Available skills",
            "",
            *self._render_snapshot_entries(current, kind="skills"),
        ]
        if include_unavailable_parent:
            parent_snapshot = (
                parent.snapshot(is_agentic=is_agentic) if parent is not None else None
            )
            lines.extend(
                [
                    "",
                    "### Parent tools unavailable in this level",
                    "",
                    *self._render_unavailable_entries(
                        parent_snapshot=parent_snapshot,
                        current_snapshot=current,
                        kind="tools",
                    ),
                    "",
                    "### Parent skills unavailable in this level",
                    "",
                    *self._render_unavailable_entries(
                        parent_snapshot=parent_snapshot,
                        current_snapshot=current,
                        kind="skills",
                    ),
                ]
            )
        return "\n".join([CAPABILITY_SUMMARY_START, *lines, CAPABILITY_SUMMARY_END])

    @classmethod
    def _render_snapshot_entries(
        cls, snapshot: CapabilitySnapshot, *, kind: str
    ) -> list[str]:
        """Render one ordered tool or skill list from a capability snapshot."""
        names = (
            snapshot.tools if kind == "tools" else cls._snapshot_skill_names(snapshot)
        )
        if not names:
            return ["- None."]
        return [f"- `{name}`: {snapshot.descriptions[name]}" for name in names]

    @classmethod
    def _render_unavailable_entries(
        cls,
        *,
        parent_snapshot: CapabilitySnapshot | None,
        current_snapshot: CapabilitySnapshot,
        kind: str,
    ) -> list[str]:
        """Render parent capabilities that are absent from the child surface."""
        if parent_snapshot is None:
            return ["- None."]
        parent_names = (
            parent_snapshot.tools
            if kind == "tools"
            else cls._snapshot_skill_names(parent_snapshot)
        )
        current_names = set(
            current_snapshot.tools
            if kind == "tools"
            else cls._snapshot_skill_names(current_snapshot)
        )
        unavailable = [name for name in parent_names if name not in current_names]
        if not unavailable:
            return ["- None."]
        return [
            f"- `{name}`: {parent_snapshot.descriptions[name]}" for name in unavailable
        ]

    @staticmethod
    def _snapshot_skill_names(snapshot: CapabilitySnapshot) -> list[str]:
        """Return the exit skill followed by regular deep skills in runtime order."""
        names = list(snapshot.skills)
        if snapshot.exit_skill and snapshot.exit_skill not in names:
            names.insert(0, snapshot.exit_skill)
        return names

    def _to_llm_capability(
        self,
        *,
        capability: Tool | DeepSkill | ExitSkill,
        client: Client,
        override_name: str | None = None,
        include_description: bool = True,
    ) -> Dict[str, Any]:
        """Serialize one visible capability with the correct model-facing prefix or override name."""
        name = override_name or capability.get_runtime_name()
        description = ""
        if isinstance(capability, Tool) and self.is_exit_tool(capability.name):
            return self.exit.to_llm_exit_tool_capability(
                client=client,
                override_name=name,
                include_description=include_description,
            )
        if isinstance(capability, Tool):
            if include_description:
                description = capability.get_model_description()
            return client.build_function_tool(
                name=name,
                description=description,
                handler=capability.handler,
                strict=True,
            )
        if isinstance(capability, DeepSkill):
            if include_description:
                description = format_skill_description(capability.description)
            return client.build_deep_skill_tool(
                name=name,
                description=description,
                strict=True,
            )
        return capability.to_llm_capability(
            client=client,
            override_name=name,
            include_description=include_description,
        )

    def _format_snapshot_description(
        self, capability: Tool | DeepSkill | ExitSkill
    ) -> str:
        """Return the debug-facing description for one visible capability."""
        if isinstance(capability, Tool):
            if self.is_exit_tool(capability.name):
                return format_exit_tool_description(capability.description)
            return capability.get_model_description()
        return format_skill_description(capability.description)

    @staticmethod
    def _merge_capabilities(
        *groups: Sequence[Tool | DeepSkill | ExitSkill],
    ) -> List[Tool | DeepSkill | ExitSkill]:
        """Merge capability groups while keeping the first occurrence of each name."""
        merged: list[Tool | DeepSkill | ExitSkill] = []
        seen_names: set[str] = set()
        capability_kinds_by_name: dict[str, str] = {}

        for group in groups:
            for capability in group:
                capability_kind = "tool" if isinstance(capability, Tool) else "skill"
                public_names = {capability.name, capability.get_runtime_name()}
                conflicting_names = [
                    name
                    for name in public_names
                    if name in capability_kinds_by_name
                    and capability_kinds_by_name[name] != capability_kind
                ]
                if conflicting_names:
                    conflict = sorted(conflicting_names)[0]
                    raise ValueError(
                        f"Capability name collision: '{conflict}' is declared as both "
                        "a tool and a skill. Capability names must be unique across types."
                    )
                if capability.name in seen_names:
                    continue
                for name in public_names:
                    seen_names.add(name)
                    capability_kinds_by_name[name] = capability_kind
                merged.append(capability)

        return merged
