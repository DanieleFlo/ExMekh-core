from dataclasses import dataclass
from typing import Optional
from agent_wiki.configs.runtime import RuntimePackageConfig

from .capability_roots import CapabilityRoots


@dataclass(slots=True)
class DeepSkillParseContext:
    """Encapsulates the configuration and environment for loading deep skills."""

    config: RuntimePackageConfig
    name: Optional[str] = None
    capability_roots: Optional[CapabilityRoots] = None
