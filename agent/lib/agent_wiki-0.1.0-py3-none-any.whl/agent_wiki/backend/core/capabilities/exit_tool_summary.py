from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from agent_wiki.backend.interface.capability_middleware import CapabilityMiddleware

from .agent_capabilities import AgentCapabilities
from .deep_skill import DeepSkill
from .exit_skill import ExitSkill
from .tool import Tool, ToolAfterResult, ToolMiddleware


@dataclass(frozen=True, slots=True)
class UsedCapability:
    """Describe one successful capability call made in the active level."""

    name: str
    kind: str
    call_id: str
    arguments: Mapping[str, Any]


class ExitToolSummaryMiddleware(CapabilityMiddleware):
    """Preserve exit-tool middleware chaining for every loaded exit skill."""

    def on_tool_loaded(self, *, tool: Tool) -> Tool:
        """Return a loaded standard tool unchanged."""
        return tool

    def on_exit_skill_loaded(self, *, exit_skill: ExitSkill) -> ExitSkill:
        """Attach the summary after-middleware to the exit skill's closing tool."""
        existing = exit_skill.tool.middleware
        existing_after = existing.after if existing is not None else None

        def after_exit_tool(
            *,
            tool: Tool,
            result: Any,
            arguments: dict[str, Any],
            injected_arguments: Mapping[str, Any],
        ) -> ToolAfterResult | None:
            """Run existing exit-tool middleware while preserving valid JSON output."""
            current = result
            metadata = None
            if existing_after is not None:
                existing_result = existing_after(
                    tool=tool,
                    result=current,
                    arguments=dict(arguments),
                    injected_arguments=injected_arguments,
                )
                if existing_result is not None:
                    current = existing_result.result
                    metadata = existing_result.metadata

            return ToolAfterResult(result=current, metadata=metadata)

        exit_skill.tool.middleware = ToolMiddleware(
            before=existing.before if existing is not None else None,
            after=after_exit_tool,
        )
        return exit_skill

    def on_skill_loaded(self, *, skill: DeepSkill) -> DeepSkill:
        """Return a loaded deep skill unchanged."""
        return skill

    def on_hds_loaded(self, *, hds: Any) -> Any:
        """Return a loaded hierarchical deep skill unchanged."""
        return hds


def enrich_exit_payload(
    *,
    payload: Any,
    runtime_history: Any,
    hds_context: Any,
    runtime_tool_call_id: Any,
) -> Any:
    """Return the exit payload unchanged.

    Used-capability details are now attached to the parent-visible promoted skill
    result envelope rather than appended to the exit message.
    """
    normalized = _payload_to_mapping(payload)
    if normalized is None:
        return payload
    return payload


def collect_used_capabilities(
    *,
    runtime_history: Any,
    hds_context: Any,
    runtime_tool_call_id: str | None,
) -> list[UsedCapability]:
    """Return successful capability calls visible in the active level."""
    if not isinstance(runtime_history, Sequence) or isinstance(
        runtime_history, (str, bytes)
    ):
        return []

    level_start_index = int(getattr(hds_context, "level_start_index", 0) or 0)
    local_tools = getattr(hds_context, "local_tools", None)
    scoped_history = [
        item
        for item in runtime_history[level_start_index:]
        if isinstance(item, Mapping)
    ]
    error_call_ids = {
        str(item.get("tool_call_id"))
        for item in scoped_history
        if item.get("role") == "tool"
        and item.get("kind") == "error"
        and item.get("tool_call_id")
    }

    used: list[UsedCapability] = []
    seen: set[str] = set()
    for message in scoped_history:
        if message.get("role") != "assistant":
            continue
        tool_calls = message.get("tool_calls")
        if not isinstance(tool_calls, Sequence) or isinstance(tool_calls, (str, bytes)):
            continue
        for tool_call in tool_calls:
            parsed = _parse_tool_call(tool_call)
            if parsed is None:
                continue
            call_id, name, arguments = parsed
            if call_id in error_call_ids:
                continue
            if call_id in seen:
                continue
            if call_id != runtime_tool_call_id and not _has_successful_tool_result(
                call_id=call_id,
                scoped_history=scoped_history,
            ):
                continue
            seen.add(call_id)
            used.append(
                UsedCapability(
                    name=name,
                    kind=_classify_capability(name=name, local_tools=local_tools),
                    call_id=call_id,
                    arguments=arguments,
                )
            )
    return used


def _payload_to_mapping(payload: Any) -> dict[str, Any] | None:
    """Normalize a handler result into a mutable exit-payload mapping."""
    if isinstance(payload, Mapping):
        return dict(payload)
    if not isinstance(payload, str):
        return None
    try:
        parsed = json.loads(payload)
    except json.JSONDecodeError:
        return None
    return dict(parsed) if isinstance(parsed, Mapping) else None


def _parse_tool_call(tool_call: Any) -> tuple[str, str, Mapping[str, Any]] | None:
    """Extract provider call id, capability name, and public args from a call."""
    if not isinstance(tool_call, Mapping):
        return None
    call_id = tool_call.get("id")
    function = tool_call.get("function")
    if not isinstance(call_id, str) or not isinstance(function, Mapping):
        return None
    name = function.get("name")
    if not isinstance(name, str) or not name.strip():
        return None
    return call_id, name.strip(), _parse_tool_call_arguments(function.get("arguments"))


def _parse_tool_call_arguments(arguments: Any) -> Mapping[str, Any]:
    """Parse provider tool-call arguments into a public mapping for metadata."""
    if isinstance(arguments, Mapping):
        return dict(arguments)
    if not isinstance(arguments, str) or not arguments.strip():
        return {}
    try:
        parsed = json.loads(arguments)
    except json.JSONDecodeError:
        return {}
    return dict(parsed) if isinstance(parsed, Mapping) else {}


def _has_successful_tool_result(
    *, call_id: str, scoped_history: Sequence[Mapping[str, Any]]
) -> bool:
    """Return whether a call has a non-error tool response in scoped history."""
    return any(
        item.get("role") == "tool"
        and item.get("tool_call_id") == call_id
        and item.get("kind") != "error"
        for item in scoped_history
    )


def _classify_capability(*, name: str, local_tools: Any) -> str:
    """Classify a capability name using the active capability surface."""
    if isinstance(local_tools, AgentCapabilities):
        if local_tools.is_exit_tool(name):
            return "exit_tool"
        if local_tools.is_exit_skill(name):
            return "exit_skill"
        capability = local_tools.get_tool_by_name(name)
        if isinstance(capability, DeepSkill):
            return "skill"
        if isinstance(capability, ExitSkill):
            return "exit_skill"
        if isinstance(capability, Tool):
            return "tool"
    return "tool"
