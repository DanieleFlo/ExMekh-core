from __future__ import annotations

from dataclasses import dataclass
import logging
from pathlib import Path
from typing import Any, Iterable, Sequence

from agent_wiki.configs.runtime import RuntimePackageConfig


DEFAULT_WORKROOT_CAPABILITIES_DIR = "capabilities"
logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class CapabilityRoots:
    """Resolved capability directories used by runtime and frontend loaders."""

    capability_roots: tuple[Path, ...]
    tool_roots: tuple[Path, ...]
    exit_skill_roots: tuple[Path, ...]
    skill_roots: tuple[Path, ...]
    hds_roots: tuple[Path, ...]

    @property
    def primary_hds_root(self) -> Path:
        if not self.hds_roots:
            raise ValueError("At least one hierarchical-skill root is required.")
        return self.hds_roots[0]


def resolve_capability_roots(
    *, config: RuntimePackageConfig, workroot: Path | None = None
) -> CapabilityRoots:
    """Resolve workroot-local, user-extra, and builtin capability roots."""
    capabilities_config = config.capabilities
    builtin_roots = _read_builtin_roots(capabilities_config)
    bridge_root = build_workroot_capabilities_root(
        config=config,
        workroot=workroot,
    )
    extra_roots = [
        Path(value).resolve()
        for value in _read_path_list(capabilities_config, "extra_roots")
    ]

    capability_roots = _unique_paths([bridge_root, *extra_roots, *builtin_roots])
    tool_roots = _unique_paths(
        [
            *[root / "tools" for root in capability_roots],
            Path(str(capabilities_config.tools.tools_path)).resolve(),
        ]
    )
    exit_skill_roots = _unique_paths(
        [
            *[root / "exit-skills" for root in capability_roots],
            Path(str(capabilities_config.exit_skills.exit_skills_path)).resolve(),
        ]
    )
    skill_roots = _unique_paths(
        [
            *[root / "skills" for root in capability_roots],
            Path(str(capabilities_config.deep_skill.deep_skills_path)).resolve(),
        ]
    )
    hds_roots = _unique_paths(
        [
            *[root / "hierarchical-skills" for root in capability_roots],
            Path(str(capabilities_config.hds.hds_path)).resolve(),
        ]
    )
    roots = CapabilityRoots(
        capability_roots=capability_roots,
        tool_roots=tool_roots,
        exit_skill_roots=exit_skill_roots,
        skill_roots=skill_roots,
        hds_roots=hds_roots,
    )
    logger.debug(
        "Resolved capability roots",
        extra={
            "workroot": str(workroot) if workroot is not None else None,
            "capability_roots": [str(path) for path in capability_roots],
            "tool_roots": [str(path) for path in tool_roots],
            "skill_roots": [str(path) for path in skill_roots],
            "hds_roots": [str(path) for path in hds_roots],
        },
    )
    return roots


def build_workroot_capabilities_root(
    *, config: RuntimePackageConfig, workroot: Path | None = None
) -> Path | None:
    """Return the optional capabilities bridge root relative to the active workroot."""
    if workroot is None:
        return None

    bridge_dir = _read_optional_string(config.capabilities, "workroot_bridge_dir")
    if bridge_dir is None:
        bridge_dir = DEFAULT_WORKROOT_CAPABILITIES_DIR
    if not bridge_dir:
        return None

    return (workroot / bridge_dir).resolve()


def iter_existing_capability_dirs(*, roots: Sequence[Path]) -> Iterable[Path]:
    """Yield existing capability directories in root precedence order."""
    for root in roots:
        if not root.exists() or not root.is_dir():
            continue
        for child in sorted(root.iterdir()):
            if child.is_dir():
                yield child


def find_named_capability_dir(*, roots: Sequence[Path], name: str) -> Path:
    """Locate one named capability directory across multiple roots."""
    for root in roots:
        candidate = root / name
        if candidate.exists() and candidate.is_dir():
            return candidate

    searched_roots = ", ".join(str(root) for root in roots)
    raise ValueError(f"Capability '{name}' not found in roots: {searched_roots}")


def _unique_paths(paths: Sequence[Path | None]) -> tuple[Path, ...]:
    """Deduplicate paths while preserving order."""
    unique: list[Path] = []
    seen: set[Path] = set()
    for path in paths:
        if path is None:
            continue
        if path in seen:
            continue
        seen.add(path)
        unique.append(path)
    return tuple(unique)


def _read_optional_string(config_section: Any, key: str) -> str | None:
    """Read an optional string from a config-like object."""
    value = getattr(config_section, key, None)
    if value is None:
        return None
    if isinstance(value, str):
        stripped = value.strip()
        return stripped or None
    return None


def _read_builtin_roots(capabilities_config: Any) -> list[Path]:
    """Read internal builtin capability roots with legacy path fallback."""
    configured_roots = [
        Path(value).resolve()
        for value in _read_path_list(capabilities_config, "builtin_roots")
    ]
    if configured_roots:
        return configured_roots

    return [Path(str(capabilities_config.capabilities_path)).resolve()]


def _read_path_list(config_section: Any, key: str) -> list[str]:
    """Read an optional list of string paths from config."""
    value = getattr(config_section, key, None)
    if value is None:
        return []
    if isinstance(value, Path):
        return [str(value)]
    if isinstance(value, str):
        stripped = value.strip()
        return [stripped] if stripped else []
    if isinstance(value, (list, tuple)):
        result: list[str] = []
        for item in value:
            if isinstance(item, Path):
                result.append(str(item))
            elif isinstance(item, str) and item.strip():
                result.append(item.strip())
        return result
    return []
