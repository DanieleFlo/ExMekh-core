from __future__ import annotations

import importlib.machinery
import importlib.util
import importlib
import sys
import types
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Sequence


def normalize_module_name(value: str) -> str:
    """Normalize an arbitrary path fragment into a valid Python module token."""
    normalized = "".join(
        character if character.isalnum() else "_" for character in value
    ).strip("_")
    if not normalized:
        return "module"
    if normalized[0].isdigit():
        return f"_{normalized}"
    return normalized


def build_dynamic_package_name(*, directory: Path) -> str:
    """Build an isolated package name for modules loaded from one directory."""
    normalized_parts = [normalize_module_name(part) for part in directory.parts]
    return "_agent_wiki_dynamic_" + "_".join(normalized_parts)


def module_suffix(*, directory: Path, file_path: Path) -> str:
    """Convert a Python file path inside a directory into a module suffix."""
    relative_path = file_path.relative_to(directory).with_suffix("")
    parts = list(relative_path.parts)
    if parts[-1] == "__init__":
        parts.pop()
    return ".".join(normalize_module_name(part) for part in parts)


def load_module_from_file(*, module_name: str, file_path: Path) -> types.ModuleType:
    """Import one Python module from an arbitrary filesystem path."""
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create import spec for '{file_path}'")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


@contextmanager
def load_directory_modules(
    *,
    directory: Path,
    files: Sequence[Path],
) -> Iterator[list[types.ModuleType]]:
    """Load selected files as one temporary package and clean them afterward."""
    package_name = build_dynamic_package_name(directory=directory)
    module_name_prefix = f"{package_name}."
    root_init = directory / "__init__.py"
    if root_init in files:
        spec = importlib.util.spec_from_file_location(
            package_name,
            root_init,
            submodule_search_locations=[str(directory)],
        )
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot create package import spec for '{root_init}'")
        package_module = importlib.util.module_from_spec(spec)
        sys.modules[package_name] = package_module
        spec.loader.exec_module(package_module)
    else:
        package_module = types.ModuleType(package_name)
        package_module.__path__ = [str(directory)]
        package_module.__spec__ = importlib.machinery.ModuleSpec(
            name=package_name,
            loader=None,
            is_package=True,
        )
        package_module.__spec__.submodule_search_locations = [str(directory)]
        sys.modules[package_name] = package_module

    modules: list[types.ModuleType] = []
    try:
        for file_path in files:
            if file_path == root_init:
                modules.append(package_module)
                continue
            suffix = module_suffix(directory=directory, file_path=file_path)
            module_name = (
                package_name if not suffix else f"{module_name_prefix}{suffix}"
            )
            if module_name in sys.modules and module_name != package_name:
                modules.append(sys.modules[module_name])
                continue
            modules.append(importlib.import_module(module_name))
        yield modules
    finally:
        stale_modules = [
            module_name
            for module_name in list(sys.modules)
            if module_name == package_name or module_name.startswith(module_name_prefix)
        ]
        for module_name in stale_modules:
            sys.modules.pop(module_name, None)
