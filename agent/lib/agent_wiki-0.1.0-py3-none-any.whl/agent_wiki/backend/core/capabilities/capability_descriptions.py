from __future__ import annotations


TOOL_DESCRIPTION_PREFIX = "Tool:"
SKILL_DESCRIPTION_PREFIX = "Skill:"
EXIT_TOOL_DESCRIPTION_PREFIX = "Exit tool:"

_KNOWN_PREFIXES = (
    TOOL_DESCRIPTION_PREFIX,
    SKILL_DESCRIPTION_PREFIX,
    EXIT_TOOL_DESCRIPTION_PREFIX,
)


def format_tool_description(description: str) -> str:
    """Return the model-facing description for a regular tool."""
    return _format_prefixed_description(description, TOOL_DESCRIPTION_PREFIX)


def format_skill_description(description: str) -> str:
    """Return the model-facing description for a deep skill or exit-skill activation."""
    return _format_prefixed_description(description, SKILL_DESCRIPTION_PREFIX)


def format_exit_tool_description(description: str) -> str:
    """Return the model-facing description for an activated exit tool."""
    return _format_prefixed_description(description, EXIT_TOOL_DESCRIPTION_PREFIX)


def _format_prefixed_description(description: str, prefix: str) -> str:
    """Prefix one description once while preserving already-prefixed text."""
    normalized = description.strip()
    if any(normalized.startswith(known_prefix) for known_prefix in _KNOWN_PREFIXES):
        return normalized
    return f"{prefix} {normalized}"
