from __future__ import annotations

from dataclasses import dataclass, field
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, List, Sequence

from ..utils import (
    get_bool,
    get_name_list,
    get_optional_bool,
    parse_frontmatter_lines,
    require_string,
)
from agent_wiki.backend.utils.handler_files_dirs import (
    check_file,
    read_optional_file,
)
from .capability_descriptions import format_skill_description
from agent_wiki.configs.settings import SystemConfig
from agent_wiki.configs.runtime import RuntimePackageConfig
from .deep_skill_context import DeepSkillParseContext
from .capability_middleware import CapabilityMiddlewareRegistry
from .deep_skill_middleware import load_deep_skill_middleware
from .capability_roots import (
    CapabilityRoots,
    find_named_capability_dir,
    iter_existing_capability_dirs,
    resolve_capability_roots,
)
from .tool import Tool

if TYPE_CHECKING:
    from ..client import Client
    from .exit_skill import ExitSkill
    from agent_wiki.backend.interface.deep_skill_middleware import (
        DeepSkillMiddleware,
        DeepSkillPatch,
    )


logger = logging.getLogger(__name__)


@dataclass(slots=True)
class _DeepSkillMetadata:
    """Stores the parsed metadata extracted from a deep-skill definition."""

    name: str
    context: str
    description: str
    source_path: Path | None = None
    developer_message: str | None = None
    exit_skill: ExitSkill | None = None
    sub_tools: List[Tool] = field(default_factory=list)
    sub_skills: List[DeepSkill] | None = None
    inherits_parent_tools: bool = True
    parallel_tool_calls: bool | None = None

    def get_content(self) -> str:
        """Render the skill context injected when the skill opens."""
        return self.context

    def get_runtime_name(self) -> str:
        """Return the provider-visible capability identifier."""
        return self.name


@dataclass(slots=True, kw_only=True)
class DeepSkill(_DeepSkillMetadata):
    """Represents a capability that opens a child runtime level."""

    _config: RuntimePackageConfig | None = field(init=False, repr=False)
    middleware: DeepSkillMiddleware | None = field(default=None, repr=False)
    _capability_roots: CapabilityRoots | None = field(
        default=None,
        repr=False,
    )

    def __post_init__(self) -> None:
        """Load the runtime configuration associated with the skill."""
        self.load_config()

    def load_config(self) -> None:
        """Refresh the configuration object used by filesystem loaders."""
        self._config = SystemConfig.load_default().config

    def to_llm_capability(
        self,
        client: Client,
    ) -> dict[str, Any]:
        """Serialize the deep skill as a provider-visible capability."""
        return client.build_deep_skill_tool(
            name=self.get_runtime_name(),
            description=format_skill_description(self.description),
            strict=True,
        )

    @classmethod
    def from_metadata(
        cls,
        *,
        metadata: _DeepSkillMetadata,
        middleware: DeepSkillMiddleware | None = None,
        capability_roots: CapabilityRoots | None = None,
        config: RuntimePackageConfig | None = None,
    ) -> DeepSkill:
        """Build a runtime deep skill from parsed metadata."""
        skill = cls(
            name=metadata.name,
            context=metadata.context,
            description=metadata.description,
            source_path=metadata.source_path,
            developer_message=metadata.developer_message,
            exit_skill=metadata.exit_skill,
            sub_tools=metadata.sub_tools,
            sub_skills=metadata.sub_skills,
            inherits_parent_tools=metadata.inherits_parent_tools,
            parallel_tool_calls=metadata.parallel_tool_calls,
            middleware=middleware,
            _capability_roots=capability_roots,
        )
        if config is not None:
            skill._config = config
        return CapabilityMiddlewareRegistry.apply_skill_loaded(skill=skill)

    @staticmethod
    def load_deep_skills(
        *,
        config: RuntimePackageConfig,
        capability_roots: CapabilityRoots | None = None,
    ) -> List[DeepSkill]:
        """Load every deep skill declared under the configured skills root."""
        resolved_roots = capability_roots or resolve_capability_roots(config=config)
        skills: list[DeepSkill] = []
        seen_names: set[str] = set()
        for skill_path in iter_existing_capability_dirs(
            roots=resolved_roots.skill_roots
        ):
            parse_context = DeepSkillParseContext(
                config=config, capability_roots=resolved_roots
            )
            deep_skill = DeepSkill.load_deep_skill(
                skill_path=skill_path,
                parse_context=parse_context,
            )
            runtime_name = deep_skill.get_runtime_name()
            if deep_skill.name in seen_names or runtime_name in seen_names:
                continue
            seen_names.add(deep_skill.name)
            seen_names.add(runtime_name)
            skills.append(deep_skill)
            logger.debug(
                "Loaded deep skill capability",
                extra={
                    "skill_name": deep_skill.name,
                    "runtime_name": runtime_name,
                    "skill_path": str(skill_path),
                },
            )

        if not skills:
            searched_roots = ", ".join(str(root) for root in resolved_roots.skill_roots)
            raise ValueError(f"No deep skills found in roots: {searched_roots}")

        return skills

    @staticmethod
    def load_deep_skill(
        *,
        skill_path: Path | None = None,
        parse_context: DeepSkillParseContext,
    ) -> DeepSkill:
        """Load a single deep skill from its filesystem directory."""
        resolved_roots = parse_context.capability_roots or resolve_capability_roots(
            config=parse_context.config
        )
        if parse_context.name is not None:
            skill_path = find_named_capability_dir(
                roots=resolved_roots.skill_roots, name=parse_context.name
            )
        if skill_path is None:
            raise ValueError("A deep skill path or name is required.")
        prompt_path = (
            skill_path / parse_context.config.capabilities.deep_skill.prompt_file
        )
        check_file(prompt_path)

        child_context = DeepSkillParseContext(
            config=parse_context.config,
            capability_roots=resolved_roots,
            name=skill_path.name,
        )
        metadata = DeepSkill.metadata_from_prompt_file(
            prompt_path=prompt_path,
            parse_context=child_context,
        )
        # Developer-message loading is intentionally suspended until provider
        # implementations can expose consistent semantics for this role.
        # developer_message_path = (
        #     skill_path
        #     / parse_context.config.capabilities.deep_skill.developer_message_file
        # )
        # metadata.developer_message = read_optional_file(developer_message_path)
        middleware = load_deep_skill_middleware(skill_dir=skill_path)
        skill = DeepSkill.from_metadata(
            metadata=metadata,
            middleware=middleware,
            capability_roots=resolved_roots,
            config=parse_context.config,
        )
        logger.debug(
            "Loaded deep skill capability",
            extra={"skill_name": skill.name, "skill_path": str(skill_path)},
        )
        return skill

    def resolve_patch_tools(self, names: Sequence[str]) -> list[Tool]:
        """Resolve one invocation-local ordered tool list from canonical names."""
        roots = self._require_capability_roots()
        resolved: list[Tool] = []
        for name in names:
            tool = Tool.load_tool(paths=roots.tool_roots, name=name)
            if tool is None:
                raise ValueError(f"No tools found with name: {name}")
            resolved.append(tool)
        return resolved

    def resolve_patch_skills(self, names: Sequence[str]) -> list[DeepSkill]:
        """Resolve one invocation-local ordered deep-skill list from canonical names."""
        roots = self._require_capability_roots()
        if self._config is None:
            raise ValueError(
                f"Deep skill '{self.name}' has no loader configuration for patches."
            )
        resolved: list[DeepSkill] = []
        for name in names:
            if name == self.name:
                raise ValueError(
                    f"Deep skill '{self.name}' cannot add itself as a sub-skill."
                )
            resolved.append(
                DeepSkill.load_deep_skill(
                    parse_context=DeepSkillParseContext(
                        config=self._config,
                        capability_roots=roots,
                        name=name,
                    )
                )
            )
        return resolved

    def apply_patch(
        self,
        *,
        patch: DeepSkillPatch | None,
    ) -> tuple[str, list[Tool], list[DeepSkill]]:
        """Resolve one middleware patch without mutating the shared skill object."""
        if patch is None:
            return (
                self.get_content(),
                list(self.sub_tools),
                list(self.sub_skills or []),
            )
        tools = (
            list(self.sub_tools)
            if patch.sub_tool_names is None
            else self.resolve_patch_tools(patch.sub_tool_names)
        )
        skills = (
            list(self.sub_skills or [])
            if patch.sub_skill_names is None
            else self.resolve_patch_skills(patch.sub_skill_names)
        )
        return (
            self.get_content() if patch.content is None else patch.content,
            tools,
            skills,
        )

    def _require_capability_roots(self) -> CapabilityRoots:
        """Return loader roots required for name-based middleware patches."""
        if self._capability_roots is None:
            raise ValueError(
                f"Deep skill '{self.name}' has no capability roots for patches."
            )
        return self._capability_roots

    @staticmethod
    def metadata_from_prompt_file(
        *,
        prompt_path: Path,
        parse_context: DeepSkillParseContext,
    ) -> _DeepSkillMetadata:
        """Parse the metadata and context stored in a deep-skill markdown file."""
        raw_content = read_optional_file(prompt_path)
        if not raw_content:
            raise ValueError(
                f"{parse_context.config.capabilities.deep_skill.prompt_file} in '{prompt_path}' is empty"
            )
        metadata = parse_deep_skill_markdown(
            raw_content=raw_content,
            parse_context=parse_context,
        )
        metadata.source_path = prompt_path
        return metadata


def parse_deep_skill_markdown(
    *,
    raw_content: str,
    parse_context: DeepSkillParseContext,
) -> _DeepSkillMetadata:
    """Parse a deep-skill markdown document into runtime metadata."""
    lines = raw_content.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ValueError(
            "Deep skill markdown must start with a frontmatter block delimited by '---'"
        )

    closing_index = None
    for index in range(1, len(lines)):
        if lines[index].strip() == "---":
            closing_index = index
            break

    if closing_index is None:
        raise ValueError("Deep skill markdown has an unterminated frontmatter block")

    row_metadata = parse_frontmatter_lines(lines=lines[1:closing_index])
    context = "\n".join(lines[closing_index + 1 :]).strip()

    metadata = _row_metadata_to_deep_skill_metadata(
        raw_metadata=row_metadata,
        context=context,
        parse_context=parse_context,
    )

    return metadata


def _row_metadata_to_deep_skill_metadata(
    *,
    raw_metadata: dict[str, Any],
    context: str,
    parse_context: DeepSkillParseContext,
) -> _DeepSkillMetadata:
    """Resolve parsed frontmatter into concrete tool and skill objects."""
    description = require_string(metadata=raw_metadata, key="description")
    exit_skill_name = require_string(metadata=raw_metadata, key="exit-skill")
    sub_tool_names = get_name_list(metadata=raw_metadata, keys=("sub-tools", "tools"))
    sub_skill_names = get_name_list(
        metadata=raw_metadata, keys=("sub-skills", "skills")
    )
    inherits_parent_tools = get_bool(
        metadata=raw_metadata, key="inherits-parent-tools", default=True
    )
    parallel_tool_calls = get_optional_bool(
        metadata=raw_metadata,
        key="parallel-tool-calls",
    )

    resolved_roots = parse_context.capability_roots or resolve_capability_roots(
        config=parse_context.config
    )

    tools: list[Tool] = []
    for tool_name in sub_tool_names:
        loaded_tools = Tool.load_tool(paths=resolved_roots.tool_roots, name=tool_name)
        if not loaded_tools:
            raise ValueError(f"No tools found with name: {tool_name}")
        tools.append(loaded_tools)

    from .exit_skill import ExitSkill

    exit_skill = ExitSkill.load_exit_skill(
        paths=resolved_roots.exit_skill_roots,
        name=exit_skill_name,
        prompt_file=parse_context.config.capabilities.deep_skill.prompt_file,
    )

    sub_skills: list[DeepSkill] = []
    for skill_name in sub_skill_names:
        child_context = DeepSkillParseContext(
            config=parse_context.config,
            capability_roots=resolved_roots,
            name=skill_name,
        )
        loaded_skill = DeepSkill.load_deep_skill(
            parse_context=child_context,
        )
        sub_skills.append(loaded_skill)

    return _DeepSkillMetadata(
        name=parse_context.name or "",
        context=context,
        description=description,
        exit_skill=exit_skill,
        sub_tools=tools,
        sub_skills=sub_skills,
        inherits_parent_tools=inherits_parent_tools,
        parallel_tool_calls=parallel_tool_calls,
    )
