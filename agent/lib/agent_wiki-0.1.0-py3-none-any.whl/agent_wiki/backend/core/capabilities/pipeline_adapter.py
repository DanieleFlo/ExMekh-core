"""Discover and execute configured-pipeline tool input adapters."""

from __future__ import annotations

from dataclasses import dataclass
from html import escape
import inspect
from pathlib import Path
import re
from typing import Any, Mapping, get_type_hints

from pydantic import BaseModel, ConfigDict, create_model

from agent_wiki.backend.interface.pipeline import ToolInputAdapterContext
from agent_wiki.configs.text_catalog import get_runtime_text

from .dynamic_modules import load_directory_modules
from .tool import INJECTED_TOOL_ARGUMENTS


ADAPTER_FILE_NAME = "adapter.py"


@dataclass(frozen=True, slots=True)
class LoadedToolInputAdapter:
    """Store one validated custom or default tool input adapter."""

    instance: Any
    directory: Path
    is_default: bool = False

    def adapt(self, context: ToolInputAdapterContext) -> dict[str, Any]:
        """Execute the adapter and normalize its result to an argument dictionary."""
        value = self.instance.adapt(context)
        if not isinstance(value, Mapping):
            raise TypeError("Pipeline tool input adapters must return a mapping.")
        return dict(value)


class DefaultToolInputAdapter:
    """Adapt text from a configured pipeline using a tool signature or the LLM."""

    def adapt(self, context: ToolInputAdapterContext) -> Mapping[str, Any]:
        """Build arguments directly when safe or request validated structured output."""
        fields = public_tool_fields(context.tool.handler)
        if not fields:
            return {}
        if len(fields) == 1 and fields[0][1] is str:
            return {fields[0][0]: context.text}

        output_model = build_tool_arguments_model(context.tool)
        xml_message = get_runtime_text(
            "pipeline.adapter_prompt",
            tool_description=escape(context.tool.description),
            data=escape(context.text),
        )
        messages = _structured_history(context.history)
        messages.append({"role": "user", "content": xml_message})
        adapted = context.client.create_structured(
            messages=messages,
            config=context.config,
            output_model=output_model,
            schema_name=_schema_name(context.tool.name),
        )
        return adapted.model_dump()


def load_tool_input_adapter(directory: Path) -> LoadedToolInputAdapter:
    """Load one optional custom adapter or return the shared default implementation."""
    adapter_file = directory / ADAPTER_FILE_NAME
    if not adapter_file.is_file():
        return LoadedToolInputAdapter(
            instance=DefaultToolInputAdapter(),
            directory=directory,
            is_default=True,
        )

    with load_directory_modules(directory=directory, files=[adapter_file]) as modules:
        module = modules[0]
        candidates: list[Any] = []
        for value in vars(module).values():
            if not inspect.isclass(value) or value.__module__ != module.__name__:
                continue
            adapt = getattr(value, "adapt", None)
            if callable(adapt) and getattr(adapt, "__pipeline_tool_input_adapter__", False):
                candidates.append(value)
        if len(candidates) != 1:
            raise ValueError(
                f"Expected exactly one decorated pipeline tool input adapter class in "
                f"'{adapter_file}', found {len(candidates)}."
            )
        adapter_class = candidates[0]
        _validate_custom_adapter(adapter_class=adapter_class, directory=directory)
        return LoadedToolInputAdapter(instance=adapter_class(), directory=directory)


def public_tool_fields(handler: Any) -> list[tuple[str, Any, Any]]:
    """Return public handler fields as name, resolved annotation, and default triples."""
    signature = inspect.signature(handler)
    hints = get_type_hints(handler)
    fields: list[tuple[str, Any, Any]] = []
    for parameter in signature.parameters.values():
        if parameter.name == "self" or parameter.name in INJECTED_TOOL_ARGUMENTS:
            continue
        if parameter.kind not in (
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ):
            continue
        annotation = hints.get(parameter.name, parameter.annotation)
        if annotation is inspect.Signature.empty:
            annotation = Any
        fields.append((parameter.name, annotation, parameter.default))
    return fields


def build_tool_arguments_model(tool: Any) -> type[BaseModel]:
    """Create a strict Pydantic model matching one tool's public handler arguments."""
    definitions: dict[str, tuple[Any, Any]] = {}
    for name, annotation, default in public_tool_fields(tool.handler):
        definitions[name] = (
            annotation,
            ... if default is inspect.Signature.empty else default,
        )
    return create_model(
        _schema_name(tool.name),
        __config__=ConfigDict(extra="forbid"),
        **definitions,
    )


def _validate_custom_adapter(*, adapter_class: type[Any], directory: Path) -> None:
    """Validate the stable signature required from one custom tool adapter."""
    method = getattr(adapter_class, "adapt")
    signature = inspect.signature(method)
    parameters = list(signature.parameters.values())
    if [parameter.name for parameter in parameters] != ["self", "context"]:
        raise TypeError(
            f"Pipeline tool input adapter in '{directory}' must define "
            "adapt(self, context)."
        )
    hints = get_type_hints(method)
    if hints.get("context") is not ToolInputAdapterContext:
        raise TypeError(
            f"Pipeline tool input adapter in '{directory}' must annotate context "
            "as ToolInputAdapterContext."
        )


def _structured_history(
    history: tuple[Mapping[str, Any], ...],
) -> list[dict[str, Any]]:
    """Copy history and omit the unfinished delegation call currently being handled."""
    messages = [dict(message) for message in history]
    if messages and messages[-1].get("role") == "assistant" and messages[-1].get(
        "tool_calls"
    ):
        messages.pop()
    return messages


def _schema_name(tool_name: str) -> str:
    """Return a provider-safe structured-output schema name for one tool."""
    normalized = re.sub(r"[^A-Za-z0-9_-]", "_", tool_name).strip("_-")
    return f"{normalized or 'tool'}_pipeline_arguments"
