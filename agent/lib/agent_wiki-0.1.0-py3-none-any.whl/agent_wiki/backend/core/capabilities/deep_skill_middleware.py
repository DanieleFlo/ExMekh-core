from __future__ import annotations

import copy
import inspect
from pathlib import Path
from typing import Callable, Sequence, cast

from agent_wiki.backend.interface.deep_skill_middleware import (
    DeepSkillAfterCallable,
    DeepSkillAfterResult,
    DeepSkillBeforeCallable,
    DeepSkillBeforeResult,
    DeepSkillHistory,
    DeepSkillMiddleware,
    DeepSkillPatch,
)
from agent_wiki.backend.interface.envelope import EnvelopeMetadata

from ..conversation.message import (
    AssistantMessage,
    DeveloperMessage,
    SystemMessage,
    ToolMessage,
    UserMessage,
)
from .dynamic_modules import load_directory_modules


_CHAT_MESSAGE_TYPES = (
    SystemMessage,
    DeveloperMessage,
    UserMessage,
    AssistantMessage,
    ToolMessage,
)


def sign_before(func: DeepSkillBeforeCallable) -> DeepSkillBeforeCallable:
    """Mark one function as the pre-descent hook for its deep skill."""
    _validate_hook_signature(func=func, decorator_name="sign_before")
    setattr(func, "__deep_skill_before__", True)
    return func


def sign_after(func: DeepSkillAfterCallable) -> DeepSkillAfterCallable:
    """Mark one function as the post-injection hook for its deep skill."""
    _validate_hook_signature(func=func, decorator_name="sign_after")
    setattr(func, "__deep_skill_after__", True)
    return func


def load_deep_skill_middleware(*, skill_dir: Path) -> DeepSkillMiddleware | None:
    """Discover at most one before and after hook below a deep-skill directory."""
    python_files = _iter_python_files(skill_dir=skill_dir)
    if not python_files:
        return None

    before_hooks: list[DeepSkillBeforeCallable] = []
    after_hooks: list[DeepSkillAfterCallable] = []
    with load_directory_modules(directory=skill_dir, files=python_files) as modules:
        seen_objects: set[int] = set()
        for module in modules:
            for value in vars(module).values():
                if not callable(value) or id(value) in seen_objects:
                    continue
                if getattr(value, "__module__", None) != module.__name__:
                    continue
                seen_objects.add(id(value))
                if getattr(value, "__deep_skill_before__", False):
                    before_hooks.append(cast(DeepSkillBeforeCallable, value))
                if getattr(value, "__deep_skill_after__", False):
                    after_hooks.append(cast(DeepSkillAfterCallable, value))

    if len(before_hooks) > 1:
        raise ValueError(
            f"Expected at most one @sign_before in '{skill_dir}', "
            f"found {len(before_hooks)}."
        )
    if len(after_hooks) > 1:
        raise ValueError(
            f"Expected at most one @sign_after in '{skill_dir}', "
            f"found {len(after_hooks)}."
        )
    if not before_hooks and not after_hooks:
        return None
    return DeepSkillMiddleware(
        before=before_hooks[0] if before_hooks else None,
        after=after_hooks[0] if after_hooks else None,
    )


def snapshot_history(
    history: Sequence[object],
) -> DeepSkillHistory:
    """Return a detached tuple of runtime chat messages for one middleware call."""
    snapshot = tuple(copy.deepcopy(list(history)))
    if not all(isinstance(message, _CHAT_MESSAGE_TYPES) for message in snapshot):
        raise TypeError("Deep-skill middleware history contains an invalid message.")
    return cast(DeepSkillHistory, snapshot)


def validate_before_result(result: object) -> DeepSkillBeforeResult | None:
    """Validate one value returned by a deep-skill before hook."""
    if result is None:
        return None
    if not isinstance(result, DeepSkillBeforeResult):
        raise TypeError(
            "A @sign_before hook must return DeepSkillBeforeResult or None, "
            f"got {type(result).__name__}."
        )
    if result.message is not None and not isinstance(
        result.message, _CHAT_MESSAGE_TYPES
    ):
        raise TypeError("DeepSkillBeforeResult.message must be a ChatMessage or None.")
    return result


def validate_after_result(result: object) -> DeepSkillAfterResult | None:
    """Validate one value returned by a deep-skill after hook."""
    if result is None:
        return None
    if not isinstance(result, DeepSkillAfterResult):
        raise TypeError(
            "A @sign_after hook must return DeepSkillAfterResult or None, "
            f"got {type(result).__name__}."
        )
    if result.patch is not None and not isinstance(result.patch, DeepSkillPatch):
        raise TypeError("DeepSkillAfterResult.patch must be DeepSkillPatch or None.")
    if result.metadata is not None and not isinstance(
        result.metadata, EnvelopeMetadata
    ):
        raise TypeError(
            "DeepSkillAfterResult.metadata must be EnvelopeMetadata or None."
        )
    if result.patch is not None:
        _validate_patch_names(
            field_name="sub_tool_names", names=result.patch.sub_tool_names
        )
        _validate_patch_names(
            field_name="sub_skill_names", names=result.patch.sub_skill_names
        )
    return result


def _validate_hook_signature(
    *, func: Callable[..., object], decorator_name: str
) -> None:
    """Require valid positional hook parameters and reject variadic signatures."""
    parameters = list(inspect.signature(func).parameters.values())
    expected_names = (
        ("history", "metadata") if decorator_name == "sign_after" else ("history",)
    )
    if (
        len(parameters) != len(expected_names)
        or tuple(parameter.name for parameter in parameters) != expected_names
    ):
        if expected_names == ("history",):
            raise TypeError(
                f"@{decorator_name} requires exactly one parameter named 'history'."
            )
        raise TypeError(
            f"@{decorator_name} requires exactly two parameters named "
            "'history' and 'metadata'."
        )
    valid_kinds = {
        inspect.Parameter.POSITIONAL_ONLY,
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
    }
    if any(parameter.kind not in valid_kinds for parameter in parameters):
        raise TypeError(f"@{decorator_name} parameters must be positional.")


def _iter_python_files(*, skill_dir: Path) -> list[Path]:
    """Return stable recursive Python entrypoints while ignoring cache directories."""
    return sorted(
        file_path
        for file_path in skill_dir.rglob("*.py")
        if "__pycache__" not in file_path.parts
        and not any(
            part.startswith(".") for part in file_path.relative_to(skill_dir).parts
        )
    )


def _validate_patch_names(
    *,
    field_name: str,
    names: tuple[str, ...] | list[str] | None,
) -> None:
    """Validate one optional ordered list of canonical capability names."""
    if names is None:
        return
    if not isinstance(names, (list, tuple)):
        raise TypeError(f"DeepSkillPatch.{field_name} must be a list or tuple.")
    if any(not isinstance(name, str) or not name.strip() for name in names):
        raise ValueError(f"DeepSkillPatch.{field_name} must contain non-empty strings.")
    if len(set(names)) != len(names):
        raise ValueError(f"DeepSkillPatch.{field_name} contains duplicate names.")
