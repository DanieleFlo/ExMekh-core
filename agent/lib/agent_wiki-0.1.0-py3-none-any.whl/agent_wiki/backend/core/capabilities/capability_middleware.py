from __future__ import annotations

from typing import TYPE_CHECKING

from ...interface.capability_middleware import CapabilityMiddleware

if TYPE_CHECKING:
    from .deep_skill import DeepSkill
    from .exit_skill import ExitSkill
    from .hierarchical_deep_skill import HierarchicalDeepSkill
    from .tool import Tool


class CapabilityMiddlewareAbort(RuntimeError):
    """Signal that a middleware intentionally skipped a tool execution."""

    def __init__(self, message: str) -> None:
        """Store the model-facing message returned instead of the tool result."""
        super().__init__(message)
        self.message = message


class CapabilityMiddlewareRegistry:
    """Process-wide registry for capability middleware hooks."""

    _middlewares: list[CapabilityMiddleware] = []

    @classmethod
    def register(cls, middleware: CapabilityMiddleware) -> None:
        cls._middlewares.append(middleware)

    @classmethod
    def register_once(cls, middleware: CapabilityMiddleware) -> None:
        """Register middleware unless an instance of the same class already exists."""
        middleware_type = type(middleware)
        if any(isinstance(item, middleware_type) for item in cls._middlewares):
            return
        cls.register(middleware)

    @classmethod
    def clear(cls) -> None:
        cls._middlewares.clear()

    @classmethod
    def apply_tool_loaded(cls, *, tool: Tool) -> Tool:
        """Apply load middleware to one standard tool."""
        current_tool = tool
        for middleware in cls._middlewares:
            current_tool = middleware.on_tool_loaded(tool=current_tool)
        return current_tool

    @classmethod
    def apply_exit_skill_loaded(cls, *, exit_skill: ExitSkill) -> ExitSkill:
        """Apply load middleware to one exit skill."""
        from .exit_tool_summary import ExitToolSummaryMiddleware

        current_exit_skill = ExitToolSummaryMiddleware().on_exit_skill_loaded(
            exit_skill=exit_skill
        )
        for middleware in cls._middlewares:
            current_exit_skill = middleware.on_exit_skill_loaded(
                exit_skill=current_exit_skill
            )
        return current_exit_skill

    @classmethod
    def apply_skill_loaded(cls, *, skill: DeepSkill) -> DeepSkill:
        """Apply load middleware to one deep skill."""
        current_skill = skill
        for middleware in cls._middlewares:
            current_skill = middleware.on_skill_loaded(skill=current_skill)
        return current_skill

    @classmethod
    def apply_hds_loaded(cls, *, hds: HierarchicalDeepSkill) -> HierarchicalDeepSkill:
        """Apply load middleware to one hierarchical deep skill."""
        current_hds = hds
        for middleware in cls._middlewares:
            current_hds = middleware.on_hds_loaded(hds=current_hds)
        return current_hds
