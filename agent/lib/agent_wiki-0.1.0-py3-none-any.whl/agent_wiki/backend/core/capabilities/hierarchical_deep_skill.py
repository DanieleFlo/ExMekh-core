from __future__ import annotations

from dataclasses import dataclass
import logging
from agent_wiki.configs.runtime import RuntimePackageConfig

from .capability_middleware import CapabilityMiddlewareRegistry
from .capability_roots import (
    CapabilityRoots,
    find_named_capability_dir,
    resolve_capability_roots,
)
from .deep_skill import DeepSkill
from agent_wiki.backend.utils.handler_files_dirs import check_file
# from agent_wiki.backend.utils.handler_files_dirs import read_optional_file


logger = logging.getLogger(__name__)


@dataclass(slots=True, kw_only=True)
class HierarchicalDeepSkill(DeepSkill):
    """Root-capable deep skill that also defines a system prompt."""

    system_prompt: str
    context: None = None

    @staticmethod
    def load_hierarchical_deep_skill(
        *,
        name: str,
        config: RuntimePackageConfig,
        capability_roots: CapabilityRoots | None = None,
    ) -> HierarchicalDeepSkill:
        """Load the hierarchical skill used to bootstrap a runtime tree."""
        resolved_roots = capability_roots or resolve_capability_roots(config=config)
        skill_path = find_named_capability_dir(
            roots=resolved_roots.hds_roots, name=name
        )
        prompt_path = skill_path / config.capabilities.deep_skill.prompt_file
        check_file(prompt_path)
        from .deep_skill_context import DeepSkillParseContext

        parse_context = DeepSkillParseContext(
            name=skill_path.name,
            config=config,
            capability_roots=resolved_roots,
        )
        metadata = DeepSkill.metadata_from_prompt_file(
            prompt_path=prompt_path,
            parse_context=parse_context,
        )
        # Developer-message loading is intentionally suspended until provider
        # implementations can expose consistent semantics for this role.
        # metadata.developer_message = read_optional_file(
        #     skill_path / config.capabilities.hds.developer_message_file
        # )

        hds = CapabilityMiddlewareRegistry.apply_hds_loaded(
            hds=HierarchicalDeepSkill(
                name=metadata.name,
                description=metadata.description,
                source_path=metadata.source_path,
                developer_message=metadata.developer_message,
                exit_skill=metadata.exit_skill,
                sub_tools=metadata.sub_tools,
                sub_skills=metadata.sub_skills,
                inherits_parent_tools=metadata.inherits_parent_tools,
                parallel_tool_calls=metadata.parallel_tool_calls,
                system_prompt=metadata.get_content(),
            )
        )
        logger.debug(
            "Loaded hierarchical deep skill",
            extra={
                "hds_name": hds.name,
                "skill_path": str(skill_path),
                "sub_tools": [tool.name for tool in hds.sub_tools],
                "sub_skills": [skill.name for skill in hds.sub_skills],
            },
        )
        return hds
