from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from ..conversation.message import (
    AssistantMessage,
    ChatMessage,
    ToolMessage,
)
from ..conversation.history_graph import HistoryGraph
from ..conversation.types import parse_message_kind
from ..outputs.tool_output_memory import StoredToolOutput
from ..utils import safe_hds_node_path, safe_runtime_name
from agent_wiki.backend.interface.checkpoint import (
    CheckpointPolicyInterface,
    CheckpointStoreInterface,
)


CHECKPOINT_VERSION = 5


@dataclass(slots=True)
class CheckpointHDSChat:
    """Serialize one persistent configured HDS child chat."""

    hds_node_path: list[str]
    history_cursor: dict[str, Any]


@dataclass(slots=True)
class CheckpointPipelineState:
    """Serialize resumable progress for one active sequential pipeline."""

    node_path: list[str]
    next_step: int
    text: str
    accumulating_outputs: bool = False
    pipeline_kind: str = "sequential"
    iteration_index: int = 0
    iteration_total: int = 0
    messages: list[str] = field(default_factory=list)
    static_text: str | None = None
    outputs: list[str] = field(default_factory=list)


@dataclass(slots=True)
class CheckpointFrame:
    """Serialize one active runtime level for checkpoint resume."""

    frame_kind: str
    current_skill: str | None
    execution_id: str
    memory_hds_id: str
    depth: int
    level_start_index: int
    parallel_tool_calls: bool
    history_cursor: dict[str, Any]
    hds_node_path: list[str]
    parent_hds_node_path: list[str] | None = None
    delegating_tool_call_id: str | None = None
    delegating_child_name: str | None = None
    opening_skill_name: str | None = None
    opening_tool_call_id: str | None = None
    pending_return_skill_call_id: str | None = None
    pending_tool_call: dict[str, Any] | None = None


@dataclass(slots=True)
class CheckpointRecord:
    """Serialize the minimum state needed to resume an Agent Wiki run."""

    version: int
    checkpoint_id: str
    reason: str
    timestamp: str
    workroot: str
    hds_name: str
    memory_hds_id: str
    level_execution_sequence: int
    frames: list[CheckpointFrame]
    history_graph: dict[str, Any]
    checkpoint_node_path: list[str]
    hds_child_chats: list[CheckpointHDSChat] = field(default_factory=list)
    tool_outputs: list[dict[str, Any]] = field(default_factory=list)
    pipeline_states: list[CheckpointPipelineState] = field(default_factory=list)
    dynamic_pipeline_definitions: list[dict[str, Any]] = field(default_factory=list)
    pending_interaction: dict[str, Any] | None = None
    interaction_response: dict[str, Any] | None = None

    def to_payload(self) -> dict[str, Any]:
        """Convert the checkpoint record into a JSON-friendly payload."""
        return {
            "version": self.version,
            "checkpoint_id": self.checkpoint_id,
            "reason": self.reason,
            "timestamp": self.timestamp,
            "workroot": self.workroot,
            "hds_name": self.hds_name,
            "memory_hds_id": self.memory_hds_id,
            "level_execution_sequence": self.level_execution_sequence,
            "checkpoint_node_path": list(self.checkpoint_node_path),
            "history_graph": dict(self.history_graph),
            "frames": [asdict(frame) for frame in self.frames],
            "hds_child_chats": [asdict(chat) for chat in self.hds_child_chats],
            "tool_outputs": [dict(output) for output in self.tool_outputs],
            "pipeline_states": [asdict(state) for state in self.pipeline_states],
            "dynamic_pipeline_definitions": [
                dict(definition) for definition in self.dynamic_pipeline_definitions
            ],
            "pending_interaction": (
                dict(self.pending_interaction)
                if self.pending_interaction is not None
                else None
            ),
            "interaction_response": (
                dict(self.interaction_response)
                if self.interaction_response is not None
                else None
            ),
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> CheckpointRecord:
        """Build a checkpoint record from decoded JSON data."""
        version = _required_int(payload, "version")
        if version != CHECKPOINT_VERSION:
            raise ValueError(f"Unsupported checkpoint version: {version}")

        raw_frames = payload.get("frames")
        if not isinstance(raw_frames, list):
            raise ValueError("Checkpoint payload must contain a frame list.")
        raw_history_graph = payload.get("history_graph")
        if not isinstance(raw_history_graph, Mapping):
            raise ValueError("Checkpoint payload must contain a history graph.")

        frames: list[CheckpointFrame] = []
        for raw_frame in raw_frames:
            if not isinstance(raw_frame, Mapping):
                raise ValueError("Checkpoint frame must be a JSON object.")
            frames.append(
                CheckpointFrame(
                    frame_kind=_required_string(raw_frame, "frame_kind"),
                    current_skill=_optional_string(raw_frame.get("current_skill")),
                    execution_id=_required_string(raw_frame, "execution_id"),
                    memory_hds_id=_required_string(raw_frame, "memory_hds_id"),
                    depth=_required_int(raw_frame, "depth"),
                    level_start_index=_required_int(raw_frame, "level_start_index"),
                    parallel_tool_calls=bool(raw_frame.get("parallel_tool_calls")),
                    history_cursor=_required_mapping(raw_frame, "history_cursor"),
                    hds_node_path=_required_string_list(raw_frame, "hds_node_path"),
                    parent_hds_node_path=_optional_string_list(
                        raw_frame.get("parent_hds_node_path")
                    ),
                    delegating_tool_call_id=_optional_string(
                        raw_frame.get("delegating_tool_call_id")
                    ),
                    delegating_child_name=_optional_string(
                        raw_frame.get("delegating_child_name")
                    ),
                    opening_skill_name=_optional_string(
                        raw_frame.get("opening_skill_name")
                    ),
                    opening_tool_call_id=_optional_string(
                        raw_frame.get("opening_tool_call_id")
                    ),
                    pending_return_skill_call_id=_optional_string(
                        raw_frame.get("pending_return_skill_call_id")
                    ),
                    pending_tool_call=(
                        dict(raw_frame["pending_tool_call"])
                        if isinstance(raw_frame.get("pending_tool_call"), Mapping)
                        else None
                    ),
                )
            )

        hds_child_chats: list[CheckpointHDSChat] = []
        raw_hds_child_chats = payload.get("hds_child_chats")
        if isinstance(raw_hds_child_chats, list):
            for raw_chat in raw_hds_child_chats:
                if not isinstance(raw_chat, Mapping):
                    raise ValueError("Checkpoint HDS child chat must be a JSON object.")
                hds_child_chats.append(
                    CheckpointHDSChat(
                        hds_node_path=_required_string_list(raw_chat, "hds_node_path"),
                        history_cursor=_required_mapping(raw_chat, "history_cursor"),
                    )
                )

        raw_tool_outputs = payload.get("tool_outputs")
        tool_outputs = (
            [dict(item) for item in raw_tool_outputs if isinstance(item, Mapping)]
            if isinstance(raw_tool_outputs, list)
            else []
        )
        raw_pipeline_states = payload.get("pipeline_states", [])
        if not isinstance(raw_pipeline_states, list):
            raise ValueError("Checkpoint pipeline_states must be a list.")
        pipeline_states: list[CheckpointPipelineState] = []
        for raw_state in raw_pipeline_states:
            if not isinstance(raw_state, Mapping):
                raise ValueError("Checkpoint pipeline state must be a JSON object.")
            pipeline_states.append(
                CheckpointPipelineState(
                    node_path=_required_string_list(raw_state, "node_path"),
                    next_step=_required_int(raw_state, "next_step"),
                    text=_required_string(raw_state, "text"),
                    accumulating_outputs=bool(
                        raw_state.get("accumulating_outputs", False)
                    ),
                    pipeline_kind=str(raw_state.get("pipeline_kind", "sequential")),
                    iteration_index=int(raw_state.get("iteration_index", 0)),
                    iteration_total=int(raw_state.get("iteration_total", 0)),
                    messages=_optional_string_list(raw_state.get("messages")) or [],
                    static_text=_optional_string(raw_state.get("static_text")),
                    outputs=_optional_string_list(raw_state.get("outputs")) or [],
                )
            )
        return cls(
            version=version,
            checkpoint_id=_required_string(payload, "checkpoint_id"),
            reason=_required_string(payload, "reason"),
            timestamp=_required_string(payload, "timestamp"),
            workroot=_required_string(payload, "workroot"),
            hds_name=_required_string(payload, "hds_name"),
            memory_hds_id=_required_string(payload, "memory_hds_id"),
            level_execution_sequence=_required_int(payload, "level_execution_sequence"),
            frames=frames,
            history_graph=dict(raw_history_graph),
            checkpoint_node_path=_required_string_list(payload, "checkpoint_node_path"),
            hds_child_chats=hds_child_chats,
            tool_outputs=tool_outputs,
            pipeline_states=pipeline_states,
            dynamic_pipeline_definitions=[
                dict(item)
                for item in payload.get("dynamic_pipeline_definitions", [])
                if isinstance(item, Mapping)
            ],
            pending_interaction=(
                dict(payload["pending_interaction"])
                if isinstance(payload.get("pending_interaction"), Mapping)
                else None
            ),
            interaction_response=(
                dict(payload["interaction_response"])
                if isinstance(payload.get("interaction_response"), Mapping)
                else None
            ),
        )


class FilesystemCheckpointStore(CheckpointStoreInterface):
    """Persist and load checkpoint records from the configured runtime directory."""

    def __init__(self, *, checkpoint_dir: Path | None) -> None:
        """Initialize the store with an optional filesystem directory."""
        self.checkpoint_dir = checkpoint_dir.resolve() if checkpoint_dir else None

    def save(self, *, record: CheckpointRecord) -> Path | None:
        """Write one checkpoint record and return the path when persistence is enabled."""
        if self.checkpoint_dir is None:
            return None

        destination = (
            self.checkpoint_dir
            / record.memory_hds_id
            / safe_hds_node_path(record.checkpoint_node_path)
        )
        destination.mkdir(parents=True, exist_ok=True)
        path = destination / f"{safe_runtime_name(record.checkpoint_id)}.json"
        path.write_text(
            json.dumps(record.to_payload(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return path

    @staticmethod
    def load(path: Path | str) -> CheckpointRecord:
        """Load one checkpoint record from a JSON file."""
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("Checkpoint file must contain a JSON object.")
        return CheckpointRecord.from_payload(payload)


class CheckpointStore(FilesystemCheckpointStore):
    """Backward-compatible filesystem checkpoint store alias."""


@dataclass(slots=True)
class DefaultCheckpointPolicy(CheckpointPolicyInterface):
    """Apply the default DeepAgent checkpoint trigger rules."""

    enabled: bool = True
    message_threshold: int | None = None
    on_tool_or_skill_before_execution: bool = True
    on_skill_close: bool = True

    def should_save_before_execution(self) -> bool:
        """Return whether to checkpoint before a tool or skill executes."""
        return self.enabled and self.on_tool_or_skill_before_execution

    def should_save_after_skill_close(self) -> bool:
        """Return whether to checkpoint after a child skill closes."""
        return self.enabled and self.on_skill_close

    def should_save_after_message_count(
        self,
        *,
        message_count: int,
        last_checkpoint_message_count: int,
    ) -> bool:
        """Return whether the configured message threshold has been crossed."""
        if not self.enabled:
            return False
        if self.message_threshold is None or self.message_threshold < 1:
            return False
        if message_count < self.message_threshold:
            return False
        return (message_count - last_checkpoint_message_count) >= self.message_threshold


class CheckpointMiddleware:
    """Runtime execution middleware that saves automatic checkpoints."""

    def __init__(
        self,
        *,
        enabled: bool,
        store: CheckpointStoreInterface,
    ) -> None:
        """Configure the middleware with a store and an enabled flag."""
        self.enabled = enabled
        self.store = store

    def save(self, *, record: CheckpointRecord) -> Path | None:
        """Persist a checkpoint when middleware execution is enabled."""
        if not self.enabled:
            return None
        return self.store.save(record=record)


def build_checkpoint_record(
    *,
    checkpoint_id: str,
    reason: str,
    workroot: Path,
    hds_name: str,
    memory_hds_id: str,
    level_execution_sequence: int,
    frames: Sequence[CheckpointFrame],
    history_graph: HistoryGraph,
    tool_outputs: Sequence[StoredToolOutput],
    checkpoint_node_path: Sequence[str],
    hds_child_chats: Sequence[CheckpointHDSChat] | None = None,
    pipeline_states: Sequence[CheckpointPipelineState] | None = None,
    dynamic_pipeline_definitions: Sequence[Mapping[str, Any]] | None = None,
    pending_interaction: Mapping[str, Any] | None = None,
    interaction_response: Mapping[str, Any] | None = None,
) -> CheckpointRecord:
    """Build a timestamped checkpoint record from active runtime state."""
    return CheckpointRecord(
        version=CHECKPOINT_VERSION,
        checkpoint_id=checkpoint_id,
        reason=reason,
        timestamp=datetime.now(UTC).isoformat(),
        workroot=str(workroot),
        hds_name=hds_name,
        memory_hds_id=memory_hds_id,
        level_execution_sequence=level_execution_sequence,
        frames=list(frames),
        history_graph=history_graph.to_dict(),
        checkpoint_node_path=list(checkpoint_node_path),
        hds_child_chats=list(hds_child_chats or []),
        tool_outputs=[output.to_payload() for output in tool_outputs],
        pipeline_states=list(pipeline_states or []),
        dynamic_pipeline_definitions=[
            dict(item) for item in (dynamic_pipeline_definitions or [])
        ],
        pending_interaction=(
            dict(pending_interaction) if pending_interaction is not None else None
        ),
        interaction_response=(
            dict(interaction_response) if interaction_response is not None else None
        ),
    )


def serialize_message(message: ChatMessage) -> dict[str, Any]:
    """Serialize a runtime chat message with enough type data to rebuild it."""
    payload = message.to_dict()
    payload["kind"] = message.kind
    payload["message_type"] = type(message).__name__
    if isinstance(message, AssistantMessage):
        payload["tool_calls"] = [dict(tool_call) for tool_call in message.tool_calls]
    elif isinstance(message, ToolMessage):
        payload["tool_call_id"] = message.tool_call_id
    return payload


def deserialize_message(*, client: Any, payload: Mapping[str, Any]) -> ChatMessage:
    """Rebuild a runtime chat message using the active provider client."""
    message_type = payload.get("message_type")
    role = payload.get("role")
    content = payload.get("content")
    name = payload.get("name")
    normalized_content = content if isinstance(content, str) else ""
    normalized_name = name if isinstance(name, str) else None
    kind = parse_message_kind(payload.get("kind"))

    if message_type == "SystemMessage" or role == "system":
        message = client.build_system_message(
            content=normalized_content, name=normalized_name
        )
        message.kind = kind
        return message
    if message_type == "DeveloperMessage" or role == "developer":
        message = client.build_developer_message(
            content=normalized_content, name=normalized_name
        )
        message.kind = kind
        return message
    if message_type == "UserMessage" or role == "user":
        message = client.build_user_message(
            content=normalized_content, name=normalized_name
        )
        message.kind = kind
        return message
    if message_type == "AssistantMessage" or role == "assistant":
        raw_tool_calls = payload.get("tool_calls")
        tool_calls = (
            [
                dict(tool_call)
                for tool_call in raw_tool_calls
                if isinstance(tool_call, Mapping)
            ]
            if isinstance(raw_tool_calls, list)
            else []
        )
        message = client.build_assistant_message(
            content=normalized_content,
            name=normalized_name,
            tool_calls=tool_calls,
        )
        message.kind = kind
        return message
    if message_type == "ToolMessage" or role == "tool":
        tool_call_id = payload.get("tool_call_id")
        message = client.build_tool_message(
            content=normalized_content,
            tool_call_id=tool_call_id if isinstance(tool_call_id, str) else "",
            name=normalized_name,
        )
        message.kind = kind
        return message
    raise ValueError(f"Unsupported checkpoint message type: {message_type or role}")


def _optional_string(value: Any) -> str | None:
    """Return a string only when the raw value is a string."""
    return value if isinstance(value, str) else None


def _required_string(payload: Mapping[str, Any], key: str) -> str:
    """Read a required string from a decoded checkpoint payload."""
    value = payload.get(key)
    if not isinstance(value, str):
        raise ValueError(f"Checkpoint field '{key}' must be a string.")
    return value


def _required_int(payload: Mapping[str, Any], key: str) -> int:
    """Read a required integer from a decoded checkpoint payload."""
    value = payload.get(key)
    if not isinstance(value, int):
        raise ValueError(f"Checkpoint field '{key}' must be an integer.")
    return value


def _required_mapping_list(
    payload: Mapping[str, Any], key: str
) -> list[dict[str, Any]]:
    """Read a required list of mapping objects from a decoded checkpoint payload."""
    value = payload.get(key)
    if not isinstance(value, list):
        raise ValueError(f"Checkpoint field '{key}' must be a list.")
    return [dict(item) for item in value if isinstance(item, Mapping)]


def _required_mapping(payload: Mapping[str, Any], key: str) -> dict[str, Any]:
    """Read a required mapping object from a decoded checkpoint payload."""
    value = payload.get(key)
    if not isinstance(value, Mapping):
        raise ValueError(f"Checkpoint field '{key}' must be an object.")
    return dict(value)


def _required_string_list(payload: Mapping[str, Any], key: str) -> list[str]:
    """Read a required list of strings from a decoded checkpoint payload."""
    value = payload.get(key)
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ValueError(f"Checkpoint field '{key}' must be a string list.")
    return list(value)


def _optional_string_list(value: Any) -> list[str] | None:
    """Return a string list only when the raw value has that shape."""
    if value is None:
        return None
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        return None
    return list(value)
