from __future__ import annotations

import ast
from collections.abc import Sequence
from typing import Any


def parse_frontmatter_lines(*, lines: list[str]) -> dict[str, Any]:
    """Parse a simplified frontmatter block into a Python dictionary."""
    metadata: dict[str, Any] = {}
    current_list_key: str | None = None

    for raw_line in lines:
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        if raw_line.startswith((" ", "\t")) and stripped.startswith("- "):
            if current_list_key is None:
                raise ValueError(f"Invalid frontmatter list item: {raw_line}")
            metadata.setdefault(current_list_key, []).append(stripped[2:].strip())
            continue

        if ":" not in raw_line:
            raise ValueError(f"Invalid frontmatter entry: {raw_line}")

        key, raw_value = raw_line.split(":", 1)
        normalized_key = key.strip()
        cleaned_value = strip_inline_comment(raw_value.strip())

        if not cleaned_value:
            metadata[normalized_key] = (
                []
                if normalized_key in {"sub-tools", "tools", "sub-skills", "skills"}
                else ""
            )
            current_list_key = normalized_key
            continue

        metadata[normalized_key] = parse_frontmatter_value(cleaned_value)
        current_list_key = None

    return metadata


def parse_frontmatter_value(raw_value: str) -> Any:
    """Parse a scalar frontmatter value into its runtime representation."""
    if raw_value.startswith("[") and raw_value.endswith("]"):
        parsed = ast.literal_eval(raw_value)
        if not isinstance(parsed, list):
            raise ValueError("Frontmatter list value must be a list")
        return parsed

    if "," in raw_value:
        return [item.strip() for item in raw_value.split(",") if item.strip()]

    return raw_value


def strip_inline_comment(value: str) -> str:
    """Remove an inline comment suffix from a frontmatter value."""
    if " #" in value:
        return value.split(" #", 1)[0].rstrip()
    if value.startswith("#"):
        return ""
    return value


def require_string(*, metadata: dict[str, Any], key: str) -> str:
    """Read a required non-empty string field from parsed metadata."""
    value = metadata.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Missing required frontmatter field '{key}'")
    return value.strip()


def get_name_list(*, metadata: dict[str, Any], keys: tuple[str, ...]) -> list[str]:
    """Read a list-like metadata field accepting the supported input shapes."""
    for key in keys:
        if key not in metadata:
            continue

        value = metadata[key]
        if value == "":
            return []
        if isinstance(value, str):
            return [value] if value else []
        if isinstance(value, list) and all(isinstance(item, str) for item in value):
            return [item.strip() for item in value if item.strip()]
        raise ValueError(
            f"Frontmatter field '{key}' must be a string or list of strings"
        )

    return []


def get_bool(*, metadata: dict[str, Any], key: str, default: bool) -> bool:
    """Read a boolean metadata field with a fallback default."""
    if key not in metadata:
        return default

    value = metadata[key]
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "yes", "1"}:
            return True
        if normalized in {"false", "no", "0"}:
            return False

    raise ValueError(f"Frontmatter field '{key}' must be a boolean")


def get_optional_bool(*, metadata: dict[str, Any], key: str) -> bool | None:
    """Read an optional boolean metadata field preserving absence as None."""
    if key not in metadata:
        return None

    value = metadata[key]
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "yes", "1"}:
            return True
        if normalized in {"false", "no", "0"}:
            return False

    raise ValueError(f"Frontmatter field '{key}' must be a boolean")


def safe_runtime_name(value: str) -> str:
    """Normalize one runtime identifier into a safe filesystem segment."""
    return (
        "".join(
            character if character.isalnum() or character in {"-", "_", "."} else "-"
            for character in value.strip()
        ).strip(".-")
        or "runtime"
    )


def safe_hds_node_path(value: Sequence[str]) -> str:
    """Normalize one HDS node path into a single filesystem segment."""
    return "__".join(safe_runtime_name(part) for part in value if part) or "unknown-hds"
