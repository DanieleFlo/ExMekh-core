"""Static backend catalogs used by the runtime."""
