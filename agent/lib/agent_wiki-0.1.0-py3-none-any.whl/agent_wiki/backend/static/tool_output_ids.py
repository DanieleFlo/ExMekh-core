from __future__ import annotations

import json
from pathlib import Path

TOOL_OUTPUT_IDS_PATH = Path(__file__).with_suffix(".json")


def clear_tool_output_ids_file() -> None:
    """Reset the runtime-generated visible tool output id list."""
    TOOL_OUTPUT_IDS_PATH.write_text("[]\n", encoding="utf-8")


def read_tool_output_ids_file() -> list[str]:
    """Read generated visible tool output ids from the static JSON file."""
    try:
        payload = json.loads(TOOL_OUTPUT_IDS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(payload, list):
        return []
    return [item for item in payload if isinstance(item, str) and item.strip()]


def write_tool_output_ids_file(values: list[str]) -> None:
    """Write generated visible tool output ids into the static JSON file."""
    TOOL_OUTPUT_IDS_PATH.write_text(
        json.dumps(values, ensure_ascii=True, indent=2) + "\n",
        encoding="utf-8",
    )
