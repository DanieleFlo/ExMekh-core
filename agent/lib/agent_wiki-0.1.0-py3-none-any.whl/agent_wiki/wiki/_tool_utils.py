from __future__ import annotations

import json
from importlib.resources import files
from pathlib import Path
from typing import Any

SOURCE_DIRECTORY_NAME = "row"
METADATA_DIRECTORY_NAME = ".agent_wiki"
SCHEMA_FILE_NAME = "AGENT_WIKI.md"
RESERVED_COMPILED_NAMES = {
    SOURCE_DIRECTORY_NAME,
    METADATA_DIRECTORY_NAME,
    SCHEMA_FILE_NAME,
}


def default_schema_text() -> str:
    """Return the bundled default AgentWiki schema template."""
    return (
        files("agent_wiki.wiki")
        .joinpath("default_schema.md")
        .read_text(encoding="utf-8")
    )


def wiki_root(*, workroot: Path | None) -> Path:
    """Return the AgentWiki root anchored at the injected agent workroot."""
    workspace_root = workroot if workroot is not None else Path.cwd()
    return workspace_root.resolve()


def raw_wiki_root(*, workroot: Path | None) -> Path:
    """Return the source directory inside the injected AgentWiki workroot."""
    return (wiki_root(workroot=workroot) / SOURCE_DIRECTORY_NAME).resolve()


def compiled_wiki_root(*, workroot: Path | None) -> Path:
    """Return the injected AgentWiki workroot containing compiled pages."""
    return wiki_root(workroot=workroot)


def metadata_wiki_root(*, workroot: Path | None) -> Path:
    """Return the metadata directory used by AgentWiki tools."""
    return (wiki_root(workroot=workroot) / METADATA_DIRECTORY_NAME).resolve()


def schema_path(*, workroot: Path | None) -> Path:
    """Return the workspace-level AgentWiki schema path."""
    return wiki_root(workroot=workroot) / SCHEMA_FILE_NAME


def _relative_argument(path: str, *, logical_root: str) -> Path:
    """Validate and return one model-facing path relative to a logical root."""
    candidate = Path(path)
    if candidate.is_absolute():
        raise ValueError(f"Path must be relative to {logical_root}.")
    if ".." in candidate.parts:
        raise ValueError(f"Path must stay inside {logical_root}.")
    return candidate


def resolve_wiki_path(path: str, *, root: Path, logical_root: str) -> Path:
    """Resolve one relative path and ensure it stays under the supplied root."""
    resolved_root = root.resolve()
    candidate = _relative_argument(path, logical_root=logical_root)
    target = resolved_root / candidate
    resolved_target = target.resolve()
    try:
        resolved_target.relative_to(resolved_root)
    except ValueError as error:
        raise ValueError(f"Path must stay inside {logical_root}.") from error
    return resolved_target


def resolve_compiled_wiki_path(path: str, *, workroot: Path | None) -> Path:
    """Resolve one compiled page path under the injected AgentWiki workroot."""
    root = compiled_wiki_root(workroot=workroot)
    target = resolve_wiki_path(path, root=root, logical_root="the AgentWiki workroot")
    relative = target.relative_to(root)
    if relative.parts and relative.parts[0] in RESERVED_COMPILED_NAMES:
        raise ValueError("Path belongs to a reserved AgentWiki workspace area.")
    return target


def resolve_raw_wiki_path(path: str, *, workroot: Path | None) -> Path:
    """Resolve one source-root-relative path inside row/."""
    candidate = _relative_argument(path, logical_root="the row/ source root")
    if candidate.parts and candidate.parts[0] == SOURCE_DIRECTORY_NAME:
        raise ValueError(
            "Source paths are already relative to row/; remove the leading 'row/'."
        )
    return resolve_wiki_path(
        path,
        root=raw_wiki_root(workroot=workroot),
        logical_root="the row/ source root",
    )


def workspace_relative_path(path: Path, *, workroot: Path | None) -> str:
    """Return one stable model-facing path relative to the AgentWiki workroot."""
    root = wiki_root(workroot=workroot)
    try:
        relative = path.resolve().relative_to(root)
    except ValueError as error:
        raise ValueError("Path is outside the AgentWiki workroot.") from error
    return relative.as_posix() or "."


def compiled_relative_path(path: Path, *, workroot: Path | None) -> str:
    """Return one compiled-page path relative to the AgentWiki workroot."""
    return workspace_relative_path(path, workroot=workroot)


def source_relative_path(path: Path, *, workroot: Path | None) -> str:
    """Return one source path relative to the row/ source root."""
    root = raw_wiki_root(workroot=workroot)
    try:
        relative = path.resolve().relative_to(root)
    except ValueError as error:
        raise ValueError("Path is outside the row/ source root.") from error
    return relative.as_posix() or "."


def safe_argument_path(path: str) -> str | None:
    """Return a relative path argument only when it is safe to echo to the model."""
    candidate = Path(path)
    if candidate.is_absolute() or ".." in candidate.parts:
        return None
    return candidate.as_posix()


def normalize_compiled_path(path: str, *, workroot: Path | None) -> str:
    """Validate and normalize one compiled-page reference for model-facing storage."""
    target = resolve_compiled_wiki_path(path, workroot=workroot)
    if target.suffix != ".md":
        raise ValueError("Compiled page references must use the .md extension.")
    return compiled_relative_path(target, workroot=workroot)


def filesystem_error_name(error: BaseException) -> str:
    """Return a safe filesystem error label without leaking host path details."""
    return type(error).__name__


def iter_compiled_wiki_pages(*, workroot: Path | None) -> list[Path]:
    """Return compiled Markdown pages while excluding reserved workspace paths."""
    root = compiled_wiki_root(workroot=workroot)
    if not root.exists():
        return []
    return [
        page
        for page in sorted(root.rglob("*.md"))
        if page.relative_to(root).parts
        and page.relative_to(root).parts[0] not in RESERVED_COMPILED_NAMES
    ]


def ingest_log_path(*, workroot: Path | None) -> Path:
    """Return the ingest log path under the wiki metadata directory."""
    return metadata_wiki_root(workroot=workroot) / "ingest-log.jsonl"


def index_path(*, workroot: Path | None) -> Path:
    """Return the wiki index path under the wiki metadata directory."""
    return metadata_wiki_root(workroot=workroot) / "index.json"


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    """Read JSON Lines records from a file, skipping blank lines."""
    if not path.exists():
        return []
    records: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        loaded = json.loads(stripped)
        if isinstance(loaded, dict):
            records.append(loaded)
    return records
