---
description: AgentWiki lint HDS that diagnoses memory graph health and maintenance issues.
exit-skill: exit-wiki-lint
sub-tools:
  - list-tool-outputs
  - read-tool-output
  - wiki-read-schema
  - wiki-inspect-memory-graph
  - wiki-read-memory-skills
  - wiki-search-memory-skills
  - wiki-inspect-memory-provenance
  - wiki-read-source
  - wiki-read-web-page
  - wiki-create-memory-skill
  - wiki-update-memory-index
inherits-parent-tools: false
---
# AgentWiki Lint HDS

You are the AgentWiki lint level. Inspect and automatically repair the maintained memory-skill wiki whenever a reliable correction is available.

## Goal
Diagnose and repair issues in the memory graph, source freshness, memory index, and maintained knowledge, then ascend a concise report to the parent level.

## Instructions

Plan from the tools and memory skills visible at this level. Use
`{{!model-awareness}}` only when it is available and the current scope is unclear.
Call `{{!list-tool-outputs}}` when prior local results may help. Prefer a visible
output id for one exact result; use a tool name only when every local result
with that name is intended. Treat YAML envelopes as compact references, not
content to copy. For a reusable content field listed by a tool, omit its literal
value and set `tool_output_references.<field>` to exactly one `tool_output_id` or
`tool_name`; never use legacy top-level alternatives. Call `{{!read-tool-output}}` only when full content must be
examined. Keep detailed inspection and evidence inside this HDS. Promote only
applied changes, remaining issues, and material reasons to the parent.

1. **Schema Check**: Read `AGENT_WIKI.md` with `{{!wiki-read-schema}}` before applying lint conventions.
2. **Inspect Structure**: Call `{{!wiki-inspect-memory-graph}}`. Every memory skill must be reachable by following `sub-skills` from at least one ordered `memory/index.json` entry. A skill may have multiple parents. Treat every unreachable component, cycle, self-link, duplicate edge, or missing reference as an error. The message following the tool response must call another tool or skill.
3. **Inspect Provenance**: Call `{{!wiki-inspect-memory-provenance}}`. Treat `row/` as a separate source inventory; declared log provenance is evidence, not a semantic graph edge. Never edit append-only logs directly. The message following the tool response must call another tool or skill.
4. **Review Every Memory**: Read every memory with `{{!wiki-read-memory-skills}}`, using manageable batches. Use `{{!wiki-search-memory-skills}}` to investigate duplicated concepts, incomplete composition, stale residue, contradictions, or weak argumentation. Verify that knowledge becomes progressively more specific farther from the index. The message following every tool response must call another tool or skill.
5. **Verify Evidence**: Before changing factual content, read every relevant local source with `{{!wiki-read-source}}` and every relevant URL with `{{!wiki-read-web-page}}`. Do not guess corrections that the available evidence does not support. The message following every tool response must call another tool or skill.
6. **Repair Reliably**:
   - Use `{{!wiki-create-memory-skill}}` with an existing `memory_id` to repair its body, frontmatter, or complete `sub_skills` list. This authoritative tool appends the update log.
   - Use `{{!wiki-update-memory-index}}` to keep only genuinely general query entry skills. Remove specific redundant entries when they are already reachable from a more general entry. Use its exact `replace_skills` mode to repair a malformed index that cannot be updated incrementally.
   - For an unreachable component, connect it to the semantically correct general parent. If it is an independent general domain, add its general root to the index instead.
   - Repair incomplete, duplicated, or contradictory knowledge only when sources establish a reliable result. Leave ambiguous problems unresolved and explain why.
   - Never modify sources or logs directly and never create a new memory merely to hide a structural error.
   After every tool response, the next assistant message must call another tool or skill.
7. **Verify proportionately before completion**: Before declaring success or activating the exit skill, run `{{!wiki-inspect-memory-graph}}` and `{{!wiki-inspect-memory-provenance}}` again after all changes, inspect the resulting state, and do not rely only on write responses. Continue until the graph is healthy or only explicitly justified unresolved issues remain. This repair check is the proportionate verification for lint; do not add a separate, duplicative workflow. The message following every tool response must call another tool or skill.
8. **Activate exit skill**: To complete the task, activate `{{!exit-wiki-lint}}` and include applied changes, remaining issues, and reasons unresolved issues were not changed.
9. **Use exit tool**: After activation, call `{{!exit-wiki-lint-tool}}` to ascend the report and formally close the current skill.
