---
description: AgentWiki ingest HDS that turns source sections into persistent memory deep skills.
exit-skill: exit-wiki-ingest
sub-tools:
  - list-tool-outputs
  - read-tool-output
  - wiki-read-schema
  - wiki-ensure-schema
  - wiki-read-memory-index
  - wiki-list-sources
  - wiki-read-source
  - wiki-read-web-page
  - wiki-create-memory-skill
  - wiki-update-memory-index
  - wiki-inspect-memory-graph
  - wiki-read-memory-skills
  - wiki-search-memory-skills
  - wiki-inspect-memory-provenance
inherits-parent-tools: false
---
# AgentWiki Ingest HDS

## Mission

Transform source material into a persistent, navigable knowledge graph of deep
skills under `memory/skills/`. Integrate concepts across sources instead of
creating a file-shaped archive.

## Invariants

- A source file is evidence, not the default boundary of a memory skill.
- Each memory skill represents one stable concept, semantic section, or useful
  synthesis.
- An evident category is a stable shared concept covering at least two planned
  skills and improving navigation or synthesis.
- Every evident category must have a parent memory skill with a concise,
  standalone synthesis, aggregated sources, and direct child ids in
  `sub_skills`.
- Standalone roots are allowed only when no meaningful evident category applies.
- Read all requested sources before the first `{{!wiki-create-memory-skill}}` call so
  the graph is designed globally rather than one file at a time.
- At depth greater than one, every assistant message immediately following a
  tool or skill response must contain another tool or skill call. Plain text is
  invalid.

## Workflow

Plan from the tools and memory skills visible at this level. Use
`{{!model-awareness}}` only when it is available and the current scope is unclear.
Call `{{!list-tool-outputs}}` when prior local results may help. Prefer a visible
output id for one exact result; use a tool name only when every local result
with that name is intended. Treat YAML envelopes as compact references, not
content to copy. For a reusable content field listed by a tool, omit its literal
value and set `tool_output_references.<field>` to exactly one `tool_output_id` or
`tool_name`; never use legacy top-level alternatives. Call `{{!read-tool-output}}` only when full content must be
examined. Keep long sources, comparisons, and graph-design work inside this HDS.
Promote only the decisions and results the parent and user need.

1. **Read the schema and index**: Call `{{!wiki-read-schema}}` before changing
   memory. Its output includes the current `memory/index.json` entries. If the
   schema is missing, call `{{!wiki-ensure-schema}}`, then call
   `{{!wiki-read-memory-index}}` to inspect the index separately. After every tool
   response, the next assistant message must call another tool or skill.
2. **Discover local sources**: For any local ingest, call `{{!wiki-list-sources}}`
   before reading files. Use the exact returned paths without a `row/` prefix.
   Each file is classified as `new`, `modified`, or `processed` and lists the
   memory ids currently associated with it. Do not guess filenames or assume
   one default document. After the response, the next assistant message must
   call another tool or skill.
3. **Inspect existing memory**: Call `{{!wiki-inspect-memory-graph}}` and
   `{{!wiki-inspect-memory-provenance}}` before designing changes. Use
   `{{!wiki-search-memory-skills}}` and `{{!wiki-read-memory-skills}}` to reuse existing
   concepts rather than duplicate them. After every response, the next
   assistant message must call another tool or skill.
4. **Read every requested source**: Call `{{!wiki-read-source}}` once for each
   relevant discovered file whose status is `new` or `modified`, and call
   `{{!wiki-read-web-page}}` for each requested URL. Skip `processed` local files
   unless the user explicitly requests a forced reread. An all-local-sources
   request means process every `new` or `modified` file returned by discovery,
   not every already processed file. After every response, the next assistant
   message must call another tool or skill.
5. **Design the complete graph before writing**:
   - Identify atomic concepts and useful source sections.
   - Compare concepts across all sources.
   - Group related concepts under evident categories.
   - Decide every planned leaf, parent, edge, and standalone root.
   - Reject the automatic mapping `one source file = one memory skill`.
6. **Create leaves first**: Call `{{!wiki-create-memory-skill}}` for each atomic
   concept. Omit `memory_id` for creation and retain each returned id. Use exact
   source-relative paths or HTTP(S) URLs in `sources`. After every response, the
   next assistant message must call another tool or skill.
7. **Create category parents**: For every evident category, call
   `{{!wiki-create-memory-skill}}` with a concise synthesis, the union of relevant
   sources, and the direct leaf or subordinate parent ids in `sub_skills`.
   Parent bodies summarize the category without copying all child bodies. After
   every response, the next assistant message must call another tool or skill.
8. **Apply updates carefully**: Pass an existing `memory_id` only when it is
   already known. For a modified source, update every associated memory id
   returned by `{{!wiki-list-sources}}` that still derives from that source; the
   source remains `modified` until every association records the current hash.
   Reconcile graph changes without creating duplicate concepts. Pass
   `sub_skills` when setting or replacing direct links; omit it when preserving
   existing links. The tool preserves manually customized exit skills and
   sub-tools. After every response, the next assistant message must call
   another tool or skill.
9. **Curate the query index**: After every referenced memory skill exists, use
   `{{!wiki-update-memory-index}}` to add only the principal, top-level skills that
   serve as useful navigation entry points, and remove entries that should no
   longer serve that role. Never add every memory skill merely because it
   exists or because the wiki currently contains only a small number of skills.
   Leaves and subordinate skills must remain reachable through their parent
   skills' `sub-skills` links instead of being duplicated in the index. The
   index is a curated navigation surface, not a complete inventory. Prefer no
   more than ten direct entries so query remains easy to navigate, but this is
   guidance rather than a structural limit. Every memory must be reachable from
   at least one index entry, so a non-empty memory graph cannot use an empty
   index. After the response, the next assistant message must call another tool
   or skill.
10. **Verify proportionately before completion**: Run the completion gate by
   calling `{{!wiki-inspect-memory-graph}}` again and verify every condition below
   before declaring success or activating the exit skill. Confirm the persisted
   graph and index rather than relying only on prior write responses. This gate
   is the proportionate verification for ingest; do not add a separate,
   duplicative verification workflow. If one condition fails, continue creating
   or linking memory.
11. **Activate the exit skill**: Only after the gate passes, call
   `{{!exit-wiki-ingest}}`. After its response, the next assistant message must call
   another tool or skill.
12. **Close the level**: Call `{{!exit-wiki-ingest-tool}}` with the controlled
    summary and formally ascend to the parent. The message following its
    response must necessarily contain a tool or skill call when execution
    continues at depth greater than one.

## Decision Rules

- Create a parent when two or more planned skills share an evident category.
- Do not create a parent merely because files share an extension, directory, or
  ingestion batch.
- Prefer a small number of meaningful parents over a generic catch-all root.
- A parent may contain child skills sourced from different files.
- One source may contribute to multiple skills when it contains distinct
  concepts.
- Do not create compiled wiki pages or legacy ingest records.
- Never edit `memory/index.json` directly; only `{{!wiki-update-memory-index}}` may
  change it.
- Index only principal navigation roots. Do not index leaves, subordinate
  skills, or every existing skill for completeness.
- Do not write directly into `memory/` or `logs/`; only
  `{{!wiki-create-memory-skill}}` may persist definitions and events.

## Completion Gate

Do not activate `{{!exit-wiki-ingest}}` until all statements are true:

- Every requested source was read, or a concrete reason for excluding it is
  available.
- Every `new` or `modified` requested source was processed, while unchanged
  `processed` sources were skipped unless explicitly forced.
- Every memory id associated with a modified source was updated or has a
  concrete reason why it no longer derives from that source.
- Every created skill represents a concept or synthesis rather than merely
  mirroring one source file.
- Every evident category has a created parent.
- Every category parent contains all intended direct `sub_skills`.
- Every standalone root has a specific semantic reason for remaining standalone.
- Every memory skill is reachable by following `sub-skills` from an index entry.
- Every index addition references an existing skill, and every index removal is
  intentional.
- No recognized hierarchy is deferred to `next_recommended_actions`.

Recognizing a category and suggesting that a parent could be created later is
an incomplete ingest, not a valid completion.

## Structural Example

Suppose six sources clearly describe two unrelated categories with three
concepts each. Create the six concept leaves first, then create two category
parents. Each parent links its three leaves through `sub_skills`; the two
parents become the derived roots. This illustrates graph shape only. Category
names and membership must always come from the actual sources.

## Invalid Outcomes

- Turning six sources into six roots without comparing their relationships.
- Reporting an evident parent as a possible future improvement.
- Copying an entire source into one skill without semantic segmentation or
  cross-source integration.
