from __future__ import annotations

from collections.abc import Mapping, Sequence
import re
from typing import Any

from agent_wiki.backend.core.capabilities.tool import get_local_tool_error_text
from agent_wiki.backend.core.outputs.exit_validation import (
    ExitErrorSuggestion,
    ExitValidationError,
)

_PLACEHOLDER_PATTERN = re.compile(r"\{\{\s*([A-Za-z0-9_-]+)\s*\}\}")
_NULL_MARKER_PATTERN = re.compile(
    r"\{\{\s*null\s*\}\}|\{\{\s*\}\}|\[\[null\]\]|\[null\]"
)


def generate_error_suggestions(
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Build corrective payloads for the exit-wiki-ingest contract."""
    if error.code == "selected_outputs_required":
        return _one(
            "select_placeholders",
            _payload(
                payload,
                selected_tool_outputs=_detail_strings(
                    error,
                    "placeholder_tokens",
                ),
            ),
        )

    if error.code == "missing_tokens":
        missing = _detail_strings(error, "missing_tokens")
        selected = _real_selections(payload.get("selected_tool_outputs"))
        return [
            _suggestion(
                "add_missing_selections",
                _payload(
                    payload,
                    selected_tool_outputs=_unique([*selected, *missing]),
                ),
            ),
            _suggestion(
                "remove_missing_placeholders",
                _payload(
                    payload,
                    message=_remove_placeholders(
                        str(payload.get("message", "")),
                        missing,
                    ),
                    selected_tool_outputs=selected,
                ),
            ),
        ]

    if error.code == "extra_tokens":
        extra = _detail_strings(error, "extra_tokens")
        selected = _real_selections(payload.get("selected_tool_outputs"))
        return _one(
            "cite_extra_selections",
            _payload(
                payload,
                message=_append_placeholders(
                    str(payload.get("message", "")),
                    extra,
                ),
                selected_tool_outputs=selected,
            ),
        )

    if error.code == "null_only_item":
        selected = _real_selections(payload.get("selected_tool_outputs"))
        message = _remove_null_markers(str(payload.get("message", "")))
        return [
            _suggestion(
                "keep_real_outputs",
                _payload(
                    payload,
                    message=_append_placeholders(message, selected),
                    selected_tool_outputs=selected,
                ),
            ),
            _suggestion("use_no_outputs", _without_outputs_payload(payload)),
        ]

    if error.code in {"selected_outputs_array", "selected_item_type"}:
        placeholders = _detail_strings(error, "placeholder_tokens")
        if placeholders:
            return _one(
                "rebuild_selection",
                _payload(payload, selected_tool_outputs=placeholders),
            )
        return _one("use_no_outputs", _without_outputs_payload(payload))

    if error.code in {"non_empty_message", "null_marker_required"}:
        return _one("use_no_outputs", _without_outputs_payload(payload))

    if error.code == "multiple_null_markers":
        return _one("keep_one_null_marker", _without_outputs_payload(payload))

    if error.code == "unknown_local_reference":
        return _unknown_reference_suggestions(
            error=error,
            payload=payload,
            local_references=local_references,
        )

    return []


def _unknown_reference_suggestions(
    *,
    error: ExitValidationError,
    payload: Mapping[str, Any],
    local_references: Sequence[str],
) -> Sequence[ExitErrorSuggestion]:
    """Suggest replacing an unknown token with each local output candidate."""
    token = str(error.details.get("token", ""))
    replacements = _detail_strings(error, "replacement_tokens")
    available = ", ".join(local_references) or "none"
    suggestions = [
        ExitErrorSuggestion(
            description=_text(
                "replace_unknown_reference",
                token=token,
                replacement=replacement,
                available_references=available,
            ),
            payload=_replace_unknown_reference_payload(
                payload=payload, token=token, replacement=replacement
            ),
        )
        for replacement in replacements
    ]
    return suggestions or _one("use_no_outputs", _without_outputs_payload(payload))


def _replace_unknown_reference_payload(
    *, payload: Mapping[str, Any], token: str, replacement: str
) -> dict[str, Any]:
    """Replace one unknown selection and cite its local replacement in the message."""
    selected = [
        replacement if item == token else item
        for item in _real_selections(payload.get("selected_tool_outputs"))
    ]
    message = _remove_placeholders(str(payload.get("message", "")), [token])
    return _payload(
        payload,
        message=_append_placeholders(message, [replacement]),
        selected_tool_outputs=_unique(selected),
    )


def _payload(
    payload: Mapping[str, Any],
    *,
    message: str | None = None,
    selected_tool_outputs: Sequence[str | None] | None = None,
) -> dict[str, Any]:
    """Copy a payload while replacing its message-selection contract fields."""
    updated = dict(payload)
    if message is not None:
        updated["message"] = message
    if selected_tool_outputs is not None:
        updated["selected_tool_outputs"] = list(selected_tool_outputs)
    return updated


def _without_outputs_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Build a canonical payload that intentionally promotes no tool output."""
    message = _remove_null_markers(str(payload.get("message", ""))).strip()
    message = _PLACEHOLDER_PATTERN.sub("", message).strip()
    if not message:
        message = _text("no_output_message")
    return _payload(
        payload,
        message=f"{message} {{{{null}}}}",
        selected_tool_outputs=[None],
    )


def _append_placeholders(message: str, tokens: Sequence[str]) -> str:
    """Append any missing placeholders to a message."""
    existing = set(_PLACEHOLDER_PATTERN.findall(message))
    additions = [f"{{{{{token}}}}}" for token in tokens if token not in existing]
    return " ".join(part for part in [message.strip(), *additions] if part)


def _remove_placeholders(message: str, tokens: Sequence[str]) -> str:
    """Remove selected shorthand placeholders from a message."""
    token_set = set(tokens)
    return _PLACEHOLDER_PATTERN.sub(
        lambda match: "" if match.group(1) in token_set else match.group(0),
        message,
    ).strip()


def _remove_null_markers(message: str) -> str:
    """Remove every supported null marker from a message."""
    return _NULL_MARKER_PATTERN.sub("", message).strip()


def _real_selections(value: Any) -> list[str]:
    """Return normalized real string selections from an arbitrary value."""
    if not isinstance(value, list):
        return []
    selections: list[str] = []
    for item in value:
        if not isinstance(item, str):
            continue
        token = item.strip()
        if token.startswith("{{") and token.endswith("}}"):
            token = token[2:-2].strip()
        if token and token != "null":
            selections.append(token)
    return _unique(selections)


def _detail_strings(error: ExitValidationError, key: str) -> list[str]:
    """Read one ordered string sequence from validation details."""
    value = error.details.get(key, ())
    if not isinstance(value, Sequence) or isinstance(value, str):
        return []
    return _unique([item for item in value if isinstance(item, str) and item])


def _unique(values: Sequence[str]) -> list[str]:
    """Return values in first-seen order without duplicates."""
    return list(dict.fromkeys(values))


def _one(key: str, payload: Mapping[str, Any]) -> Sequence[ExitErrorSuggestion]:
    """Build a one-item suggestion sequence."""
    return [_suggestion(key, payload)]


def _suggestion(key: str, payload: Mapping[str, Any]) -> ExitErrorSuggestion:
    """Build one suggestion using the exit-local text catalog."""
    return ExitErrorSuggestion(description=_text(key), payload=payload)


def _text(key: str, **values: object) -> str:
    """Resolve one exit-local suggestion string."""
    return get_local_tool_error_text(
        __file__,
        f"suggestions.{key}",
        **values,
    )
