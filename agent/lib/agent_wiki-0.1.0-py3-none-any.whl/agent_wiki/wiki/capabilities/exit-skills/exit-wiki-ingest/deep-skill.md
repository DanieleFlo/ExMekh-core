---
description: Closes the AgentWiki ingest level with a controlled result.
---
# AgentWiki Ingest Exit

Close this HDS only after its completion gate passes, promoting the concise
result its parent needs. An HDS may respond normally when it does not need
controlled output reuse.

## Instructions

1. Recheck that every evident category has its parent and intended
   `sub_skills`, every standalone root has a semantic reason, and no recognized
   hierarchy was deferred. Continue ingest if any condition fails.
2. Build a concise JSON document in `message` with `operation: "ingest"`,
   `sources_processed`, `memory_skills_created`, `memory_skills_updated`,
   `semantic_groups_considered`, `root_memory_skills`, `sub_skill_links`,
   `standalone_roots_with_reason`, `contradictions_or_conflicts`, and
   `next_recommended_actions`. Each considered group must name its parent or
   explain why grouping was not useful. Do not defer required parents or links
   through `next_recommended_actions`.
3. When the document alone is sufficient, append `{{null}}` and use
   `selected_tool_outputs: [null]`. Do not copy sources, memory bodies, local chat,
   reasoning, or write results merely to prove they exist; the envelope can expose
   successful local activity through `metadata.used_capabilities`.
4. When raw node-visible content is essential, call `list-tool-outputs`; use one
   visible id for one exact result or an exact tool name for every matching result.
   The HDS node root and all of its regular deep skills share these outputs before
   and after ascent. Call `read-tool-output` only to inspect full content. Put each
   reference in `message` as `{{reference}}` and list the same bare string in
   `selected_tool_outputs`. Never use invented or provider-internal ids.
5. Call `exit-wiki-ingest-tool`. At depth greater than one, every assistant
   message after a tool or skill response must contain another tool or skill call.

Do not mix `null` with real selections. Every selected reference must have one
matching placeholder and vice versa; references are local to this HDS node.

## Example

```json
{"message":"{\"operation\":\"ingest\",\"sources_processed\":[\"document.md\"],\"memory_skills_created\":[\"topic-a\"],\"memory_skills_updated\":[],\"semantic_groups_considered\":[{\"group\":\"Topic A\",\"parent\":\"topic-a\"}],\"root_memory_skills\":[\"topic-a\"],\"sub_skill_links\":[],\"standalone_roots_with_reason\":[],\"contradictions_or_conflicts\":[],\"next_recommended_actions\":[]} {{null}}","selected_tool_outputs":[null]}
```
