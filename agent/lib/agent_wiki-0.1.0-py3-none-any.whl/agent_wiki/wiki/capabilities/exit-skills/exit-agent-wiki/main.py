from __future__ import annotations

from agent_wiki.backend.core.capabilities.tool import sign_tool
from agent_wiki.wiki._exit_tools import build_exit_payload


@sign_tool(
    short_description=(
        "Closes the AgentWiki root level with a message template that can inline local tool outputs."
    )
)
def main(
    message: str | None = None,
    selected_tool_outputs: list[str | None] | None = None,
) -> dict[str, object]:
    """Return the selected AgentWiki root exit payload for runtime rendering."""
    return build_exit_payload(
        message=message,
        selected_tool_outputs=selected_tool_outputs,
    )
