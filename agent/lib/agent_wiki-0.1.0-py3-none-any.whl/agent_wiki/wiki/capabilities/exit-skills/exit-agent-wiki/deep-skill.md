---
description: Closes the AgentWiki root level with a controlled result.
---
# AgentWiki Root Exit

Close this HDS by promoting only the result its parent needs. An HDS may respond
normally when it does not need controlled output reuse.

## Instructions

1. Build a concise JSON document in `message` with `operation: "agent-wiki"`,
   `result`, `child_results`, `pages_or_sources_referenced`, and
   `next_recommended_actions`. Exclude local chat, reasoning, and unrelated data.
2. When the document alone is sufficient, append `{{null}}` and use
   `selected_tool_outputs: [null]`. Do not copy child output merely to prove it
   exists; the promoted envelope can expose successful local activity through
   `metadata.used_capabilities`.
3. When raw node-visible content is essential, call `list-tool-outputs`; use one
   visible id for one exact result or an exact tool name for every matching result.
   The HDS node root and all of its regular deep skills share these outputs before
   and after ascent. Call `read-tool-output` only to inspect full content. Put each
   reference in `message` as `{{reference}}` and list the same bare string in
   `selected_tool_outputs`. Never use invented or provider-internal ids.
4. Call `exit-agent-wiki-tool`. At depth greater than one, every assistant
   message after a tool or skill response must contain another tool or skill call.

Do not mix `null` with real selections. Every selected reference must have one
matching placeholder and vice versa; references are local to this HDS node.

## Example

```json
{"message":"{\"operation\":\"agent-wiki\",\"result\":\"Query completed.\",\"child_results\":[\"wiki-query answered the request\"],\"pages_or_sources_referenced\":[],\"next_recommended_actions\":[]} {{null}}","selected_tool_outputs":[null]}
```
