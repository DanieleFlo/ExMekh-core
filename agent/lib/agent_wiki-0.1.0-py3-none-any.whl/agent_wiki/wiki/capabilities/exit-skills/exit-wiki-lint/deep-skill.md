---
description: Closes the AgentWiki lint level with a concise health result.
---
# AgentWiki Lint Exit

Close this HDS by promoting only the verified health result its parent needs. An
HDS may respond normally when it does not need controlled output reuse.

## Instructions

1. Build a concise JSON document in `message` with `operation: "lint"`,
   `applied_changes`, `remaining_issues`, `unresolved_reasons`,
   `final_graph_status`, and `final_provenance_status`. Exclude full memory
   bodies, local chat, reasoning, and unrelated data.
2. When the document alone is sufficient, append `{{null}}` and use
   `selected_tool_outputs: [null]`. Do not copy inspection or repair output
   merely to prove it exists; the promoted envelope can expose successful local
   activity through `metadata.used_capabilities`.
3. When raw node-visible content is essential, call `list-tool-outputs`; use one
   visible id for one exact result or an exact tool name for every matching result.
   The HDS node root and all of its regular deep skills share these outputs before
   and after ascent. Call `read-tool-output` only to inspect full content. Put each
   reference in `message` as `{{reference}}` and list the same bare string in
   `selected_tool_outputs`. Never use invented or provider-internal ids.
4. Call `exit-wiki-lint-tool`. At depth greater than one, every assistant
   message after a tool or skill response must contain another tool or skill call.

Do not mix `null` with real selections. Every selected reference must have one
matching placeholder and vice versa; references are local to this HDS node.

## Example

```json
{"message":"{\"operation\":\"lint\",\"applied_changes\":[],\"remaining_issues\":[],\"unresolved_reasons\":[],\"final_graph_status\":{\"healthy\":true},\"final_provenance_status\":{\"healthy\":true}} {{null}}","selected_tool_outputs":[null]}
```
