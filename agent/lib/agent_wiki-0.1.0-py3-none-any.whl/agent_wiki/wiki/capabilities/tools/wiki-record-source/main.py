from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.wiki._tool_utils import (
    filesystem_error_name,
    ingest_log_path,
    normalize_compiled_path,
    read_jsonl,
    resolve_raw_wiki_path,
    source_relative_path,
    workspace_relative_path,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(
    short_description="Records one source-root-relative file as processed by AgentWiki ingest.",
    reusable_input_fields=("notes",),
)
def main(
    source_path: str,
    pages_created: list[str] | None = None,
    pages_updated: list[str] | None = None,
    notes: str = "",
    workroot: Path | None = None,
) -> dict[str, object] | ToolOutput:
    """Append one source-processing record to the ingest log."""
    try:
        source = resolve_raw_wiki_path(source_path, workroot=workroot)
    except Exception as error:
        return {
            "recorded": False,
            "error": _error("resolve_path", error=error),
        }

    relative_source = source_relative_path(source, workroot=workroot)
    if not source.exists():
        return {
            "recorded": False,
            "error": _error("path_not_found", path=relative_source),
        }
    if source.is_dir():
        return {
            "recorded": False,
            "error": _error("path_is_directory", path=relative_source),
        }

    target = ingest_log_path(workroot=workroot)
    relative_target = workspace_relative_path(target, workroot=workroot)
    try:
        normalized_created = [
            normalize_compiled_path(path, workroot=workroot)
            for path in pages_created or []
        ]
        normalized_updated = [
            normalize_compiled_path(path, workroot=workroot)
            for path in pages_updated or []
        ]
    except ValueError as error:
        return {
            "recorded": False,
            "error": _error("resolve_page_path", error=error),
        }
    record = {
        "source_path": relative_source,
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "pages_created": normalized_created,
        "pages_updated": normalized_updated,
        "notes": notes,
    }

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a", encoding="utf-8") as file:
            file.write(json.dumps(record, ensure_ascii=False) + "\n")
        total_records = len(read_jsonl(target))
    except (OSError, json.JSONDecodeError) as error:
        return {
            "recorded": False,
            "error": _error(
                "write_failed",
                path=relative_target,
                error=filesystem_error_name(error),
            ),
        }

    payload = {
        "recorded": True,
        "path": relative_target,
        "record": record,
        "total_records": total_records,
    }
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "path": relative_target,
                "recorded": True,
                "source_path": relative_source,
                "pages_created": len(normalized_created),
                "pages_updated": len(normalized_updated),
                "total_records": total_records,
            }
        ),
    )
