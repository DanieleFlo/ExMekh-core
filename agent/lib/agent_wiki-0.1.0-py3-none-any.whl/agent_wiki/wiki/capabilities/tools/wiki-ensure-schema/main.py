from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.wiki._tool_utils import (
    default_schema_text,
    filesystem_error_name,
    schema_path,
    workspace_relative_path,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(short_description="Creates the workspace AgentWiki schema file when needed.")
def main(
    overwrite: bool = False, workroot: Path | None = None
) -> dict[str, object] | ToolOutput:
    """Ensure the workspace-level AGENT_WIKI.md schema file exists."""
    target = schema_path(workroot=workroot)
    relative_path = workspace_relative_path(target, workroot=workroot)
    if target.exists() and target.is_dir():
        return {
            "path": relative_path,
            "created": False,
            "overwritten": False,
            "error": _error("path_is_directory", path=relative_path),
        }
    if target.exists() and not overwrite:
        payload = {
            "path": relative_path,
            "created": False,
            "overwritten": False,
            "preserved": True,
        }
        return ToolOutput(
            result=json.dumps(payload, ensure_ascii=False),
            metadata=format_tool_metadata(
                {"path": relative_path, "created": False, "overwritten": False}
            ),
        )

    existed = target.exists()
    try:
        schema_text = default_schema_text()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(schema_text, encoding="utf-8")
    except OSError as error:
        return {
            "path": relative_path,
            "created": False,
            "overwritten": False,
            "error": _error(
                "write_failed",
                path=relative_path,
                error=filesystem_error_name(error),
            ),
        }

    payload = {
        "path": relative_path,
        "created": not existed,
        "overwritten": existed,
        "preserved": False,
        "bytes": len(schema_text.encode("utf-8")),
    }
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "path": relative_path,
                "created": not existed,
                "overwritten": existed,
                "bytes": len(schema_text.encode("utf-8")),
            }
        ),
    )
