from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki._tool_utils import workspace_relative_path
from agent_wiki.wiki.memory_index import read_memory_index


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(short_description="Reads the ordered AgentWiki memory skill index.")
def main(
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> dict[str, object] | ToolOutput:
    """Return the current memory index without creating a missing file."""
    if config is None:
        return {
            "read": False,
            "error": _error("missing_config"),
        }
    try:
        index = read_memory_index(workroot=workroot, config=config)
        relative_path = workspace_relative_path(index.path, workroot=workroot)
    except Exception as error:
        return {
            "read": False,
            "error": _error("invalid_index", error=error),
        }

    payload = {
        "read": True,
        "path": relative_path,
        "exists": index.exists,
        "skills": list(index.skills),
    }
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "path": relative_path,
                "exists": index.exists,
                "skills": len(index.skills),
            }
        ),
    )
