from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki.memory_toolkit import (
    list_source_inventory,
    load_memory_workspace_snapshot,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(short_description="Shows the complete AgentWiki memory graph and disconnected branches.")
def main(
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> dict[str, object] | ToolOutput:
    """Return the indexed memory graph, reachability diagnostics, and row inventory."""
    if config is None:
        return {"inspected": False, "error": _error("missing_config")}
    try:
        snapshot = load_memory_workspace_snapshot(workroot=workroot, config=config)
        sources = list_source_inventory(workroot=workroot, snapshot=snapshot)
        issues = list(snapshot.graph.issues)
        if snapshot.index_error is not None:
            issues.insert(
                0,
                {
                    "type": "invalid_memory_index",
                    "path": "memory/index.json",
                    "error": snapshot.index_error,
                },
            )
        elif snapshot.definitions and not snapshot.index.exists:
            issues.insert(0, {"type": "missing_memory_index", "path": "memory/index.json"})
        nodes = [
            {
                "memory_id": memory_id,
                "description": definition.description,
                "indexed": memory_id in snapshot.index.skills,
                "reachable_from_index": memory_id in snapshot.graph.reachable_from_index,
                "depth": snapshot.graph.depths.get(memory_id),
                "incoming_skills": list(snapshot.graph.incoming.get(memory_id, ())),
                "sub_skills": list(definition.sub_skills),
            }
            for memory_id, definition in sorted(snapshot.definitions.items())
        ]
        payload = {
            "inspected": True,
            "healthy": not issues,
            "index": {
                "exists": snapshot.index.exists,
                "valid": snapshot.index_error is None,
                "skills": list(snapshot.index.skills),
                "error": snapshot.index_error,
            },
            "roots": list(snapshot.graph.roots),
            "indexed_roots": list(snapshot.graph.indexed_roots),
            "reachable_from_index": list(snapshot.graph.reachable_from_index),
            "unreachable_from_index": list(snapshot.graph.unreachable_from_index),
            "unreachable_components": list(snapshot.graph.unreachable_components),
            "nodes": nodes,
            "issues": issues,
            "warnings": list(snapshot.graph.warnings),
            "diagram": snapshot.graph.diagram,
            "row_sources": sources,
        }
    except Exception as error:
        return {"inspected": False, "error": _error("inspection_failed", error=error)}
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "healthy": payload["healthy"],
                "memory_skills": len(snapshot.definitions),
                "unreachable": len(snapshot.graph.unreachable_from_index),
                "source_kind": "wiki_memory_graph",
            }
        ),
    )
