from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki._tool_utils import workspace_relative_path
from agent_wiki.wiki.memory_index import read_memory_index, write_memory_index
from agent_wiki.wiki.memory_skills import validate_memory_id


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _normalize_ids(values: list[str]) -> list[str]:
    """Normalize and deduplicate model-provided skill ids in order."""
    normalized: list[str] = []
    for value in values:
        skill_id = validate_memory_id(value)
        if skill_id not in normalized:
            normalized.append(skill_id)
    return normalized


@sign_tool(short_description="Adds, removes, or authoritatively replaces memory index skills.")
def main(
    add_skills: list[str],
    remove_skills: list[str],
    replace_skills: list[str] | None = None,
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> dict[str, object] | ToolOutput:
    """Apply an incremental update or exact replacement to the memory index."""
    if config is None:
        return {
            "updated": False,
            "error": _error("missing_config"),
        }
    try:
        additions = _normalize_ids(add_skills)
        removals = _normalize_ids(remove_skills)
        replacements = (
            _normalize_ids(replace_skills) if replace_skills is not None else None
        )
        if replacements is not None and (additions or removals):
            raise ValueError(
                "replace_skills cannot be combined with add_skills or remove_skills."
            )
        overlap = sorted(set(additions) & set(removals))
        if overlap:
            raise ValueError(
                "The same skill id cannot be added and removed in one update: "
                f"{', '.join(overlap)}."
            )

        if replacements is not None:
            try:
                current = read_memory_index(
                    workroot=workroot,
                    config=config,
                    validate_references=False,
                )
                current_exists = current.exists
            except (OSError, UnicodeError, ValueError):
                current_exists = False
            updated = replacements
        else:
            current = read_memory_index(
                workroot=workroot,
                config=config,
                validate_references=False,
            )
            current_exists = current.exists
            removal_set = set(removals)
            updated = [
                skill_id for skill_id in current.skills if skill_id not in removal_set
            ]
            for skill_id in additions:
                if skill_id not in updated:
                    updated.append(skill_id)
        written = write_memory_index(
            skills=updated,
            workroot=workroot,
            config=config,
        )
        relative_path = workspace_relative_path(written.path, workroot=workroot)
    except Exception as error:
        return {
            "updated": False,
            "error": _error("invalid_update", error=error),
        }

    payload = {
        "updated": True,
        "created": not current_exists,
        "path": relative_path,
        "added": additions,
        "removed": removals,
        "replaced": replacements is not None,
        "skills": list(written.skills),
    }
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "path": relative_path,
                "created": not current_exists,
                "skills": len(written.skills),
            }
        ),
    )
