from __future__ import annotations

import json
import re
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.wiki._tool_utils import (
    compiled_relative_path,
    filesystem_error_name,
    resolve_compiled_wiki_path,
    safe_argument_path,
)

_MARKDOWN_LINK_PATTERN = re.compile(r"\[[^\]]+\]\(([^)]+)\)")
_WIKI_LINK_PATTERN = re.compile(r"\[\[([^\]]+)\]\]")


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _extract_links(text: str) -> list[str]:
    """Extract Markdown and wiki-style links from text."""
    markdown_links = [
        match.group(1).strip() for match in _MARKDOWN_LINK_PATTERN.finditer(text)
    ]
    wiki_links = [match.group(1).strip() for match in _WIKI_LINK_PATTERN.finditer(text)]
    return [link for link in [*markdown_links, *wiki_links] if link]


@sign_tool(short_description="Detects links in one compiled AgentWiki Markdown page.")
def main(path: str, workroot: Path | None = None) -> dict[str, object] | ToolOutput:
    """Return links found in one compiled Markdown page."""
    try:
        target = resolve_compiled_wiki_path(path, workroot=workroot)
    except Exception as error:
        return {
            "path": safe_argument_path(path),
            "links": [],
            "error": _error("resolve_path", error=error),
        }

    relative_path = compiled_relative_path(target, workroot=workroot)
    if not target.exists():
        return {
            "path": relative_path,
            "links": [],
            "error": _error("path_not_found", path=relative_path),
        }
    if target.is_dir():
        return {
            "path": relative_path,
            "links": [],
            "error": _error("path_is_directory", path=relative_path),
        }
    if target.suffix != ".md":
        return {
            "path": relative_path,
            "links": [],
            "error": _error("not_markdown", path=relative_path),
        }

    try:
        text = target.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as error:
        return {
            "path": relative_path,
            "links": [],
            "error": _error(
                "read_failed",
                path=relative_path,
                error=filesystem_error_name(error),
            ),
        }

    links = _extract_links(text)
    payload = {"path": relative_path, "links": links}
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata({"path": relative_path, "links": len(links)}),
    )
