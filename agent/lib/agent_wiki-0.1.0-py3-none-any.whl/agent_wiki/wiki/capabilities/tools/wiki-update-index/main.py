from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.wiki._tool_utils import (
    compiled_wiki_root,
    filesystem_error_name,
    index_path,
    iter_compiled_wiki_pages,
    workspace_relative_path,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _page_title(path: Path) -> str:
    """Return the first Markdown heading from a page, falling back to its stem."""
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith("#"):
                return stripped.lstrip("#").strip() or path.stem
    except (OSError, UnicodeDecodeError):
        return path.stem
    return path.stem


@sign_tool(short_description="Updates the AgentWiki compiled page index.")
def main(workroot: Path | None = None) -> dict[str, object] | ToolOutput:
    """Build a JSON index of compiled Markdown pages."""
    root = compiled_wiki_root(workroot=workroot)
    target = index_path(workroot=workroot)
    if not root.exists():
        return {
            "updated": False,
            "pages": [],
            "error": _error("root_not_found", path="."),
        }

    pages = [
        {"path": page.relative_to(root).as_posix(), "title": _page_title(page)}
        for page in iter_compiled_wiki_pages(workroot=workroot)
    ]
    payload = {"pages": pages}
    relative_target = workspace_relative_path(target, workroot=workroot)

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    except OSError as error:
        return {
            "updated": False,
            "pages": pages,
            "error": _error(
                "write_failed",
                path=relative_target,
                error=filesystem_error_name(error),
            ),
        }

    payload = {"updated": True, "path": relative_target, "pages": pages}
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {"path": relative_target, "updated": True, "pages": len(pages)}
        ),
    )
