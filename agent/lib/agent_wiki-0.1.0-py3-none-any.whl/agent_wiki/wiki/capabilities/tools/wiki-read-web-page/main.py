from __future__ import annotations

import json
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any
from urllib.parse import urlparse

from playwright.sync_api import Error as PlaywrightError
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki.pdf_markdown import convert_pdf_to_markdown
from agent_wiki.wiki._tool_utils import filesystem_error_name


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _is_supported_url(url: str) -> bool:
    """Return whether a URL uses an ingest-supported web scheme."""
    parsed = urlparse(url)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def _render_url_to_pdf(url: str, target: Path, *, timeout_ms: int) -> None:
    """Render one web page URL to a PDF file with Playwright."""
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        try:
            page = browser.new_page()
            page.goto(url, wait_until="networkidle", timeout=timeout_ms)
            page.pdf(path=str(target), print_background=True)
        finally:
            browser.close()


@sign_tool(
    short_description="Reads one web page as Markdown through AgentWiki PDF ingest."
)
def main(
    url: str,
    workroot: Path | None = None,
    client: Any = None,
    config: RuntimePackageConfig | None = None,
    model_name: str | None = None,
    timeout_seconds: int = 30,
) -> dict[str, object] | ToolOutput:
    """Render one web page to a temporary PDF and convert it to Markdown."""
    del workroot
    if not _is_supported_url(url):
        return {
            "url": url,
            "read": False,
            "markdown": "",
            "error": _error("invalid_url", url=url),
        }
    if timeout_seconds <= 0:
        return {
            "url": url,
            "read": False,
            "markdown": "",
            "error": _error("invalid_timeout", timeout=timeout_seconds),
        }

    try:
        with TemporaryDirectory(prefix="agent-wiki-web-pdf-") as temp_dir:
            pdf_path = Path(temp_dir) / "page.pdf"
            _render_url_to_pdf(
                url,
                pdf_path,
                timeout_ms=timeout_seconds * 1000,
            )
            result = convert_pdf_to_markdown(
                path=pdf_path,
                client=client,
                config=config,
                model_name=model_name,
            )
    except PlaywrightTimeoutError as error:
        return {
            "url": url,
            "read": False,
            "markdown": "",
            "error": _error(
                "render_timeout",
                url=url,
                error=filesystem_error_name(error),
            ),
        }
    except PlaywrightError as error:
        return {
            "url": url,
            "read": False,
            "markdown": "",
            "error": _error(
                "render_failed",
                url=url,
                error=filesystem_error_name(error),
            ),
        }
    except Exception as error:
        return {
            "url": url,
            "read": False,
            "markdown": "",
            "error": _error(
                "pdf_parse_failed",
                url=url,
                error=filesystem_error_name(error),
            ),
        }

    payload = {
        "url": url,
        "read": True,
        "markdown": result.markdown,
        "page_count": result.page_count,
        "model": result.model,
    }
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "url": url,
                "read": True,
                "page_count": result.page_count,
                "model": result.model,
                "bytes": len(result.markdown.encode("utf-8")),
                "lines": len(result.markdown.splitlines()),
            }
        ),
    )
