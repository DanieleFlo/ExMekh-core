from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki.memory_skills import (
    file_sha256,
    load_source_processing_states,
    resolve_memory_skill_paths,
)
from agent_wiki.wiki._tool_utils import (
    filesystem_error_name,
    raw_wiki_root,
    source_relative_path,
)


logger = logging.getLogger(__name__)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _empty_payload() -> dict[str, object]:
    """Return the canonical empty source inventory."""
    return {
        "source_root": "row/",
        "files": [],
        "count": 0,
        "status_counts": {
            "new": 0,
            "modified": 0,
            "processed": 0,
        },
    }


def _is_hidden(path: Path, *, root: Path) -> bool:
    """Return whether a source path has a hidden component below the source root."""
    try:
        relative_parts = path.relative_to(root).parts
    except ValueError:
        return True
    return any(part.startswith(".") for part in relative_parts)


@sign_tool(
    short_description=(
        "Recursively lists AgentWiki source files with paths relative to row/."
    )
)
def main(
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> dict[str, object] | ToolOutput:
    """Return a recursive inventory of regular, non-hidden source files."""
    if config is None:
        logger.warning("wiki-list-sources called without runtime config")
        return {
            **_empty_payload(),
            "error": _error("missing_config"),
        }
    root = raw_wiki_root(workroot=workroot)
    logger.info(
        "Listing AgentWiki sources",
        extra={"workroot": str(workroot) if workroot is not None else None},
    )
    if not root.exists():
        payload = _empty_payload()
        logger.info("AgentWiki source root is missing", extra={"source_root": str(root)})
        return ToolOutput(
            result=json.dumps(payload, ensure_ascii=False),
            metadata=format_tool_metadata(
                {"source_root": "row/", "files": 0}
            ),
        )
    if not root.is_dir():
        logger.warning(
            "AgentWiki source root is not a directory",
            extra={"source_root": str(root)},
        )
        return {
            **_empty_payload(),
            "error": _error("root_not_directory"),
        }

    memory_paths = resolve_memory_skill_paths(workroot=workroot, config=config)
    processing_states = load_source_processing_states(paths=memory_paths)
    files: list[dict[str, object]] = []
    status_counts = {
        "new": 0,
        "modified": 0,
        "processed": 0,
    }
    walk_errors: list[str] = []

    def _record_walk_error(error: OSError) -> None:
        """Record a safe error label for an inaccessible source branch."""
        walk_errors.append(filesystem_error_name(error))

    for current_root, directory_names, file_names in os.walk(
        root,
        topdown=True,
        onerror=_record_walk_error,
        followlinks=False,
    ):
        current_path = Path(current_root)
        directory_names[:] = sorted(
            directory_name
            for directory_name in directory_names
            if not directory_name.startswith(".")
            and not (current_path / directory_name).is_symlink()
        )
        for file_name in sorted(file_names):
            candidate = current_path / file_name
            if file_name.startswith(".") or candidate.is_symlink():
                continue
            if _is_hidden(candidate, root=root) or not candidate.is_file():
                continue
            try:
                relative_path = source_relative_path(candidate, workroot=workroot)
                size = candidate.stat().st_size
                source_hash = file_sha256(candidate)
            except (OSError, ValueError) as error:
                walk_errors.append(filesystem_error_name(error))
                continue
            state = processing_states.get(relative_path)
            status = (
                state.status_for_hash(source_hash) if state is not None else "new"
            )
            memory_ids = list(state.memory_ids) if state is not None else []
            status_counts[status] += 1
            files.append(
                {
                    "path": relative_path,
                    "extension": candidate.suffix.casefold(),
                    "bytes": size,
                    "sha256": source_hash,
                    "status": status,
                    "memory_ids": memory_ids,
                }
            )

    files.sort(key=lambda item: str(item["path"]).casefold())
    payload: dict[str, object] = {
        "source_root": "row/",
        "files": files,
        "count": len(files),
        "status_counts": status_counts,
    }
    if walk_errors:
        payload["warning"] = _error("partial_inventory", skipped=len(walk_errors))
    logger.info(
        "Listed AgentWiki sources",
        extra={
            "source_root": str(root),
            "files": len(files),
            "skipped": len(walk_errors),
            **status_counts,
        },
    )
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "source_root": "row/",
                "files": len(files),
                "skipped": len(walk_errors),
                **status_counts,
            }
        ),
    )
