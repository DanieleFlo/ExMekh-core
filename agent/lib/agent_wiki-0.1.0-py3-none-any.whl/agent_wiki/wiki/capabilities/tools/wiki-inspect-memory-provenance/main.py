from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import urlparse

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki.memory_skills import inspect_memory_logs
from agent_wiki.wiki.memory_toolkit import (
    list_source_inventory,
    load_memory_workspace_snapshot,
    select_memory_ids,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(short_description="Inspects memory logs, source freshness, and update residue.")
def main(
    memory_ids: list[str] | None = None,
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> dict[str, object] | ToolOutput:
    """Return provenance diagnostics without modifying memories or append-only logs."""
    if config is None:
        return {"inspected": False, "error": _error("missing_config")}
    try:
        snapshot = load_memory_workspace_snapshot(workroot=workroot, config=config)
        selected = select_memory_ids(
            requested=memory_ids,
            available=snapshot.definitions,
        ) if memory_ids is not None else tuple(sorted(snapshot.definitions))
        selected_set = set(selected)
        log_report = inspect_memory_logs(
            paths=snapshot.paths,
            definitions=snapshot.definitions,
        )
        source_inventory = list_source_inventory(workroot=workroot, snapshot=snapshot)
        known_local_sources = {
            str(source["path"])
            for source in source_inventory["files"]
            if isinstance(source, dict) and "path" in source
        }
        issues = [
            issue
            for issue in log_report.issues
            if issue.get("memory_id") in selected_set
        ]
        warnings = [
            warning
            for warning in log_report.warnings
            if warning.get("memory_id") in selected_set
            or warning.get("type") == "orphan_memory_log"
        ]
        declared_sources: dict[str, list[str]] = {}
        for memory_id in selected:
            record = snapshot.latest_logs.get(memory_id, {})
            raw_sources = record.get("sources", [])
            sources = [value for value in raw_sources if isinstance(value, str)] if isinstance(raw_sources, list) else []
            declared_sources[memory_id] = sources
            for source in sources:
                parsed = urlparse(source)
                if not parsed.scheme and source not in known_local_sources:
                    issues.append(
                        {
                            "type": "missing_declared_source",
                            "memory_id": memory_id,
                            "source": source,
                        }
                    )
        for source in source_inventory["files"]:
            if isinstance(source, dict) and source.get("status") in {"new", "modified"}:
                issues.append(
                    {
                        "type": "source_requires_ingest",
                        "source": source.get("path"),
                        "status": source.get("status"),
                    }
                )
        payload = {
            "inspected": True,
            "healthy": not issues,
            "memory_ids": list(selected),
            "declared_sources": declared_sources,
            "valid_logs": [memory_id for memory_id in log_report.valid_logs if memory_id in selected_set],
            "missing_logs": [memory_id for memory_id in log_report.missing_logs if memory_id in selected_set],
            "issues": issues,
            "warnings": warnings,
            "row_sources": source_inventory,
        }
    except Exception as error:
        return {"inspected": False, "error": _error("inspection_failed", error=error)}
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "healthy": payload["healthy"],
                "memory_skills": len(selected),
                "issues": len(issues),
                "source_kind": "wiki_memory_provenance",
            }
        ),
    )
