from __future__ import annotations

import json
import logging
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki.memory_skills import (
    MemorySkillDefinition,
    append_memory_log,
    collect_source_hashes,
    content_sha256,
    generate_memory_id,
    load_memory_skill_definitions,
    normalize_memory_description,
    normalize_sources,
    read_memory_skill,
    render_memory_skill,
    resolve_memory_skill_paths,
    validate_memory_graph,
    validate_memory_id,
    write_text_atomically,
)


logger = logging.getLogger(__name__)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(
    short_description=(
        "Creates or updates one persistent AgentWiki memory deep skill."
    ),
    reusable_input_fields=("body", "description"),
)
def main(
    title: str,
    body: str,
    sources: list[str],
    description: str = "",
    sub_skills: list[str] | None = None,
    memory_id: str | None = None,
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> dict[str, object] | ToolOutput:
    """Create or update one validated memory skill and append its audit event."""
    if config is None:
        logger.warning("wiki-create-memory-skill called without runtime config")
        return {
            "written": False,
            "error": _error("missing_config"),
        }
    try:
        logger.info(
            "Creating or updating AgentWiki memory skill",
            extra={
                "title": title,
                "memory_id": memory_id,
                "source_count": len(sources),
            },
        )
        paths = resolve_memory_skill_paths(workroot=workroot, config=config)
        resolved_id = (
            validate_memory_id(memory_id)
            if memory_id is not None
            else generate_memory_id(title=title, config=config)
        )
        normalized_sources = normalize_sources(sources)
        source_hashes = collect_source_hashes(
            sources=normalized_sources,
            workroot=workroot,
        )
        definitions = load_memory_skill_definitions(paths=paths)
        existing = definitions.get(resolved_id)
        if memory_id is not None and existing is None:
            logger.warning(
                "Requested AgentWiki memory update target does not exist",
                extra={"memory_id": resolved_id},
            )
            return {
                "written": False,
                "memory_id": resolved_id,
                "error": _error("update_not_found", memory_id=resolved_id),
            }

        default_exit_skill = str(config.wiki.memory.default_exit_skill).strip()
        if not default_exit_skill:
            raise ValueError("Configured default memory exit skill is empty.")
        default_inherits_parent_tools = bool(
            config.wiki.memory.default_inherits_parent_tools
        )
        effective_exit_skill = (
            existing.exit_skill if existing is not None else default_exit_skill
        )
        default_sub_tools = tuple(
            str(name).strip()
            for name in config.wiki.memory.default_sub_tools
            if str(name).strip()
        )
        effective_sub_tools = (
            existing.sub_tools if existing is not None else default_sub_tools
        )
        effective_sub_skills = (
            existing.sub_skills
            if existing is not None and sub_skills is None
            else tuple(validate_memory_id(name) for name in (sub_skills or []))
        )
        effective_inherits_parent_tools = (
            existing.inherits_parent_tools
            if existing is not None
            else default_inherits_parent_tools
        )
        rendered = render_memory_skill(
            title=title,
            description=description,
            body=body,
            exit_skill=effective_exit_skill,
            sub_tools=effective_sub_tools,
            sub_skills=effective_sub_skills,
            inherits_parent_tools=effective_inherits_parent_tools,
            instruction_introduction=str(config.wiki.memory.instruction_introduction),
            instruction_activation=str(config.wiki.memory.instruction_activation),
            instruction_closure=str(config.wiki.memory.instruction_closure),
        )
        proposed = MemorySkillDefinition(
            memory_id=resolved_id,
            description=normalize_memory_description(
                title=" ".join(title.split()),
                description=description,
            ),
            exit_skill=effective_exit_skill,
            sub_tools=tuple(effective_sub_tools),
            sub_skills=tuple(effective_sub_skills),
            inherits_parent_tools=effective_inherits_parent_tools,
            body=body.strip(),
        )
        validate_memory_graph(definitions=definitions, proposed=proposed)

        prompt_path = paths.skills / resolved_id / paths.prompt_file
        previous_content = (
            prompt_path.read_text(encoding="utf-8") if prompt_path.exists() else None
        )
        write_text_atomically(prompt_path, rendered)
        event = "updated" if existing is not None else "created"
        content_hash = content_sha256(rendered)
        version = append_memory_log(
            path=paths.logs / f"{resolved_id}.jsonl",
            event=event,
            memory_id=resolved_id,
            title=title,
            sources=normalized_sources,
            source_hashes=source_hashes,
            previous_hash=(
                content_sha256(previous_content)
                if previous_content is not None
                else None
            ),
            content_hash=content_hash,
        )
        verified = read_memory_skill(prompt_path, memory_id=resolved_id)
    except Exception as error:
        logger.exception("Failed to create or update AgentWiki memory skill")
        return {
            "written": False,
            "error": _error("invalid_memory_skill", error=error),
        }

    relative_prompt = (
        Path(str(config.wiki.memory.directory))
        / str(config.wiki.memory.skills_directory)
        / resolved_id
        / paths.prompt_file
    ).as_posix()
    relative_log = (
        Path(str(config.wiki.memory.logs_directory)) / f"{resolved_id}.jsonl"
    ).as_posix()
    payload = {
        "written": True,
        "operation": event,
        "memory_id": resolved_id,
        "path": relative_prompt,
        "log_path": relative_log,
        "version": version,
        "sub_skills": list(verified.sub_skills),
        "sources": list(normalized_sources),
    }
    logger.info(
        "Created or updated AgentWiki memory skill",
        extra={
            "memory_id": resolved_id,
            "operation": event,
            "path": relative_prompt,
            "log_path": relative_log,
            "version": version,
        },
    )
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "memory_id": resolved_id,
                "operation": event,
                "path": relative_prompt,
                "version": version,
            }
        ),
    )
