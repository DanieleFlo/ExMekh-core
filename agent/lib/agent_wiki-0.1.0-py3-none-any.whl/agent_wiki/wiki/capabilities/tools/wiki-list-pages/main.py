from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.wiki._tool_utils import (
    RESERVED_COMPILED_NAMES,
    compiled_relative_path,
    filesystem_error_name,
    resolve_compiled_wiki_path,
    safe_argument_path,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(short_description="Lists compiled Markdown pages in the AgentWiki workroot.")
def main(
    path: str = ".", workroot: Path | None = None
) -> dict[str, object] | ToolOutput:
    """List direct compiled wiki entries under a path inside the injected workroot."""
    try:
        target = resolve_compiled_wiki_path(path, workroot=workroot)
    except Exception as error:
        return {
            "path": safe_argument_path(path),
            "exists": False,
            "entries": [],
            "error": _error("resolve_path", error=error),
        }

    relative_path = compiled_relative_path(target, workroot=workroot)
    if not target.exists():
        return {
            "path": relative_path,
            "exists": False,
            "entries": [],
            "error": _error("path_not_found", path=relative_path),
        }

    if target.is_file():
        if target.suffix != ".md":
            return {
                "path": relative_path,
                "exists": True,
                "kind": "file",
                "entries": [],
                "error": _error("not_markdown", path=relative_path),
            }
        payload = {
            "path": relative_path,
            "exists": True,
            "kind": "file",
            "entries": [
                {
                    "name": target.name,
                    "path": relative_path,
                    "kind": "file",
                }
            ],
        }
        return ToolOutput(
            result=json.dumps(payload, ensure_ascii=False),
            metadata=format_tool_metadata(
                {"path": relative_path, "kind": "file", "entries": 1}
            ),
        )

    try:
        children = sorted(target.iterdir())
    except OSError as error:
        return {
            "path": relative_path,
            "exists": True,
            "kind": "directory",
            "entries": [],
            "error": _error(
                "list_failed",
                path=relative_path,
                error=filesystem_error_name(error),
            ),
        }

    entries = [
        {
            "name": child.name,
            "path": compiled_relative_path(child, workroot=workroot),
            "kind": "directory" if child.is_dir() else "file",
        }
        for child in children
        if child.name not in RESERVED_COMPILED_NAMES
        and (child.is_dir() or child.suffix == ".md")
    ]

    payload = {
        "path": relative_path,
        "exists": True,
        "kind": "directory",
        "entries": entries,
    }
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {"path": relative_path, "kind": "directory", "entries": len(entries)}
        ),
    )
