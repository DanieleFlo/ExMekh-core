from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.wiki._tool_utils import (
    compiled_relative_path,
    filesystem_error_name,
    resolve_compiled_wiki_path,
    safe_argument_path,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(
    short_description="Writes one compiled AgentWiki Markdown page.",
    reusable_input_fields=("content",),
)
def main(
    path: str, content: str, workroot: Path | None = None
) -> dict[str, object] | ToolOutput:
    """Write one UTF-8 Markdown page inside the AgentWiki workroot."""
    try:
        target = resolve_compiled_wiki_path(path, workroot=workroot)
    except Exception as error:
        return {
            "path": safe_argument_path(path),
            "written": False,
            "error": _error("resolve_path", error=error),
        }

    relative_path = compiled_relative_path(target, workroot=workroot)
    if target.suffix != ".md":
        return {
            "path": relative_path,
            "written": False,
            "error": _error("not_markdown", path=relative_path),
        }

    try:
        existed = target.exists()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    except OSError as error:
        return {
            "path": relative_path,
            "written": False,
            "error": _error(
                "write_failed",
                path=relative_path,
                error=filesystem_error_name(error),
            ),
        }

    payload = {
        "path": relative_path,
        "written": True,
        "created": not existed,
        "bytes": len(content.encode("utf-8")),
    }
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "path": relative_path,
                "written": True,
                "created": not existed,
                "bytes": len(content.encode("utf-8")),
            }
        ),
    )
