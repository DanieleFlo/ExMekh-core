from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.wiki._tool_utils import (
    compiled_relative_path,
    compiled_wiki_root,
    iter_compiled_wiki_pages,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(short_description="Searches compiled AgentWiki Markdown pages.")
def main(
    query: str, limit: int = 20, workroot: Path | None = None
) -> dict[str, object] | ToolOutput:
    """Search compiled Markdown pages for a case-insensitive text query."""
    root = compiled_wiki_root(workroot=workroot)
    if not query.strip():
        return {"query": query, "matches": [], "error": _error("empty_query")}
    if not root.exists():
        return {
            "query": query,
            "matches": [],
            "error": _error("root_not_found", path="."),
        }

    needle = query.casefold()
    matches: list[dict[str, object]] = []
    for page in iter_compiled_wiki_pages(workroot=workroot):
        try:
            text = page.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for line_number, line in enumerate(text.splitlines(), start=1):
            if needle in line.casefold():
                matches.append(
                    {
                        "path": compiled_relative_path(page, workroot=workroot),
                        "line": line_number,
                        "excerpt": line.strip(),
                    }
                )
                break
        if len(matches) >= limit:
            break

    payload = {"query": query, "matches": matches, "truncated": len(matches) >= limit}
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {
                "path": ".",
                "matches": len(matches),
                "truncated": len(matches) >= limit,
            }
        ),
    )
