from __future__ import annotations

from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki._tool_utils import (
    filesystem_error_name,
    schema_path,
    workspace_relative_path,
)
from agent_wiki.wiki.memory_index import read_memory_index


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(short_description="Reads the workspace AgentWiki schema and memory index.")
def main(
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> str | ToolOutput:
    """Read the workspace-level AGENT_WIKI.md schema file."""
    if config is None:
        return _error("missing_config")
    target = schema_path(workroot=workroot)
    relative_path = workspace_relative_path(target, workroot=workroot)
    if not target.exists():
        return _error("path_not_found", path=relative_path)
    if target.is_dir():
        return _error("path_is_directory", path=relative_path)

    try:
        content = target.read_text(encoding="utf-8")
        index = read_memory_index(workroot=workroot, config=config)
        indexed_lines = (
            [f"- `{skill_id}`" for skill_id in index.skills]
            if index.skills
            else ["- No memory skills are currently indexed."]
        )
        rendered = "\n".join(
            [
                content.rstrip(),
                "",
                "## Current Memory Index",
                "",
                f"Path: `{workspace_relative_path(index.path, workroot=workroot)}`",
                "",
                *indexed_lines,
                "",
            ]
        )
        return ToolOutput(
            result=rendered,
            metadata=format_tool_metadata(
                {
                    "path": relative_path,
                    "bytes": len(rendered.encode("utf-8")),
                    "lines": len(rendered.splitlines()),
                    "indexed_skills": len(index.skills),
                    "source_kind": "wiki_schema",
                }
            ),
        )
    except UnicodeDecodeError as error:
        return _error(
            "decode_failed",
            path=relative_path,
            error=filesystem_error_name(error),
        )
    except OSError as error:
        return _error(
            "read_failed",
            path=relative_path,
            error=filesystem_error_name(error),
        )
    except ValueError as error:
        return _error("memory_index_invalid", error=error)
