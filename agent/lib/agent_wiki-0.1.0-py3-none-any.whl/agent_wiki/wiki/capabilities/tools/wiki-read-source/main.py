from __future__ import annotations

from pathlib import Path
from typing import Any

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki.pdf_markdown import convert_pdf_to_markdown
from agent_wiki.wiki._tool_utils import (
    filesystem_error_name,
    resolve_raw_wiki_path,
    source_relative_path,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(
    short_description="Reads one AgentWiki source file using a path relative to row/."
)
def main(
    path: str,
    workroot: Path | None = None,
    client: Any = None,
    config: RuntimePackageConfig | None = None,
    model_name: str | None = None,
) -> str | ToolOutput:
    """Read one source-root-relative file, converting PDFs to Markdown when needed."""
    try:
        target = resolve_raw_wiki_path(path, workroot=workroot)
    except Exception as error:
        return _error("resolve_path", error=error)

    relative_path = source_relative_path(target, workroot=workroot)
    if not target.exists():
        return _error("path_not_found", path=relative_path)
    if target.is_dir():
        return _error("path_is_directory", path=relative_path)
    if target.suffix.casefold() == ".pdf":
        try:
            markdown_path = resolve_raw_wiki_path(
                Path(path).with_suffix(".md").as_posix(),
                workroot=workroot,
            )
            conversion = convert_pdf_to_markdown(
                path=target,
                client=client,
                config=config,
                model_name=model_name,
                output_path=markdown_path,
            )
            saved_relative_path = source_relative_path(
                markdown_path,
                workroot=workroot,
            )
            result = (
                f"{conversion.markdown}\n\n---\n"
                f"{_error('pdf_saved', path=saved_relative_path)}"
            )
            return ToolOutput(
                result=result,
                metadata=format_tool_metadata(
                    {
                        "path": relative_path,
                        "saved_markdown_path": saved_relative_path,
                        "source_kind": "pdf",
                        "pages": conversion.page_count,
                        "model": conversion.model,
                        "bytes": len(conversion.markdown.encode("utf-8")),
                        "lines": len(conversion.markdown.splitlines()),
                    }
                ),
            )
        except Exception as error:
            return _error(
                "pdf_parse_failed",
                path=relative_path,
                error=filesystem_error_name(error),
            )

    try:
        content = target.read_text(encoding="utf-8")
        return ToolOutput(
            result=content,
            metadata=format_tool_metadata(
                {
                    "path": relative_path,
                    "source_kind": "raw_text",
                    "bytes": len(content.encode("utf-8")),
                    "lines": len(content.splitlines()),
                }
            ),
        )
    except UnicodeDecodeError as error:
        return _error(
            "decode_failed",
            path=relative_path,
            error=filesystem_error_name(error),
        )
    except OSError as error:
        return _error(
            "read_failed",
            path=relative_path,
            error=filesystem_error_name(error),
        )
