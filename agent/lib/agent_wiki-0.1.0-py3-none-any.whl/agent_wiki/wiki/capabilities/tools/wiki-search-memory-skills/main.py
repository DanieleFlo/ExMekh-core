from __future__ import annotations

import json
import re
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki.memory_toolkit import (
    load_memory_workspace_snapshot,
    memory_skill_payload,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


def _excerpt(text: str, *, terms: list[str], limit: int = 280) -> str:
    """Return a compact excerpt centered near the first matching term."""
    normalized = " ".join(text.split())
    positions = [normalized.casefold().find(term) for term in terms]
    positions = [position for position in positions if position >= 0]
    start = max(0, (min(positions) if positions else 0) - 80)
    excerpt = normalized[start : start + limit]
    return ("…" if start else "") + excerpt + ("…" if start + limit < len(normalized) else "")


@sign_tool(short_description="Searches all memory skill content with graph context.")
def main(
    query: str,
    limit: int = 20,
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> dict[str, object] | ToolOutput:
    """Search memory ids, descriptions, bodies, and declared source names."""
    if config is None:
        return {"searched": False, "error": _error("missing_config")}
    try:
        terms = [term.casefold() for term in re.findall(r"[\w-]+", query) if term.strip()]
        if not terms:
            raise ValueError("Search query must contain at least one term.")
        if limit < 1 or limit > 100:
            raise ValueError("Search limit must be between 1 and 100.")
        snapshot = load_memory_workspace_snapshot(workroot=workroot, config=config)
        matches: list[dict[str, object]] = []
        for memory_id in sorted(snapshot.definitions):
            memory = memory_skill_payload(snapshot=snapshot, memory_id=memory_id)
            sources = " ".join(str(value) for value in memory["declared_sources"])
            searchable = "\n".join(
                [memory_id, str(memory["description"]), str(memory["body"]), sources]
            ).casefold()
            score = sum(searchable.count(term) for term in terms)
            if score == 0:
                continue
            matches.append(
                {
                    "memory_id": memory_id,
                    "score": score,
                    "description": memory["description"],
                    "indexed": memory["indexed"],
                    "reachable_from_index": memory["reachable_from_index"],
                    "depth": memory["depth"],
                    "incoming_skills": memory["incoming_skills"],
                    "sub_skills": memory["sub_skills"],
                    "declared_sources": memory["declared_sources"],
                    "excerpt": _excerpt(str(memory["body"]), terms=terms),
                }
            )
        matches.sort(key=lambda item: (-int(item["score"]), str(item["memory_id"])))
        payload = {
            "searched": True,
            "query": query,
            "matches": matches[:limit],
            "total_matches": len(matches),
        }
    except Exception as error:
        return {"searched": False, "error": _error("search_failed", error=error)}
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {"matches": len(payload["matches"]), "source_kind": "wiki_memory_search"}
        ),
    )
