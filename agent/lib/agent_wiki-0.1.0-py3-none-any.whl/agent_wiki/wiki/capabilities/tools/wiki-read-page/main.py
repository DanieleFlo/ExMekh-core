from __future__ import annotations

from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.wiki._tool_utils import (
    compiled_relative_path,
    filesystem_error_name,
    resolve_compiled_wiki_path,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(short_description="Reads one compiled AgentWiki Markdown page.")
def main(path: str, workroot: Path | None = None) -> str | ToolOutput:
    """Read one compiled Markdown page from the AgentWiki workroot."""
    try:
        target = resolve_compiled_wiki_path(path, workroot=workroot)
    except Exception as error:
        return _error("resolve_path", error=error)

    relative_path = compiled_relative_path(target, workroot=workroot)
    if not target.exists():
        return _error("path_not_found", path=relative_path)
    if target.is_dir():
        return _error("path_is_directory", path=relative_path)
    if target.suffix != ".md":
        return _error("not_markdown", path=relative_path)

    try:
        content = target.read_text(encoding="utf-8")
        return ToolOutput(
            result=content,
            metadata=format_tool_metadata(
                {
                    "path": relative_path,
                    "bytes": len(content.encode("utf-8")),
                    "lines": len(content.splitlines()),
                    "source_kind": "compiled_wiki_page",
                }
            ),
        )
    except UnicodeDecodeError as error:
        return _error(
            "decode_failed",
            path=relative_path,
            error=filesystem_error_name(error),
        )
    except OSError as error:
        return _error(
            "read_failed",
            path=relative_path,
            error=filesystem_error_name(error),
        )
