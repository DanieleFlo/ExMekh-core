from __future__ import annotations

import json
from pathlib import Path

from agent_wiki.backend.core.capabilities.tool import (
    ToolOutput,
    format_tool_metadata,
    get_local_tool_error_text,
    sign_tool,
)
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki.memory_toolkit import (
    load_memory_workspace_snapshot,
    memory_skill_payload,
    select_memory_ids,
)


def _error(key: str, **values: object) -> str:
    """Return one message from this tool's local error catalog."""
    return get_local_tool_error_text(__file__, key, **values)


@sign_tool(short_description="Reads memory skill bodies with graph and provenance context.")
def main(
    memory_ids: list[str],
    workroot: Path | None = None,
    config: RuntimePackageConfig | None = None,
) -> dict[str, object] | ToolOutput:
    """Return selected memory definitions without modifying the wiki."""
    if config is None:
        return {"read": False, "error": _error("missing_config")}
    try:
        snapshot = load_memory_workspace_snapshot(workroot=workroot, config=config)
        selected = select_memory_ids(requested=memory_ids, available=snapshot.definitions)
        payload = {
            "read": True,
            "memories": [
                memory_skill_payload(snapshot=snapshot, memory_id=memory_id)
                for memory_id in selected
            ],
        }
    except Exception as error:
        return {"read": False, "error": _error("read_failed", error=error)}
    return ToolOutput(
        result=json.dumps(payload, ensure_ascii=False),
        metadata=format_tool_metadata(
            {"memory_skills": len(selected), "source_kind": "wiki_memory_skills"}
        ),
    )
