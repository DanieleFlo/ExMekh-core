from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence

from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki._tool_utils import (
    filesystem_error_name,
    raw_wiki_root,
    source_relative_path,
)
from agent_wiki.wiki.memory_index import MemoryIndex, read_memory_index
from agent_wiki.wiki.memory_skills import (
    MemoryGraphInspection,
    MemorySkillDefinition,
    MemorySkillPaths,
    file_sha256,
    inspect_memory_graph,
    load_memory_skill_definitions,
    load_source_processing_states,
    resolve_memory_skill_paths,
)


@dataclass(frozen=True, slots=True)
class MemoryWorkspaceSnapshot:
    """Collect one consistent read-only view of the AgentWiki memory workspace."""

    paths: MemorySkillPaths
    definitions: Mapping[str, MemorySkillDefinition]
    index: MemoryIndex
    graph: MemoryGraphInspection
    latest_logs: Mapping[str, Mapping[str, object]]
    index_error: str | None


def load_memory_workspace_snapshot(
    *, workroot: Path | None, config: RuntimePackageConfig
) -> MemoryWorkspaceSnapshot:
    """Load memory definitions, index, graph inspection, and latest log records."""
    paths = resolve_memory_skill_paths(workroot=workroot, config=config)
    definitions = load_memory_skill_definitions(paths=paths)
    index_error: str | None = None
    try:
        index = read_memory_index(
            workroot=workroot,
            config=config,
            validate_references=False,
        )
    except (OSError, UnicodeError, ValueError) as error:
        index = MemoryIndex(
            path=paths.index,
            exists=paths.index.exists(),
            skills=(),
        )
        index_error = str(error)
    graph = inspect_memory_graph(
        definitions=definitions,
        indexed_skill_ids=index.skills,
    )
    return MemoryWorkspaceSnapshot(
        paths=paths,
        definitions=definitions,
        index=index,
        graph=graph,
        latest_logs=load_latest_memory_log_records(paths=paths),
        index_error=index_error,
    )


def load_latest_memory_log_records(
    *, paths: MemorySkillPaths
) -> dict[str, Mapping[str, object]]:
    """Return the latest valid object record from every memory JSONL log."""
    records: dict[str, Mapping[str, object]] = {}
    if not paths.logs.is_dir():
        return records
    for log_path in sorted(paths.logs.glob("*.jsonl")):
        if not log_path.is_file() or log_path.is_symlink():
            continue
        latest: Mapping[str, object] | None = None
        try:
            lines = log_path.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeError):
            continue
        for line in lines:
            if not line.strip():
                continue
            try:
                loaded = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(loaded, dict):
                latest = loaded
        if latest is not None:
            records[log_path.stem] = latest
    return records


def memory_skill_payload(
    *, snapshot: MemoryWorkspaceSnapshot, memory_id: str
) -> dict[str, object]:
    """Return one memory definition with graph and declared provenance context."""
    definition = snapshot.definitions[memory_id]
    latest_log = snapshot.latest_logs.get(memory_id, {})
    raw_sources = latest_log.get("sources", [])
    sources = [value for value in raw_sources if isinstance(value, str)] if isinstance(raw_sources, list) else []
    return {
        "memory_id": memory_id,
        "description": definition.description,
        "exit_skill": definition.exit_skill,
        "sub_tools": list(definition.sub_tools),
        "sub_skills": list(definition.sub_skills),
        "incoming_skills": list(snapshot.graph.incoming.get(memory_id, ())),
        "indexed": memory_id in snapshot.index.skills,
        "reachable_from_index": memory_id in snapshot.graph.reachable_from_index,
        "depth": snapshot.graph.depths.get(memory_id),
        "body": definition.body,
        "declared_sources": sources,
        "latest_log_version": latest_log.get("version"),
    }


def list_source_inventory(
    *, workroot: Path | None, snapshot: MemoryWorkspaceSnapshot
) -> dict[str, object]:
    """Return row files and freshness without treating provenance as graph edges."""
    root = raw_wiki_root(workroot=workroot)
    counts = {"new": 0, "modified": 0, "processed": 0}
    files: list[dict[str, object]] = []
    errors: list[dict[str, object]] = []
    if not root.exists():
        return {
            "source_root": "row/",
            "exists": False,
            "files": files,
            "status_counts": counts,
            "errors": errors,
        }
    if not root.is_dir():
        return {
            "source_root": "row/",
            "exists": False,
            "files": files,
            "status_counts": counts,
            "errors": [{"type": "invalid_source_root"}],
        }

    states = load_source_processing_states(paths=snapshot.paths)

    def record_walk_error(error: OSError) -> None:
        """Record a safe recursive source-discovery error."""
        errors.append({"type": "source_walk_error", "error": filesystem_error_name(error)})

    for current_root, directory_names, file_names in os.walk(
        root,
        topdown=True,
        onerror=record_walk_error,
        followlinks=False,
    ):
        current_path = Path(current_root)
        directory_names[:] = sorted(
            name
            for name in directory_names
            if not name.startswith(".") and not (current_path / name).is_symlink()
        )
        for file_name in sorted(file_names):
            source = current_path / file_name
            if file_name.startswith(".") or source.is_symlink() or not source.is_file():
                continue
            try:
                path = source_relative_path(source, workroot=workroot)
                digest = file_sha256(source)
                size = source.stat().st_size
            except (OSError, ValueError) as error:
                errors.append(
                    {
                        "type": "unreadable_source",
                        "error": filesystem_error_name(error),
                    }
                )
                continue
            state = states.get(path)
            status = state.status_for_hash(digest) if state is not None else "new"
            counts[status] += 1
            files.append(
                {
                    "path": path,
                    "bytes": size,
                    "sha256": digest,
                    "status": status,
                }
            )
    return {
        "source_root": "row/",
        "exists": True,
        "files": files,
        "status_counts": counts,
        "errors": errors,
    }


def select_memory_ids(
    *, requested: Sequence[str] | None, available: Mapping[str, object]
) -> tuple[str, ...]:
    """Validate an optional ordered memory selection against available ids."""
    if requested is None:
        return tuple(sorted(available))
    selected: list[str] = []
    for memory_id in requested:
        normalized = memory_id.strip().casefold()
        if normalized not in available:
            raise ValueError(f"Unknown memory skill '{normalized}'.")
        if normalized not in selected:
            selected.append(normalized)
    if not selected:
        raise ValueError("At least one memory skill id is required.")
    return tuple(selected)
