from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence
from urllib.parse import urlparse

from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.backend.core.utils import get_name_list, parse_frontmatter_lines


_MEMORY_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
_NON_SLUG_PATTERN = re.compile(r"[^a-z0-9]+")
_CONFLICT_MARKER_PATTERN = re.compile(
    r"(\bconflict\b|\bcontradiction\b|\[conflict\])",
    re.IGNORECASE,
)
_FUTURE_WORK_PATTERN = re.compile(
    r"(\bfuture work\b|\bto be added\b|\btodo\b|\btbd\b)",
    re.IGNORECASE,
)
MAX_DIRECT_MEMORY_SUB_SKILLS = 10


@dataclass(frozen=True, slots=True)
class MemorySkillDefinition:
    """Represent one parsed memory-skill definition."""

    memory_id: str
    description: str
    exit_skill: str
    sub_tools: tuple[str, ...]
    sub_skills: tuple[str, ...]
    inherits_parent_tools: bool
    body: str


@dataclass(frozen=True, slots=True)
class MemorySkillPaths:
    """Store resolved filesystem locations for the memory-skill subsystem."""

    root: Path
    skills: Path
    index: Path
    logs: Path
    prompt_file: str


@dataclass(frozen=True, slots=True)
class SourceProcessingState:
    """Represent the hashes recorded by memory skills for one local source."""

    memory_hashes: Mapping[str, str | None]

    @property
    def memory_ids(self) -> tuple[str, ...]:
        """Return associated memory ids in stable order."""
        return tuple(sorted(self.memory_hashes))

    def status_for_hash(self, current_hash: str) -> str:
        """Classify one current source hash against every associated memory."""
        if not self.memory_hashes:
            return "new"
        if any(
            stored_hash != current_hash for stored_hash in self.memory_hashes.values()
        ):
            return "modified"
        return "processed"


@dataclass(frozen=True, slots=True)
class MemoryGraphInspection:
    """Represent structural and semantic lint findings for memory skills."""

    issues: tuple[dict[str, object], ...]
    warnings: tuple[dict[str, object], ...]
    roots: tuple[str, ...]
    indexed_roots: tuple[str, ...]
    reachable_from_index: tuple[str, ...]
    unreachable_from_index: tuple[str, ...]
    unreachable_components: tuple[dict[str, object], ...]
    incoming: Mapping[str, tuple[str, ...]]
    depths: Mapping[str, int]
    diagram: str
    semantic_issues: tuple[dict[str, object], ...]


@dataclass(frozen=True, slots=True)
class MemoryLogInspection:
    """Represent append-only log lint findings for generated memories."""

    issues: tuple[dict[str, object], ...]
    warnings: tuple[dict[str, object], ...]
    valid_logs: tuple[str, ...]
    missing_logs: tuple[str, ...]


def resolve_memory_skill_paths(
    *, workroot: Path | None, config: RuntimePackageConfig
) -> MemorySkillPaths:
    """Resolve configured memory paths from the injected AgentWiki workroot."""
    if workroot is None:
        raise ValueError("wiki-create-memory-skill requires an injected workroot.")
    resolved_workroot = workroot.resolve()
    memory_config = config.wiki.memory
    root = _resolve_configured_child(
        base=resolved_workroot,
        value=str(memory_config.directory),
        label="memory directory",
    )
    skills = _resolve_configured_child(
        base=root,
        value=str(memory_config.skills_directory),
        label="memory skills directory",
    )
    logs = _resolve_configured_child(
        base=resolved_workroot,
        value=str(memory_config.logs_directory),
        label="memory logs directory",
    )
    prompt_file = str(memory_config.prompt_file).strip()
    index_file = str(memory_config.index_file).strip()
    if not prompt_file or Path(prompt_file).name != prompt_file:
        raise ValueError("Memory prompt filename must be one relative filename.")
    if not index_file or Path(index_file).name != index_file:
        raise ValueError("Memory index filename must be one relative filename.")
    return MemorySkillPaths(
        root=root,
        skills=skills,
        index=root / index_file,
        logs=logs,
        prompt_file=prompt_file,
    )


def generate_memory_id(*, title: str, config: RuntimePackageConfig) -> str:
    """Generate one deterministic memory id from a knowledge-section title."""
    normalized_title = " ".join(title.split()).casefold()
    if not normalized_title:
        raise ValueError("Memory skill title must not be empty.")
    prefix = str(config.wiki.memory.id_prefix).strip().casefold()
    slug = _NON_SLUG_PATTERN.sub("-", normalized_title).strip("-") or "section"
    digest = hashlib.sha256(normalized_title.encode("utf-8")).hexdigest()[:10]
    available_slug_length = 64 - len(prefix) - len(digest) - 2
    if available_slug_length < 1:
        raise ValueError("Configured memory id prefix is too long.")
    memory_id = f"{prefix}-{slug[:available_slug_length].rstrip('-')}-{digest}"
    validate_memory_id(memory_id)
    return memory_id


def validate_memory_id(memory_id: str) -> str:
    """Validate and normalize one model-facing memory skill identifier."""
    normalized = memory_id.strip().casefold()
    if not _MEMORY_ID_PATTERN.fullmatch(normalized):
        raise ValueError(
            "Memory id must contain only lowercase letters, digits, and hyphens "
            "and must be at most 64 characters."
        )
    return normalized


def normalize_sources(sources: Sequence[str]) -> tuple[str, ...]:
    """Validate local source references and HTTP(S) URLs for memory logs."""
    normalized: list[str] = []
    for source in sources:
        if not isinstance(source, str) or not source.strip():
            raise ValueError("Memory sources must contain non-empty strings.")
        value = source.strip()
        parsed = urlparse(value)
        if parsed.scheme:
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                raise ValueError("Memory source URLs must use HTTP or HTTPS.")
        else:
            candidate = Path(value)
            if candidate.is_absolute() or ".." in candidate.parts:
                raise ValueError(
                    "Local memory sources must be relative to the row/ source root."
                )
            if candidate.parts and candidate.parts[0] in {"row", "wiki"}:
                raise ValueError(
                    "Local memory sources must use the exact path returned by "
                    "wiki-list-sources without row/ or wiki/ prefixes."
                )
            if not candidate.parts:
                raise ValueError("Local memory sources must identify one source file.")
            value = candidate.as_posix()
        if value not in normalized:
            normalized.append(value)
    return tuple(normalized)


def read_memory_skill(path: Path, *, memory_id: str) -> MemorySkillDefinition:
    """Read one existing memory skill from its deep-skill Markdown file."""
    raw_content = path.read_text(encoding="utf-8")
    lines = raw_content.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ValueError(f"Memory skill '{memory_id}' has invalid frontmatter.")
    try:
        closing_index = next(
            index
            for index, line in enumerate(lines[1:], start=1)
            if line.strip() == "---"
        )
    except StopIteration as error:
        raise ValueError(
            f"Memory skill '{memory_id}' has unterminated frontmatter."
        ) from error
    metadata = parse_frontmatter_lines(lines=lines[1:closing_index])
    description = _required_metadata_string(
        metadata=metadata,
        key="description",
        memory_id=memory_id,
    )
    exit_skill = _required_metadata_string(
        metadata=metadata,
        key="exit-skill",
        memory_id=memory_id,
    )
    sub_tools = tuple(get_name_list(metadata=metadata, keys=("sub-tools", "tools")))
    sub_skills = tuple(get_name_list(metadata=metadata, keys=("sub-skills", "skills")))
    inherits_parent_tools = _read_inherits_parent_tools(metadata)
    body = "\n".join(lines[closing_index + 1 :]).strip()
    return MemorySkillDefinition(
        memory_id=memory_id,
        description=description,
        exit_skill=exit_skill,
        sub_tools=sub_tools,
        sub_skills=sub_skills,
        inherits_parent_tools=inherits_parent_tools,
        body=body,
    )


def load_memory_skill_definitions(
    *, paths: MemorySkillPaths
) -> dict[str, MemorySkillDefinition]:
    """Load every validly located memory skill from the configured skills root."""
    if not paths.skills.exists():
        return {}
    definitions: dict[str, MemorySkillDefinition] = {}
    for skill_dir in sorted(paths.skills.iterdir()):
        if not skill_dir.is_dir() or skill_dir.is_symlink():
            continue
        memory_id = validate_memory_id(skill_dir.name)
        prompt_path = skill_dir / paths.prompt_file
        if not prompt_path.is_file():
            raise ValueError(f"Memory skill '{memory_id}' is missing its prompt file.")
        definitions[memory_id] = read_memory_skill(
            prompt_path,
            memory_id=memory_id,
        )
    return definitions


def validate_memory_graph(
    *,
    definitions: Mapping[str, MemorySkillDefinition],
    proposed: MemorySkillDefinition,
) -> None:
    """Validate references, duplicate edges, and cycles in the proposed graph."""
    graph = {
        memory_id: definition.sub_skills
        for memory_id, definition in definitions.items()
    }
    graph[proposed.memory_id] = proposed.sub_skills
    known_ids = set(graph)
    for memory_id, children in graph.items():
        if len(children) != len(set(children)):
            raise ValueError(f"Memory skill '{memory_id}' has duplicate sub-skills.")
        if memory_id in children:
            raise ValueError(f"Memory skill '{memory_id}' cannot reference itself.")
        missing = [child for child in children if child not in known_ids]
        if missing:
            raise ValueError(
                f"Memory skill '{memory_id}' references missing sub-skills: "
                f"{', '.join(missing)}."
            )

    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(memory_id: str) -> None:
        """Traverse one memory node and reject back edges."""
        if memory_id in visiting:
            raise ValueError(
                f"Memory skill graph contains a cycle involving '{memory_id}'."
            )
        if memory_id in visited:
            return
        visiting.add(memory_id)
        for child in graph[memory_id]:
            visit(child)
        visiting.remove(memory_id)
        visited.add(memory_id)

    for memory_id in graph:
        visit(memory_id)


def find_root_memory_skill_ids(
    definitions: Mapping[str, MemorySkillDefinition],
) -> tuple[str, ...]:
    """Return memory skill ids that are not referenced by another skill."""
    referenced = {
        child for definition in definitions.values() for child in definition.sub_skills
    }
    return tuple(sorted(set(definitions) - referenced))


def inspect_memory_graph(
    *,
    definitions: Mapping[str, MemorySkillDefinition],
    indexed_skill_ids: Sequence[str],
) -> MemoryGraphInspection:
    """Inspect the generated memory-skill graph for lintable issues."""
    issues: list[dict[str, object]] = []
    warnings: list[dict[str, object]] = []
    normalized_index = tuple(validate_memory_id(skill_id) for skill_id in indexed_skill_ids)
    known_ids = set(definitions)
    graph = {
        memory_id: tuple(definition.sub_skills)
        for memory_id, definition in definitions.items()
    }
    missing_index_skills = tuple(
        skill_id for skill_id in normalized_index if skill_id not in known_ids
    )
    if missing_index_skills:
        issues.append(
            {
                "type": "missing_index_skill",
                "skills": missing_index_skills,
            }
        )

    for memory_id, children in graph.items():
        duplicate_children = _duplicate_values(children)
        if duplicate_children:
            issues.append(
                {
                    "type": "duplicate_sub_skill",
                    "memory_id": memory_id,
                    "sub_skills": duplicate_children,
                }
            )
        if memory_id in children:
            issues.append({"type": "self_sub_skill", "memory_id": memory_id})
        if len(children) > MAX_DIRECT_MEMORY_SUB_SKILLS:
            issues.append(
                {
                    "type": "too_many_sub_skills",
                    "memory_id": memory_id,
                    "count": len(children),
                    "limit": MAX_DIRECT_MEMORY_SUB_SKILLS,
                }
            )
        missing_children = [child for child in children if child not in known_ids]
        if missing_children:
            issues.append(
                {
                    "type": "missing_sub_skill",
                    "memory_id": memory_id,
                    "sub_skills": missing_children,
                }
            )

    issues.extend(_cycle_issues(graph=graph))
    roots = find_root_memory_skill_ids(definitions)
    indexed_roots = tuple(skill_id for skill_id in normalized_index if skill_id in roots)
    non_root_index_entries = tuple(
        skill_id
        for skill_id in normalized_index
        if skill_id in known_ids and skill_id not in roots
    )
    if non_root_index_entries:
        warnings.append(
            {
                "type": "non_root_index_entry",
                "skills": non_root_index_entries,
            }
        )

    reachable, depths = _reachable_from_index(
        graph=graph,
        indexed_skill_ids=normalized_index,
    )
    unreachable = tuple(sorted(known_ids - reachable))
    incoming = _incoming_memory_edges(graph=graph, known_ids=known_ids)
    unreachable_components = _unreachable_memory_components(
        graph=graph,
        incoming=incoming,
        unreachable=set(unreachable),
    )
    for component in unreachable_components:
        issues.append(
            {
                "type": "unreachable_memory_component",
                "skills": component["skills"],
                "entry_skills": component["entry_skills"],
                "reason": "no_path_from_memory_index",
            }
        )

    semantic_issues = _semantic_memory_issues(definitions=definitions)
    issues.extend(semantic_issues)
    if not definitions:
        warnings.append({"type": "empty_memory_graph"})

    return MemoryGraphInspection(
        issues=tuple(issues),
        warnings=tuple(warnings),
        roots=roots,
        indexed_roots=indexed_roots,
        reachable_from_index=tuple(sorted(reachable)),
        unreachable_from_index=unreachable,
        unreachable_components=unreachable_components,
        incoming=incoming,
        depths=depths,
        diagram=render_memory_graph_diagram(
            graph=graph,
            indexed_skill_ids=normalized_index,
            unreachable_components=unreachable_components,
        ),
        semantic_issues=tuple(semantic_issues),
    )


def inspect_memory_logs(
    *,
    paths: MemorySkillPaths,
    definitions: Mapping[str, MemorySkillDefinition],
) -> MemoryLogInspection:
    """Inspect memory append-only logs for missing or malformed records."""
    issues: list[dict[str, object]] = []
    warnings: list[dict[str, object]] = []
    valid_logs: list[str] = []
    missing_logs: list[str] = []

    for memory_id in sorted(definitions):
        log_path = paths.logs / f"{memory_id}.jsonl"
        if not log_path.exists():
            missing_logs.append(memory_id)
            issues.append({"type": "missing_memory_log", "memory_id": memory_id})
            continue
        if not log_path.is_file() or log_path.is_symlink():
            issues.append({"type": "invalid_memory_log_path", "memory_id": memory_id})
            continue
        line_errors, has_valid_record = _inspect_memory_log_file(
            path=log_path,
            memory_id=memory_id,
        )
        issues.extend(line_errors)
        if has_valid_record:
            valid_logs.append(memory_id)
        else:
            warnings.append({"type": "empty_memory_log", "memory_id": memory_id})

    if paths.logs.exists() and paths.logs.is_dir():
        for log_path in sorted(paths.logs.glob("*.jsonl")):
            if log_path.stem not in definitions and log_path.is_file():
                warnings.append(
                    {
                        "type": "orphan_memory_log",
                        "memory_id": log_path.stem,
                    }
                )

    return MemoryLogInspection(
        issues=tuple(issues),
        warnings=tuple(warnings),
        valid_logs=tuple(valid_logs),
        missing_logs=tuple(missing_logs),
    )


def _duplicate_values(values: Sequence[str]) -> tuple[str, ...]:
    """Return duplicated values while preserving first duplicate order."""
    seen: set[str] = set()
    duplicates: list[str] = []
    for value in values:
        if value in seen and value not in duplicates:
            duplicates.append(value)
        seen.add(value)
    return tuple(duplicates)


def _cycle_issues(*, graph: Mapping[str, Sequence[str]]) -> list[dict[str, object]]:
    """Return one lint issue for each detected memory graph back edge."""
    issues: list[dict[str, object]] = []
    visiting: list[str] = []
    visited: set[str] = set()
    reported: set[tuple[str, ...]] = set()

    def visit(memory_id: str) -> None:
        """Depth-first traversal that records cycles without raising."""
        if memory_id in visiting:
            cycle = tuple([*visiting[visiting.index(memory_id) :], memory_id])
            key = tuple(sorted(cycle))
            if key not in reported:
                reported.add(key)
                issues.append({"type": "cycle", "path": cycle})
            return
        if memory_id in visited or memory_id not in graph:
            return
        visiting.append(memory_id)
        for child in graph[memory_id]:
            visit(child)
        visiting.pop()
        visited.add(memory_id)

    for memory_id in sorted(graph):
        visit(memory_id)
    return issues


def _reachable_from_index(
    *,
    graph: Mapping[str, Sequence[str]],
    indexed_skill_ids: Sequence[str],
) -> tuple[set[str], dict[str, int]]:
    """Return reachable memory ids and their minimum index distance."""
    reachable: set[str] = set()
    depths: dict[str, int] = {}
    pending = [(skill_id, 0) for skill_id in indexed_skill_ids]
    while pending:
        memory_id, depth = pending.pop(0)
        if memory_id not in graph:
            continue
        previous_depth = depths.get(memory_id)
        if previous_depth is not None and previous_depth <= depth:
            continue
        reachable.add(memory_id)
        depths[memory_id] = depth
        pending.extend((child, depth + 1) for child in graph[memory_id])
    return reachable, dict(sorted(depths.items()))


def _incoming_memory_edges(
    *, graph: Mapping[str, Sequence[str]], known_ids: set[str]
) -> dict[str, tuple[str, ...]]:
    """Return valid incoming memory edges for every known node."""
    incoming: dict[str, list[str]] = {memory_id: [] for memory_id in sorted(known_ids)}
    for parent, children in graph.items():
        for child in children:
            if child in incoming and parent not in incoming[child]:
                incoming[child].append(parent)
    return {
        memory_id: tuple(sorted(parents))
        for memory_id, parents in incoming.items()
    }


def _unreachable_memory_components(
    *,
    graph: Mapping[str, Sequence[str]],
    incoming: Mapping[str, Sequence[str]],
    unreachable: set[str],
) -> tuple[dict[str, object], ...]:
    """Group unreachable nodes into weakly connected diagnostic components."""
    components: list[dict[str, object]] = []
    remaining = set(unreachable)
    while remaining:
        start = min(remaining)
        component: set[str] = set()
        pending = [start]
        while pending:
            memory_id = pending.pop()
            if memory_id in component or memory_id not in unreachable:
                continue
            component.add(memory_id)
            neighbors = [
                child for child in graph.get(memory_id, ()) if child in unreachable
            ]
            neighbors.extend(
                parent for parent in incoming.get(memory_id, ()) if parent in unreachable
            )
            pending.extend(neighbors)
        remaining.difference_update(component)
        entry_skills = sorted(
            memory_id
            for memory_id in component
            if not any(parent in component for parent in incoming.get(memory_id, ()))
        )
        if not entry_skills:
            entry_skills = [min(component)]
        components.append(
            {
                "skills": sorted(component),
                "entry_skills": entry_skills,
                "edges": [
                    {"from": parent, "to": child}
                    for parent in sorted(component)
                    for child in graph.get(parent, ())
                    if child in component
                ],
            }
        )
    return tuple(components)


def render_memory_graph_diagram(
    *,
    graph: Mapping[str, Sequence[str]],
    indexed_skill_ids: Sequence[str],
    unreachable_components: Sequence[Mapping[str, object]],
) -> str:
    """Render a cycle-safe text diagram of indexed and unreachable memory nodes."""
    lines = ["INDEX"]
    rendered: set[str] = set()

    def render_node(memory_id: str, *, prefix: str, connector: str) -> None:
        """Render one node and its descendants with repeated-node markers."""
        repeated = memory_id in rendered
        suffix = " [already shown]" if repeated else ""
        lines.append(f"{prefix}{connector}{memory_id}{suffix}")
        if repeated or memory_id not in graph:
            return
        rendered.add(memory_id)
        children = list(graph[memory_id])
        for index, child in enumerate(children):
            is_last = index == len(children) - 1
            render_node(
                child,
                prefix=prefix + ("    " if connector == "└── " else "│   "),
                connector="└── " if is_last else "├── ",
            )

    valid_index = [skill_id for skill_id in indexed_skill_ids if skill_id in graph]
    if not valid_index:
        lines.append("└── [empty]")
    for index, skill_id in enumerate(valid_index):
        render_node(
            skill_id,
            prefix="",
            connector="└── " if index == len(valid_index) - 1 else "├── ",
        )

    for component_number, component in enumerate(unreachable_components, start=1):
        lines.extend(["", f"UNREACHABLE COMPONENT {component_number} [ERROR]"])
        entries = [str(value) for value in component.get("entry_skills", [])]
        for index, memory_id in enumerate(entries):
            render_node(
                memory_id,
                prefix="",
                connector="└── " if index == len(entries) - 1 else "├── ",
            )
        lines.append("Reason: no path exists from any memory/index.json entry.")
    return "\n".join(lines)


def _semantic_memory_issues(
    *,
    definitions: Mapping[str, MemorySkillDefinition],
) -> list[dict[str, object]]:
    """Return simple model-facing semantic quality issues for memory bodies."""
    issues: list[dict[str, object]] = []
    normalized_bodies: dict[str, str] = {}
    for memory_id, definition in sorted(definitions.items()):
        body = definition.body.strip()
        normalized = " ".join(body.casefold().split())
        normalized_bodies[memory_id] = normalized
        if not body:
            issues.append({"type": "empty_memory_body", "memory_id": memory_id})
        for line_number, line in enumerate(body.splitlines(), start=1):
            if _CONFLICT_MARKER_PATTERN.search(line):
                issues.append(
                    {
                        "type": "conflicting_claim",
                        "memory_id": memory_id,
                        "line": line_number,
                        "excerpt": line.strip(),
                    }
                )
            if _FUTURE_WORK_PATTERN.search(line):
                issues.append(
                    {
                        "type": "stale_placeholder",
                        "memory_id": memory_id,
                        "line": line_number,
                        "excerpt": line.strip(),
                    }
                )

    seen_bodies: dict[str, str] = {}
    for memory_id, normalized in normalized_bodies.items():
        if not normalized or len(normalized) < 80:
            continue
        duplicate_of = seen_bodies.get(normalized)
        if duplicate_of is not None:
            issues.append(
                {
                    "type": "duplicate_memory_body",
                    "memory_id": memory_id,
                    "duplicate_of": duplicate_of,
                }
            )
        else:
            seen_bodies[normalized] = memory_id
    return issues


def _inspect_memory_log_file(
    *,
    path: Path,
    memory_id: str,
) -> tuple[list[dict[str, object]], bool]:
    """Inspect one memory JSONL log and report malformed lines."""
    issues: list[dict[str, object]] = []
    has_valid_record = False
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as error:
        return (
            [
                {
                    "type": "unreadable_memory_log",
                    "memory_id": memory_id,
                    "error": type(error).__name__,
                }
            ],
            False,
        )
    for line_number, line in enumerate(lines, start=1):
        if not line.strip():
            continue
        try:
            loaded = json.loads(line)
        except json.JSONDecodeError:
            issues.append(
                {
                    "type": "malformed_memory_log",
                    "memory_id": memory_id,
                    "line": line_number,
                }
            )
            continue
        if not _is_valid_memory_log_event(loaded, memory_id=memory_id):
            issues.append(
                {
                    "type": "invalid_memory_log_record",
                    "memory_id": memory_id,
                    "line": line_number,
                }
            )
            continue
        has_valid_record = True
    return issues, has_valid_record


def _is_valid_memory_log_event(value: object, *, memory_id: str) -> bool:
    """Return whether one JSON value is a usable memory log event."""
    if not isinstance(value, dict):
        return False
    if value.get("memory_id") != memory_id:
        return False
    if not isinstance(value.get("event"), str) or not value["event"].strip():
        return False
    if not isinstance(value.get("version"), int) or value["version"] < 1:
        return False
    if not isinstance(value.get("sources"), list):
        return False
    if any(not isinstance(source, str) or not source.strip() for source in value["sources"]):
        return False
    source_hashes = value.get("source_hashes")
    if not isinstance(source_hashes, dict):
        return False
    return all(
        isinstance(source, str)
        and isinstance(digest, str)
        and re.fullmatch(r"[0-9a-fA-F]{64}", digest)
        for source, digest in source_hashes.items()
    )


def render_memory_skill(
    *,
    title: str,
    description: str | None,
    body: str,
    exit_skill: str,
    sub_tools: Sequence[str],
    sub_skills: Sequence[str],
    inherits_parent_tools: bool,
    instruction_introduction: str,
    instruction_activation: str,
    instruction_closure: str,
) -> str:
    """Render one loader-compatible memory deep-skill Markdown document."""
    normalized_title = " ".join(title.split())
    normalized_description = normalize_memory_description(
        title=normalized_title,
        description=description,
    )
    normalized_body = body.strip()
    if not normalized_title:
        raise ValueError("Memory skill title must not be empty.")
    if not normalized_body:
        raise ValueError("Memory skill body must not be empty.")
    rendered_activation = instruction_activation.format(exit_skill=exit_skill)
    rendered_closure = instruction_closure.format(exit_tool=f"{exit_skill}-tool")

    lines = [
        "---",
        f"description: {normalized_description}",
        f"exit-skill: {exit_skill}",
        "sub-tools:",
        *[f"  - {name}" for name in sub_tools],
        "sub-skills:",
        *[f"  - {name}" for name in sub_skills],
        f"inherits-parent-tools: {str(inherits_parent_tools).lower()}",
        "---",
        f"# {normalized_title}",
        "",
        normalized_body,
        "",
        "## Instructions",
        f"1. {instruction_introduction.strip()}",
        f"2. {rendered_activation.strip()}",
        f"3. {rendered_closure.strip()}",
        "",
    ]
    return "\n".join(lines)


def normalize_memory_description(*, title: str, description: str | None) -> str:
    """Return a scalar description compatible with the frontmatter parser."""
    candidate = " ".join((description or "").split())
    if not candidate:
        candidate = f"Knowledge memory for {title}."
    normalized = candidate.replace(",", ";").replace(" #", " — ").lstrip("#").strip()
    if not normalized:
        raise ValueError("Memory skill description must not be empty.")
    return normalized


def write_text_atomically(path: Path, content: str) -> None:
    """Write UTF-8 text through a temporary sibling followed by atomic replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as file:
            file.write(content)
        os.replace(temporary_path, path)
    except Exception:
        temporary_path.unlink(missing_ok=True)
        raise


def append_memory_log(
    *,
    path: Path,
    event: str,
    memory_id: str,
    title: str,
    sources: Sequence[str],
    source_hashes: Mapping[str, str],
    previous_hash: str | None,
    content_hash: str,
) -> int:
    """Append one creation or update event and return its monotonic version."""
    path.parent.mkdir(parents=True, exist_ok=True)
    version = _next_log_version(path)
    record = {
        "event": event,
        "memory_id": memory_id,
        "title": " ".join(title.split()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "version": version,
        "sources": list(sources),
        "source_hashes": dict(source_hashes),
        "previous_hash": previous_hash,
        "content_hash": content_hash,
    }
    with path.open("a", encoding="utf-8") as file:
        file.write(json.dumps(record, ensure_ascii=False) + "\n")
    return version


def content_sha256(content: str) -> str:
    """Return the hexadecimal SHA-256 digest of one rendered skill document."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def file_sha256(path: Path) -> str:
    """Return the hexadecimal SHA-256 digest of one file's raw bytes."""
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect_source_hashes(
    *,
    sources: Sequence[str],
    workroot: Path | None,
) -> dict[str, str]:
    """Hash existing local sources while leaving URLs and missing files unversioned."""
    if workroot is None:
        raise ValueError("Source hashing requires an injected workroot.")
    source_root = (workroot.resolve() / "row").resolve()
    hashes: dict[str, str] = {}
    for source in normalize_sources(sources):
        if _is_web_source(source):
            continue
        candidate = (source_root / source).resolve()
        try:
            candidate.relative_to(source_root)
        except ValueError:
            continue
        if candidate.is_file() and not candidate.is_symlink():
            hashes[source] = file_sha256(candidate)
    return hashes


def load_source_processing_states(
    *, paths: MemorySkillPaths
) -> dict[str, SourceProcessingState]:
    """Load source-to-memory hash state from each memory's latest valid log event."""
    if not paths.logs.is_dir():
        return {}
    associations: dict[str, dict[str, str | None]] = {}
    for log_path in sorted(paths.logs.glob("*.jsonl")):
        if not log_path.is_file() or log_path.is_symlink():
            continue
        record = _latest_valid_memory_log_record(log_path)
        if record is None:
            continue
        memory_id = record["memory_id"]
        source_hashes = record["source_hashes"]
        for source in record["sources"]:
            associations.setdefault(source, {})[memory_id] = source_hashes.get(source)
    return {
        source: SourceProcessingState(memory_hashes=dict(memory_hashes))
        for source, memory_hashes in associations.items()
    }


def _latest_valid_memory_log_record(path: Path) -> dict[str, Any] | None:
    """Return the latest usable source-state record from one append-only log."""
    latest: dict[str, Any] | None = None
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError):
        return None
    for line in lines:
        record = _parse_memory_log_record(line, fallback_memory_id=path.stem)
        if record is not None:
            latest = record
    return latest


def _parse_memory_log_record(
    line: str, *, fallback_memory_id: str
) -> dict[str, Any] | None:
    """Parse one log line into normalized local source-state data."""
    if not line.strip():
        return None
    try:
        loaded = json.loads(line)
    except json.JSONDecodeError:
        return None
    if not isinstance(loaded, dict):
        return None
    raw_memory_id = loaded.get("memory_id", fallback_memory_id)
    raw_sources = loaded.get("sources")
    if not isinstance(raw_memory_id, str) or not isinstance(raw_sources, list):
        return None
    try:
        memory_id = validate_memory_id(raw_memory_id)
        sources = _normalize_logged_sources(
            [source for source in raw_sources if isinstance(source, str)]
        )
    except ValueError:
        return None
    if not sources:
        return None
    source_hashes = _normalize_logged_source_hashes(loaded.get("source_hashes"))
    return {
        "memory_id": memory_id,
        "sources": sources,
        "source_hashes": source_hashes,
    }


def _normalize_logged_source_hashes(value: object) -> dict[str, str]:
    """Normalize valid SHA-256 entries from one current or legacy log record."""
    if not isinstance(value, dict):
        return {}
    normalized: dict[str, str] = {}
    for source, digest in value.items():
        if not isinstance(source, str) or not isinstance(digest, str):
            continue
        if not re.fullmatch(r"[0-9a-fA-F]{64}", digest):
            continue
        try:
            normalized_source = _normalize_logged_sources([source])[0]
        except (ValueError, IndexError):
            continue
        if not _is_web_source(normalized_source):
            normalized[normalized_source] = digest.casefold()
    return normalized


def _normalize_logged_sources(sources: Sequence[str]) -> tuple[str, ...]:
    """Normalize current paths while retaining legacy row-prefixed log support."""
    normalized: list[str] = []
    for source in sources:
        candidate = Path(source.strip())
        if candidate.parts and candidate.parts[0] == "row":
            candidate = Path(*candidate.parts[1:])
        normalized_source = normalize_sources([candidate.as_posix()])[0]
        if normalized_source not in normalized:
            normalized.append(normalized_source)
    return tuple(normalized)


def _is_web_source(source: str) -> bool:
    """Return whether one normalized memory source is an HTTP(S) URL."""
    parsed = urlparse(source)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def _resolve_configured_child(*, base: Path, value: str, label: str) -> Path:
    """Resolve one configured relative directory and keep it below its base."""
    candidate = Path(value)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError(f"Configured {label} must be relative.")
    target = (base / candidate).resolve()
    try:
        target.relative_to(base)
    except ValueError as error:
        raise ValueError(f"Configured {label} must stay inside its base.") from error
    return target


def _required_metadata_string(
    *, metadata: Mapping[str, Any], key: str, memory_id: str
) -> str:
    """Return one required string from parsed memory-skill metadata."""
    value = metadata.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(
            f"Memory skill '{memory_id}' is missing frontmatter field '{key}'."
        )
    return value.strip()


def _read_inherits_parent_tools(metadata: Mapping[str, Any]) -> bool:
    """Read the optional inherited-tool flag from parsed frontmatter."""
    value = metadata.get("inherits-parent-tools", "false")
    if isinstance(value, str):
        normalized = value.strip().casefold()
        if normalized in {"true", "yes", "1"}:
            return True
        if normalized in {"false", "no", "0"}:
            return False
    if isinstance(value, bool):
        return value
    raise ValueError("Memory skill inherits-parent-tools must be a boolean.")


def _next_log_version(path: Path) -> int:
    """Return the next append-only log version after validating existing records."""
    if not path.exists():
        return 1
    version = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        if not isinstance(record, dict) or not isinstance(record.get("version"), int):
            raise ValueError("Memory skill log contains an invalid record.")
        version = max(version, int(record["version"]))
    return version + 1
