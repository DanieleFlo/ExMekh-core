from __future__ import annotations

import base64
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from agent_wiki.configs.runtime import RuntimePackageConfig

if TYPE_CHECKING:
    from agent_wiki.backend.core.client import Client


PDF_MARKDOWN_PROMPT = """Convert these PDF page images to clean Markdown.

Preserve headings, paragraphs, lists, tables, links, captions, and visible source
references when they can be read. Do not add commentary, summaries, or facts that
are not visible in the pages. If a page is unreadable, write a short Markdown note
for that page instead of guessing.
"""


@dataclass(frozen=True, slots=True)
class PdfMarkdownResult:
    """Store Markdown converted from a PDF and related conversion metadata."""

    markdown: str
    page_count: int
    model: str
    output_path: Path | None = None


@dataclass(frozen=True, slots=True)
class RenderedPdfPage:
    """Store one rendered PDF page and its position in the source document."""

    number: int
    total: int
    image_data_url: str


def convert_pdf_to_markdown(
    *,
    path: Path,
    client: Client | None,
    config: RuntimePackageConfig | None,
    model_name: str | None,
    output_path: Path | None = None,
) -> PdfMarkdownResult:
    """Convert PDF pages individually, merge them, and optionally save Markdown."""
    if client is None:
        raise RuntimeError(
            "No runtime client was injected for PDF-to-Markdown parsing."
        )

    selected_model = _resolve_pdf_markdown_model(
        config=config,
        fallback_model=model_name or client.model,
    )
    page_markdown: list[str] = []
    for rendered_page in iter_rendered_pdf_pages(path):
        converted_page = client.create_multimodal_text(
            prompt=_page_conversion_prompt(rendered_page),
            image_data_urls=[rendered_page.image_data_url],
            model=selected_model,
            config=config,
        ).strip()
        if not converted_page:
            raise RuntimeError(
                "The configured vision model returned no Markdown for "
                f"PDF page {rendered_page.number}."
            )
        page_markdown.append(converted_page)

    markdown = _merge_page_markdown(page_markdown)
    saved_path = output_path.resolve() if output_path is not None else None
    if saved_path is not None:
        saved_path.write_text(markdown, encoding="utf-8")

    return PdfMarkdownResult(
        markdown=markdown,
        page_count=len(page_markdown),
        model=selected_model,
        output_path=saved_path,
    )


def iter_rendered_pdf_pages(
    path: Path,
    *,
    zoom: float = 2.0,
) -> Iterator[RenderedPdfPage]:
    """Render and yield one PDF page at a time as a PNG data URL."""
    try:
        import fitz
    except ImportError as error:
        raise RuntimeError(
            "PyMuPDF is required to parse PDF sources. Install the pymupdf dependency."
        ) from error

    try:
        document = fitz.open(path)
    except Exception as error:
        raise RuntimeError(f"Could not open PDF source: {error}") from error

    try:
        if document.page_count <= 0:
            raise RuntimeError("PDF source has no pages.")

        matrix = fitz.Matrix(zoom, zoom)
        for page_number, page in enumerate(document, start=1):
            pixmap = page.get_pixmap(matrix=matrix, alpha=False)
            png_bytes = pixmap.tobytes("png")
            encoded = base64.b64encode(png_bytes).decode("ascii")
            yield RenderedPdfPage(
                number=page_number,
                total=document.page_count,
                image_data_url=f"data:image/png;base64,{encoded}",
            )
    finally:
        document.close()


def render_pdf_pages_to_data_urls(path: Path, *, zoom: float = 2.0) -> list[str]:
    """Render every PDF page to PNG data URLs for compatibility callers."""
    return [page.image_data_url for page in iter_rendered_pdf_pages(path, zoom=zoom)]


def _page_conversion_prompt(page: RenderedPdfPage) -> str:
    """Return the conversion prompt for one ordered PDF page."""
    return (
        f"{PDF_MARKDOWN_PROMPT}\n"
        f"This image is page {page.number} of {page.total}. "
        "Return Markdown for this page only."
    )


def _merge_page_markdown(page_markdown: list[str]) -> str:
    """Join ordered per-page Markdown into one document."""
    if not page_markdown:
        raise RuntimeError("PDF source has no pages.")
    return "\n\n".join(page.strip() for page in page_markdown).strip()


def _resolve_pdf_markdown_model(
    *,
    config: RuntimePackageConfig | None,
    fallback_model: str,
) -> str:
    """Return the configured PDF Markdown model or the active agent model."""
    configured = None
    if config is not None and hasattr(config, "wiki"):
        configured = getattr(config.wiki, "pdf_markdown_model", None)
    if isinstance(configured, str) and configured.strip():
        return configured.strip()
    return fallback_model
