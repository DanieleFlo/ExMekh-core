# AgentWiki Schema

## Directory Contract

- `row/` contains immutable user-provided source files.
- `memory/skills/` contains maintained deep skills generated from semantic source sections.
- `memory/index.json` contains the ordered memory skill ids exposed to query.
- `logs/` contains append-only creation and update events for memory skills.
- `AGENT_WIKI.md` defines the schema and workflow conventions for this workspace.

Filesystem tools use paths relative to their logical area:

- Source tools receive paths relative to `row/`, such as `document.pdf`.
- Do not prefix source-tool arguments with `row/`.
- Use `wiki-list-sources` to discover the complete recursive source inventory before reading local files.
- The source inventory reports SHA-256, associated memory ids, and one status:
  `new`, `modified`, or `processed`.

## Memory Skill Conventions

Every generated memory skill:

- Lives at `memory/skills/<memory-id>/deep-skill.md`.
- Represents one coherent semantic section rather than one entire source file.
- Uses source files as evidence rather than as automatic skill boundaries.
- Stores maintained knowledge in its Markdown body.
- Uses `sub-skills` for directly subordinate knowledge.
- Uses the configured default exit skill unless a user customizes it manually.
- Declares the configured default sub-tools, including `list-tool-outputs`,
  explicitly in frontmatter so the skill can inspect output ids available in
  its current HDS node without inheriting parent tools.

## Markdown And Frontmatter

- Use UTF-8 `deep-skill.md` files with loader-compatible frontmatter.
- Keep generated identifiers stable when updating existing knowledge.
- Preserve manually customized exit skills and sub-tools during ingestion updates.
- Prefer multiple focused memory skills over one long mixed-topic skill.

## Relationships

- `sub-skills` defines directed parent-to-child knowledge relationships.
- Design the complete graph after reading all requested sources and before
  writing the first memory skill.
- An evident category is a stable shared concept covering at least two skills
  and improving navigation or synthesis.
- Every evident category must have a parent with a concise standalone summary,
  aggregated sources, and direct child ids in `sub-skills`.
- Create child skills before parents so every reference exists when validated.
- Leave a skill as a standalone root only when no meaningful evident category
  applies, and record the reason in the ingest summary.
- Do not create duplicate links, self-links, missing references, or cycles.
- Memory roots are derived as skills that no other memory skill references.
- `memory/index.json` is a curated query entry surface, not a complete catalog
  and not a replacement for the graph encoded by `sub-skills`.
- Include only principal top-level navigation skills in the index. Do not list
  every memory skill, even when the wiki is small; leaves and subordinate
  knowledge remain reachable through parent `sub-skills`.
- Prefer no more than ten direct index entries for navigability, without
  treating this recommendation as a validation limit.

## Ingest Policy

- Never delete source files from `row/`.
- Discover local sources before ingest and use the exact paths returned by `wiki-list-sources`.
- Read `new` and `modified` sources before claiming they were processed.
- Skip unchanged `processed` sources unless the user explicitly requests a
  forced reread.
- For a modified source, update every associated memory skill that still
  derives from it. The source remains modified until all associations record
  the current hash.
- Read every requested source before creating memory so classification is
  global rather than file-by-file; unchanged processed sources count as already
  read for this purpose.
- Reject the automatic mapping `one source file = one memory skill`.
- Update existing memory skills before creating duplicate concepts.
- Record every creation and update under `logs/<memory-id>.jsonl`.
- Store current local source hashes in each new log event. Legacy events without
  hashes are treated as modified once so they can be refreshed safely.
- Flag contradictions or unresolved conflicts instead of silently resolving them.
- Do not finish while an evident parent or required `sub-skills` link remains a
  future recommendation.
- Update `memory/index.json` only through the dedicated index tool and only
  after every added skill exists.
- Do not create compiled pages or legacy ingest logs.

## Query Policy

- Query starts from the memory skills listed in `memory/index.json`.
- Follow each indexed skill's `sub-skills` to reach more specific knowledge.
- Treat an absent index as an empty query surface and report missing knowledge
  instead of guessing memory ids.

## Lint Policy

- Lint checks the memory-skill graph, `memory/index.json`, append-only logs,
  source freshness, and semantic quality, then automatically applies reliable
  repairs through the canonical memory and index tools.
- A memory skill should not have more than ten direct `sub-skills`.
- Every memory skill must be reachable by following `sub-skills` from at least
  one general `memory/index.json` entry. Multiple parents are valid.
- New or modified `row/` sources mean the parent should run `wiki-ingest`
  before treating the wiki as fully current.
- Report graph cycles, missing `sub-skills`, duplicate links, malformed logs,
  unresolved conflict markers, stale placeholders, and duplicated memory text.
- Reinspect graph and provenance after repairs. Never edit append-only logs or
  source files directly, and leave ambiguous corrections unresolved with a
  concrete explanation.
