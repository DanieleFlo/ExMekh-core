from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.backend.core.capabilities.capability_roots import (
    CapabilityRoots,
    resolve_capability_roots,
)
from agent_wiki.backend.core.capabilities.deep_skill import DeepSkill
from agent_wiki.backend.core.capabilities.deep_skill_context import (
    DeepSkillParseContext,
)
from agent_wiki.wiki.memory_skills import (
    resolve_memory_skill_paths,
    validate_memory_id,
    write_text_atomically,
)


@dataclass(frozen=True, slots=True)
class MemoryIndex:
    """Represent the validated ordered AgentWiki memory index."""

    path: Path
    exists: bool
    skills: tuple[str, ...]


def read_memory_index(
    *,
    workroot: Path | None,
    config: RuntimePackageConfig,
    validate_references: bool = True,
) -> MemoryIndex:
    """Read and validate the configured memory index without creating it."""
    paths = resolve_memory_skill_paths(workroot=workroot, config=config)
    if not paths.index.exists():
        return MemoryIndex(path=paths.index, exists=False, skills=())
    if not paths.index.is_file():
        raise ValueError("Memory index path must be a regular file.")

    try:
        loaded = json.loads(paths.index.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise ValueError(f"Memory index contains invalid JSON: {error.msg}.") from error
    except UnicodeDecodeError as error:
        raise ValueError("Memory index must be valid UTF-8 JSON.") from error

    skills = _parse_memory_index_payload(loaded)
    if validate_references:
        load_indexed_memory_skills(
            skill_ids=skills,
            workroot=workroot,
            config=config,
        )
    return MemoryIndex(path=paths.index, exists=True, skills=skills)


def write_memory_index(
    *,
    skills: Sequence[str],
    workroot: Path | None,
    config: RuntimePackageConfig,
) -> MemoryIndex:
    """Validate and atomically write the ordered memory index."""
    normalized = _normalize_unique_skill_ids(skills)
    load_indexed_memory_skills(
        skill_ids=normalized,
        workroot=workroot,
        config=config,
    )
    paths = resolve_memory_skill_paths(workroot=workroot, config=config)
    content = json.dumps(
        {"skills": list(normalized)},
        ensure_ascii=False,
        indent=2,
    )
    write_text_atomically(paths.index, content + "\n")
    return MemoryIndex(path=paths.index, exists=True, skills=normalized)


def load_indexed_memory_skills(
    *,
    skill_ids: Sequence[str],
    workroot: Path | None,
    config: RuntimePackageConfig,
) -> list[DeepSkill]:
    """Load indexed memory skills through the active capability registries."""
    paths = resolve_memory_skill_paths(workroot=workroot, config=config)
    capability_roots = _memory_capability_roots(
        paths_root=paths.root,
        skills_root=paths.skills,
        workroot=workroot,
        config=config,
    )
    loaded: list[DeepSkill] = []
    for raw_skill_id in skill_ids:
        skill_id = validate_memory_id(raw_skill_id)
        try:
            skill = DeepSkill.load_deep_skill(
                parse_context=DeepSkillParseContext(
                    config=config,
                    capability_roots=capability_roots,
                    name=skill_id,
                )
            )
        except (OSError, TypeError, ValueError) as error:
            raise ValueError(
                f"Memory index references unavailable or invalid skill '{skill_id}'."
            ) from error
        loaded.append(skill)
    return loaded


def _parse_memory_index_payload(value: Any) -> tuple[str, ...]:
    """Validate the exact JSON shape used by the memory index."""
    if not isinstance(value, dict) or set(value) != {"skills"}:
        raise ValueError("Memory index must contain only the 'skills' field.")
    raw_skills = value["skills"]
    if not isinstance(raw_skills, list):
        raise ValueError("Memory index 'skills' must be a JSON array.")
    if any(not isinstance(skill_id, str) for skill_id in raw_skills):
        raise ValueError("Memory index skill ids must all be strings.")
    normalized = tuple(validate_memory_id(skill_id) for skill_id in raw_skills)
    if len(normalized) != len(set(normalized)):
        raise ValueError("Memory index must not contain duplicate skill ids.")
    return normalized


def _normalize_unique_skill_ids(skill_ids: Sequence[str]) -> tuple[str, ...]:
    """Normalize skill ids and remove duplicates while preserving order."""
    normalized: list[str] = []
    for raw_skill_id in skill_ids:
        skill_id = validate_memory_id(raw_skill_id)
        if skill_id not in normalized:
            normalized.append(skill_id)
    return tuple(normalized)


def _memory_capability_roots(
    *,
    paths_root: Path,
    skills_root: Path,
    workroot: Path | None,
    config: RuntimePackageConfig,
) -> CapabilityRoots:
    """Prepend generated memory skills to the active capability roots."""
    resolved = resolve_capability_roots(config=config, workroot=workroot)
    return CapabilityRoots(
        capability_roots=_prepend_unique(paths_root, resolved.capability_roots),
        tool_roots=resolved.tool_roots,
        exit_skill_roots=resolved.exit_skill_roots,
        skill_roots=_prepend_unique(skills_root, resolved.skill_roots),
        hds_roots=resolved.hds_roots,
    )


def _prepend_unique(path: Path, values: Sequence[Path]) -> tuple[Path, ...]:
    """Prepend one path to an ordered sequence unless it is already present."""
    resolved_path = path.resolve()
    return (resolved_path, *(value for value in values if value != resolved_path))
