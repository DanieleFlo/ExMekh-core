from __future__ import annotations


def build_exit_payload(
    *,
    message: str | None = None,
    selected_tool_outputs: list[str | None] | None = None,
) -> dict[str, object]:
    """Return the normalized exit payload used by AgentWiki exit tools."""
    return {
        "message": message or "",
        "selected_tool_outputs": selected_tool_outputs or [],
    }
