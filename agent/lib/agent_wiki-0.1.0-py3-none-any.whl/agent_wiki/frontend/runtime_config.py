from __future__ import annotations

from dataclasses import dataclass
from os import getenv
from pathlib import Path

from dotenv import load_dotenv

from agent_wiki.backend.core.client import Client
from agent_wiki.backend.providers.lmstudio import LMSTUDIO_BASE_URL
from agent_wiki.backend.providers.openrouter import OPENROUTER_BASE_URL
from agent_wiki.configs.settings import SystemConfig
from agent_wiki.configs.runtime import (
    DiagnosticLogConfigOverride,
    RuntimeConfigOverrides,
    UNSET,
)


DEFAULT_MODELS = {
    "ollama": "qwen3.5:9b-mlx",
    "openai": "gpt-4.1-mini",
    "openrouter": "openai/gpt-4.1-mini",
    "agentic_openai": "gpt-4.1-mini",
}

SUPPORTED_BACKENDS = frozenset((*DEFAULT_MODELS, "lmstudio", "agentic-openai"))


_ENVIRONMENT_LOADED = False


DEFAULT_SYSTEM_PROMPT = """You are the root assistant for Agent Wiki.

# 1. Capabilities
Use only declared capabilities. If the user asks for an available skill, open it before using that skill's local tools. If a capability does not exist, say so explicitly.

# 2. Levels
A skill opens a specialized child context. Do not replace a requested skill with a root tool if the skill exists. When a child skill finishes with promoted content, treat it as local output available to the parent level.

# 3. Exit skill
Whenever you close a skill, first call its exit skill to load the closing context, then call the associated exit tool exposed by that context. If the parent level receives a useful result from a child skill, the final payload must promote that result instead of replacing it with `{{null}}`. To refer to a child skill result, use only identifiers already present in the runtime tool message: the skill `tool_name` or its `tool_call_id`. Do not invent new placeholders and do not insert rendered JSON into `selected_tool_outputs`. Use `{{null}}` only when the current level truly has no local output to promote. The detailed exit contract is defined by the exit-skill context loaded inside the current level.

# 4. Filesystem
If a tool receives `workroot`, treat it as the workspace base path.

# 5. Errors
Do not invent capabilities, files, or results. If something fails, report it explicitly.
"""


@dataclass(slots=True)
class RuntimeSettings:
    """Store frontend runtime configuration resolved from the environment."""

    backend: str
    model: str
    base_url: str | None
    api_key: str | None
    system_prompt: str
    diagnostic_logs_enabled: bool | None
    diagnostic_logs_dir: str | None
    diagnostic_logs_level: str | None
    diagnostic_logs_file_name: str | None


def load_environment() -> None:
    """Load environment variables from the project .env file when present."""
    global _ENVIRONMENT_LOADED
    if _ENVIRONMENT_LOADED:
        return
    load_dotenv(override=False)
    _ENVIRONMENT_LOADED = True


def load_runtime_settings() -> RuntimeSettings:
    """Build frontend runtime settings from canonical environment variables."""
    backend = getenv("AGENT_WIKI_BACKEND", "ollama").strip().lower() or "ollama"
    model = getenv("AGENT_WIKI_MODEL", "").strip()
    if not model and backend != "lmstudio":
        model = DEFAULT_MODELS.get(backend, DEFAULT_MODELS["ollama"])
    base_url = getenv("AGENT_WIKI_BASE_URL")
    explicit_api_key = getenv("AGENT_WIKI_API_KEY")
    system_prompt = getenv("AGENT_WIKI_SYSTEM_PROMPT", DEFAULT_SYSTEM_PROMPT)
    api_key = explicit_api_key or getenv("OPENAI_API_KEY")

    return RuntimeSettings(
        backend=backend,
        model=model,
        base_url=base_url,
        api_key=api_key,
        system_prompt=system_prompt,
        diagnostic_logs_enabled=_optional_bool(
            getenv("AGENT_WIKI_DIAGNOSTIC_LOGS_ENABLED")
        ),
        diagnostic_logs_dir=_optional_string(getenv("AGENT_WIKI_DIAGNOSTIC_LOGS_DIR")),
        diagnostic_logs_level=_optional_string(
            getenv("AGENT_WIKI_DIAGNOSTIC_LOGS_LEVEL")
        ),
        diagnostic_logs_file_name=_optional_string(
            getenv("AGENT_WIKI_DIAGNOSTIC_LOGS_FILE_NAME")
        ),
    )


def build_client(*, settings: RuntimeSettings) -> Client:
    """Instantiate the provider client configured for the frontend runtime."""
    if not settings.model.strip():
        raise ValueError(
            "AGENT_WIKI_MODEL is required or a backend default model must be configured."
        )

    if settings.backend in {"openai", "agentic_openai", "agentic-openai"}:
        if not settings.api_key:
            raise ValueError(
                f"AGENT_WIKI_API_KEY or OPENAI_API_KEY is required when AGENT_WIKI_BACKEND={settings.backend}"
            )
        if settings.backend in {"agentic_openai", "agentic-openai"}:
            return Client.agentic_openai(
                model=settings.model,
                api_key=settings.api_key,
                base_url=settings.base_url,
            )
        return Client.openai(
            model=settings.model,
            api_key=settings.api_key,
            base_url=settings.base_url,
        )

    if settings.backend == "openrouter":
        if not settings.api_key:
            raise ValueError(
                "AGENT_WIKI_API_KEY is required when AGENT_WIKI_BACKEND=openrouter"
            )
        return Client.openrouter(
            model=settings.model,
            api_key=settings.api_key,
            base_url=settings.base_url or OPENROUTER_BASE_URL,
        )

    if settings.backend == "lmstudio":
        return Client.lmstudio(
            model=settings.model,
            base_url=settings.base_url or LMSTUDIO_BASE_URL,
            api_key=settings.api_key or "lm-studio",
        )

    if settings.backend == "ollama":
        return Client.ollama(
            model=settings.model,
            base_url=settings.base_url or "http://localhost:11434/v1",
            api_key=settings.api_key or "ollama",
        )

    supported = ", ".join(sorted(SUPPORTED_BACKENDS))
    raise ValueError(
        f"Unsupported AGENT_WIKI_BACKEND '{settings.backend}'. "
        f"Supported backends: {supported}."
    )


def diagnostic_runtime_overrides(*, settings: RuntimeSettings) -> RuntimeConfigOverrides | None:
    """Build runtime overrides for environment-backed diagnostic logging."""
    if (
        settings.diagnostic_logs_enabled is None
        and settings.diagnostic_logs_dir is None
        and settings.diagnostic_logs_level is None
        and settings.diagnostic_logs_file_name is None
    ):
        return None
    return RuntimeConfigOverrides(
        diagnostic_logs=DiagnosticLogConfigOverride(
            enabled=(
                settings.diagnostic_logs_enabled
                if settings.diagnostic_logs_enabled is not None
                else UNSET
            ),
            directory=settings.diagnostic_logs_dir or UNSET,
            level=settings.diagnostic_logs_level or UNSET,
            file_name=settings.diagnostic_logs_file_name or UNSET,
        )
    )


def resolve_capabilities_path() -> Path:
    """Resolve the capabilities directory configured for the installed package."""
    config = SystemConfig().config
    return Path(str(config.capabilities.capabilities_path)).resolve()


def _optional_string(value: str | None) -> str | None:
    """Return a stripped environment string or None."""
    if value is None:
        return None
    stripped = value.strip()
    return stripped or None


def _optional_bool(value: str | None) -> bool | None:
    """Parse an optional boolean environment value."""
    stripped = _optional_string(value)
    if stripped is None:
        return None
    return stripped.casefold() in {"1", "true", "yes", "on"}
