export const state = {
  bootstrap: null,
  sessionId: null,
  eventSource: null,
  lastEventId: 0,
  seenEventIds: new Set(),
  isConnected: true,
  pendingSessionConfig: false,
  thinkingEnabled: true,
  selectedCapabilities: new Set(),
  traceEvents: [],
  hdsNodes: [],
  activeTraceHdsPath: null,
  traceScrollLeftByHdsPath: new Map(),
  traceScrollPinnedByHdsPath: new Map(),
  chatMessages: [],
  interactions: [],
  rawChatMessages: [],
  lastTurnTokenUsage: null,
  sessionTokenUsage: null,
  activeTraceSequence: null,
  pressedKeys: new Set(),
  toolColorMap: new Map(),
  generatedHds: null,
  hdsSessions: {},
  hdsCapabilities: {},
  stripItems: [],
  activityItems: [],
  thinkingByRequestId: new Map(),
  liveThinkingRequestId: null,
  liveThinkingExpanded: false,
  traceDetailMode: "content",
  traceContentExpansionBySequence: new Map(),
  currentTheme: "light",
  rawChatFilterSequence: null,
  rawChatFilterLabel: null,
  activeSkillSpans: new Set(),
  expandedTraceGroups: new Set(),
  collapsedTraceGroups: new Set(),
};

export const TOOL_PALETTE = [
  "#34a853",
  "#1a73e8",
  "#fbbc04",
  "#ea4335",
  "#8e24aa",
  "#00897b",
  "#5e97f6",
  "#c2185b",
];

export const KIND_LABELS = {
  hds: "HDS",
  "exit-skill": "Exit skill",
  "exit-tool": "Exit tool",
  skill: "Skill",
  tool: "Tool",
};

export const elements = {
  backendName: null,
  modelName: null,
  sessionStatus: null,
  settingsButton: null,
  themeToggleButton: null,
  thinkingToggleButton: null,
  connectionToggleButton: null,
  closeSettingsButton: null,
  settingsDialog: null,
  settingsForm: null,
  hdsList: null,
  exitSkillsList: null,
  skillsList: null,
  toolsList: null,
  systemPrompt: null,
  availableHdsList: null,
  capabilityListDialog: null,
  closeCapabilityListButton: null,
  capabilityListTitle: null,
  capabilityListContent: null,
  activityFeed: null,
  activityStatusText: null,
  tokenUsageSummary: null,
  chatHistory: null,
  chatForm: null,
  chatInput: null,
  chatSubmitButton: null,
  hdsTraceList: null,
  traceDetail: null,
  rawChatBox: null,
  rawChatDump: null,
  capabilityTemplate: null,
  stopAgentButton: null,
  errorDialog: null,
  closeErrorButton: null,
  errorDialogMessage: null,
  interactionDetailsDialog: null,
  closeInteractionDetailsButton: null,
  interactionDetailsTitle: null,
  interactionDetailsContent: null,
};

export function refreshElements() {
  elements.backendName = document.getElementById("backendName");
  elements.modelName = document.getElementById("modelName");
  elements.sessionStatus = document.getElementById("sessionStatus");
  elements.settingsButton = document.getElementById("settingsButton");
  elements.themeToggleButton = document.getElementById("themeToggleButton");
  elements.thinkingToggleButton = document.getElementById("thinkingToggleButton");
  elements.connectionToggleButton = document.getElementById("connectionToggleButton");
  elements.closeSettingsButton = document.getElementById("closeSettingsButton");
  elements.settingsDialog = document.getElementById("settingsDialog");
  elements.settingsForm = document.getElementById("settingsForm");
  elements.hdsList = document.getElementById("hdsList");
  elements.exitSkillsList = document.getElementById("exitSkillsList");
  elements.skillsList = document.getElementById("skillsList");
  elements.toolsList = document.getElementById("toolsList");
  elements.systemPrompt = document.getElementById("systemPrompt");
  elements.availableHdsList = document.getElementById("availableHdsList");
  elements.capabilityListDialog = document.getElementById("capabilityListDialog");
  elements.closeCapabilityListButton = document.getElementById("closeCapabilityListButton");
  elements.capabilityListTitle = document.getElementById("capabilityListTitle");
  elements.capabilityListContent = document.getElementById("capabilityListContent");
  elements.activityFeed = document.getElementById("activityFeed");
  elements.activityStatusText = document.getElementById("activityStatusText");
  elements.tokenUsageSummary = document.getElementById("tokenUsageSummary");
  elements.chatHistory = document.getElementById("chatHistory");
  elements.chatForm = document.getElementById("chatForm");
  elements.chatInput = document.getElementById("chatInput");
  elements.chatSubmitButton = document.querySelector("#chatForm button[type='submit']");
  elements.hdsTraceList = document.getElementById("hdsTraceList");
  elements.traceDetail = document.getElementById("traceDetail");
  elements.rawChatBox = document.getElementById("rawChatBox");
  elements.rawChatDump = document.getElementById("rawChatDump");
  elements.capabilityTemplate = document.getElementById("capabilityTemplate");
  elements.favicon = document.getElementById("favicon");
  elements.stopAgentButton = document.getElementById("stopAgentButton");
  elements.errorDialog = document.getElementById("errorDialog");
  elements.closeErrorButton = document.getElementById("closeErrorButton");
  elements.errorDialogMessage = document.getElementById("errorDialogMessage");
  elements.interactionDetailsDialog = document.getElementById("interactionDetailsDialog");
  elements.closeInteractionDetailsButton = document.getElementById("closeInteractionDetailsButton");
  elements.interactionDetailsTitle = document.getElementById("interactionDetailsTitle");
  elements.interactionDetailsContent = document.getElementById("interactionDetailsContent");
}
