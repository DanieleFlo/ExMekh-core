const STORAGE_KEY = "agent-wiki-theme";

export function initializeTheme({ state, elements }) {
  const preferredTheme = readStoredTheme() || "light";
  applyTheme({ state, elements, theme: preferredTheme });

  elements.themeToggleButton.addEventListener("click", () => {
    const nextTheme = state.currentTheme === "dark" ? "light" : "dark";
    applyTheme({ state, elements, theme: nextTheme });
  });
}

function readStoredTheme() {
  try {
    return localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

function writeStoredTheme(theme) {
  try {
    localStorage.setItem(STORAGE_KEY, theme);
  } catch {
    // Ignore storage errors in constrained environments.
  }
}

function applyTheme({ state, elements, theme }) {
  state.currentTheme = theme;
  document.documentElement.dataset.theme = theme;
  writeStoredTheme(theme);

  const isDark = theme === "dark";
  elements.themeToggleButton.textContent = isDark ? "☀" : "☾";
  elements.themeToggleButton.setAttribute("aria-label", isDark ? "Attiva tema chiaro" : "Attiva tema scuro");
  elements.themeToggleButton.setAttribute("title", isDark ? "Attiva tema chiaro" : "Attiva tema scuro");
  elements.favicon.setAttribute("href", isDark ? "/static/icons/favicon-dark.ico" : "/static/icons/favicon-light.ico");
  
  const hljsLight = document.getElementById("hljsLight");
  const hljsDark = document.getElementById("hljsDark");
  if (hljsLight && hljsDark) {
    if (isDark) {
      hljsLight.setAttribute("disabled", "disabled");
      hljsDark.removeAttribute("disabled");
    } else {
      hljsDark.setAttribute("disabled", "disabled");
      hljsLight.removeAttribute("disabled");
    }
  }
}
