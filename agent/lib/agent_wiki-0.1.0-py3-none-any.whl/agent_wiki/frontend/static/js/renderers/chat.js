import { elements, state } from "../core/state.js";

import { renderInteractionCard } from "./interactions.js";

const userBubbleObserver = new ResizeObserver((entries) => {
  for (const entry of entries) {
    entry.target.style.minWidth = '0';
    const height = entry.target.offsetHeight;
    entry.target.style.minWidth = `${height}px`;
    entry.target.style.textAlign = entry.target.offsetWidth > height ? "left" : "center";
  }
});

/** Render chat. */
export function renderChat() {
  elements.chatHistory.innerHTML = "";
  if (!state.chatMessages.length && !state.interactions.length) {
    elements.chatHistory.innerHTML = '<div class="empty-state">The conversation history will appear here after the first session message.</div>';
    return;
  }

  let toolGroupDetails = null;
  let toolGroupContainer = null;

  const combinedItems = [];
  const messageSequenceMap = new Map();
  const toolCallSequenceMap = new Map();
  let maxSequence = 0;

  for (const event of state.traceEvents) {
    if (event.sequence > maxSequence) maxSequence = event.sequence;
    if (event.added_message_ids && event.added_message_ids.length > 0) {
      for (const msgId of event.added_message_ids) {
        messageSequenceMap.set(msgId, event.sequence);
      }
    }
    if (event.tool_call_id) {
      if (event.event_type === "tool_call" || !toolCallSequenceMap.has(event.tool_call_id)) {
        toolCallSequenceMap.set(event.tool_call_id, event.sequence);
      }
    }
  }

  for (const message of state.chatMessages) {
    let order = messageSequenceMap.get(message.id);
    if (order === undefined) {
      order = maxSequence + 1;
      maxSequence++;
    }
    combinedItems.push({ type: "message", item: message, order });
  }

  for (const interaction of state.interactions) {
    let order = maxSequence + 1;
    const tcid = interaction.payload?.tool_call_id;
    if (tcid && toolCallSequenceMap.has(tcid)) {
      order = toolCallSequenceMap.get(tcid) + 0.5;
    } else {
      maxSequence++;
    }
    combinedItems.push({ type: "interaction", item: interaction, order });
  }

  combinedItems.sort((a, b) => a.order - b.order);

  for (const wrapped of combinedItems) {
    if (wrapped.type === "interaction") {
      toolGroupDetails = null;
      toolGroupContainer = null;
      elements.chatHistory.appendChild(renderInteractionCard(wrapped.item));
      continue;
    }

    const message = wrapped.item;
    if (message.kind === "error") {
      toolGroupDetails = null;
      toolGroupContainer = null;
      elements.chatHistory.appendChild(renderCompactClientError(message));
      continue;
    }

    if (message.role === "tool") {
      if (!toolGroupDetails) {
        toolGroupDetails = document.createElement("details");
        toolGroupDetails.className = "tool-group-details";

        const summary = document.createElement("summary");
        summary.className = "tool-group-summary";
        summary.textContent = "🛠 Tools eseguiti";
        toolGroupDetails.appendChild(summary);

        toolGroupContainer = document.createElement("div");
        toolGroupContainer.className = "tool-group-container";
        toolGroupDetails.appendChild(toolGroupContainer);

        elements.chatHistory.appendChild(toolGroupDetails);
      }

      const toolDetails = document.createElement("details");
      toolDetails.className = "tool-specific-details";

      const toolSummary = document.createElement("summary");
      toolSummary.className = "tool-specific-summary";
      toolSummary.textContent = message.name ? `Risultato: ${message.name}` : buildMessageMeta(message);

      const content = document.createElement("pre");
      content.className = "tool-specific-content";
      content.textContent = message.content;

      toolDetails.append(toolSummary, content);
      toolGroupContainer.appendChild(toolDetails);
    } else {
      toolGroupDetails = null;
      toolGroupContainer = null;

      const bubble = document.createElement("article");
      bubble.className = `message-bubble ${message.role}`;

      const meta = document.createElement("div");
      meta.className = "message-meta";

      const metaText = document.createElement("span");
      metaText.textContent = buildMessageMeta(message);
      meta.append(metaText);
      const usageBadge = renderMessageTokenBadge(message);
      if (usageBadge) {
        meta.append(usageBadge);
      }

      const content = document.createElement("div");
      content.className = "message-content markdown-body";

      if (message.role === "user") {
        userBubbleObserver.observe(bubble);
      }
      if (typeof marked !== "undefined") {
        content.innerHTML = marked.parse(message.content);
        content.querySelectorAll("pre").forEach((pre) => {
          const wrapper = document.createElement("div");
          wrapper.className = "code-block-wrapper";

          const codeCopyBtn = document.createElement("button");
          codeCopyBtn.className = "code-copy-button";
          codeCopyBtn.title = "Copia codice";
          codeCopyBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`;
          codeCopyBtn.type = "button";

          codeCopyBtn.addEventListener("click", () => {
            const codeEl = pre.querySelector("code");
            navigator.clipboard.writeText(codeEl ? codeEl.textContent : pre.textContent);
            codeCopyBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
            setTimeout(() => {
              codeCopyBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`;
            }, 2000);
          });

          const codeEl = pre.querySelector("code");
          if (codeEl && typeof hljs !== "undefined") {
            hljs.highlightElement(codeEl);
          }

          pre.parentNode.insertBefore(wrapper, pre);
          wrapper.appendChild(pre);
          wrapper.appendChild(codeCopyBtn);
        });
      } else {
        content.textContent = message.content;
      }

      const copyButton = document.createElement("button");
      copyButton.className = `copy-button ${message.role}`;
      copyButton.title = "Copia messaggio";
      copyButton.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`;

      copyButton.addEventListener("click", () => {
        navigator.clipboard.writeText(message.content);
        copyButton.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
        setTimeout(() => {
          copyButton.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`;
        }, 2000);
      });

      bubble.append(meta, content, copyButton);
      elements.chatHistory.appendChild(bubble);

      requestAnimationFrame(() => {
        if (content.scrollHeight > 450 && !content.classList.contains("tall-message-container")) {
          content.classList.add("tall-message-container");

          const fader = document.createElement("div");
          fader.className = "message-fader";

          const expandBtn = document.createElement("button");
          expandBtn.className = "expand-message-button";
          expandBtn.title = "Espandi messaggio";
          expandBtn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>`;

          expandBtn.addEventListener("click", () => {
            if (content.classList.contains("expanded")) {
              content.classList.remove("expanded");
              expandBtn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>`;
              expandBtn.title = "Espandi messaggio";
            } else {
              content.classList.add("expanded");
              expandBtn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>`;
              expandBtn.title = "Comprimi messaggio";
            }
          });

          fader.appendChild(expandBtn);
          content.appendChild(fader);
        }
      });
    }
  }

  if (state.activeSkillContext) {
    const details = document.createElement("details");
    details.className = "tool-group-details active-skill-details";
    details.open = true;

    const summary = document.createElement("summary");
    summary.className = "tool-group-summary";
    summary.textContent = `🧠 Skill in esecuzione: ${state.activeSkillContext.name}`;
    details.appendChild(summary);

    const container = document.createElement("div");
    container.className = "tool-group-container";

    for (const msg of state.activeSkillContext.messages) {
      if (msg.role === "assistant") {
        const bubble = document.createElement("article");
        bubble.className = "message-bubble assistant";
        const meta = document.createElement("div");
        meta.className = "message-meta";
        meta.innerHTML = `<span class="message-role">assistant (skill)</span>`;
        const content = document.createElement("div");
        content.className = "message-content markdown-body";
        if (typeof marked !== "undefined") {
          content.innerHTML = marked.parse(msg.content);
          content.querySelectorAll("pre code").forEach(codeEl => {
            if (typeof hljs !== "undefined") hljs.highlightElement(codeEl);
          });
        } else {
          content.textContent = msg.content;
        }
        bubble.append(meta, content);
        container.appendChild(bubble);
      }
    }

    if (state.activeSkillContext.streamingContent) {
      const bubble = document.createElement("article");
      bubble.className = "message-bubble assistant streaming";
      const meta = document.createElement("div");
      meta.className = "message-meta";
      meta.innerHTML = `<span class="message-role">assistant (skill)</span><span class="message-time">sto scrivendo...</span>`;
      const content = document.createElement("div");
      content.className = "message-content markdown-body";
      if (typeof marked !== "undefined") {
        content.innerHTML = marked.parse(state.activeSkillContext.streamingContent);
        content.querySelectorAll("pre code").forEach(codeEl => {
          if (typeof hljs !== "undefined") hljs.highlightElement(codeEl);
        });
      } else {
        content.textContent = state.activeSkillContext.streamingContent;
      }
      bubble.append(meta, content);
      container.appendChild(bubble);
    }

    details.appendChild(container);
    elements.chatHistory.appendChild(details);
  }

  if (state.streamingAssistantContent && elements.sessionStatus.textContent === "running") {
    const bubble = document.createElement("article");
    bubble.className = "message-bubble assistant streaming";

    const meta = document.createElement("div");
    meta.className = "message-meta";

    const roleSpan = document.createElement("span");
    roleSpan.className = "message-role";
    roleSpan.textContent = "assistant";

    const timeSpan = document.createElement("span");
    timeSpan.className = "message-time";
    timeSpan.textContent = "sto scrivendo...";

    meta.append(roleSpan, timeSpan);

    const content = document.createElement("div");
    content.className = "message-content markdown-body";
    if (typeof marked !== "undefined") {
      content.innerHTML = marked.parse(state.streamingAssistantContent);
      content.querySelectorAll("pre code").forEach(codeEl => {
        if (typeof hljs !== "undefined") hljs.highlightElement(codeEl);
      });
    } else {
      content.textContent = state.streamingAssistantContent;
    }

    bubble.append(meta, content);
    elements.chatHistory.appendChild(bubble);
  }

  requestAnimationFrame(() => {
    elements.chatHistory.scrollTop = elements.chatHistory.scrollHeight;
  });
}

/**
 * Render a compact token usage badge for assistant messages with real usage.
 */
function renderMessageTokenBadge(message) {
  if (message.role !== "assistant" || !message.token_usage?.usage) {
    return null;
  }
  const usage = message.token_usage.usage;
  if (!hasTokenUsage(usage)) {
    return null;
  }
  const badge = document.createElement("span");
  badge.className = "token-usage-badge";
  badge.textContent = tokenUsageLabel(usage);
  badge.title = detailedTokenUsageLabel(usage);
  return badge;
}

/**
 * Render the global last-turn and session token usage summary.
 */
export function renderTokenUsageSummary() {
  if (!elements.tokenUsageSummary) {
    return;
  }
  const lastTurn = state.lastTurnTokenUsage;
  const session = state.sessionTokenUsage;
  if (!hasTokenUsage(lastTurn) && !hasTokenUsage(session)) {
    elements.tokenUsageSummary.hidden = true;
    elements.tokenUsageSummary.innerHTML = "";
    return;
  }
  elements.tokenUsageSummary.hidden = false;
  elements.tokenUsageSummary.innerHTML = "";
  if (hasTokenUsage(lastTurn)) {
    elements.tokenUsageSummary.appendChild(tokenUsageSummaryItem("Last turn", lastTurn));
  }
  if (hasTokenUsage(session)) {
    elements.tokenUsageSummary.appendChild(tokenUsageSummaryItem("Session", session));
  }
}

/**
 * Build one labeled summary item for token usage totals.
 */
function tokenUsageSummaryItem(label, usage) {
  const item = document.createElement("span");
  item.className = "token-usage-summary-item";
  const total = Number(usage.total_tokens || 0);
  const requests = Number(usage.request_count || 0);
  item.textContent = `${label}: ${formatTokenCount(total)} tokens`;
  if (requests > 0) {
    item.title = `${requests} model request${requests === 1 ? "" : "s"} • ${detailedTokenUsageLabel(usage)}`;
  }
  return item;
}

/**
 * Return whether a usage payload has visible provider-reported totals.
 */
function hasTokenUsage(usage) {
  if (!usage) {
    return false;
  }
  return [
    usage.input_tokens,
    usage.output_tokens,
    usage.total_tokens,
    usage.reasoning_tokens,
    usage.cache_read_tokens,
    usage.cache_write_tokens,
  ].some((value) => Number(value || 0) > 0);
}

/**
 * Build a terse token usage label for message badges.
 */
function tokenUsageLabel(usage) {
  const total = Number(usage.total_tokens || 0);
  if (total > 0) {
    return `${formatTokenCount(total)} tok`;
  }
  return `${formatTokenCount(Number(usage.output_tokens || 0))} out`;
}

/**
 * Build a tooltip-style token usage detail string.
 */
function detailedTokenUsageLabel(usage) {
  const parts = [];
  if (Number(usage.input_tokens || 0) > 0) {
    parts.push(`input ${formatTokenCount(Number(usage.input_tokens))}`);
  }
  if (Number(usage.output_tokens || 0) > 0) {
    parts.push(`output ${formatTokenCount(Number(usage.output_tokens))}`);
  }
  if (Number(usage.reasoning_tokens || 0) > 0) {
    parts.push(`reasoning ${formatTokenCount(Number(usage.reasoning_tokens))}`);
  }
  if (Number(usage.cache_read_tokens || 0) > 0) {
    parts.push(`cache read ${formatTokenCount(Number(usage.cache_read_tokens))}`);
  }
  if (Number(usage.cache_write_tokens || 0) > 0) {
    parts.push(`cache write ${formatTokenCount(Number(usage.cache_write_tokens))}`);
  }
  if (Number(usage.total_tokens || 0) > 0) {
    parts.push(`total ${formatTokenCount(Number(usage.total_tokens))}`);
  }
  return parts.join(" • ");
}

/**
 * Format token counts with compact thousands separators.
 */
function formatTokenCount(value) {
  return new Intl.NumberFormat("en", { maximumFractionDigits: 0 }).format(value);
}

/**
 * Build a minimal corrective-error row whose full content opens in the shared dialog.
 */
function renderCompactClientError(message) {
  const row = document.createElement("article");
  row.className = "client-error-row";

  const icon = document.createElement("span");
  icon.className = "client-error-icon";
  icon.textContent = "⚠";
  icon.setAttribute("aria-hidden", "true");

  const label = document.createElement("span");
  label.className = "client-error-label";
  label.textContent = "Issue";

  const detailsButton = document.createElement("button");
  detailsButton.className = "client-error-details";
  detailsButton.type = "button";
  detailsButton.textContent = "Details";
  detailsButton.setAttribute("aria-label", "Show issue details");
  detailsButton.addEventListener("click", () => {
    window.showErrorPopup(message.content);
  });

  row.append(icon, label, detailsButton);
  return row;
}

/**
 * Render one pending interaction card or its compact resolved summary.
 */

/** Build message meta. */
function buildMessageMeta(message) {
  const parts = [message.role];
  if (message.name) {
    parts.push(message.name);
  }
  if (message.tool_call_id) {
    parts.push(message.tool_call_id);
  }
  if (message.optimistic) {
    parts.push("in attesa");
  }
  return parts.join(" • ");
}

/**
 * Render runtime events as expandable SVG trace nodes.
 */


