import { elements, state } from "../core/state.js";
import { truncateText } from "./utils.js";

/** Render activity feed. */
export function renderActivityFeed() {
  elements.activityFeed.innerHTML = "";
  const container = elements.activityFeed.closest('.activity-message-container');

  const hasItems = state.activityItems && state.activityItems.length > 0;

  const isBusy = elements.sessionStatus.textContent === "running";

  if (!hasItems && !isBusy) {
    elements.activityFeed.innerHTML = '<div class="empty-state compact">The agent will show running operations, tools, and skills here.</div>';
    if (container) container.style.display = 'none';
    return;
  }

  if (container) container.style.display = '';

  if (hasItems) {
    const currentItem = state.activityItems[0];
    elements.activityFeed.appendChild(createActivityNode(currentItem));
  }

  if (hasItems && state.activityItems.length > 1) {
    const details = document.createElement("details");
    details.className = "activity-history-details";
    const summary = document.createElement("summary");
    summary.textContent = `Precedenti (${state.activityItems.length - 1})`;
    details.appendChild(summary);

    const historyContainer = document.createElement("div");
    historyContainer.className = "activity-history-container";

    for (const item of state.activityItems.slice(1, 6)) {
      historyContainer.appendChild(createActivityNode(item));
    }

    details.appendChild(historyContainer);
    elements.activityFeed.appendChild(details);
  }

  const isAnyRunning = hasItems && state.activityItems.some(i => i.status === 'running');
  if (isBusy && !isAnyRunning) {
    const thinkingNode = createActivityNode(createActivityFallback({
      id: "thinking",
      kind: "system",
      label: "Model generation",
      snippet: "Waiting for model output",
      status: "running",
    }));
    elements.activityFeed.insertBefore(thinkingNode, elements.activityFeed.firstChild);
  }
}

/** Create activity fallback. */
function createActivityFallback(item) {
  return {
    id: item.id,
    kind: item.kind,
    label: item.label,
    snippet: item.snippet,
    status: item.status,
    kindLabel: "Status",
  };
}

/** Create activity node. */
function createActivityNode(item) {
  const row = document.createElement("div");
  row.className = `activity-item ${item.status}`;

  const marker = document.createElement("div");
  if (item.status === "running") {
    marker.className = "activity-spinner";
  } else if (item.status === "error") {
    marker.className = "activity-error-mark";
    marker.textContent = "!";
  } else {
    marker.className = "activity-check";
    marker.textContent = "✓";
  }

  const main = document.createElement("div");
  main.className = "activity-item-main";

  const label = document.createElement("div");
  label.className = "activity-item-label";
  label.textContent = item.label;

  const snippet = document.createElement("div");
  snippet.className = "activity-item-snippet";
  snippet.textContent = item.snippet || "Model generation";

  const badge = document.createElement("div");
  badge.className = "activity-kind-badge";
  badge.textContent = item.kindLabel;

  main.append(label, snippet);
  const liveThinking = currentLiveThinking();
  if (item.status === "running" && liveThinking) {
    main.appendChild(renderLiveThinking(liveThinking));
  }
  row.append(marker, main, badge);
  return row;
}

/** Current live thinking. */
function currentLiveThinking() {
  if (!state.liveThinkingRequestId) {
    return null;
  }
  return state.thinkingByRequestId.get(state.liveThinkingRequestId) || null;
}

/** Render live thinking. */
function renderLiveThinking(thinking) {
  const container = document.createElement("div");
  container.className = `live-thinking${state.liveThinkingExpanded ? " expanded" : ""}`;

  const preview = document.createElement("div");
  preview.className = "live-thinking-preview";
  preview.textContent = state.liveThinkingExpanded
    ? lastThinkingLines(thinking.content, 10).join("\n")
    : thinkingTail(thinking.content);

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.className = "live-thinking-toggle";
  toggle.textContent = state.liveThinkingExpanded ? "Collapse" : "Expand";
  toggle.setAttribute("aria-expanded", String(state.liveThinkingExpanded));
  toggle.addEventListener("click", () => {
    state.liveThinkingExpanded = !state.liveThinkingExpanded;
    renderActivityFeed();
  });

  container.append(preview, toggle);
  return container;
}

/** Thinking tail. */
function thinkingTail(content, maxLength = 140) {
  const normalized = String(content || "").replace(/\s+/g, " ").trim();
  if (!normalized) {
    return "Waiting for thinking stream";
  }
  return normalized.length > maxLength
    ? normalized.slice(normalized.length - maxLength)
    : normalized;
}

/** Last thinking lines. */
function lastThinkingLines(content, maxLines) {
  const lines = String(content || "")
    .split(/\r?\n/)
    .map((line) => line.trimEnd())
    .filter((line) => line.length > 0);
  if (!lines.length) {
    return ["Waiting for thinking stream"];
  }
  return lines.slice(-maxLines);
}

/**
 * Render the current conversation projection and pending interactions.
 */

