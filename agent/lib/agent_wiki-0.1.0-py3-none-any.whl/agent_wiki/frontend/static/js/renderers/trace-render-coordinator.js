/** Coordinate transport-driven trace renders around pointer interactions. */
export function createTraceRenderCoordinator({ render, defer = (callback) => setTimeout(callback, 0) }) {
  let interactionActive = false;
  let interactionGeneration = 0;
  let renderPending = false;

  /** Record that a pointer interaction with the trace has started. */
  function beginInteraction() {
    interactionActive = true;
    interactionGeneration += 1;
  }

  /** Release the interaction after the browser has dispatched its click. */
  function endInteraction() {
    if (!interactionActive) {
      return;
    }
    const endingGeneration = interactionGeneration;
    defer(() => {
      if (endingGeneration !== interactionGeneration) {
        return;
      }
      interactionActive = false;
      if (renderPending) {
        renderPending = false;
        render();
      }
    });
  }

  /** Render now unless an active pointer gesture requires preserving the DOM. */
  function requestRender() {
    if (interactionActive) {
      renderPending = true;
      return;
    }
    render();
  }

  return Object.freeze({ beginInteraction, endInteraction, requestRender });
}
