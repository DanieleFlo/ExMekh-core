const TOKEN_KEYS = Object.freeze([
  "input_tokens",
  "output_tokens",
  "total_tokens",
  "reasoning_tokens",
  "cache_read_tokens",
  "cache_write_tokens",
]);

/**
 * Normalize the token categories carried by one assistant response event.
 */
export function normalizeEventTokenUsage(event) {
  if (event?.event_type !== "assistant_response") {
    return null;
  }
  const rawUsage = event.payload?.token_usage;
  if (!rawUsage || typeof rawUsage !== "object") {
    return null;
  }
  const usage = {};
  for (const key of TOKEN_KEYS) {
    const value = Number(rawUsage[key]);
    usage[key] = Number.isFinite(value) && value >= 0 ? value : null;
  }
  return Object.freeze(usage);
}

/**
 * Calculate one request total without double-counting reasoning or cache subsets.
 */
export function requestTokenTotal(usage) {
  if (!usage) {
    return null;
  }
  if (usage.input_tokens !== null && usage.output_tokens !== null) {
    return usage.input_tokens + usage.output_tokens;
  }
  return usage.total_tokens !== null ? usage.total_tokens : null;
}

/**
 * Build per-request samples before any visual span folding is applied.
 */
export function buildCanonicalTokenSamples(events) {
  return Object.freeze(events
    .filter((event) => event.event_type === "assistant_response")
    .map((event) => {
      const usage = normalizeEventTokenUsage(event);
      return Object.freeze({
        sequence: event.sequence,
        usage,
        tokens: requestTokenTotal(usage),
      });
    }));
}

/**
 * Anchor canonical request samples to visible nodes while preserving explicit gaps.
 */
export function projectTokenSamples({ samples, points }) {
  const pointBySequence = new Map(
    points.map((point) => [point.event.sequence, point]),
  );
  const collapsedGroups = points
    .filter((point) => point.collapsedSequenceRange)
    .map((point) => {
      const [startSequence, endSequence] = point.collapsedSequenceRange;
      const groupedSamples = samples.filter(
        (sample) => sample.sequence >= startSequence
          && sample.sequence <= endSequence,
      );
      return { point, startSequence, endSequence, groupedSamples };
    });
  const projected = samples.map((sample) => {
    const exactPoint = pointBySequence.get(sample.sequence);
    const collapsedGroup = collapsedGroups.find(
      (group) => sample.sequence >= group.startSequence
        && sample.sequence <= group.endSequence,
    );
    let x = exactPoint?.x;
    if (collapsedGroup && collapsedGroup.groupedSamples.length > 1) {
      const sampleIndex = collapsedGroup.groupedSamples.findIndex(
        (candidate) => candidate.sequence === sample.sequence,
      );
      const centerIndex = (collapsedGroup.groupedSamples.length - 1) / 2;
      x = collapsedGroup.point.x + ((sampleIndex - centerIndex) * 24);
    }
    return Object.freeze({
      x: x ?? sample.sequence,
      sequence: sample.sequence,
      tokens: sample.tokens,
      usage: sample.usage,
      isGap: sample.tokens === null,
    });
  });
  return Object.freeze(projected);
}

/**
 * Return the largest known per-request total in a token series.
 */
export function tokenChartMax(points) {
  const known = points
    .map((point) => point.tokens)
    .filter((tokens) => tokens !== null);
  return known.length ? Math.max(...known, 1) : null;
}
