/**
 * Return the vertical coordinate for one trace event.
 */
export function traceEventY(event, pairedStartDepth = null, hdsDepth = 0) {
  const baseY = 50;
  const depthGap = 54;
  if (event.event_type === "parent_message") {
    return baseY;
  }
  const isBoundary = event.operation === "skill" || event.operation === "hds-child";
  const eventDepth = isBoundary && pairedStartDepth !== null
    ? pairedStartDepth
    : event.depth || 0;
  const depth = Math.min(Math.max(0, eventDepth - hdsDepth), 3);
  const layerY = baseY + depth * depthGap;
  return isBoundary && depth > 0 ? layerY - depthGap / 2 : layerY;
}

/**
 * Assign stable SVG coordinates to one already projected trace.
 */
export function layoutTraceProjection({ events, projection, spans, hdsDepth }) {
  const spanByEnd = new Map(spans.map((span) => [span.endSequence, span]));
  let graphBaseDepth = Infinity;
  for (const event of events) {
    if (event.event_type !== "parent_message" && typeof event.depth === "number") {
      graphBaseDepth = Math.min(graphBaseDepth, event.depth);
    }
  }
  const effectiveDepth = graphBaseDepth === Infinity ? hdsDepth : graphBaseDepth;
  const points = projection.map((item, index) => {
    const pairedStartDepth = spanByEnd.get(item.event.sequence)?.start.depth ?? null;
    return Object.freeze({
      ...item,
      x: 90 + index * 140,
      y: traceEventY(item.event, pairedStartDepth, effectiveDepth),
      radius: item.isMerged ? 16 : 12,
      isExpandedStart: Boolean(item.expandedPairId),
      collapsedSequenceRange: item.isMerged
        ? [item.span.startSequence, item.span.endSequence]
        : null,
    });
  });
  return Object.freeze({
    points: Object.freeze(points),
    width: 90 + points.length * 140 + 50,
    height: 320,
  });
}
