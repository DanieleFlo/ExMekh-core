const LONG_MULTILINE_LINE_COUNT = 8;
const LONG_MULTILINE_CHARACTER_COUNT = 800;

/**
 * Build the navigable Content inspector for one immutable Trace event.
 */
export function buildTraceContentInspector({ event, expansionState }) {
  const inspector = document.createElement("section");
  inspector.className = "trace-content-inspector";

  const controls = document.createElement("div");
  controls.className = "trace-content-controls";
  const expandAll = createInspectorControl("Expand all", () => {
    setInspectorDetailsOpen(inspector, true, expansionState);
  });
  const collapseAll = createInspectorControl("Collapse all", () => {
    setInspectorDetailsOpen(inspector, false, expansionState);
  });
  controls.append(expandAll, collapseAll);

  const sections = document.createElement("div");
  sections.className = "trace-content-sections";
  sections.append(
    createInspectorSection({
      label: "content",
      value: event.content,
      path: "content",
      defaultOpen: true,
      expansionState,
    }),
    createInspectorSection({
      label: "payload",
      value: event.payload,
      path: "payload",
      defaultOpen: false,
      expansionState,
    }),
    createInspectorSection({
      label: "capabilities",
      value: event.capabilities,
      path: "capabilities",
      defaultOpen: false,
      expansionState,
    }),
  );
  inspector.append(controls, sections);
  return inspector;
}

/**
 * Create a top-level event section with independently retained open state.
 */
function createInspectorSection({ label, value, path, defaultOpen, expansionState }) {
  const section = createExpandableNode({
    className: "trace-content-section",
    path,
    defaultOpen,
    expansionState,
  });
  const summary = document.createElement("summary");
  summary.className = "trace-content-section-summary";
  appendToken(summary, "trace-json-key", label);
  appendToken(summary, "trace-json-punctuation", describeValue(value));

  const body = document.createElement("div");
  body.className = "trace-content-section-body";
  body.append(renderValue({ value, path: `${path}.value`, expansionState }));
  section.append(summary, body);
  return section;
}

/**
 * Render one value without changing the source event object.
 */
function renderValue({ value, path, expansionState }) {
  const embeddedJson = parseEmbeddedJson(value);
  if (embeddedJson !== null) {
    return renderValue({ value: embeddedJson, path: `${path}.parsed`, expansionState });
  }
  if (Array.isArray(value)) {
    return renderCollection({
      entries: value.map((item, index) => [String(index), item]),
      path,
      expansionState,
      type: "array",
    });
  }
  if (isPlainObject(value)) {
    return renderCollection({
      entries: Object.entries(value),
      path,
      expansionState,
      type: "object",
    });
  }
  if (typeof value === "string") {
    return renderString({ value, path, expansionState });
  }
  return renderPrimitive(value);
}

/**
 * Render an object or array as a collapsed, labelled tree branch.
 */
function renderCollection({ entries, path, expansionState, type }) {
  const node = createExpandableNode({
    className: "trace-json-node",
    path,
    defaultOpen: false,
    expansionState,
  });
  const summary = document.createElement("summary");
  summary.className = "trace-json-node-summary";
  appendToken(summary, "trace-json-punctuation", type === "array" ? "[" : "{");
  appendToken(
    summary,
    "trace-json-count",
    `${entries.length} ${entries.length === 1 ? "item" : "items"}`,
  );
  appendToken(summary, "trace-json-punctuation", type === "array" ? "]" : "}");

  const children = document.createElement("div");
  children.className = "trace-json-children";
  for (const [key, childValue] of entries) {
    const row = document.createElement("div");
    row.className = "trace-json-row";
    appendToken(row, "trace-json-key", type === "array" ? `[${key}]` : `\"${key}\"`);
    appendToken(row, "trace-json-punctuation", ":");
    row.append(renderValue({
      value: childValue,
      path: `${path}.${escapePathSegment(key)}`,
      expansionState,
    }));
    children.append(row);
  }
  node.append(summary, children);
  return node;
}

/**
 * Render text with readable newlines and collapse only unusually large values.
 */
function renderString({ value, path, expansionState }) {
  const lineCount = value.split("\n").length;
  if (lineCount >= LONG_MULTILINE_LINE_COUNT || value.length >= LONG_MULTILINE_CHARACTER_COUNT) {
    const node = createExpandableNode({
      className: "trace-json-multiline",
      path: `${path}.multiline`,
      defaultOpen: false,
      expansionState,
    });
    const summary = document.createElement("summary");
    summary.className = "trace-json-multiline-summary";
    appendToken(summary, "trace-json-string", `${lineCount} lines · ${value.length} characters`);
    const content = document.createElement("pre");
    content.className = "trace-json-multiline-content";
    content.textContent = value;
    node.append(summary, content);
    return node;
  }
  const content = document.createElement("span");
  content.className = "trace-json-string";
  content.textContent = value;
  return content;
}

/**
 * Render a JSON primitive with a stable semantic colour class.
 */
function renderPrimitive(value) {
  if (value === null || value === undefined) {
    return createToken("trace-json-null", "null");
  }
  if (typeof value === "boolean") {
    return createToken("trace-json-boolean", String(value));
  }
  if (typeof value === "number") {
    return createToken("trace-json-number", String(value));
  }
  return createToken("trace-json-unknown", String(value));
}

/**
 * Parse only complete JSON object and array strings, leaving other text untouched.
 */
function parseEmbeddedJson(value) {
  if (typeof value !== "string") {
    return null;
  }
  const candidate = value.trim();
  const hasJsonContainer = (candidate.startsWith("{") && candidate.endsWith("}"))
    || (candidate.startsWith("[") && candidate.endsWith("]"));
  if (!hasJsonContainer) {
    return null;
  }
  try {
    const parsed = JSON.parse(candidate);
    return Array.isArray(parsed) || isPlainObject(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

/**
 * Return whether one value is a non-null object suitable for JSON tree rendering.
 */
function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Create one details element and synchronize its state with the selected event.
 */
function createExpandableNode({ className, path, defaultOpen, expansionState }) {
  const node = document.createElement("details");
  node.className = className;
  node.dataset.traceContentPath = path;
  node.open = expansionState.has(path) ? expansionState.get(path) : defaultOpen;
  node.addEventListener("toggle", () => {
    expansionState.set(path, node.open);
  });
  return node;
}

/**
 * Create a control button for all inspector branches.
 */
function createInspectorControl(label, onClick) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "trace-content-control";
  button.textContent = label;
  button.addEventListener("click", onClick);
  return button;
}

/**
 * Open or close every rendered tree branch and retain that choice for the event.
 */
function setInspectorDetailsOpen(inspector, isOpen, expansionState) {
  for (const node of inspector.querySelectorAll("details[data-trace-content-path]")) {
    node.open = isOpen;
    expansionState.set(node.dataset.traceContentPath, isOpen);
  }
}

/**
 * Add one syntax-coloured token without parsing its text as markup.
 */
function appendToken(parent, className, text) {
  parent.append(createToken(className, text));
}

/**
 * Create one syntax-coloured token without parsing its text as markup.
 */
function createToken(className, text) {
  const token = document.createElement("span");
  token.className = className;
  token.textContent = text;
  return token;
}

/**
 * Describe a value briefly in a section summary.
 */
function describeValue(value) {
  if (Array.isArray(value)) {
    return ` [${value.length}]`;
  }
  if (isPlainObject(value)) {
    return ` {${Object.keys(value).length}}`;
  }
  if (typeof value === "string") {
    return ` ${value.length} characters`;
  }
  return ` ${String(value)}`;
}

/**
 * Escape a property name so it stays distinct inside the retained state key.
 */
function escapePathSegment(segment) {
  return segment.replaceAll(".", "\\.");
}
