import { elements, state } from "../core/state.js";

/** Render interaction card. */
export function renderInteractionCard(interaction) {
  if (interaction.status?.startsWith("resolved:") || interaction.status === "cancelled") {
    return renderResolvedInteraction(interaction);
  }
  const card = document.createElement("article");
  card.className = "interaction-card";
  card.dataset.interactionId = interaction.id;
  card.dataset.status = interaction.status || "pending";

  if (interaction.interaction_type?.startsWith("user_question.")) {
    return renderUserQuestionCard(interaction, card);
  }

  const eyebrow = document.createElement("div");
  eyebrow.className = "interaction-eyebrow";
  eyebrow.textContent = interaction.interaction_type === "hitl"
    ? "Human approval required"
    : interaction.interaction_type;

  const title = document.createElement("h3");
  title.textContent = interaction.content;
  const description = document.createElement("p");
  description.className = "interaction-description";
  description.textContent = interaction.payload?.tool_description || "";

  const toolName = document.createElement("code");
  toolName.className = "interaction-tool-name";
  toolName.textContent = interaction.payload?.tool_name || "Unknown tool";

  const argumentsBlock = document.createElement("pre");
  argumentsBlock.className = "interaction-arguments";
  argumentsBlock.textContent = JSON.stringify(interaction.payload?.arguments || {}, null, 2);

  const status = document.createElement("div");
  status.className = "interaction-status";
  status.textContent = interactionStatusLabel(interaction.status);

  card.append(eyebrow, title, toolName, description, argumentsBlock, status);
  if ((interaction.status || "pending") === "pending") {
    card.appendChild(renderInteractionActions(interaction, argumentsBlock.textContent));
  }
  return card;
}

/** Render the control matching one typed user-question interaction. */
function renderUserQuestionCard(interaction, card) {
  const question = interaction.payload?.question || {};
  const eyebrow = document.createElement("div");
  eyebrow.className = "interaction-eyebrow";
  eyebrow.textContent = "Input required";
  const title = document.createElement("h3");
  title.textContent = question.title || "Question";
  const prompt = document.createElement("p");
  prompt.className = "interaction-description";
  prompt.textContent = question.question || interaction.content;
  card.append(eyebrow, title, prompt);
  if (question.comment) {
    const comment = document.createElement("p");
    comment.className = "question-comment";
    comment.textContent = question.comment;
    card.appendChild(comment);
  }
  const form = document.createElement("form");
  form.className = "user-question-form";
  const type = interaction.interaction_type;
  if (type === "user_question.text") {
    form.appendChild(buildQuestionTextControl(question.text || {}, "text"));
  } else {
    form.appendChild(buildQuestionOptions(question.options || []));
    if (type === "user_question.choice_or_text") {
      form.appendChild(buildQuestionTextControl(question.text || {}, "custom_text"));
      wireChoiceOrTextExclusivity(form);
    }
  }
  const status = document.createElement("div");
  status.className = "interaction-status";
  status.textContent = interactionStatusLabel(interaction.status);
  const submit = document.createElement("button");
  submit.type = "submit";
  submit.className = "primary-button";
  submit.textContent = "Submit answer";
  form.append(status, submit);
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    try {
      dispatchInteractionResponse(interaction.id, "submit", questionResponsePayload(form, interaction));
    } catch (error) {
      window.showErrorPopup(error.message || "Invalid answer.");
    }
  });
  card.appendChild(form);
  return card;
}

/** Build one accessible free-text control from its transport configuration. */
function buildQuestionTextControl(config, name) {
  const wrapper = document.createElement("label");
  wrapper.className = "question-text-control";
  const label = document.createElement("span");
  label.textContent = config.label || "Your answer";
  const input = document.createElement("textarea");
  input.name = name;
  input.rows = 4;
  input.placeholder = config.placeholder || "";
  input.required = Boolean(config.required);
  input.minLength = Number(config.min_length ?? 0);
  input.maxLength = Number(config.max_length ?? 512);
  wrapper.append(label, input);
  return wrapper;
}

/** Build one radio group for the predefined options of a question. */
function buildQuestionOptions(options) {
  const fieldset = document.createElement("fieldset");
  fieldset.className = "question-options";
  const legend = document.createElement("legend");
  legend.textContent = "Choose one option";
  fieldset.appendChild(legend);
  for (const option of options) {
    const label = document.createElement("label");
    const input = document.createElement("input");
    input.type = "radio";
    input.name = "option_id";
    input.value = option.id;
    const copy = document.createElement("span");
    copy.textContent = option.comment ? `${option.title} — ${option.comment}` : option.title;
    label.append(input, copy);
    fieldset.appendChild(label);
  }
  return fieldset;
}

/** Keep the predefined and free-text answer branches mutually exclusive and reversible. */
function wireChoiceOrTextExclusivity(form) {
  const textControl = form.elements.namedItem("custom_text");
  const optionControls = [...form.querySelectorAll('input[name="option_id"]')];
  const textIsRequired = textControl.required;
  form.dataset.selectedOption = "";

  textControl.addEventListener("input", () => {
    textControl.required = textIsRequired;
    if (!textControl.value) return;
    for (const optionControl of optionControls) {
      optionControl.checked = false;
    }
    form.dataset.selectedOption = "";
  });

  for (const optionControl of optionControls) {
    optionControl.addEventListener("click", () => {
      if (form.dataset.selectedOption === optionControl.value) {
        optionControl.checked = false;
        form.dataset.selectedOption = "";
        textControl.required = textIsRequired;
        return;
      }
      form.dataset.selectedOption = optionControl.value;
      textControl.value = "";
      textControl.required = false;
    });
  }
}

/** Normalize and validate one browser answer before transport. */
function questionResponsePayload(form, interaction) {
  const type = interaction.interaction_type;
  const selected = form.querySelector('input[name="option_id"]:checked')?.value || null;
  const textControl = form.elements.namedItem(type === "user_question.text" ? "text" : "custom_text");
  const text = textControl ? textControl.value : "";
  if (type === "user_question.text") {
    if (!textControl.checkValidity()) throw new Error("Enter a valid answer before submitting.");
    return { text };
  }
  if (type === "user_question.choice") {
    if (!selected) throw new Error("Select one option before submitting.");
    return { option_id: selected };
  }
  if (selected && text) throw new Error("Choose an option or enter text, not both.");
  if (selected) return { response_type: "choice", option_id: selected };
  if (!textControl.checkValidity() || !text) throw new Error("Select an option or enter a valid answer.");
  return { response_type: "text", text };
}

/**
 * Render one resolved interaction as a single compact line.
 */
function renderResolvedInteraction(interaction) {
  const row = document.createElement("article");
  row.className = "interaction-summary-row";
  row.dataset.interactionId = interaction.id;
  row.dataset.status = interaction.status;

  const toolName = document.createElement("code");
  toolName.className = "interaction-summary-tool";
  toolName.textContent = interaction.payload?.tool_name
    || interaction.payload?.question?.title
    || "Interaction";

  const preview = document.createElement("span");
  preview.className = "interaction-summary-preview";
  preview.textContent = truncateInteractionPreview(interaction.content);

  const outcome = document.createElement("span");
  outcome.className = "interaction-summary-outcome";
  outcome.textContent = interactionOutcomeLabel(interaction.status);

  const detailsButton = document.createElement("button");
  detailsButton.type = "button";
  detailsButton.className = "interaction-summary-details";
  detailsButton.textContent = "Details";
  detailsButton.setAttribute("aria-label", `Show details for ${toolName.textContent}`);
  detailsButton.addEventListener("click", () => {
    document.dispatchEvent(new CustomEvent("agentwiki:show-interaction-details", {
      detail: { interaction },
    }));
  });

  row.append(
    toolName,
    interactionSummarySeparator(),
    preview,
    interactionSummarySeparator(),
    outcome,
    interactionSummarySeparator(),
    detailsButton,
  );
  return row;
}

/**
 * Normalize and truncate interaction content for the compact summary.
 */
export function truncateInteractionPreview(content, maxLength = 30) {
  const normalized = String(content || "").replace(/\s+/g, " ").trim();
  return normalized.length > maxLength
    ? `${normalized.slice(0, maxLength)}…`
    : normalized;
}

/**
 * Build an accessible visual separator for a compact interaction summary.
 */
function interactionSummarySeparator() {
  const separator = document.createElement("span");
  separator.className = "interaction-summary-separator";
  separator.textContent = "·";
  separator.setAttribute("aria-hidden", "true");
  return separator;
}

/**
 * Convert one interaction status into its concise user-facing outcome.
 */
export function interactionOutcomeLabel(status) {
  const action = status?.startsWith("resolved:") ? status.split(":")[1] : status;
  return {
    approve: "Approved",
    deny: "Denied",
    modify: "Modified",
    submit: "Submitted",
    cancelled: "Cancelled",
  }[action] || "Resolved";
}

/**
 * Populate the dedicated dialog with the complete interaction request and response.
 */
export function renderInteractionDetailsDialog(interaction) {
  const question = interaction.payload?.question;
  elements.interactionDetailsTitle.textContent = `${interaction.payload?.tool_name || question?.title || "Interaction"} details`;
  elements.interactionDetailsContent.innerHTML = "";
  appendInteractionDetail("Outcome", interactionOutcomeLabel(interaction.status));
  appendInteractionDetail("Request", interaction.content || "");
  if (question) {
    appendInteractionDetail("Question schema", question, true);
    appendInteractionDetail("Answer", interaction.response?.payload || {}, true);
    return;
  }
  appendInteractionDetail("Description", interaction.payload?.tool_description || "");
  appendInteractionDetail("Tool", interaction.payload?.tool_name || "Unknown tool");
  appendInteractionDetail("Original arguments", interaction.payload?.arguments || {}, true);
  if (interaction.response?.action === "modify") {
    appendInteractionDetail(
      "Modified arguments",
      interaction.response?.payload?.arguments || {},
      true,
    );
  }
  if (interaction.response?.action === "deny" && interaction.response?.content) {
    appendInteractionDetail("Denial message", interaction.response.content);
  }
}

/**
 * Append one labeled value to the interaction details dialog.
 */
function appendInteractionDetail(label, value, formatAsJson = false) {
  const section = document.createElement("section");
  section.className = "interaction-detail-section";
  const heading = document.createElement("h3");
  heading.textContent = label;
  const content = document.createElement(formatAsJson ? "pre" : "p");
  content.textContent = formatAsJson ? JSON.stringify(value, null, 2) : String(value);
  section.append(heading, content);
  elements.interactionDetailsContent.appendChild(section);
}

/** Render interaction actions. */
function renderInteractionActions(interaction, formattedArguments) {
  const container = document.createElement("div");
  container.className = "interaction-controls";
  const actions = new Set(interaction.allowed_actions || []);

  if (interaction.payload?.allow_denial_override) {
    const denialInput = document.createElement("textarea");
    denialInput.className = "interaction-denial-input";
    denialInput.rows = 2;
    denialInput.placeholder = "Optional message returned to the agent when denied";
    container.appendChild(denialInput);
  }

  const editor = document.createElement("textarea");
  editor.className = "interaction-argument-editor";
  editor.rows = 7;
  editor.value = formattedArguments;
  editor.hidden = true;
  container.appendChild(editor);

  const buttons = document.createElement("div");
  buttons.className = "interaction-actions";
  if (actions.has("approve")) {
    buttons.appendChild(interactionButton("Continue", "approve", interaction));
  }
  if (actions.has("modify")) {
    const modify = document.createElement("button");
    modify.type = "button";
    modify.className = "ghost-button";
    modify.textContent = "Modify";
    modify.addEventListener("click", () => {
      if (editor.hidden) {
        editor.hidden = false;
        modify.textContent = "Run modified";
        editor.focus();
        return;
      }
      try {
        const argumentsPayload = JSON.parse(editor.value);
        if (!argumentsPayload || Array.isArray(argumentsPayload) || typeof argumentsPayload !== "object") {
          throw new Error("Arguments must be a JSON object.");
        }
        dispatchInteractionResponse(interaction.id, "modify", { arguments: argumentsPayload });
      } catch (error) {
        window.showErrorPopup(error.message || "Arguments must contain valid JSON.");
      }
    });
    buttons.appendChild(modify);
  }
  if (actions.has("deny")) {
    const deny = document.createElement("button");
    deny.type = "button";
    deny.className = "danger-button";
    deny.textContent = "Cancel";
    deny.addEventListener("click", () => {
      const input = container.querySelector(".interaction-denial-input");
      dispatchInteractionResponse(
        interaction.id,
        "deny",
        {},
        input?.value.trim() || null,
      );
    });
    buttons.appendChild(deny);
  }
  container.appendChild(buttons);
  return container;
}

/** Interaction button. */
function interactionButton(label, action, interaction) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "primary-button";
  button.textContent = label;
  button.addEventListener("click", () => {
    dispatchInteractionResponse(interaction.id, action);
  });
  return button;
}

/** Dispatch interaction response. */
function dispatchInteractionResponse(requestId, action, payload = {}, content = null) {
  document.dispatchEvent(new CustomEvent("agentwiki:respond-interaction", {
    detail: { requestId, action, payload, content },
  }));
}

/** Interaction status label. */
function interactionStatusLabel(status) {
  if (status === "submitting") return "Submitting decision…";
  if (status === "cancelled") return "Interaction cancelled";
  if (status?.startsWith("resolved:")) return `Resolved: ${status.split(":")[1]}`;
  return "The agent is paused until you decide.";
}

/**
 * Build the compact metadata label for a normal chat message.
 */


