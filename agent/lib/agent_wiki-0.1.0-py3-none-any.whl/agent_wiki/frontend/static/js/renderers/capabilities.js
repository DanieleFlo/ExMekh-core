import { elements, KIND_LABELS, state } from "../core/state.js";

/** Render capability lists. */
export function renderCapabilityLists() {
  renderCapabilityGroup(elements.hdsList, getCapabilitiesByKind("hds"));
  renderCapabilityGroup(elements.exitSkillsList, getCapabilitiesByKind("exit-skill"));
  renderCapabilityGroup(elements.skillsList, getCapabilitiesByKind("skill"));
  renderCapabilityGroup(elements.toolsList, getCapabilitiesByKind("tool"));
}

/** Get capabilities by kind. */
export function getCapabilitiesByKind(kind) {
  return state.bootstrap.capabilities.filter((item) => item.kind === kind);
}

/** Render capability group. */
function renderCapabilityGroup(container, capabilities) {
  container.innerHTML = "";
  if (!capabilities.length) {
    container.innerHTML = '<div class="empty-state">Nessuna capability disponibile.</div>';
    return;
  }

  for (const capability of capabilities) {
    const fragment = elements.capabilityTemplate.content.cloneNode(true);
    const card = fragment.querySelector(".capability-card");
    const kind = fragment.querySelector(".capability-kind");
    const name = fragment.querySelector(".capability-name");
    const description = fragment.querySelector(".capability-description");
    const extra = fragment.querySelector(".capability-extra");
    const button = fragment.querySelector(".toggle-capability");

    card.dataset.kind = capability.kind;
    kind.textContent = KIND_LABELS[capability.kind] || capability.kind;
    name.textContent = capability.name;
    description.textContent = capability.description;
    extra.textContent = buildCapabilityExtra(capability);

    if (state.selectedCapabilities.has(capability.name)) {
      card.classList.add("selected");
      button.textContent = "−";
    }

    button.addEventListener("click", () => {
      document.dispatchEvent(new CustomEvent("agentwiki:toggle-capability", { detail: capability }));
    });

    container.appendChild(fragment);
  }
}

/** Build capability extra. */
function buildCapabilityExtra(capability) {
  const parts = [];
  if (capability.exit_skill) {
    parts.push(`exit-skill: ${capability.exit_skill}`);
  }
  if (capability.sub_tools && capability.sub_tools.length) {
    parts.push(`tools: ${capability.sub_tools.join(", ")}`);
  }
  if (capability.sub_skills && capability.sub_skills.length) {
    parts.push(`skills: ${capability.sub_skills.join(", ")}`);
  }
  return parts.join(" • ");
}

/** Render hds controls. */
export function renderHdsControls() {
  renderAvailableHdsList();
}


/** Build strip items. */
function buildStripItems() {
  if (!state.generatedHds) {
    return [];
  }

  const items = [];
  const sourceHdsName = state.generatedHds.source_hds || state.generatedHds.name;
  const sourceHds = state.bootstrap?.capabilities?.find(
    (capability) => capability.kind === "hds" && capability.name === sourceHdsName,
  );
  items.push({
    kind: "hds",
    label: "HDS",
    name: sourceHdsName,
    description: sourceHds?.description || state.generatedHds.path,
    extra: buildCapabilityExtra(sourceHds || state.generatedHds),
  });

  if (state.generatedHds.exit_skill) {
    const exitSkill = state.bootstrap?.capabilities?.find(
      (capability) => capability.kind === "exit-skill" && capability.name === state.generatedHds.exit_skill,
    );
    items.push({
      kind: "exit-skill",
      label: "Exit skill",
      name: state.generatedHds.exit_skill,
      description: exitSkill?.description || "Active HDS exit skill",
      extra: buildCapabilityExtra(exitSkill),
    });
  }

  for (const toolName of state.generatedHds.selected_tools || []) {
    const tool = state.bootstrap?.capabilities?.find(
      (capability) => capability.kind === "tool" && capability.name === toolName,
    );
    items.push({
      kind: "tool",
      label: "Tool",
      name: toolName,
      description: tool?.description || "Tool attivo nella HDS corrente",
      extra: buildCapabilityExtra(tool),
    });
  }

  for (const skillName of state.generatedHds.selected_skills || []) {
    const skill = state.bootstrap?.capabilities?.find(
      (capability) => capability.kind === "skill" && capability.name === skillName,
    );
    items.push({
      kind: "skill",
      label: "Skill",
      name: skillName,
      description: skill?.description || "Skill attiva nella HDS corrente",
      extra: buildCapabilityExtra(skill),
    });
  }

  return items;
}

/** Render available hds list. */
function renderAvailableHdsList() {
  elements.availableHdsList.innerHTML = "";
  const hdsItems = getCapabilitiesByKind("hds");

  if (!hdsItems.length) {
    elements.availableHdsList.innerHTML = '<div class="empty-state compact">Nessuna HDS disponibile.</div>';
    return;
  }

  state.stripItems = buildStripItems();
  const activeHdsName = state.stripItems.find((item) => item.kind === "hds")?.name || null;

  for (const capability of hdsItems) {
    const isActive = activeHdsName === capability.name;
    const card = document.createElement("article");
    card.className = `hds-selector-card${isActive ? " selected" : ""}`;
    card.title = capability.description;

    const copy = document.createElement("div");
    copy.className = "hds-selector-copy";

    const title = document.createElement("h4");
    title.textContent = capability.name;
    copy.appendChild(title);

    if (isActive) {
      const dotRow = document.createElement("div");
      dotRow.className = "capability-dot-row";

      const stripWithoutHds = state.stripItems.filter((entry) => entry.kind !== "hds");
      for (const item of stripWithoutHds.slice(0, 3)) {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = `capability-dot ${item.kind}`;
        chip.title = `${item.label}: ${item.name}`;
        chip.setAttribute("aria-label", `${item.label}: ${item.name}`);
        chip.addEventListener("click", () => {
          document.dispatchEvent(new CustomEvent("agentwiki:show-capability-details", { detail: item }));
        });
        dotRow.appendChild(chip);
      }

      if (stripWithoutHds.length === 0) {
        dotRow.innerHTML = '<span class="empty-state compact">Nessuna capability.</span>';
      }

      card.append(copy, dotRow);
    } else {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "hds-select-button";
      button.textContent = "+";
      button.setAttribute("aria-label", `Seleziona HDS ${capability.name}`);
      button.title = `Seleziona HDS ${capability.name}`;
      button.addEventListener("click", () => {
        document.dispatchEvent(new CustomEvent("agentwiki:select-hds", { detail: capability }));
      });
      card.append(copy, button);
    }

    elements.availableHdsList.appendChild(card);
  }
}

/** Render capability list dialog. */
export function renderCapabilityListDialog(selectedCapabilityName = null) {
  elements.capabilityListContent.innerHTML = "";
  elements.capabilityListTitle.textContent = selectedCapabilityName
    ? `Capability Detail: ${selectedCapabilityName}`
    : "Active Capabilities";

  const orderedItems = state.stripItems.slice().sort((left, right) => {
    if (left.name === selectedCapabilityName) {
      return -1;
    }
    if (right.name === selectedCapabilityName) {
      return 1;
    }
    return 0;
  });

  for (const item of orderedItems) {
    const row = document.createElement("div");
    row.className = `capability-list-row ${item.kind}${item.name === selectedCapabilityName ? " selected" : ""}`;

    const title = document.createElement("strong");
    title.textContent = `${item.label}: ${item.name}`;

    const detail = document.createElement("div");
    detail.textContent = item.description;

    row.append(title, detail);
    if (item.extra) {
      const extra = document.createElement("div");
      extra.className = "capability-extra";
      extra.textContent = item.extra;
      row.appendChild(extra);
    }
    elements.capabilityListContent.appendChild(row);
  }
}


