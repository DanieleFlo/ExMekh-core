import { elements, state, TOOL_PALETTE } from "../core/state.js";
import { truncateText } from "./utils.js";
import { normalizeTraceEvents } from "./trace-events.js";
import { layoutTraceProjection } from "./trace-layout.js";
import { buildTraceSpans, projectTraceEvents } from "./trace-spans.js";
import {
  buildCanonicalTokenSamples,
  projectTokenSamples,
  tokenChartMax,
} from "./trace-tokens.js";
import { createTraceRenderCoordinator } from "./trace-render-coordinator.js";
import { buildTraceContentInspector } from "./trace-content.js";

const transportTraceRenderCoordinator = createTraceRenderCoordinator({
  render: () => renderTrace(),
});
let tracePointerHandlersInstalled = false;

/** Request a structural trace render without interrupting an active click. */
export function requestTransportTraceRender() {
  transportTraceRenderCoordinator.requestRender();
}

/** Render trace. */
export function renderTrace() {
  installTracePointerHandlers();
  rememberActiveTraceScrollPosition();
  const visibleTraceEvents = normalizeTraceEvents(state.traceEvents);

  elements.hdsTraceList.innerHTML = "";
  if (!state.hdsNodes.length) {
    elements.hdsTraceList.innerHTML = '<div class="hds-trace-empty">No configured HDS nodes.</div>';
    return;
  }

  const availablePaths = new Set(
    state.hdsNodes.map((node) => node.path.join("/")),
  );
  if (!state.activeTraceHdsPath || !availablePaths.has(state.activeTraceHdsPath)) {
    state.activeTraceHdsPath = state.hdsNodes[0].path.join("/");
  }
  const selectedNode = state.hdsNodes.find(
    (node) => node.path.join("/") === state.activeTraceHdsPath,
  );
  const selector = buildHdsTraceSelector();
  const selectedEvents = visibleTraceEvents.filter(
    (event) => (event.hds_node_path || []).join("/") === state.activeTraceHdsPath,
  );
  const card = buildHdsTraceCard(selectedNode);
  elements.hdsTraceList.append(selector, card.element);
  renderHdsTrace({
    svg: card.svg,
    legend: card.legend,
    empty: card.empty,
    events: selectedEvents,
    hdsKey: state.activeTraceHdsPath,
    hdsDepth: Math.max(0, selectedNode.path.length - 1),
  });
  restoreActiveTraceScrollPosition(card.scroll);

  if (!selectedEvents.length) {
    elements.traceDetail.innerHTML = "<h3>Node Detail</h3><p>The trace will appear here when the session produces SSE events.</p>";
    return;
  }

  if (!state.expandedTraceGroups) {
    state.expandedTraceGroups = new Set();
  }
  if (!state.collapsedTraceGroups) {
    state.collapsedTraceGroups = new Set();
  }

  if (!state.traceGlobalClickInstalled) {
    window.addEventListener("click", (e) => {
      if (elements.rawChatBox && elements.rawChatBox.contains(e.target)) {
        return;
      }
      // No longer clear expandedTraceGroups here to keep groups open
    });
    state.traceGlobalClickInstalled = true;
  }

  const activeEventIsVisible = selectedEvents.some(
    (event) => event.sequence === state.activeTraceSequence,
  );
  if (!activeEventIsVisible) {
    state.activeTraceSequence = selectedEvents[selectedEvents.length - 1].sequence;
    renderTraceDetail(selectedEvents[selectedEvents.length - 1]);
  } else {
    renderTraceDetail(
      selectedEvents.find((event) => event.sequence === state.activeTraceSequence),
    );
  }
}

/** Keep transport renders from replacing a target between pointerdown and click. */
function installTracePointerHandlers() {
  if (tracePointerHandlersInstalled || !elements.hdsTraceList) {
    return;
  }
  elements.hdsTraceList.addEventListener("pointerdown", () => {
    transportTraceRenderCoordinator.beginInteraction();
  });
  document.addEventListener("pointerup", () => {
    transportTraceRenderCoordinator.endInteraction();
  });
  document.addEventListener("pointercancel", () => {
    transportTraceRenderCoordinator.endInteraction();
  });
  tracePointerHandlersInstalled = true;
}

/**
 * Build the HDS trace switcher shown above the active chart.
 */
function buildHdsTraceSelector() {
  const selector = document.createElement("nav");
  selector.className = "hds-trace-selector";
  selector.setAttribute("aria-label", "HDS trace selector");

  for (const hdsNode of state.hdsNodes) {
    const hdsPath = hdsNode.path.join("/");
    const button = document.createElement("button");
    button.type = "button";
    button.className = "hds-trace-button";
    button.dataset.hdsPath = hdsPath;
    button.textContent = hdsNode.name;
    const isActive = hdsPath === state.activeTraceHdsPath;
    button.classList.toggle("is-active", isActive);
    button.setAttribute("aria-pressed", String(isActive));
    button.addEventListener("click", () => {
      state.activeTraceHdsPath = hdsPath;
      state.activeTraceSequence = null;
      renderTrace();
    });
    selector.appendChild(button);
  }
  return selector;
}

/**
 * Build one trace card for a configured HDS node.
 */
function buildHdsTraceCard(hdsNode) {
  const element = document.createElement("section");
  element.className = "hds-trace-card";
  element.dataset.hdsPath = hdsNode.path.join("/");

  const head = document.createElement("div");
  head.className = "hds-trace-card-head";
  const title = document.createElement("h3");
  title.textContent = hdsNode.name;
  const parent = document.createElement("p");
  const capability = hdsNode.hds_name && hdsNode.hds_name !== hdsNode.name
    ? ` · Capability: ${hdsNode.hds_name}`
    : "";
  parent.textContent = `${hdsNode.parent ? `Parent: ${hdsNode.parent}` : "Root HDS"}${capability}`;
  head.append(title, parent);

  const legend = document.createElement("div");
  legend.className = "trace-legend";
  const empty = document.createElement("div");
  empty.className = "hds-trace-empty";
  empty.textContent = "No trace events for this HDS yet.";

  const scroll = document.createElement("div");
  scroll.className = "trace-scroll";
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.classList.add("hds-trace-svg");
  svg.setAttribute("viewBox", "0 0 0 220");
  svg.setAttribute("preserveAspectRatio", "xMinYMid meet");
  scroll.appendChild(svg);
  element.append(head, legend, empty, scroll);
  return { element, legend, empty, scroll, svg };
}

/**
 * Save the current horizontal position before the active trace DOM is replaced.
 */
function rememberActiveTraceScrollPosition() {
  const activeCard = elements.hdsTraceList.querySelector(".hds-trace-card");
  const activeScroll = activeCard?.querySelector(".trace-scroll");
  const hdsPath = activeCard?.dataset.hdsPath;
  if (!activeScroll || !hdsPath) {
    return;
  }
  const hasHorizontalOverflow = activeScroll.scrollWidth > activeScroll.clientWidth + 5;
  const isPinned = hasHorizontalOverflow
    && activeScroll.scrollWidth - activeScroll.scrollLeft - activeScroll.clientWidth <= 5;
  state.traceScrollPinnedByHdsPath.set(hdsPath, isPinned);
  state.traceScrollLeftByHdsPath.set(hdsPath, activeScroll.scrollLeft);
}

/**
 * Restore the saved horizontal position for the newly rendered active trace.
 */
function restoreActiveTraceScrollPosition(scroll) {
  const isPinned = state.traceScrollPinnedByHdsPath.get(state.activeTraceHdsPath);

  if (isPinned === true) {
    scroll.scrollLeft = scroll.scrollWidth;
  } else {
    const savedScrollLeft = state.traceScrollLeftByHdsPath.get(state.activeTraceHdsPath);
    if (savedScrollLeft !== undefined) {
      scroll.scrollLeft = savedScrollLeft;
    }
  }
}

/**
 * Render one HDS-local projection using the shared trace algorithm.
 */
function renderHdsTrace({ svg, legend, empty, events, hdsKey, hdsDepth }) {
  svg.innerHTML = "";
  renderTraceLegend(legend, events);
  empty.hidden = events.length > 0;
  svg.parentElement.hidden = events.length === 0;
  if (!events.length) {
    return;
  }

  const spans = buildTraceSpans({ events, hdsKey });
  const projection = projectTraceEvents({
    events,
    spans,
    expandedSpanIds: state.expandedTraceGroups,
  });
  const layout = layoutTraceProjection({ events, projection, spans, hdsDepth });
  const { points, width, height } = layout;
  svg.setAttribute("width", String(width));
  svg.setAttribute("height", String(height));
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);

  const tokenChartPoints = projectTokenSamples({
    samples: buildCanonicalTokenSamples(events),
    points,
  });
  if (tokenChartPoints.length) {
    const maxTokens = tokenChartMax(tokenChartPoints);
    if (maxTokens !== null) {
      const chartGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
      chartGroup.setAttribute("class", "token-chart-bg");
      const knownTokenPoints = tokenChartPoints.filter((point) => point.tokens !== null);
      let visibleTokenPoints = knownTokenPoints;

      visibleTokenPoints = [
        { ...visibleTokenPoints[0], x: visibleTokenPoints[0].x - 30 },
        ...visibleTokenPoints,
        { ...visibleTokenPoints[visibleTokenPoints.length - 1], x: visibleTokenPoints[visibleTokenPoints.length - 1].x + 70 }
      ];

      const chartBottom = height - 20;
      const maxGraphHeight = 90;

      const d = buildTokenAreaPath({
        points: tokenChartPoints,
        chartBottom,
        maxGraphHeight,
        maxTokens,
      });

      const areaPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
      areaPath.setAttribute("d", d);
      areaPath.setAttribute("fill", "var(--accent-soft)");
      areaPath.setAttribute("stroke", "var(--accent)");
      areaPath.setAttribute("stroke-width", "2");
      areaPath.setAttribute("stroke-opacity", "0.8");
      areaPath.setAttribute("pointer-events", "none");
      areaPath.dataset.tokenMax = String(maxTokens);
      areaPath.dataset.tokenValues = tokenChartPoints
        .map((p) => p.tokens === null ? "gap" : String(p.tokens))
        .join(",");
      areaPath.dataset.tokenSource = "assistant-response-payload";
      areaPath.style.filter = "drop-shadow(0px 0px 5px var(--accent))";

      chartGroup.appendChild(areaPath);

      for (const gap of tokenChartPoints.filter((point) => point.isGap)) {
        const marker = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        marker.setAttribute("class", "token-gap-marker");
        marker.setAttribute("cx", String(gap.x));
        marker.setAttribute("cy", String(chartBottom));
        marker.setAttribute("r", "3");
        marker.setAttribute("fill", "none");
        marker.setAttribute("stroke", "var(--accent)");
        marker.setAttribute("stroke-dasharray", "2 1");
        chartGroup.appendChild(marker);
      }

      const axisGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
      axisGroup.setAttribute("class", "token-axis");

      const axisLine = document.createElementNS("http://www.w3.org/2000/svg", "line");
      axisLine.setAttribute("x1", "40");
      axisLine.setAttribute("y1", String(chartBottom));
      axisLine.setAttribute("x2", "40");
      axisLine.setAttribute("y2", String(chartBottom - maxGraphHeight));
      axisLine.setAttribute("stroke", "var(--text-dim)");
      axisLine.setAttribute("stroke-width", "1");
      axisGroup.appendChild(axisLine);

      const tickCounts = [0, maxTokens / 2, maxTokens];
      for (const tickVal of tickCounts) {
        const tickY = chartBottom - ((tickVal / maxTokens) * maxGraphHeight);
        const tick = document.createElementNS("http://www.w3.org/2000/svg", "line");
        tick.setAttribute("x1", "35");
        tick.setAttribute("y1", String(tickY));
        tick.setAttribute("x2", "40");
        tick.setAttribute("y2", String(tickY));
        tick.setAttribute("stroke", "var(--text-dim)");
        tick.setAttribute("stroke-width", "1");

        const tickLabel = document.createElementNS("http://www.w3.org/2000/svg", "text");
        tickLabel.setAttribute("x", "32");
        tickLabel.setAttribute("y", String(tickY + 3));
        tickLabel.setAttribute("font-size", "9");
        tickLabel.setAttribute("fill", "var(--text-dim)");
        tickLabel.setAttribute("text-anchor", "end");
        let labelText = Math.round(tickVal).toString();
        if (tickVal >= 1000000) labelText = (tickVal / 1000000).toFixed(1) + 'M';
        else if (tickVal >= 1000) labelText = (tickVal / 1000).toFixed(1) + 'k';
        tickLabel.textContent = labelText;

        axisGroup.appendChild(tick);
        axisGroup.appendChild(tickLabel);
      }

      const lastVal = visibleTokenPoints[visibleTokenPoints.length - 1].tokens;
      const lastValY = chartBottom - ((lastVal / maxTokens) * maxGraphHeight);

      const lastValCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      lastValCircle.setAttribute("cx", "40");
      lastValCircle.setAttribute("cy", String(lastValY));
      lastValCircle.setAttribute("r", "3");
      lastValCircle.setAttribute("fill", "#ff9800");

      axisGroup.appendChild(lastValCircle);
      chartGroup.appendChild(axisGroup);

      const interactiveGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
      interactiveGroup.style.display = "none";
      interactiveGroup.style.pointerEvents = "none";

      const hoverCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      hoverCircle.setAttribute("cy", String(chartBottom));
      hoverCircle.setAttribute("r", "5");
      hoverCircle.setAttribute("fill", "#ff9800");

      const hoverTextGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");

      const hoverTextBg = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      hoverTextBg.setAttribute("fill", "var(--panel-strong)");
      hoverTextBg.setAttribute("rx", "4");

      const hoverText = document.createElementNS("http://www.w3.org/2000/svg", "text");
      hoverText.setAttribute("font-size", "10");
      hoverText.setAttribute("fill", "var(--text)");
      hoverText.setAttribute("text-anchor", "middle");

      hoverTextGroup.appendChild(hoverTextBg);
      hoverTextGroup.appendChild(hoverText);

      interactiveGroup.appendChild(hoverCircle);
      interactiveGroup.appendChild(hoverTextGroup);

      chartGroup.appendChild(interactiveGroup);

      svg.addEventListener("mousemove", (e) => {
        const pt = svg.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        const svgP = pt.matrixTransform(svg.getScreenCTM().inverse());
        const mouseX = svgP.x;

        if (mouseX >= visibleTokenPoints[0].x - 20 && mouseX <= visibleTokenPoints[visibleTokenPoints.length - 1].x) {
          interactiveGroup.style.display = "";

          let tokensAtX = 0;
          if (mouseX <= visibleTokenPoints[0].x) {
            tokensAtX = visibleTokenPoints[0].tokens;
          } else if (mouseX >= visibleTokenPoints[visibleTokenPoints.length - 1].x) {
            tokensAtX = visibleTokenPoints[visibleTokenPoints.length - 1].tokens;
          } else {
            for (let i = 0; i < visibleTokenPoints.length - 1; i++) {
              const p1 = visibleTokenPoints[i];
              const p2 = visibleTokenPoints[i + 1];
              if (mouseX >= p1.x && mouseX <= p2.x) {
                if (p2.x === p1.x) {
                  tokensAtX = p2.tokens;
                } else {
                  const dist1 = Math.abs(mouseX - p1.x);
                  const dist2 = Math.abs(mouseX - p2.x);
                  tokensAtX = dist1 < dist2 ? p1.tokens : p2.tokens;
                }
                break;
              }
            }
          }

          let clampedX = Math.max(visibleTokenPoints[0].x, Math.min(mouseX, visibleTokenPoints[visibleTokenPoints.length - 1].x));
          hoverCircle.setAttribute("cx", String(clampedX));

          let labelText = Math.round(tokensAtX).toString();
          if (tokensAtX >= 1000000) labelText = (tokensAtX / 1000000).toFixed(1) + "M";
          else if (tokensAtX >= 1000) labelText = (tokensAtX / 1000).toFixed(1) + "k";

          hoverText.textContent = labelText;
          hoverText.setAttribute("x", String(mouseX));
          hoverText.setAttribute("y", String(chartBottom - 12));

          const textWidth = labelText.length * 6 + 8;
          hoverTextBg.setAttribute("x", String(mouseX - textWidth / 2));
          hoverTextBg.setAttribute("y", String(chartBottom - 22));
          hoverTextBg.setAttribute("width", String(textWidth));
          hoverTextBg.setAttribute("height", "14");

        } else {
          interactiveGroup.style.display = "none";
        }
      });

      svg.addEventListener("mouseleave", () => {
        interactiveGroup.style.display = "none";
      });

      svg.appendChild(chartGroup);
    }
  }
  for (let index = 1; index < points.length; index += 1) {
    const previousPoint = points[index - 1];
    const currentPoint = points[index];
    if (currentPoint.event.payload?.history_reset === true) {
      continue;
    }
    const segment = document.createElementNS("http://www.w3.org/2000/svg", "line");
    segment.setAttribute("x1", String(previousPoint.x));
    segment.setAttribute("y1", String(previousPoint.y));
    segment.setAttribute("x2", String(currentPoint.x));
    segment.setAttribute("y2", String(currentPoint.y));
    segment.setAttribute("stroke", "var(--trace-line)");
    segment.setAttribute("stroke-width", "10");
    segment.setAttribute("stroke-linecap", "round");
    segment.setAttribute("opacity", "0.01");
    segment.classList.add("trace-segment-hitbox");
    segment.addEventListener("click", (e) => {
      e.stopPropagation();
      state.activeTraceSequence = currentPoint.event.sequence;
      renderTraceDetail(currentPoint.event);
      setRawChatFilter({
        upToSequence: currentPoint.event.sequence,
        label: `Chat grezza fino a ${traceLabel(currentPoint.event)} #${currentPoint.event.sequence}`,
      });
      if (currentPoint.isMerged) {
        state.expandedTraceGroups.add(currentPoint.pairId);
        state.collapsedTraceGroups.delete(currentPoint.pairId);
      }
      renderTrace();
    });
    svg.appendChild(segment);

    const visibleSegment = document.createElementNS("http://www.w3.org/2000/svg", "line");
    visibleSegment.setAttribute("x1", String(previousPoint.x));
    visibleSegment.setAttribute("y1", String(previousPoint.y));
    visibleSegment.setAttribute("x2", String(currentPoint.x));
    visibleSegment.setAttribute("y2", String(currentPoint.y));
    visibleSegment.setAttribute("stroke", "var(--trace-line)");
    visibleSegment.setAttribute("stroke-width", "3");
    visibleSegment.setAttribute("stroke-linecap", "round");
    visibleSegment.setAttribute("pointer-events", "none");
    visibleSegment.classList.add("trace-segment-visible");
    svg.appendChild(visibleSegment);
  }

  for (const point of points) {
    const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
    const isActive = state.activeTraceSequence === point.event.sequence;
    group.setAttribute("class", `trace-node${isActive ? " is-active" : ""}`);
    group.setAttribute("pointer-events", "bounding-box");

    const shape = createTraceShape(point);
    if (point.isMerged) {
      shape.setAttribute("stroke-width", "2");
    }

    const label = createTraceLabel({
      x: point.x,
      y: point.y - point.radius - 10,
      content: traceLabel(point.event),
    });

    group.append(shape, label);
    group.addEventListener("click", (e) => {
      e.stopPropagation();
      state.activeTraceSequence = point.event.sequence;
      renderTraceDetail(point.event);
      setRawChatFilter({
        upToSequence: point.event.sequence,
        label: `Chat grezza fino a ${traceLabel(point.event)} #${point.event.sequence}`,
      });

      if (point.isMerged) {
        state.expandedTraceGroups.add(point.pairId);
        state.collapsedTraceGroups.delete(point.pairId);
      }
      renderTrace();
    });

    svg.appendChild(group);

    if (point.isExpandedStart) {
      const collapseBtn = document.createElementNS("http://www.w3.org/2000/svg", "g");
      collapseBtn.setAttribute("class", "collapse-btn");
      collapseBtn.dataset.traceLabel = traceLabel(point.event);
      collapseBtn.style.cursor = "pointer";
      const collapseOffset = 12;

      const btnCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      btnCircle.setAttribute("cx", String(point.x));
      btnCircle.setAttribute("cy", String(point.y + point.radius + collapseOffset));
      btnCircle.setAttribute("r", "6");
      btnCircle.setAttribute("fill", "#ea4335");

      const btnText = document.createElementNS("http://www.w3.org/2000/svg", "text");
      btnText.setAttribute("x", String(point.x));
      btnText.setAttribute("y", String(point.y + point.radius + collapseOffset + 3));
      btnText.setAttribute("text-anchor", "middle");
      btnText.setAttribute("font-size", "10");
      btnText.setAttribute("fill", "white");
      btnText.setAttribute("font-weight", "bold");
      btnText.textContent = "-";

      collapseBtn.append(btnCircle, btnText);
      collapseBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        state.expandedTraceGroups.delete(point.expandedPairId);
        state.collapsedTraceGroups.add(point.expandedPairId);
        renderTrace();
      });

      svg.appendChild(collapseBtn);
    }
  }

}

/**
 * Build closed SVG areas and break the curve at unknown requests.
 */
function buildTokenAreaPath({ points, chartBottom, maxGraphHeight, maxTokens }) {
  const paths = [];
  let segment = [];
  const closeSegment = () => {
    if (!segment.length) {
      return;
    }
    const visibleSegment = [
      { ...segment[0], x: segment[0].x - 30 },
      ...segment,
      { ...segment[segment.length - 1], x: segment[segment.length - 1].x + 70 }
    ];
    let path = `M ${visibleSegment[0].x} ${chartBottom}`;
    for (const point of visibleSegment) {
      const y = chartBottom - ((point.tokens / maxTokens) * maxGraphHeight);
      path += ` L ${point.x} ${y}`;
    }
    path += ` L ${visibleSegment.at(-1).x} ${chartBottom} Z`;
    paths.push(path);
    segment = [];
  };
  for (const point of points) {
    if (point.tokens === null) {
      closeSegment();
    } else {
      segment.push(point);
    }
  }
  closeSegment();
  return paths.join(" ");
}

/**
 * Create one consistently styled SVG label for a trace node.
 */
function createTraceLabel({ x, y, content }) {
  const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
  label.setAttribute("x", String(x));
  label.setAttribute("y", String(y));
  label.setAttribute("text-anchor", "middle");
  label.setAttribute("font-size", "11");
  label.setAttribute("fill", "var(--muted)");
  label.textContent = content;
  return label;
}

/**
 * Create the marker shape for one trace point.
 */
function createTraceShape(point) {
  if (point.event.payload?.kind === "hds-child-delegation") {
    const triangle = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
    const halfWidth = point.radius * 0.92;
    const top = point.y - point.radius;
    const bottom = point.y + point.radius * 0.72;
    triangle.setAttribute(
      "points",
      `${point.x},${top} ${point.x - halfWidth},${bottom} ${point.x + halfWidth},${bottom}`,
    );
    triangle.setAttribute("fill", traceColor(point.event));
    triangle.setAttribute("stroke", "var(--text)");
    triangle.dataset.shape = "hds-delegation";
    return triangle;
  }
  const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
  circle.setAttribute("cx", String(point.x));
  circle.setAttribute("cy", String(point.y));
  circle.setAttribute("r", String(point.radius));
  circle.setAttribute("fill", traceColor(point.event));
  circle.setAttribute("stroke", "var(--text)");
  return circle;
}

/**
 * Resolve the rendered color for one runtime or projected trace event.
 */
function traceColor(event) {
  return getDynamicColor(traceColorKey(event));
}

/**
 * Resolve the primary label shown above one trace node.
 */
function traceLabel(event) {
  if (event.tool_name) {
    return event.tool_name;
  }
  return event.event_type;
}

/** Render trace detail. */
function renderTraceDetail(event) {
  elements.traceDetail.innerHTML = "";
  if (!event) {
    return;
  }

  const title = document.createElement("h3");
  title.textContent = `${event.event_type} #${event.sequence}`;

  const summary = document.createElement("p");
  const levelPath = event.level_path?.length ? `/${event.level_path.join("/")}` : "/";
  summary.textContent = [
    `path: ${levelPath}`,
    event.current_skill ? `skill: ${event.current_skill}` : "skill: root",
    event.tool_name ? `tool/skill: ${event.tool_name}` : null,
    event.tool_call_id ? `tool_call_id: ${event.tool_call_id}` : null,
  ].filter(Boolean).join(" • ");

  const switcher = document.createElement("div");
  switcher.className = "trace-detail-switch";
  switcher.append(
    traceDetailModeButton("Content", "content", event),
    traceDetailModeButton("Thinking", "thinking", event),
  );

  const content = state.traceDetailMode === "thinking"
    ? renderTraceThinkingDetail(event)
    : renderTraceContentDetail(event);

  elements.traceDetail.append(title, summary, switcher, content);
}

/** Refresh only the selected Thinking detail without rebuilding the trace DOM. */
export function refreshSelectedTraceThinkingDetail() {
  if (state.traceDetailMode !== "thinking" || state.activeTraceSequence === null) {
    return;
  }
  const selectedEvent = state.traceEvents.find(
    (event) => event.sequence === state.activeTraceSequence,
  );
  if (selectedEvent) {
    renderTraceDetail(selectedEvent);
  }
}

/** Trace detail mode button. */
function traceDetailModeButton(label, mode, event) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "trace-detail-mode-button";
  button.textContent = label;
  const isActive = state.traceDetailMode === mode;
  button.classList.toggle("is-active", isActive);
  button.setAttribute("aria-pressed", String(isActive));
  button.addEventListener("click", () => {
    state.traceDetailMode = mode;
    renderTraceDetail(event);
  });
  return button;
}

/** Render trace content detail. */
function renderTraceContentDetail(event) {
  return buildTraceContentInspector({
    event,
    expansionState: traceContentExpansionState(event.sequence),
  });
}

/**
 * Return the persistent inspector expansion map for one selected Trace event.
 */
function traceContentExpansionState(sequence) {
  if (!state.traceContentExpansionBySequence) {
    state.traceContentExpansionBySequence = new Map();
  }
  if (!state.traceContentExpansionBySequence.has(sequence)) {
    state.traceContentExpansionBySequence.set(sequence, new Map());
  }
  return state.traceContentExpansionBySequence.get(sequence);
}

/** Render trace thinking detail. */
function renderTraceThinkingDetail(event) {
  const requestId = event?.payload?.model_request_id;
  const thinking = requestId ? state.thinkingByRequestId.get(requestId) : null;
  if (!thinking || !thinking.content.trim()) {
    const empty = document.createElement("p");
    empty.className = "trace-thinking-empty";
    empty.textContent = "No thinking stream is associated with this trace event.";
    return empty;
  }
  const content = document.createElement("pre");
  content.className = "trace-thinking-content";
  content.textContent = thinking.status === "error" && thinking.error
    ? `${thinking.content}\n\n[Thinking stream ended with error: ${thinking.error}]`
    : thinking.content;
  return content;
}

/** Render raw chat. */
export function renderRawChat() {
  const filteredMessages = filterRawChatMessages();
  elements.rawChatDump.textContent = JSON.stringify(filteredMessages, null, 2);
  if (state.rawChatFilterSequence !== null) {
    elements.rawChatBox.open = true;
  }
}

/** Filter raw chat messages. */
function filterRawChatMessages() {
  return state.rawChatMessages;
}

/** Set raw chat filter. */
function setRawChatFilter({ upToSequence, label }) {
  const selectedEvent = state.traceEvents.find(
    (event) => event.sequence === upToSequence,
  );
  document.dispatchEvent(new CustomEvent("agentwiki:load-history", {
    detail: {
      stepId: selectedEvent?.step_id || null,
      eventSequence: selectedEvent?.sequence || null,
      label,
    },
  }));
}

/** Get dynamic color. */
function getDynamicColor(key) {
  if (!state.toolColorMap.has(key)) {
    const t = (state.toolColorMap.size * 0.618033988749895) % 1;
    const color = typeof d3 !== "undefined" ? d3.interpolateRainbow(t) : `hsl(${Math.round(t * 360)}, 70%, 50%)`;
    state.toolColorMap.set(key, color);
  }
  return state.toolColorMap.get(key);
}

/**
 * Return the stable palette key used by a runtime or projected trace event.
 */
function traceColorKey(event) {
  if ((event.event_type === "tool_call" || event.event_type === "tool_result") && event.tool_name) {
    return `tool:${event.tool_name}`;
  }
  if (event.event_type === "skill_enter" || event.event_type === "skill_exit") {
    return `skill:${event.event_type}`;
  }
  return `event:${event.event_type}`;
}

/**
 * Rebuild the deterministic trace palette from the current runtime events.
 */
export function rebuildToolColorMap() {
  const nextMap = new Map();
  let count = 0;
  for (const event of state.traceEvents) {
    const key = traceColorKey(event);

    if (!nextMap.has(key)) {
      const t = (count * 0.618033988749895) % 1;
      const color = typeof d3 !== "undefined" ? d3.interpolateRainbow(t) : `hsl(${Math.round(t * 360)}, 70%, 50%)`;
      nextMap.set(key, color);
      count++;
    }
  }
  state.toolColorMap = nextMap;
}

/**
 * Render the unique color keys used by the visible HDS trace.
 */
function renderTraceLegend(container, events) {
  container.innerHTML = "";
  const eventKeys = [...new Set(events.map((event) => traceColorKey(event)))];

  if (!eventKeys.length) {
    container.innerHTML = '<div class="trace-legend-item">No trace events available.</div>';
    return;
  }

  for (const key of eventKeys) {
    const item = document.createElement("div");
    item.className = "trace-legend-item";

    const swatch = document.createElement("span");
    swatch.className = "trace-legend-swatch";
    swatch.style.background = getDynamicColor(key);

    const label = document.createElement("span");
    label.textContent = key.replace(/^(tool|skill|event):/, "");

    item.append(swatch, label);
    container.appendChild(item);
  }
}
