/**
 * Pair completed runtime spans without changing the canonical event sequence.
 */
export function buildTraceSpans({ events, hdsKey }) {
  const startsBySpanId = new Map();
  const spans = [];
  for (const event of events) {
    if (event.phase === "start" && event.span_id) {
      startsBySpanId.set(event.span_id, event);
      continue;
    }
    if (event.phase !== "end" || !event.span_id) {
      continue;
    }
    const start = startsBySpanId.get(event.span_id);
    if (!start) {
      continue;
    }
    spans.push(Object.freeze({
      id: `${hdsKey}:${event.span_id}`,
      spanId: event.span_id,
      start,
      end: event,
      startSequence: start.sequence,
      endSequence: event.sequence,
    }));
  }
  return Object.freeze(spans);
}

/**
 * Project canonical events through the current fold state without deleting data.
 */
export function projectTraceEvents({ events, spans, expandedSpanIds }) {
  const spansByStart = new Map(spans.map((span) => [span.startSequence, span]));
  const collapsedSpans = spans.filter((span) => !expandedSpanIds.has(span.id));
  const projected = [];

  for (const event of events) {
    const enclosingCollapsedSpan = collapsedSpans.find(
      (span) => event.sequence > span.startSequence
        && event.sequence <= span.endSequence,
    );
    if (enclosingCollapsedSpan) {
      continue;
    }

    const startingSpan = spansByStart.get(event.sequence);
    if (startingSpan && !expandedSpanIds.has(startingSpan.id)) {
      projected.push(Object.freeze({
        event,
        span: startingSpan,
        isMerged: true,
        pairId: startingSpan.id,
        expandedPairId: null,
      }));
      continue;
    }

    projected.push(Object.freeze({
      event,
      span: startingSpan || null,
      isMerged: false,
      pairId: startingSpan?.id || null,
      expandedPairId: startingSpan?.id || null,
    }));
  }
  return Object.freeze(projected);
}
