/**
 * Return whether one event is only the synthetic tool wrapper for a deep skill.
 */
export function isSkillToolWrapperEvent(event) {
  if (event.operation !== "tool") {
    return false;
  }
  if (event.payload?.kind === "deep-skill") {
    return true;
  }
  return event.event_type === "tool_call"
    && event.capabilities?.skills?.includes(event.tool_name);
}

/**
 * Build the immutable canonical event sequence consumed by every trace projection.
 */
export function normalizeTraceEvents(events) {
  return events
    .filter((event) => !isSkillToolWrapperEvent(event))
    .map((event) => Object.freeze({
      ...event,
      payload: Object.freeze({ ...(event.payload || {}) }),
    }))
    .sort((left, right) => left.sequence - right.sequence);
}
