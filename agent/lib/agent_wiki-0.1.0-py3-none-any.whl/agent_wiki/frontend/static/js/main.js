import { elements, refreshElements, state } from "./core/state.js";
import { initializeTheme } from "./core/theme.js";
import {
  renderCapabilityListDialog,
  renderCapabilityLists,
  renderHdsControls,
  renderInteractionDetailsDialog,
} from "./renderers.js";
import {
  connectSession,
  disconnectSession,
  handleSubmit,
  initializeSession,
  loadHistoryForStep,
  loadBootstrap,
  refreshSessionState,
  respondToInteraction,
  selectHds,
  stopAgent,
  toggleCapability,
  toggleThinkingMode,
} from "./session-runtime.js";

document.addEventListener("DOMContentLoaded", async () => {
  refreshElements();
  initializeTheme({ state, elements });
  await loadBootstrap();
  bindEvents();
  await initializeSession();
});

function bindEvents() {
  elements.settingsButton.addEventListener("click", () => showDialog(elements.settingsDialog));
  elements.connectionToggleButton.addEventListener("click", handleConnectionToggle);
  elements.thinkingToggleButton.addEventListener("click", toggleThinkingMode);
  elements.closeSettingsButton.addEventListener("click", () => closeDialog(elements.settingsDialog));
  elements.settingsForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (state.isConnected) {
      await initializeSession();
    }
    closeDialog(elements.settingsDialog);
  });
  elements.chatForm.addEventListener("submit", handleSubmit);
  elements.chatInput.addEventListener("keydown", handleChatInputKeyDown);
  elements.chatInput.addEventListener("keyup", handleChatInputKeyUp);
  elements.chatInput.addEventListener("blur", () => state.pressedKeys.clear());
  elements.chatInput.addEventListener("input", function() {
    this.style.height = "auto";
    this.style.height = this.scrollHeight + "px";
  });
  elements.settingsDialog.addEventListener("cancel", (event) => {
    event.preventDefault();
    closeDialog(elements.settingsDialog);
  });
  elements.closeCapabilityListButton.addEventListener("click", () => closeDialog(elements.capabilityListDialog));
  elements.capabilityListDialog.addEventListener("cancel", (event) => {
    event.preventDefault();
    closeDialog(elements.capabilityListDialog);
  });
  if (elements.stopAgentButton) {
    elements.stopAgentButton.addEventListener("click", stopAgent);
  }
  document.addEventListener("agentwiki:toggle-capability", (event) => {
    toggleCapability(event.detail);
    renderCapabilityLists();
    renderHdsControls();
  });
  document.addEventListener("agentwiki:select-hds", async (event) => {
    await selectHds(event.detail);
    renderCapabilityLists();
    renderHdsControls();
  });
  document.addEventListener("agentwiki:show-capability-details", (event) => {
    renderCapabilityListDialog(event.detail?.name || null);
    showDialog(elements.capabilityListDialog);
  });
  document.addEventListener("agentwiki:load-history", async (event) => {
    await loadHistoryForStep(event.detail || {});
  });
  document.addEventListener("agentwiki:respond-interaction", async (event) => {
    await respondToInteraction(event.detail || {});
  });
  document.addEventListener("agentwiki:show-interaction-details", (event) => {
    renderInteractionDetailsDialog(event.detail?.interaction || {});
    showDialog(elements.interactionDetailsDialog);
  });
  window.addEventListener("focus", async () => {
    if (state.isConnected && state.sessionId && !state.eventSource) {
      await refreshSessionState();
    }
  });

  elements.closeErrorButton.addEventListener("click", () => closeDialog(elements.errorDialog));
  elements.errorDialog.addEventListener("cancel", (event) => {
    event.preventDefault();
    closeDialog(elements.errorDialog);
  });
  elements.closeInteractionDetailsButton.addEventListener("click", () => {
    closeDialog(elements.interactionDetailsDialog);
  });
  elements.interactionDetailsDialog.addEventListener("cancel", (event) => {
    event.preventDefault();
    closeDialog(elements.interactionDetailsDialog);
  });

  window.showErrorPopup = (message) => {
    if (elements.errorDialogMessage) {
      elements.errorDialogMessage.textContent = message;
      showDialog(elements.errorDialog);
    } else {
      console.error(message);
    }
  };
}

async function handleConnectionToggle() {
  if (state.isConnected) {
    disconnectSession();
    return;
  }

  await connectSession();
}

function showDialog(dialog) {
  if (typeof dialog.showModal === "function") {
    dialog.showModal();
    return;
  }
  dialog.setAttribute("open", "open");
}

function closeDialog(dialog) {
  if (typeof dialog.close === "function") {
    dialog.close();
    return;
  }
  dialog.removeAttribute("open");
}

function handleChatInputKeyDown(event) {
  if (event.key === "Tab") {
    state.pressedKeys.add("Tab");
    event.preventDefault();
    return;
  }

  if (event.key === "Enter" && state.pressedKeys.has("Tab")) {
    event.preventDefault();
    elements.chatForm.requestSubmit();
  }
}

function handleChatInputKeyUp(event) {
  if (event.key === "Tab") {
    state.pressedKeys.delete("Tab");
  }
}
