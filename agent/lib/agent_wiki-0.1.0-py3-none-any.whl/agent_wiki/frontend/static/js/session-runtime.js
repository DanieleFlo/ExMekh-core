import { elements, state } from "./core/state.js";
import {
  rebuildToolColorMap,
  renderActivityFeed,
  renderCapabilityLists,
  renderChat,
  renderHdsControls,
  renderRawChat,
  refreshSelectedTraceThinkingDetail,
  requestTransportTraceRender,
  renderTokenUsageSummary,
  renderTrace,
  truncateText,
} from "./renderers.js";

const HDS_STORAGE_KEY = "agent-wiki-selected-hds";
const HDS_SESSIONS_STORAGE_KEY = "agent-wiki-hds-sessions";
const HDS_CAPABILITIES_STORAGE_KEY = "agent-wiki-hds-capabilities";
const PREFERRED_HDS_NAME = "bootstrap-wiki";

export async function loadBootstrap() {
  const response = await fetch("/api/bootstrap");
  state.bootstrap = await response.json();
  elements.backendName.textContent = state.bootstrap.backend || "-";
  elements.modelName.textContent = state.bootstrap.model || "-";
  elements.systemPrompt.value = state.bootstrap.default_system_prompt || "";
  applyInitialHdsSelection();
  renderCapabilityLists();
  renderHdsControls();
  renderActivityFeed();
  renderChat();
  renderTrace();
  updateConnectionUi();
}

export async function initializeSession() {
  if (!state.isConnected) {
    updateConnectionUi();
    return;
  }

  state.pendingSessionConfig = false;

  if (state.eventSource) {
    state.eventSource.close();
    state.eventSource = null;
  }

  elements.sessionStatus.textContent = "riavvio in corso";
  state.activityItems = [createActivityItem({ id: "session", kind: "system", label: "Avvio sessione", snippet: "Sto generando la HDS root.", status: "running" })];
  updateActivityStatusText("Preparazione");
  renderActivityFeed();

  const response = await fetch("/api/sessions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      system_prompt: elements.systemPrompt.value,
      selected_capabilities: Array.from(state.selectedCapabilities),
    }),
  });

  if (!response.ok) {
    const payload = await response.json();
    elements.sessionStatus.textContent = "errore";
    state.activityItems = [createActivityItem({ id: "session-error", kind: "system", label: "Errore sessione", snippet: payload.detail || "Impossibile inizializzare la sessione.", status: "error" })];
    updateActivityStatusText("Errore");
    renderActivityFeed();
    window.showErrorPopup(payload.detail || "Impossibile inizializzare la sessione.");
    return;
  }

  const sessionState = await response.json();
  applySessionState(sessionState);
  if (state.generatedHds && state.generatedHds.name) {
    state.hdsSessions[state.generatedHds.name] = state.sessionId;
  }
  
  if (state.isConnected) {
    openEventStream();
  }
  elements.chatInput.focus();
}

export async function handleSubmit(event) {
  event.preventDefault();
  if (!state.isConnected) {
    window.showErrorPopup("La connessione e' chiusa.");
    return;
  }
  if (!state.sessionId) {
    window.showErrorPopup("La sessione non e' disponibile.");
    return;
  }

  const message = elements.chatInput.value.trim();
  if (!message) {
    return;
  }

  if (!state.messageQueue) {
    state.messageQueue = [];
  }

  pushOptimisticUserMessage(message);
  elements.chatInput.value = "";
  elements.chatInput.focus();

  if (state.isSending || elements.sessionStatus.textContent === "running") {
    state.messageQueue.push(message);
    return;
  }

  await sendMessagePayload(message);
}

async function sendMessagePayload(message) {
  state.isSending = true;
  setThinkingActivity(message);

  const response = await fetch(`/api/sessions/${state.sessionId}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message }),
  });

  if (!response.ok) {
    const payload = await response.json();
    state.activityItems = [createActivityItem({ id: "turn-error", kind: "system", label: "Errore invio", snippet: payload.detail || payload.error || "Invio fallito.", status: "error" })];
    updateActivityStatusText("Errore");
    renderActivityFeed();
    window.showErrorPopup(payload.detail || payload.error || "Invio fallito.");
    state.isSending = false;
    await refreshSessionState();
  }
}

export async function refreshSessionState() {
  if (!state.sessionId) {
    return;
  }
  const response = await fetch(`/api/sessions/${state.sessionId}`);
  const sessionState = await response.json();
  applySessionState(sessionState);
}

export async function stopAgent() {
  if (!state.sessionId || !state.isConnected) {
    return;
  }
  elements.stopAgentButton.disabled = true;
  const response = await fetch(`/api/sessions/${state.sessionId}/stop`, {
    method: "POST",
  });
  if (!response.ok) {
    const payload = await response.json();
    elements.stopAgentButton.disabled = false;
    window.showErrorPopup(payload.detail || "Unable to stop the active turn.");
    await refreshSessionState();
    return;
  }
  elements.sessionStatus.textContent = "stopping";
  updateActivityStatusText("Stopping");
}
export async function toggleThinkingMode() {
  if (!state.isConnected || !state.sessionId) return;

  const newState = !state.thinkingEnabled;

  elements.thinkingToggleButton.disabled = true;
  try {
    const response = await fetch(`/api/sessions/${state.sessionId}/thinking`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ thinking_enabled: newState }),
    });

    if (!response.ok) {
      const payload = await response.json();
      window.showErrorPopup(payload.detail || "Impossibile aggiornare le impostazioni di thinking.");
      return;
    }

    state.thinkingEnabled = newState;
    elements.thinkingToggleButton.textContent = `Thinking: ${newState ? "ON" : "OFF"}`;
  } finally {
    elements.thinkingToggleButton.disabled = false;
  }
}

function openEventStream() {
  if (!state.isConnected || !state.sessionId) {
    return;
  }

  if (state.eventSource) {
    state.eventSource.close();
  }
  const eventUrl = `/api/sessions/${state.sessionId}/events?after_id=${state.lastEventId || 0}`;
  state.eventSource = new EventSource(eventUrl);
  state.eventSource.addEventListener("agent_event", (event) => {
    const envelope = JSON.parse(event.data);
    void applyTransportEvent(envelope);
  });
  state.eventSource.onerror = () => {
    elements.sessionStatus.textContent = state.sessionId ? "stream da riallineare" : "offline";
  };
}

function applySessionState(sessionState) {
  state.sessionId = sessionState.session_id;
  state.thinkingByRequestId = new Map();
  state.liveThinkingRequestId = null;
  state.traceEvents = (sessionState.trace_events || []).filter((runtimeEvent) => {
    if (isModelThinkingDelta(runtimeEvent)) {
      recordModelThinkingDelta(runtimeEvent);
      return false;
    }
    updateThinkingStatusFromTrace(runtimeEvent);
    return true;
  });
  if (sessionState.last_error && state.liveThinkingRequestId) {
    markThinkingFailed(state.liveThinkingRequestId, sessionState.last_error);
  }
  state.hdsNodes = sessionState.hds_nodes || [];
  state.activeTraceHdsPath = state.hdsNodes[0]?.path?.join("/") || null;
  state.chatMessages = sessionState.chat_messages || [];
  state.lastTurnTokenUsage = sessionState.last_turn_token_usage || null;
  state.sessionTokenUsage = sessionState.session_token_usage || null;
  const resolvedInteractions = state.interactions.filter((interaction) => (
    interaction.status?.startsWith("resolved:") || interaction.status === "cancelled"
  ));
  const pendingInteractions = (sessionState.pending_interactions || []).map((interaction) => ({
    ...interaction,
    status: "pending",
  }));
  const pendingIds = new Set(pendingInteractions.map((interaction) => interaction.id));
  state.interactions = [
    ...resolvedInteractions.filter((interaction) => !pendingIds.has(interaction.id)),
    ...pendingInteractions,
  ];
  state.rawChatMessages = sessionState.raw_chat_messages || [];
  state.lastEventId = sessionState.latest_event_id || 0;
  state.seenEventIds = new Set();
  state.generatedHds = sessionState.generated_hds || null;
  state.rawChatFilterSequence = null;
  state.rawChatFilterLabel = null;
  state.activeSkillSpans = new Set();
  elements.sessionStatus.textContent = state.isConnected
    ? sessionState.busy ? "running" : `attiva ${state.sessionId.slice(0, 8)}`
    : "disconnessa";
  if (elements.stopAgentButton) {
    elements.stopAgentButton.style.display = (state.isConnected && sessionState.busy) ? "" : "none";
    elements.stopAgentButton.disabled = false;
  }
  rebuildToolColorMap();
  renderTrace();
  renderChat();
  renderTokenUsageSummary();
  renderRawChat();
  renderHdsControls();
  updateConnectionUi();
  if (!sessionState.busy && state.activityItems.every((item) => item.status !== "error")) {
    state.activityItems = [];
    state.activeSkillContext = null;
    state.skillDepth = 0;
    state.liveThinkingRequestId = null;
    updateActivityStatusText("Pronto");
    renderActivityFeed();
  }
}

async function applyTransportEvent(envelope) {
  if (!envelope || typeof envelope.id !== "number") {
    return;
  }
  if (state.seenEventIds.has(envelope.id) || envelope.id <= state.lastEventId) {
    return;
  }
  state.seenEventIds.add(envelope.id);
  state.lastEventId = envelope.id;

  if (envelope.type === "runtime.event") {
    const runtimeEvent = envelope.data;
    if (isModelThinkingDelta(runtimeEvent)) {
      recordModelThinkingDelta(runtimeEvent);
      refreshSelectedTraceThinkingDetail();
      renderActivityFeed();
      return;
    }
    state.traceEvents.push(runtimeEvent);
    updateThinkingStatusFromTrace(runtimeEvent);
    updateActivitiesFromTrace(runtimeEvent);
    requestTransportTraceRender();
    renderActivityFeed();
    renderChat();
    return;
  }

  if (envelope.type === "session.interaction.requested") {
    const interaction = { ...envelope.data, status: "pending" };
    state.interactions = [
      ...state.interactions.filter((item) => item.id !== interaction.id),
      interaction,
    ];
    elements.sessionStatus.textContent = "waiting for input";
    renderChat();
    return;
  }

  if (envelope.type === "session.interaction.resolved") {
    updateInteractionStatus(
      envelope.data?.request_id,
      `resolved:${envelope.data?.action || "unknown"}`,
      { response: { ...envelope.data } },
    );
    renderChat();
    return;
  }

  if (envelope.type === "session.interaction.cancelled") {
    updateInteractionStatus(envelope.data?.request_id, "cancelled");
    renderChat();
    return;
  }

  if (envelope.type === "session.turn.started") {
    elements.sessionStatus.textContent = "running";
    if (elements.stopAgentButton) {
      elements.stopAgentButton.style.display = "";
      elements.stopAgentButton.disabled = false;
    }
    setThinkingActivity(envelope.data?.message || "The agent is processing.");
    return;
  }

  if (envelope.type === "session.turn.completed") {
    state.isSending = false;
    state.activityItems = [];
    state.streamingAssistantContent = null;
    state.streamingAssistantSequence = null;
    state.liveThinkingRequestId = null;
    clearActiveSkillPresentation();
    updateActivityStatusText("Pronto");
    renderActivityFeed();
    await refreshSessionState();
    if (state.messageQueue && state.messageQueue.length > 0) {
      const nextMsg = state.messageQueue.shift();
      await sendMessagePayload(nextMsg);
    }
    return;
  }

  if (envelope.type === "session.stop.requested") {
    elements.sessionStatus.textContent = "stopping";
    if (elements.stopAgentButton) {
      elements.stopAgentButton.disabled = true;
    }
    updateActivityStatusText("Stopping");
    return;
  }

  if (envelope.type === "session.turn.cancelled") {
    state.isSending = false;
    state.messageQueue = [];
    state.activityItems = [];
    state.streamingAssistantContent = null;
    state.streamingAssistantSequence = null;
    state.liveThinkingRequestId = null;
    updateActivityStatusText("Stopped");
    await refreshSessionState();
    return;
  }

  if (envelope.type === "session.turn.failed") {
    const error = envelope.data?.error || "Errore durante il turno.";
    elements.sessionStatus.textContent = "error";
    state.isSending = false;
    markThinkingFailed(envelope.data?.model_request_id, error);
    state.activityItems = [createActivityItem({ id: "turn-error", kind: "system", label: "Errore runtime", snippet: error, status: "error" })];
    updateActivityStatusText("Errore");
    renderActivityFeed();
    window.showErrorPopup(error);
    await refreshSessionState();
    return;
  }

  if (envelope.type === "session.resync_required") {
    await refreshSessionState();
  }
}

/** Clear transient nested-skill state after a turn has reached a terminal event. */
function clearActiveSkillPresentation() {
  state.activeSkillContext = null;
  state.activeSkillSpans.clear();
  state.skillDepth = 0;
}

/**
 * Return whether a runtime event is a streamed model thinking delta.
 */
function isModelThinkingDelta(event) {
  return event?.event_type === "model_thinking_delta";
}

/**
 * Record streamed model thinking without rendering it in the graphical trace.
 */
export function recordModelThinkingDelta(event) {
  const requestId = thinkingRequestId(event);
  const current = state.thinkingByRequestId.get(requestId) || {
    requestId,
    content: "",
    status: "running",
    sequenceStart: event?.sequence,
    sequenceEnd: event?.sequence,
    turnId: event?.turn_id || null,
    levelPath: event?.level_path || [],
    hdsNodePath: event?.hds_node_path || [],
  };
  current.content += event?.content || "";
  current.status = "running";
  current.sequenceEnd = event?.sequence;
  state.thinkingByRequestId.set(requestId, current);
  state.liveThinkingRequestId = requestId;
}

function thinkingRequestId(event) {
  const explicitId = event?.payload?.model_request_id;
  if (explicitId) {
    return explicitId;
  }
  const hdsPath = (event?.hds_node_path || []).join("/") || "root";
  const levelPath = (event?.level_path || []).join("/") || "root";
  return `${event?.turn_id || "unknown-turn"}:model:${hdsPath}:${levelPath}`;
}

function updateThinkingStatusFromTrace(event) {
  const requestId = event?.payload?.model_request_id;
  if (!requestId || !state.thinkingByRequestId.has(requestId)) {
    return;
  }
  const current = state.thinkingByRequestId.get(requestId);
  current.status = event.event_type === "assistant_response" ? "done" : current.status;
  current.resultSequence = event.sequence;
  state.thinkingByRequestId.set(requestId, current);
  if (state.liveThinkingRequestId === requestId && current.status === "done") {
    state.liveThinkingRequestId = null;
  }
}

function markThinkingFailed(requestId, error) {
  if (!requestId || !state.thinkingByRequestId.has(requestId)) {
    return;
  }
  const current = state.thinkingByRequestId.get(requestId);
  current.status = "error";
  current.error = error;
  state.thinkingByRequestId.set(requestId, current);
  if (state.liveThinkingRequestId === requestId) {
    state.liveThinkingRequestId = null;
  }
}

function updateInteractionStatus(requestId, status, patch = {}) {
  if (!requestId) {
    return;
  }
  state.interactions = state.interactions.map((interaction) => (
    interaction.id === requestId ? { ...interaction, ...patch, status } : interaction
  ));
}

export async function respondToInteraction({ requestId, action, payload = {}, content = null }) {
  if (!state.sessionId || !requestId) {
    return;
  }
  updateInteractionStatus(requestId, "submitting", {
    response: { request_id: requestId, action, payload, content },
  });
  renderChat();
  const response = await fetch(
    `/api/sessions/${state.sessionId}/interactions/${requestId}/response`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, payload, content }),
    },
  );
  if (!response.ok) {
    const error = await response.json();
    updateInteractionStatus(requestId, "pending", { response: null });
    renderChat();
    window.showErrorPopup(error.detail || "Unable to resolve the interaction.");
  }
}

export async function loadHistoryForStep({ stepId = null, eventSequence = null, label = null } = {}) {
  if (!state.sessionId) {
    return;
  }
  const queryParams = new URLSearchParams();
  if (stepId) {
    queryParams.set("step_id", stepId);
  }
  if (eventSequence) {
    queryParams.set("event_sequence", String(eventSequence));
  }
  const query = queryParams.size ? `?${queryParams.toString()}` : "";
  const response = await fetch(`/api/sessions/${state.sessionId}/history${query}`);
  if (!response.ok) {
    return;
  }
  const history = await response.json();
  state.rawChatMessages = history.messages || [];
  state.rawChatFilterSequence = stepId;
  state.rawChatFilterLabel = label;
  renderRawChat();
}

function pushOptimisticUserMessage(message) {
  state.chatMessages.push({
    id: `optimistic-${Date.now()}`,
    role: "user",
    kind: "user",
    content: message,
    message_type: "OptimisticUserMessage",
    optimistic: true,
  });
  renderChat();
}

function setThinkingActivity(message) {
  state.activityItems = [createActivityItem({ id: "thinking", kind: "system", label: "Model generation", snippet: truncateText(message), status: "running" })];
  updateActivityStatusText("Processing");
  renderActivityFeed();
}

function updateActivitiesFromTrace(event) {
  if (event.event_type === "tool_call") {
    finalizeStreamingAssistantMessage();
    removeActivityItem("thinking");
    upsertActivityItem(createActivityItem({
      id: event.span_id,
      kind: "tool",
      label: `Tool: ${event.tool_name || "tool"}`,
      snippet: truncateText(event.payload?.arguments || event.content || "Esecuzione tool"),
      status: "running",
    }));
    updateActivityStatusText("Tool in esecuzione");
    return;
  }

  if (event.event_type === "tool_result") {
    if (event.payload?.kind === "deep-skill") {
      removeActivityItem(event.span_id);
      return;
    }
    upsertActivityItem(createActivityItem({
      id: event.span_id,
      kind: "tool",
      label: `Tool: ${event.tool_name || "tool"}`,
      snippet: truncateText(event.content || "Tool completato"),
      status: event.payload?.kind === "tool-error" ? "error" : "done",
    }));
    trimFinishedActivities();
    return;
  }

  if (event.event_type === "skill_enter") {
    finalizeStreamingAssistantMessage();
    if (event.parent_span_id) {
      removeActivityItem(event.parent_span_id);
    }
    state.activeSkillSpans.add(event.span_id);
    state.skillDepth = state.activeSkillSpans.size;
    if (state.skillDepth === 1) {
      if (!state.activeSkillContext) {
        state.activeSkillContext = {
          name: event.tool_name || event.current_skill || "skill",
          messages: [],
          streamingContent: null,
          streamingSequence: null
        };
      }
    }
    
    removeActivityItem("thinking");
    upsertActivityItem(createActivityItem({
      id: event.span_id,
      kind: "skill",
      label: `Skill: ${event.tool_name || event.current_skill || "skill"}`,
      snippet: truncateText(event.content || "Apertura skill"),
      status: "running",
    }));
    updateActivityStatusText("Skill in esecuzione");
    return;
  }

  if (event.event_type === "skill_exit") {
    finalizeStreamingAssistantMessage();
    state.activeSkillSpans.delete(event.span_id);
    state.skillDepth = state.activeSkillSpans.size;
    
    upsertActivityItem(createActivityItem({
      id: event.span_id,
      kind: "skill",
      label: `Skill: ${event.tool_name || event.current_skill || "skill"}`,
      snippet: truncateText(event.content || "Skill completata"),
      status: "done",
    }));
    trimFinishedActivities();
    return;
  }

  if (event.event_type === "assistant_response") {
    updateThinkingStatusFromTrace(event);
    if (state.skillDepth > 0 && state.activeSkillContext) {
      if (state.activeSkillContext.streamingSequence && state.activeSkillContext.streamingSequence !== event.sequence) {
        finalizeStreamingAssistantMessage();
      }
      state.activeSkillContext.streamingSequence = event.sequence;
      state.activeSkillContext.streamingContent = event.content;

      if (!hasRunningDetailedActivities()) {
        upsertActivityItem(createActivityItem({
          id: "thinking",
          kind: "system",
          label: "Model generation",
          snippet: "Output incoming",
          status: "running",
        }));
        updateActivityStatusText("Skill generation");
      }
    } else {
      if (state.streamingAssistantSequence && state.streamingAssistantSequence !== event.sequence) {
        finalizeStreamingAssistantMessage();
      }
      state.streamingAssistantSequence = event.sequence;
      state.streamingAssistantContent = event.content;
      
      if (!hasRunningDetailedActivities()) {
        upsertActivityItem(createActivityItem({
          id: "thinking",
          kind: "system",
          label: "Model generation",
          snippet: "Output incoming",
          status: "running",
        }));
        updateActivityStatusText("Response generation");
      }
    }
  }
}

function finalizeStreamingAssistantMessage() {
  if (state.activeSkillContext && state.activeSkillContext.streamingContent) {
    state.activeSkillContext.messages.push({
      role: "assistant",
      content: state.activeSkillContext.streamingContent
    });
    state.activeSkillContext.streamingContent = null;
    state.activeSkillContext.streamingSequence = null;
  } else if (state.streamingAssistantContent) {
    state.chatMessages.push({
      id: `optimistic-assistant-${Date.now()}`,
      role: "assistant",
      content: state.streamingAssistantContent
    });
    state.streamingAssistantContent = null;
    state.streamingAssistantSequence = null;
  }
}

function hasRunningDetailedActivities() {
  return state.activityItems.some((item) => item.status === "running" && item.id !== "thinking");
}

function trimFinishedActivities() {
  const runningItems = state.activityItems.filter((item) => item.status === "running");
  const finishedItems = state.activityItems.filter((item) => item.status !== "running").slice(-3);
  state.activityItems = [...runningItems, ...finishedItems];
}

function upsertActivityItem(item) {
  const index = state.activityItems.findIndex((entry) => entry.id === item.id);
  if (index >= 0) {
    state.activityItems.splice(index, 1, item);
  } else {
    state.activityItems.unshift(item);
  }
}

function removeActivityItem(id) {
  state.activityItems = state.activityItems.filter((item) => item.id !== id);
}

function createActivityItem({ id, kind, label, snippet, status }) {
  const kindLabel = kind === "tool" ? "Tool" : kind === "skill" ? "Skill" : "Stato";
  return { id, kind, label, snippet, status, kindLabel };
}

function updateActivityStatusText(value) {
  elements.activityStatusText.textContent = value;
}

export function toggleCapability(capability) {
  const isSelected = state.selectedCapabilities.has(capability.name);
  if (capability.kind === "hds") {
    toggleHdsCapability(capability, isSelected);
    persistSelectedHds();
    return;
  }

  if (capability.kind === "exit-skill") {
    clearSelectedKind("exit-skill");
    if (!isSelected) {
      state.selectedCapabilities.add(capability.name);
    }
  } else if (isSelected) {
    state.selectedCapabilities.delete(capability.name);
  } else {
    state.selectedCapabilities.add(capability.name);
  }

  const currentHdsName = Array.from(state.selectedCapabilities).find(name => {
    const c = state.bootstrap?.capabilities?.find(cap => cap.name === name);
    return c && c.kind === "hds";
  });
  if (currentHdsName) {
    state.hdsCapabilities[currentHdsName] = Array.from(state.selectedCapabilities);
    persistSelectedHds();
  }
}

export async function selectHds(capability) {
  const currentHdsName = Array.from(state.selectedCapabilities).find(name => {
    const c = state.bootstrap?.capabilities?.find(cap => cap.name === name);
    return c && c.kind === "hds";
  });
  if (currentHdsName) {
    state.hdsCapabilities[currentHdsName] = Array.from(state.selectedCapabilities);
  }

  toggleHdsCapability(capability, false);

  if (state.hdsCapabilities[capability.name]) {
    state.selectedCapabilities = new Set(state.hdsCapabilities[capability.name]);
  }

  persistSelectedHds();
  syncGeneratedHdsPreview();

  if (state.isConnected) {
    if (state.hdsSessions && state.hdsSessions[capability.name]) {
      state.sessionId = state.hdsSessions[capability.name];
      state.pendingSessionConfig = false;
      await refreshSessionState();
      openEventStream();
    } else {
      await initializeSession();
    }
  } else {
    if (state.hdsSessions && state.hdsSessions[capability.name]) {
      state.sessionId = state.hdsSessions[capability.name];
      state.pendingSessionConfig = false;
    } else {
      state.pendingSessionConfig = true;
      state.sessionId = null;
    }
    elements.sessionStatus.textContent = "disconnessa";
  }
}

function toggleHdsCapability(capability, isSelected) {
  if (isSelected) {
    return;
  }

  clearSelectedKind("hds");
  clearSelectedKind("exit-skill");
  clearSelectedKind("tool");
  clearSelectedKind("skill");

  state.selectedCapabilities.add(capability.name);
  if (capability.system_prompt) {
    elements.systemPrompt.value = capability.system_prompt;
  }
  if (capability.exit_skill) {
    state.selectedCapabilities.add(capability.exit_skill);
  }
  for (const toolName of capability.sub_tools || []) {
    state.selectedCapabilities.add(toolName);
  }
  for (const skillName of capability.sub_skills || []) {
    state.selectedCapabilities.add(skillName);
  }
}

function clearSelectedKind(kind) {
  const capabilities = state.bootstrap.capabilities.filter((item) => item.kind === kind);
  for (const capability of capabilities) {
    state.selectedCapabilities.delete(capability.name);
  }
}

function applyInitialHdsSelection() {
  const availableHds = state.bootstrap.capabilities
    .filter((item) => item.kind === "hds")
    .sort(compareHdsByDefaultPreference);

  if (!availableHds.length) {
    persistSelectedHds();
    return;
  }

  const storedHdsName = readStoredState();
  const selectedHds = availableHds.find((item) => item.name === storedHdsName) || availableHds[0];
  state.selectedCapabilities.clear();
  toggleHdsCapability(selectedHds, false);
  
  if (state.hdsCapabilities[selectedHds.name]) {
    state.selectedCapabilities = new Set(state.hdsCapabilities[selectedHds.name]);
  }
  
  syncGeneratedHdsPreview();
  persistSelectedHds();
}

function compareHdsByDefaultPreference(left, right) {
  const leftRank = left.name === PREFERRED_HDS_NAME ? 0 : 1;
  const rightRank = right.name === PREFERRED_HDS_NAME ? 0 : 1;
  if (leftRank !== rightRank) {
    return leftRank - rightRank;
  }
  return left.name.localeCompare(right.name);
}

function readStoredState() {
  try {
    const hds = localStorage.getItem(HDS_STORAGE_KEY);
    const sessions = localStorage.getItem(HDS_SESSIONS_STORAGE_KEY);
    const caps = localStorage.getItem(HDS_CAPABILITIES_STORAGE_KEY);
    if (sessions) state.hdsSessions = JSON.parse(sessions);
    if (caps) state.hdsCapabilities = JSON.parse(caps);
    return hds;
  } catch {
    return null;
  }
}

function persistSelectedHds() {
  const selectedHds = state.bootstrap?.capabilities?.find(
    (item) => item.kind === "hds" && state.selectedCapabilities.has(item.name),
  );

  try {
    if (selectedHds) {
      localStorage.setItem(HDS_STORAGE_KEY, selectedHds.name);
    } else {
      localStorage.removeItem(HDS_STORAGE_KEY);
    }
    localStorage.setItem(HDS_SESSIONS_STORAGE_KEY, JSON.stringify(state.hdsSessions));
    localStorage.setItem(HDS_CAPABILITIES_STORAGE_KEY, JSON.stringify(state.hdsCapabilities));
  } catch {
    // Ignore storage errors in constrained environments.
  }
}

export function disconnectSession() {
  if (state.eventSource) {
    state.eventSource.close();
    state.eventSource = null;
  }

  state.isConnected = false;
  updateConnectionUi();
  elements.sessionStatus.textContent = "disconnessa";
}

export async function connectSession() {
  state.isConnected = true;
  updateConnectionUi();

  if (!state.sessionId || state.pendingSessionConfig) {
    await initializeSession();
    return;
  }

  elements.sessionStatus.textContent = "riconnessione";
  await refreshSessionState();
  openEventStream();
}

function updateConnectionUi() {
  elements.connectionToggleButton.textContent = state.isConnected ? "Disconnetti" : "Connetti";
  elements.connectionToggleButton.setAttribute("aria-label", state.isConnected ? "Disconnetti" : "Connetti");
  elements.connectionToggleButton.setAttribute("title", state.isConnected ? "Disconnetti" : "Connetti");
  elements.chatInput.disabled = !state.isConnected;
  elements.chatSubmitButton.disabled = !state.isConnected;
}

function syncGeneratedHdsPreview() {
  const selectedHds = state.bootstrap?.capabilities?.find(
    (capability) => capability.kind === "hds" && state.selectedCapabilities.has(capability.name),
  );

  if (!selectedHds) {
    state.generatedHds = null;
    renderHdsControls();
    return;
  }

  const selectedTools = state.bootstrap.capabilities
    .filter((capability) => capability.kind === "tool" && state.selectedCapabilities.has(capability.name))
    .map((capability) => capability.name);
  const selectedSkills = state.bootstrap.capabilities
    .filter((capability) => capability.kind === "skill" && state.selectedCapabilities.has(capability.name))
    .map((capability) => capability.name);

  state.generatedHds = {
    name: selectedHds.name,
    path: "",
    system_prompt: elements.systemPrompt.value,
    selected_tools: selectedTools,
    selected_skills: selectedSkills,
    exit_skill: selectedHds.exit_skill,
    source_hds: selectedHds.name,
    generated: false,
  };
  renderHdsControls();
}
