from __future__ import annotations

from os import getenv

import uvicorn

from agent_wiki.frontend.runtime_config import load_environment


def main() -> None:
    """Run the frontend development server using environment-backed settings."""
    load_environment()
    uvicorn.run(
        "agent_wiki.frontend.app:app",
        host=getenv("AGENT_WIKI_FRONTEND_HOST", "127.0.0.1"),
        port=int(getenv("AGENT_WIKI_FRONTEND_PORT", "8000")),
        reload=getenv("AGENT_WIKI_FRONTEND_RELOAD", "0") in {"1", "true", "True"},
    )
