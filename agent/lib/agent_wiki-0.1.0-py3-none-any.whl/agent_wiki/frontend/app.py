from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, AsyncIterator

from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from agent_wiki.frontend.runtime_config import (
    DEFAULT_SYSTEM_PROMPT,
    load_runtime_settings,
)

from .session import FrontendSessionStore


STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(title="Agent Wiki Frontend")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

session_store: FrontendSessionStore | None = None


def get_session_store() -> FrontendSessionStore:
    """Return the process session store, creating it only when the app is used."""
    global session_store
    if session_store is None:
        session_store = FrontendSessionStore()
    return session_store


class SessionCreateRequest(BaseModel):
    system_prompt: str = Field(default=DEFAULT_SYSTEM_PROMPT)
    selected_capabilities: list[str] = Field(default_factory=list)


class MessageCreateRequest(BaseModel):
    message: str = Field(min_length=1)


class ThinkingToggleRequest(BaseModel):
    thinking_enabled: bool


class InteractionResponseRequest(BaseModel):
    """Validate one response to a generic backend interaction request."""

    action: str = Field(min_length=1)
    payload: dict[str, Any] = Field(default_factory=dict)
    content: str | None = None


@app.get("/")
def read_index() -> FileResponse:
    return FileResponse(STATIC_DIR / "html" / "index.html")


@app.get("/api/bootstrap")
def read_bootstrap() -> JSONResponse:
    """Return frontend bootstrap settings and the visible capability catalog."""
    runtime_settings = load_runtime_settings()
    store = get_session_store()
    return JSONResponse(
        {
            "default_system_prompt": runtime_settings.system_prompt
            or DEFAULT_SYSTEM_PROMPT,
            "backend": runtime_settings.backend,
            "model": runtime_settings.model,
            "capabilities": [
                descriptor.to_dict() for descriptor in store.capability_catalog
            ],
        }
    )


@app.post("/api/sessions")
def create_session(payload: SessionCreateRequest) -> JSONResponse:
    """Create one persistent frontend session."""
    session = get_session_store().create_session(
        system_prompt=payload.system_prompt,
        selected_capabilities=payload.selected_capabilities,
    )
    return JSONResponse(session.snapshot_state(), status_code=201)


@app.get("/api/sessions/{session_id}")
def read_session(session_id: str) -> JSONResponse:
    """Return the current state for one frontend session."""
    session = get_session_store().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return JSONResponse(session.snapshot_state())


@app.get("/api/sessions/{session_id}/history")
def read_session_history(
    session_id: str,
    step_id: str | None = Query(default=None),
    event_sequence: int | None = Query(default=None, ge=1),
) -> JSONResponse:
    """Return a backend-owned history projection for the root or one step."""
    session = get_session_store().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    try:
        return JSONResponse(
            session.history_view(
                step_id=step_id,
                event_sequence=event_sequence,
            )
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get("/api/sessions/{session_id}/event-log")
def read_session_events(
    session_id: str,
    after_id: int = Query(default=0, ge=0),
) -> JSONResponse:
    """Return replayable transport events after one event id."""
    session = get_session_store().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    batch = session.events_after(after_id)
    return JSONResponse(
        {
            "events": [event.to_dict() for event in batch.events],
            "resync_required": batch.resync_required,
            "latest_event_id": batch.latest_event_id,
        }
    )


@app.post("/api/sessions/{session_id}/messages")
def create_message(session_id: str, payload: MessageCreateRequest) -> JSONResponse:
    """Start one asynchronous model turn for a frontend session."""
    session = get_session_store().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    try:
        session.start_turn(user_message=payload.message)
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    return JSONResponse({"accepted": True}, status_code=202)


@app.post("/api/sessions/{session_id}/stop")
def stop_session_turn(session_id: str) -> JSONResponse:
    """Request cooperative cancellation of the active session turn."""
    session = get_session_store().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if not session.request_stop():
        raise HTTPException(status_code=409, detail="No turn is currently running.")
    return JSONResponse({"accepted": True, "status": "stopping"}, status_code=202)


@app.patch("/api/sessions/{session_id}/thinking")
def toggle_session_thinking(session_id: str, payload: ThinkingToggleRequest) -> JSONResponse:
    """Toggle the thinking behavior for the session client."""
    session = get_session_store().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    session.set_thinking(payload.thinking_enabled)
    return JSONResponse({"accepted": True, "thinking_enabled": payload.thinking_enabled})


@app.post("/api/sessions/{session_id}/interactions/{request_id}/response")
def respond_to_session_interaction(
    session_id: str,
    request_id: str,
    payload: InteractionResponseRequest,
) -> JSONResponse:
    """Resolve one pending generic interaction for a frontend session."""
    session = get_session_store().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    try:
        session.respond_to_interaction(
            request_id=request_id,
            action=payload.action,
            payload=payload.payload,
            content=payload.content,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return JSONResponse({"accepted": True, "request_id": request_id})


@app.get("/api/sessions/{session_id}/events")
async def stream_session_events(
    session_id: str,
    last_event_id: str | None = Header(default=None, alias="Last-Event-ID"),
    after_id: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    """Stream runtime events for one frontend session."""
    session = get_session_store().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    async def event_generator() -> AsyncIterator[str]:
        cursor = _parse_event_id(
            last_event_id
            if last_event_id is not None
            else (str(after_id) if after_id is not None else None)
        )
        while True:
            batch = await asyncio.to_thread(
                session.wait_for_events,
                event_id=cursor,
                timeout=15.0,
            )
            if batch.resync_required:
                cursor = batch.latest_event_id
                payload = {
                    "id": cursor,
                    "version": 1,
                    "session_id": session_id,
                    "turn_id": None,
                    "type": "session.resync_required",
                    "data": {"latest_event_id": cursor},
                }
                yield f"id: {cursor}\n"
                yield "event: agent_event\n"
                yield f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
                continue
            if not batch.events:
                yield ": keep-alive\n\n"
                continue

            for event in batch.events:
                cursor = event.id
                yield f"id: {event.id}\n"
                yield "event: agent_event\n"
                yield f"data: {json.dumps(event.to_dict(), ensure_ascii=False)}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


def _parse_event_id(value: str | None) -> int:
    """Parse an SSE event id, falling back to the beginning of the stream."""
    if value is None:
        return 0
    try:
        return max(0, int(value))
    except ValueError:
        return 0
