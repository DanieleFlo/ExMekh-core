from __future__ import annotations

import dataclasses
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping
from uuid import uuid4

from agent_wiki.backend.core.capabilities.capability_roots import (
    resolve_capability_roots,
)
from agent_wiki.backend.core.agent.deep_agent import DeepAgent
from agent_wiki.backend.core.agent.loop_detection import DefaultLoopDetector
from agent_wiki.backend.core.capabilities.deep_skill import DeepSkill
from agent_wiki.backend.core.capabilities.exit_skill import ExitSkill
from agent_wiki.backend.core.config.hds_config import (
    GraphConfig,
    GraphNodeConfig,
)
from agent_wiki.backend.core.capabilities.hierarchical_deep_skill import (
    HierarchicalDeepSkill,
)
from agent_wiki.backend.core.capabilities.tool import Tool
from agent_wiki.backend.core.runtime_session import (
    AgentRuntimeSession,
    EventBatch,
)
from agent_wiki.frontend.runtime_config import (
    build_client,
    diagnostic_runtime_overrides,
    load_runtime_settings,
)
from agent_wiki.configs.settings import SystemConfig
from agent_wiki.backend.interface.config import SystemConfigInterface
from agent_wiki.configs.runtime import RuntimePackageConfig
from agent_wiki.wiki.config import (
    AGENT_WIKI_HDS_NAME,
    WikiGraphNodeConfig,
)


BOOTSTRAP_HDS_NAME = "bootstrap-wiki"
STRUCTURAL_NON_REUSABLE_TOOL_NAMES = (
    "model-awareness",
    "list-tool-outputs",
    "read-tool-output",
)
PREFERRED_EXIT_SKILL_NAME = "exit-with-info"
PREFERRED_HDS_NAME = BOOTSTRAP_HDS_NAME
DEFAULT_WORKROOT = Path(__file__).resolve().parents[3]
DEFAULT_NATIVE_HDS_NAME = "default-root"
FRONTEND_STRUCTURAL_TOOL_NAMES = STRUCTURAL_NON_REUSABLE_TOOL_NAMES
FRONTEND_STRUCTURAL_SKILL_NAMES: tuple[str, ...] = ()


@dataclass(slots=True)
class CapabilityDescriptor:
    name: str
    kind: str
    description: str
    exit_skill: str | None = None
    sub_tools: list[str] = field(default_factory=list)
    sub_skills: list[str] = field(default_factory=list)
    system_prompt: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind,
            "description": self.description,
            "exit_skill": self.exit_skill,
            "sub_tools": list(self.sub_tools),
            "sub_skills": list(self.sub_skills),
            "system_prompt": self.system_prompt,
        }


@dataclass(slots=True)
class GeneratedHDS:
    name: str
    path: Path
    system_prompt: str
    selected_tools: list[str]
    selected_skills: list[str]
    exit_skill: str
    source_hds: str | None = None
    generated: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "path": str(self.path),
            "system_prompt": self.system_prompt,
            "selected_tools": list(self.selected_tools),
            "selected_skills": list(self.selected_skills),
            "exit_skill": self.exit_skill,
            "source_hds": self.source_hds,
            "generated": self.generated,
        }


def load_capability_catalog(
    *,
    system_config: SystemConfigInterface | None = None,
    workroot: Path | None = None,
) -> list[CapabilityDescriptor]:
    """Load the frontend-visible capability catalog."""
    config = _frontend_catalog_config(system_config or SystemConfig.load_default())

    capability_roots = resolve_capability_roots(config=config, workroot=workroot)

    tools = Tool.load_tools(paths=capability_roots.tool_roots)
    exit_skills = ExitSkill.load_exit_skills(
        paths=capability_roots.exit_skill_roots,
        prompt_file=config.capabilities.deep_skill.prompt_file,
    )
    skills = DeepSkill.load_deep_skills(
        config=config, capability_roots=capability_roots
    )
    hds_root = capability_roots.primary_hds_root
    _ensure_default_native_hds(
        config=config, hds_root=hds_root, exit_skills=exit_skills
    )
    hds_names: set[str] = set()
    for root in capability_roots.hds_roots:
        if not root.exists() or not root.is_dir():
            continue
        for child in root.iterdir():
            if child.is_dir() and not child.name.startswith("frontend-session-"):
                hds_names.add(child.name)

    catalog: list[CapabilityDescriptor] = []
    for tool in tools:
        catalog.append(
            CapabilityDescriptor(
                name=tool.name,
                kind="tool",
                description=tool.description,
            )
        )

    for exit_skill in exit_skills:
        catalog.append(
            CapabilityDescriptor(
                name=exit_skill.name,
                kind="exit-skill",
                description=exit_skill.description,
            )
        )
        catalog.append(
            CapabilityDescriptor(
                name=exit_skill.get_exit_tool_name(),
                kind="exit-tool",
                description=exit_skill.tool.description,
                exit_skill=exit_skill.name,
            )
        )

    for skill in skills:
        catalog.append(
            CapabilityDescriptor(
                name=skill.name,
                kind="skill",
                description=skill.description,
                exit_skill=skill.exit_skill.name if skill.exit_skill else None,
                sub_tools=[tool.name for tool in skill.sub_tools],
                sub_skills=[sub_skill.name for sub_skill in (skill.sub_skills or [])],
            )
        )

    for hds_name in sorted(hds_names):
        hds = HierarchicalDeepSkill.load_hierarchical_deep_skill(
            name=hds_name,
            config=config,
            capability_roots=capability_roots,
        )
        catalog.append(
            CapabilityDescriptor(
                name=hds.name,
                kind="hds",
                description=hds.description,
                exit_skill=hds.exit_skill.name if hds.exit_skill else None,
                sub_tools=[tool.name for tool in hds.sub_tools],
                sub_skills=[sub_skill.name for sub_skill in (hds.sub_skills or [])],
                system_prompt=hds.system_prompt,
            )
        )

    return sorted(catalog, key=_capability_catalog_sort_key)


def _capability_catalog_sort_key(item: CapabilityDescriptor) -> tuple[str, int, str]:
    """Sort capabilities while keeping the preferred frontend HDS first."""
    preferred_rank = 0 if item.kind == "hds" and item.name == PREFERRED_HDS_NAME else 1
    return (item.kind, preferred_rank, item.name)


class FrontendSession:
    """Adapt one backend runtime session to frontend configuration and transport."""

    def __init__(
        self,
        *,
        session_id: str,
        system_prompt: str,
        selected_capabilities: list[str],
        capability_catalog: list[CapabilityDescriptor],
        system_config: SystemConfigInterface | None = None,
        workroot: Path | None = None,
    ) -> None:
        self.session_id = session_id
        self.system_prompt = system_prompt
        self.selected_capabilities = list(selected_capabilities)
        self.capability_catalog = capability_catalog
        self.capability_map = {
            descriptor.name: descriptor for descriptor in capability_catalog
        }
        self.system_config = system_config or SystemConfig.load_default()
        self.workroot = (workroot or DEFAULT_WORKROOT).resolve()
        self._turn_lock = threading.Lock()
        self._turn_thread: threading.Thread | None = None

        settings = load_runtime_settings()
        self.generated_hds = self._write_generated_hds(system_prompt=system_prompt)
        self.node_config = self._build_node_config()
        self.node_config.main.loop_detector = DefaultLoopDetector()
        client = build_client(settings=settings)
        self.node_config.main.client = client
        diagnostic_overrides = diagnostic_runtime_overrides(settings=settings)
        if diagnostic_overrides is not None:
            self.node_config.main.runtime = diagnostic_overrides
        self.node_config.main.workroot_base = self.workroot
        if self.node_config.main.workroot is None:
            self.node_config.main.workroot = self.workroot
        elif not Path(self.node_config.main.workroot).expanduser().is_absolute():
            (self.workroot / Path(self.node_config.main.workroot)).mkdir(
                parents=True,
                exist_ok=True,
            )
        self.agent = DeepAgent(
            node_config=self.node_config,
        )
        self.runtime = AgentRuntimeSession(
            session_id=self.session_id,
            agent=self.agent,
        )
        self.runtime.publish_session_event(
            event_type="session.initialized",
            data={
                "session_id": self.session_id,
                "system_prompt": self.system_prompt,
                "selected_capabilities": list(self.selected_capabilities),
                "available_capabilities": [
                    descriptor.to_dict() for descriptor in self.capability_catalog
                ],
                "generated_hds": self.generated_hds.to_dict(),
                "root_capabilities": self._root_capabilities_snapshot(),
            },
            turn_id=None,
        )

    @property
    def busy(self) -> bool:
        """Return whether the backend runtime is executing a turn."""
        return self.runtime.busy

    @property
    def trace_events(self) -> list[dict[str, Any]]:
        """Return the retained runtime trace projection."""
        return self.runtime.snapshot()["trace_events"]

    @property
    def chat_messages(self) -> list[dict[str, Any]]:
        """Return the user-facing chat projection from backend memory."""
        return self.runtime.snapshot()["chat_messages"]

    @property
    def raw_chat_messages(self) -> list[dict[str, Any]]:
        """Return the raw root history projection from backend memory."""
        return self.runtime.history_view()["messages"]

    def set_thinking(self, enabled: bool) -> None:
        """Toggle the thinking behavior on the backend client for this session."""
        if not hasattr(self, "agent") or self.agent is None:
            return

        config = getattr(self.agent, "_config", None)
        if config is None or getattr(config, "runtime", None) is None:
            return

        current_model = config.runtime.model
        if getattr(current_model, "thinking", None) == enabled:
            return

        new_model = dataclasses.replace(current_model, thinking=enabled)
        new_runtime = dataclasses.replace(config.runtime, model=new_model)
        self.agent._config = dataclasses.replace(config, runtime=new_runtime)

    def snapshot_state(self) -> dict[str, Any]:
        """Return frontend metadata plus backend-owned runtime projections."""
        snapshot = self.runtime.snapshot()
        return {
            **snapshot,
            "system_prompt": self.system_prompt,
            "selected_capabilities": list(self.selected_capabilities),
            "available_capabilities": [
                descriptor.to_dict() for descriptor in self.capability_catalog
            ],
            "root_capabilities": self._root_capabilities_snapshot(),
            "generated_hds": self.generated_hds.to_dict(),
        }

    def wait_for_events(self, *, event_id: int, timeout: float) -> EventBatch:
        """Wait for backend transport events newer than one event id."""
        return self.runtime.wait_for_events(event_id=event_id, timeout=timeout)

    def events_after(self, event_id: int) -> EventBatch:
        """Return retained backend events newer than one event id."""
        return self.runtime.events_after(event_id)

    def history_view(
        self,
        *,
        step_id: str | None = None,
        event_sequence: int | None = None,
    ) -> dict[str, Any]:
        """Return a backend-derived raw history projection."""
        return self.runtime.history_view(
            step_id=step_id,
            event_sequence=event_sequence,
        )

    def start_turn(self, *, user_message: str) -> None:
        """Start one background turn without owning conversation memory."""
        with self._turn_lock:
            if self.busy or (
                self._turn_thread is not None and self._turn_thread.is_alive()
            ):
                raise RuntimeError("A turn is already running for this session.")
            self._turn_thread = threading.Thread(
                target=self._run_turn,
                kwargs={"user_message": user_message},
                daemon=True,
            )
            self._turn_thread.start()

    def request_stop(self) -> bool:
        """Request cooperative cancellation of the active backend turn."""
        return self.runtime.request_stop()

    def respond_to_interaction(
        self,
        *,
        request_id: str,
        action: str,
        payload: Mapping[str, Any] | None = None,
        content: str | None = None,
    ) -> None:
        """Forward one generic frontend interaction response to the runtime."""
        self.runtime.respond_to_interaction(
            request_id=request_id,
            action=action,
            payload=payload,
            content=content,
        )

    def _run_turn(self, *, user_message: str) -> None:
        """Run one backend turn and leave failure reporting to runtime events."""
        try:
            self.runtime.run_turn(user_message)
        except Exception:
            return

    def _root_capabilities_snapshot(self) -> dict[str, Any] | None:
        root_hds = self.agent.hds_config.get_main_hds()
        if root_hds.exit_skill is None:
            return None

        root_capabilities = self.agent._hds_capabilities(
            hds=root_hds,
            node_path=self.agent.hds_config.get_main_node()._path,
        )
        return root_capabilities.snapshot(current_skill=None).to_dict()

    def _build_node_config(self) -> GraphConfig:
        """Build the internal frontend HDS node structure for the selected root."""
        return _node_config_for_selected_hds(
            self.generated_hds.name,
            system_config=self.system_config,
        )

    def _write_generated_hds(self, *, system_prompt: str) -> GeneratedHDS:
        config = self.system_config.config

        capability_roots = resolve_capability_roots(
            config=config,
            workroot=self.workroot,
        )
        exit_skills = ExitSkill.load_exit_skills(
            paths=capability_roots.exit_skill_roots,
            prompt_file=config.capabilities.deep_skill.prompt_file,
        )
        if not exit_skills:
            raise ValueError(
                "At least one exit skill is required to generate the frontend HDS."
            )

        exit_skill_name = next(
            (
                exit_skill.name
                for exit_skill in exit_skills
                if exit_skill.name == PREFERRED_EXIT_SKILL_NAME
            ),
            exit_skills[0].name,
        )

        selected_descriptors = [
            self.capability_map[name]
            for name in self.selected_capabilities
            if name in self.capability_map
        ]
        selected_hds = next(
            (
                descriptor
                for descriptor in reversed(selected_descriptors)
                if descriptor.kind == "hds"
            ),
            None,
        )
        selected_exit_skill = next(
            (
                descriptor
                for descriptor in reversed(selected_descriptors)
                if descriptor.kind == "exit-skill"
            ),
            None,
        )
        selected_tools = [
            descriptor.name
            for descriptor in selected_descriptors
            if descriptor.kind == "tool"
        ]
        selected_skills = [
            descriptor.name
            for descriptor in selected_descriptors
            if descriptor.kind == "skill"
        ]

        if selected_hds is not None:
            selected_tools = _merge_names(selected_hds.sub_tools, selected_tools)
            selected_skills = _merge_names(selected_hds.sub_skills, selected_skills)
            if selected_hds.exit_skill:
                exit_skill_name = selected_hds.exit_skill

        selected_tools = _merge_structural_frontend_tools(selected_tools)
        selected_skills = _merge_structural_frontend_skills(selected_skills)

        if selected_exit_skill is not None:
            exit_skill_name = selected_exit_skill.name

        if selected_hds is not None and self._can_reuse_selected_hds(
            selected_hds=selected_hds,
            system_prompt=system_prompt,
            selected_tools=selected_tools,
            selected_skills=selected_skills,
            exit_skill_name=exit_skill_name,
        ):
            hds_path = _find_hds_path(
                hds_roots=capability_roots.hds_roots,
                name=selected_hds.name,
            )
            return GeneratedHDS(
                name=selected_hds.name,
                path=hds_path,
                system_prompt=system_prompt,
                selected_tools=list(selected_hds.sub_tools),
                selected_skills=list(selected_hds.sub_skills),
                exit_skill=selected_hds.exit_skill or exit_skill_name,
                source_hds=selected_hds.name,
                generated=False,
            )

        hds_name = f"frontend-session-{self.session_id}"
        hds_root = capability_roots.primary_hds_root
        hds_path = hds_root / hds_name
        hds_path.mkdir(parents=True, exist_ok=True)

        lines = [
            "---",
            f"description: Frontend-generated root HDS for session {self.session_id}",
            f"exit-skill: {exit_skill_name}",
        ]
        if selected_tools:
            lines.append("sub-tools:")
            lines.extend(f"  - {tool_name}" for tool_name in selected_tools)
        if selected_skills:
            lines.append("sub-skills:")
            lines.extend(f"  - {skill_name}" for skill_name in selected_skills)
        lines.extend(["---", system_prompt.strip()])

        (hds_path / config.capabilities.deep_skill.prompt_file).write_text(
            "\n".join(lines).strip() + "\n",
            encoding="utf-8",
        )

        return GeneratedHDS(
            name=hds_name,
            path=hds_path,
            system_prompt=system_prompt,
            selected_tools=selected_tools,
            selected_skills=selected_skills,
            exit_skill=exit_skill_name,
            source_hds=selected_hds.name if selected_hds is not None else None,
        )

    @staticmethod
    def _can_reuse_selected_hds(
        *,
        selected_hds: CapabilityDescriptor,
        system_prompt: str,
        selected_tools: list[str],
        selected_skills: list[str],
        exit_skill_name: str,
    ) -> bool:
        return (
            system_prompt.strip() == (selected_hds.system_prompt or "").strip()
            and selected_tools
            == _merge_structural_frontend_tools(list(selected_hds.sub_tools))
            and selected_skills
            == _merge_structural_frontend_skills(list(selected_hds.sub_skills))
            and exit_skill_name == selected_hds.exit_skill
        )


class FrontendSessionStore:
    def __init__(
        self,
        *,
        system_config: SystemConfigInterface | None = None,
        workroot: Path | None = None,
    ) -> None:
        self._sessions: dict[str, FrontendSession] = {}
        self._lock = threading.Lock()
        self._system_config = system_config or SystemConfig.load_default()
        self._workroot = (workroot or DEFAULT_WORKROOT).resolve()
        self._capability_catalog = load_capability_catalog(
            system_config=self._system_config,
            workroot=self._workroot,
        )

    @property
    def capability_catalog(self) -> list[CapabilityDescriptor]:
        return self._capability_catalog

    def create_session(
        self, *, system_prompt: str, selected_capabilities: list[str]
    ) -> FrontendSession:
        session = FrontendSession(
            session_id=str(uuid4()),
            system_prompt=system_prompt,
            selected_capabilities=selected_capabilities,
            capability_catalog=self._capability_catalog,
            system_config=self._system_config,
            workroot=self._workroot,
        )
        with self._lock:
            self._sessions[session.session_id] = session
        return session

    def get_session(self, session_id: str) -> FrontendSession | None:
        with self._lock:
            return self._sessions.get(session_id)


def _merge_names(*groups: list[str]) -> list[str]:
    """Merge ordered capability names while preserving the first occurrence."""
    merged: list[str] = []
    seen: set[str] = set()
    for group in groups:
        for item in group:
            if item in seen:
                continue
            seen.add(item)
            merged.append(item)
    return merged


def _merge_structural_frontend_tools(selected_tools: list[str]) -> list[str]:
    """Keep structural frontend tools available in generated root HDS files."""
    return _merge_names(list(FRONTEND_STRUCTURAL_TOOL_NAMES), selected_tools)


def _merge_structural_frontend_skills(selected_skills: list[str]) -> list[str]:
    """Keep structural frontend skills available in generated root HDS files."""
    return _merge_names(list(FRONTEND_STRUCTURAL_SKILL_NAMES), selected_skills)


def _node_config_for_selected_hds(
    hds_name: str, *, system_config: SystemConfigInterface
) -> GraphConfig:
    """Build the internal node structure associated with a selected HDS."""
    if hds_name == BOOTSTRAP_HDS_NAME:
        return GraphConfig(
            system_config=system_config,
            main=GraphNodeConfig(
                name=BOOTSTRAP_HDS_NAME,
                excluded_tool_names=list(STRUCTURAL_NON_REUSABLE_TOOL_NAMES),
                children=[WikiGraphNodeConfig()],
            ),
        )
    if hds_name == AGENT_WIKI_HDS_NAME:
        return GraphConfig(
            system_config=system_config,
            main=WikiGraphNodeConfig(),
        )
    return GraphConfig.single(hds_name, system_config=system_config)


def _frontend_catalog_config(
    system_config: SystemConfigInterface,
) -> RuntimePackageConfig:
    """Return catalog config that explicitly includes bundled AgentWiki capabilities."""
    capabilities = system_config.config.capabilities
    if capabilities is None:
        raise ValueError("Frontend catalog requires capability layout settings.")
    wiki_root = Path(__file__).resolve().parents[1] / "wiki" / "capabilities"
    return system_config.config.with_capabilities(
        capabilities.with_builtin_root(wiki_root)
    )


def _find_hds_path(*, hds_roots: tuple[Path, ...], name: str) -> Path:
    """Return the first matching hierarchical deep-skill path from resolved roots."""
    for root in hds_roots:
        candidate = root / name
        if candidate.exists() and candidate.is_dir():
            return candidate
    return hds_roots[0] / name


def _ensure_default_native_hds(
    *, config: Any, hds_root: Path, exit_skills: list[ExitSkill]
) -> None:
    """Create the frontend fallback root HDS when no native HDS exists."""
    hds_root.mkdir(parents=True, exist_ok=True)
    native_hds = [
        child
        for child in hds_root.iterdir()
        if child.is_dir() and not child.name.startswith("frontend-session-")
    ]
    if native_hds:
        return

    if not exit_skills:
        raise ValueError(
            "At least one exit skill is required to create the default native HDS."
        )

    default_exit_skill = next(
        (
            exit_skill.name
            for exit_skill in exit_skills
            if exit_skill.name == PREFERRED_EXIT_SKILL_NAME
        ),
        exit_skills[0].name,
    )
    default_hds_path = hds_root / DEFAULT_NATIVE_HDS_NAME
    default_hds_path.mkdir(parents=True, exist_ok=True)
    prompt_path = default_hds_path / config.capabilities.deep_skill.prompt_file
    if prompt_path.exists():
        return

    runtime_settings = load_runtime_settings()
    prompt_path.write_text(
        "\n".join(
            [
                "---",
                "description: Default root HDS generated automatically for the frontend.",
                f"exit-skill: {default_exit_skill}",
                "---",
                runtime_settings.system_prompt.strip(),
                "",
            ]
        ),
        encoding="utf-8",
    )
